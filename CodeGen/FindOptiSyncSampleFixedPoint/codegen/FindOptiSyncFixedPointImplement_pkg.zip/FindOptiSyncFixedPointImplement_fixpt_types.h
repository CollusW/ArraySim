/*
 * File: FindOptiSyncFixedPointImplement_fixpt_types.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 25-Jan-2018 22:12:35
 */

#ifndef FINDOPTISYNCFIXEDPOINTIMPLEMENT_FIXPT_TYPES_H
#define FINDOPTISYNCFIXEDPOINTIMPLEMENT_FIXPT_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for FindOptiSyncFixedPointImplement_fixpt_types.h
 *
 * [EOF]
 */
