/*
 * File: FindOptiSyncFixedPointImplement_fixpt.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 25-Jan-2018 22:12:35
 */

#ifndef FINDOPTISYNCFIXEDPOINTIMPLEMENT_FIXPT_H
#define FINDOPTISYNCFIXEDPOINTIMPLEMENT_FIXPT_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rtwtypes.h"
#include "FindOptiSyncFixedPointImplement_fixpt_types.h"

/* Function Declarations */
extern void FindOptiSyncFixedPointImplement_fixpt(const cint16_T
  rxSigNoise_FindOptiSyncFP[2048], const cint16_T
  pilotSequenceUpSample_FindOptiS[1536], cint16_T pilotSequence_FindOptiSyncFP
  [512], unsigned char *numSyncChannel_FindOptiSyncFP, signed char
  *circShiftSelect_FindOptiSyncFP);
extern void FindOptiSyncFixedPointImplement_fixpt_initialize(void);
extern void FindOptiSyncFixedPointImplement_fixpt_terminate(void);

#endif

/*
 * File trailer for FindOptiSyncFixedPointImplement_fixpt.h
 *
 * [EOF]
 */
