/*
 * File: FindOptiSyncFixedPointImplement_fixpt.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 25-Jan-2018 22:12:35
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "FindOptiSyncFixedPointImplement_fixpt.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Type Definitions */
#ifndef typedef_int128m_T_FindOptiSyncFP
#define typedef_int128m_T_FindOptiSyncFP

typedef struct {
  unsigned long long chunks_FindOptiSyncFP[2];
} int128m_T_FindOptiSyncFP;

#endif                                 /*typedef_int128m_T_FindOptiSyncFP*/

#ifndef typedef_rtBoundsCheckInfo_FindOptiSyncF
#define typedef_rtBoundsCheckInfo_FindOptiSyncF

typedef struct {
  int iFirst_FindOptiSyncFP;
  int iLast_FindOptiSyncFP;
  int lineNo_FindOptiSyncFP;
  int colNo_FindOptiSyncFP;
  const char * aName_FindOptiSyncFP;
  const char * fName_FindOptiSyncFP;
  const char * pName_FindOptiSyncFP;
  int checkKind_FindOptiSyncFP;
} rtBoundsCheckInfo_FindOptiSyncF;

#endif                                 /*typedef_rtBoundsCheckInfo_FindOptiSyncF*/

#ifndef typedef_rtEqualityCheckInfo_FindOptiSyn
#define typedef_rtEqualityCheckInfo_FindOptiSyn

typedef struct {
  int nDims_FindOptiSyncFP;
  int lineNo_FindOptiSyncFP;
  int colNo_FindOptiSyncFP;
  const char * fName_FindOptiSyncFP;
  const char * pName_FindOptiSyncFP;
} rtEqualityCheckInfo_FindOptiSyn;

#endif                                 /*typedef_rtEqualityCheckInfo_FindOptiSyn*/

#ifndef typedef_uint128m_T_FindOptiSyncFP
#define typedef_uint128m_T_FindOptiSyncFP

typedef struct {
  unsigned long long chunks_FindOptiSyncFP[2];
} uint128m_T_FindOptiSyncFP;

#endif                                 /*typedef_uint128m_T_FindOptiSyncFP*/

/* Variable Definitions */
static rtEqualityCheckInfo_FindOptiSyn emlrtECI_FindOptiSyncFP = { -1, 39, 9,
  "FindOptiSyncFixedPointImplement_fixpt",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSampleFixedPoint\\codegen\\FindOptiSyncFixedPointImplement\\fixpt\\FindOpt"
  "iSyncFixedPointImplement_fixpt.m" };

static rtEqualityCheckInfo_FindOptiSyn b_emlrtECI_FindOptiSyncFP = { -1, 41, 9,
  "FindOptiSyncFixedPointImplement_fixpt",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSampleFixedPoint\\codegen\\FindOptiSyncFixedPointImplement\\fixpt\\FindOpt"
  "iSyncFixedPointImplement_fixpt.m" };

static rtBoundsCheckInfo_FindOptiSyncF emlrtBCI_FindOptiSyncFP = { 1, 7, 56, 22,
  "circShiftPattern", "FindOptiSyncFixedPointImplement_fixpt",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSampleFixedPoint\\codegen\\FindOptiSyncFixedPointImplement\\fixpt\\FindOpt"
  "iSyncFixedPointImplement_fixpt.m", 0 };

static rtBoundsCheckInfo_FindOptiSyncF b_emlrtBCI_FindOptiSyncFP = { 1, 7, 50, 5,
  "syncIndexMat", "FindOptiSyncFixedPointImplement_fixpt",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSampleFixedPoint\\codegen\\FindOptiSyncFixedPointImplement\\fixpt\\FindOpt"
  "iSyncFixedPointImplement_fixpt.m", 0 };

static rtBoundsCheckInfo_FindOptiSyncF c_emlrtBCI_FindOptiSyncFP = { 1, 2048, 77,
  17, "", "upsample",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\eml\\upsample.m", 0 };

static rtBoundsCheckInfo_FindOptiSyncF d_emlrtBCI_FindOptiSyncFP = { 1, 6144, 77,
  9, "", "upsample",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\eml\\upsample.m", 0 };

static rtBoundsCheckInfo_FindOptiSyncF e_emlrtBCI_FindOptiSyncFP = { 1, 2048, 77,
  9, "", "upsample",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\eml\\upsample.m", 0 };

static rtBoundsCheckInfo_FindOptiSyncF f_emlrtBCI_FindOptiSyncFP = { 1, 7, 112,
  17, "", "sum",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\fixedpoint\\@embedded\\@fi\\sum.m",
  0 };

static rtBoundsCheckInfo_FindOptiSyncF g_emlrtBCI_FindOptiSyncFP = { 1, 28, 106,
  30, "", "sum",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\fixedpoint\\@embedded\\@fi\\sum.m",
  0 };

static rtBoundsCheckInfo_FindOptiSyncF h_emlrtBCI_FindOptiSyncFP = { 1, 28, 109,
  42, "", "sum",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\fixedpoint\\@embedded\\@fi\\sum.m",
  0 };

/* Function Declarations */
static void MultiWordAdd_FindOptiSyncFP(const unsigned long long
  u1_FindOptiSyncFP[], const unsigned long long u2_FindOptiSyncFP[], unsigned
  long long y_FindOptiSyncFP[], int n_FindOptiSyncFP);
static void MultiWordUnsignedWrap_FindOptiS(const unsigned long long
  u1_FindOptiSyncFP[], int n1_FindOptiSyncFP, unsigned int n2_FindOptiSyncFP,
  unsigned long long y_FindOptiSyncFP[]);
static void abs_FindOptiSyncFP(const cint64_T xfi_FindOptiSyncFP[28], long long
  yreturn_FindOptiSyncFP[28]);
static void b_colontype_FindOptiSyncFP(void);
static void b_max_FindOptiSyncFP(const unsigned short x0_FindOptiSyncFP[7],
  unsigned short *maxval_FindOptiSyncFP, double *indx_FindOptiSyncFP);
static int c_colontype_FindOptiSyncFP(short varargin_1_FindOptiSyncFP);
static int colontype_FindOptiSyncFP(int varargin_1_FindOptiSyncFP);
static void d_colontype_FindOptiSyncFP(void);
static void eml_reinterpretcast_FindOptiSyn(const int128m_T_FindOptiSyncFP
  xfi_FindOptiSyncFP[28], uint128m_T_FindOptiSyncFP yfi_FindOptiSyncFP[28]);
static void max_FindOptiSyncFP(const long long x0_FindOptiSyncFP[28], long long
  maxval_FindOptiSyncFP[4], double indx_FindOptiSyncFP[4]);
static void mtimes_FindOptiSyncFP(const cint16_T a0_FindOptiSyncFP[6144], const
  cint16_T b0_FindOptiSyncFP[10752], cint64_T c_FindOptiSyncFP[28]);
static void rtAddSizeString_FindOptiSyncFP(char * aBuf_FindOptiSyncFP, const int
  aDim_FindOptiSyncFP);
static void rtDynamicBoundsError_FindOptiSy(int aIndexValue_FindOptiSyncFP, int
  aLoBound_FindOptiSyncFP, int aHiBound_FindOptiSyncFP, const
  rtBoundsCheckInfo_FindOptiSyncF *aInfo_FindOptiSyncFP);
static void rtGenSizeString_FindOptiSyncFP(const int aNDims_FindOptiSyncFP,
  const int *aDims_FindOptiSyncFP, char *aBuf_FindOptiSyncFP);
static boolean_T rtIsNullOrEmptyString_FindOptiS(const char
  *aString_FindOptiSyncFP);
static void rtReportErrorLocation_FindOptiS(const char * aFcnName_FindOptiSyncFP,
  const int aLineNo_FindOptiSyncFP);
static void rtSubAssignSizeCheck_FindOptiSy(const int *aDims1_FindOptiSyncFP,
  const int aNDims1_FindOptiSyncFP, const int *aDims2_FindOptiSyncFP, const int
  aNDims2_FindOptiSyncFP, const rtEqualityCheckInfo_FindOptiSyn
  *aInfo_FindOptiSyncFP);
static void sMultiWord2MultiWord_FindOptiSy(const unsigned long long
  u1_FindOptiSyncFP[], int n1_FindOptiSyncFP, unsigned long long
  y_FindOptiSyncFP[], int n_FindOptiSyncFP);
static int sMultiWordCmp_FindOptiSyncFP(const unsigned long long
  u1_FindOptiSyncFP[], const unsigned long long u2_FindOptiSyncFP[], int
  n_FindOptiSyncFP);
static boolean_T sMultiWordLe_FindOptiSyncFP(const unsigned long long
  u1_FindOptiSyncFP[], const unsigned long long u2_FindOptiSyncFP[], int
  n_FindOptiSyncFP);
static void sMultiWordMul_FindOptiSyncFP(const unsigned long long
  u1_FindOptiSyncFP[], int n1_FindOptiSyncFP, const unsigned long long
  u2_FindOptiSyncFP[], int n2_FindOptiSyncFP, unsigned long long
  y_FindOptiSyncFP[], int n_FindOptiSyncFP);
static void sum_FindOptiSyncFP(const unsigned char X_FindOptiSyncFP[28],
  unsigned short Y_FindOptiSyncFP[7]);
static void uMultiWord2MultiWord_FindOptiSy(const unsigned long long
  u1_FindOptiSyncFP[], int n1_FindOptiSyncFP, unsigned long long
  y_FindOptiSyncFP[], int n_FindOptiSyncFP);
static int uMultiWordCmp_FindOptiSyncFP(const unsigned long long
  u1_FindOptiSyncFP[], const unsigned long long u2_FindOptiSyncFP[], int
  n_FindOptiSyncFP);
static boolean_T uMultiWordLe_FindOptiSyncFP(const unsigned long long
  u1_FindOptiSyncFP[], const unsigned long long u2_FindOptiSyncFP[], int
  n_FindOptiSyncFP);
static void upsample_FindOptiSyncFP(const cint16_T x_FindOptiSyncFP[2048],
  cint16_T y_FindOptiSyncFP[6144]);

/* Function Definitions */

/*
 * Arguments    : const unsigned long long u1_FindOptiSyncFP[]
 *                const unsigned long long u2_FindOptiSyncFP[]
 *                unsigned long long y_FindOptiSyncFP[]
 *                int n_FindOptiSyncFP
 * Return Type  : void
 */
static void MultiWordAdd_FindOptiSyncFP(const unsigned long long
  u1_FindOptiSyncFP[], const unsigned long long u2_FindOptiSyncFP[], unsigned
  long long y_FindOptiSyncFP[], int n_FindOptiSyncFP)
{
  int i_FindOptiSyncFP;
  unsigned long long u1i_FindOptiSyncFP;
  unsigned long long yi_FindOptiSyncFP;
  unsigned long long carry_FindOptiSyncFP = 0ULL;
  unsigned long long carry1_FindOptiSyncFP;
  for (i_FindOptiSyncFP = 0; i_FindOptiSyncFP < n_FindOptiSyncFP;
       i_FindOptiSyncFP++) {
    u1i_FindOptiSyncFP = u1_FindOptiSyncFP[i_FindOptiSyncFP];
    yi_FindOptiSyncFP = (u1i_FindOptiSyncFP + u2_FindOptiSyncFP[i_FindOptiSyncFP])
      + carry_FindOptiSyncFP;
    y_FindOptiSyncFP[i_FindOptiSyncFP] = yi_FindOptiSyncFP;
    carry1_FindOptiSyncFP = (unsigned long long)(yi_FindOptiSyncFP <=
      u1i_FindOptiSyncFP);
    u1i_FindOptiSyncFP = (unsigned long long)(yi_FindOptiSyncFP <
      u1i_FindOptiSyncFP);
    if (carry_FindOptiSyncFP != 0ULL) {
      carry_FindOptiSyncFP = carry1_FindOptiSyncFP;
    } else {
      carry_FindOptiSyncFP = u1i_FindOptiSyncFP;
    }
  }
}

/*
 * Arguments    : const unsigned long long u1_FindOptiSyncFP[]
 *                int n1_FindOptiSyncFP
 *                unsigned int n2_FindOptiSyncFP
 *                unsigned long long y_FindOptiSyncFP[]
 * Return Type  : void
 */
static void MultiWordUnsignedWrap_FindOptiS(const unsigned long long
  u1_FindOptiSyncFP[], int n1_FindOptiSyncFP, unsigned int n2_FindOptiSyncFP,
  unsigned long long y_FindOptiSyncFP[])
{
  int n1m1_FindOptiSyncFP;
  int i_FindOptiSyncFP;
  unsigned int ns_FindOptiSyncFP;
  unsigned long long mask_FindOptiSyncFP;
  n1m1_FindOptiSyncFP = n1_FindOptiSyncFP - 1;
  for (i_FindOptiSyncFP = 0; i_FindOptiSyncFP < n1m1_FindOptiSyncFP;
       i_FindOptiSyncFP++) {
    y_FindOptiSyncFP[i_FindOptiSyncFP] = u1_FindOptiSyncFP[i_FindOptiSyncFP];
  }

  ns_FindOptiSyncFP = 64U - n2_FindOptiSyncFP;
  mask_FindOptiSyncFP = (1ULL << ns_FindOptiSyncFP) - 1ULL;
  y_FindOptiSyncFP[n1m1_FindOptiSyncFP] = u1_FindOptiSyncFP[n1m1_FindOptiSyncFP]
    & mask_FindOptiSyncFP;
}

/*
 * Arguments    : const cint64_T xfi_FindOptiSyncFP[28]
 *                long long yreturn_FindOptiSyncFP[28]
 * Return Type  : void
 */
static void abs_FindOptiSyncFP(const cint64_T xfi_FindOptiSyncFP[28], long long
  yreturn_FindOptiSyncFP[28])
{
  int128m_T_FindOptiSyncFP xfi_re_FindOptiSyncFP[28];
  long long xfi_im_FindOptiSyncFP[28];
  int k_FindOptiSyncFP;
  uint128m_T_FindOptiSyncFP rv0_FindOptiSyncFP[28];
  unsigned long long u2_FindOptiSyncFP;
  unsigned long long u3_FindOptiSyncFP;
  uint128m_T_FindOptiSyncFP rv1_FindOptiSyncFP[28];
  uint128m_T_FindOptiSyncFP r0_FindOptiSyncFP;
  uint128m_T_FindOptiSyncFP r1_FindOptiSyncFP;
  uint128m_T_FindOptiSyncFP r2_FindOptiSyncFP;
  uint128m_T_FindOptiSyncFP xfi_abs_sq_FindOptiSyncFP[28];
  static uint128m_T_FindOptiSyncFP r3_FindOptiSyncFP = { { 0ULL, 0ULL } };

  int i_FindOptiSyncFP;
  long long b_yreturn_FindOptiSyncFP;
  long long ytemp_FindOptiSyncFP;
  long long b_ytemp_FindOptiSyncFP;
  int128m_T_FindOptiSyncFP r4_FindOptiSyncFP;
  int128m_T_FindOptiSyncFP r5_FindOptiSyncFP;
  for (k_FindOptiSyncFP = 0; k_FindOptiSyncFP < 28; k_FindOptiSyncFP++) {
    xfi_im_FindOptiSyncFP[k_FindOptiSyncFP] =
      xfi_FindOptiSyncFP[k_FindOptiSyncFP].im;
    u2_FindOptiSyncFP = (unsigned long long)xfi_FindOptiSyncFP[k_FindOptiSyncFP]
      .re;
    u3_FindOptiSyncFP = (unsigned long long)xfi_FindOptiSyncFP[k_FindOptiSyncFP]
      .re;
    sMultiWordMul_FindOptiSyncFP(&u2_FindOptiSyncFP, 1, &u3_FindOptiSyncFP, 1,
      &xfi_re_FindOptiSyncFP[k_FindOptiSyncFP].chunks_FindOptiSyncFP[0U], 2);
  }

  eml_reinterpretcast_FindOptiSyn(xfi_re_FindOptiSyncFP, rv0_FindOptiSyncFP);
  for (k_FindOptiSyncFP = 0; k_FindOptiSyncFP < 28; k_FindOptiSyncFP++) {
    u2_FindOptiSyncFP = (unsigned long long)
      xfi_im_FindOptiSyncFP[k_FindOptiSyncFP];
    u3_FindOptiSyncFP = (unsigned long long)
      xfi_im_FindOptiSyncFP[k_FindOptiSyncFP];
    sMultiWordMul_FindOptiSyncFP(&u2_FindOptiSyncFP, 1, &u3_FindOptiSyncFP, 1,
      &xfi_re_FindOptiSyncFP[k_FindOptiSyncFP].chunks_FindOptiSyncFP[0U], 2);
  }

  eml_reinterpretcast_FindOptiSyn(xfi_re_FindOptiSyncFP, rv1_FindOptiSyncFP);
  for (k_FindOptiSyncFP = 0; k_FindOptiSyncFP < 28; k_FindOptiSyncFP++) {
    MultiWordUnsignedWrap_FindOptiS(&rv0_FindOptiSyncFP[k_FindOptiSyncFP].
      chunks_FindOptiSyncFP[0U], 2, 15U,
      &r0_FindOptiSyncFP.chunks_FindOptiSyncFP[0U]);
    MultiWordUnsignedWrap_FindOptiS(&rv1_FindOptiSyncFP[k_FindOptiSyncFP].
      chunks_FindOptiSyncFP[0U], 2, 15U,
      &r1_FindOptiSyncFP.chunks_FindOptiSyncFP[0U]);
    MultiWordAdd_FindOptiSyncFP(&r0_FindOptiSyncFP.chunks_FindOptiSyncFP[0U],
      &r1_FindOptiSyncFP.chunks_FindOptiSyncFP[0U],
      &r2_FindOptiSyncFP.chunks_FindOptiSyncFP[0U], 2);
    MultiWordUnsignedWrap_FindOptiS(&r2_FindOptiSyncFP.chunks_FindOptiSyncFP[0U],
      2, 15U, &xfi_abs_sq_FindOptiSyncFP[k_FindOptiSyncFP]
      .chunks_FindOptiSyncFP[0U]);
    yreturn_FindOptiSyncFP[k_FindOptiSyncFP] = 0LL;
    r2_FindOptiSyncFP = r3_FindOptiSyncFP;
    if (uMultiWordLe_FindOptiSyncFP(&xfi_abs_sq_FindOptiSyncFP[k_FindOptiSyncFP]
         .chunks_FindOptiSyncFP[0U], &r2_FindOptiSyncFP.chunks_FindOptiSyncFP[0U],
         2)) {
      yreturn_FindOptiSyncFP[k_FindOptiSyncFP] = 0LL;
    } else {
      for (i_FindOptiSyncFP = 54; i_FindOptiSyncFP >= 0; i_FindOptiSyncFP += -1)
      {
        b_yreturn_FindOptiSyncFP = yreturn_FindOptiSyncFP[k_FindOptiSyncFP];
        ytemp_FindOptiSyncFP = 1LL << (unsigned char)i_FindOptiSyncFP;
        if ((ytemp_FindOptiSyncFP & 36028797018963968LL) != 0LL) {
          b_ytemp_FindOptiSyncFP = ytemp_FindOptiSyncFP | -36028797018963968LL;
        } else {
          b_ytemp_FindOptiSyncFP = ytemp_FindOptiSyncFP & 36028797018963967LL;
        }

        ytemp_FindOptiSyncFP = yreturn_FindOptiSyncFP[k_FindOptiSyncFP] |
          b_ytemp_FindOptiSyncFP;
        if ((ytemp_FindOptiSyncFP & 36028797018963968LL) != 0LL) {
          ytemp_FindOptiSyncFP |= -36028797018963968LL;
        } else {
          ytemp_FindOptiSyncFP &= 36028797018963967LL;
        }

        u2_FindOptiSyncFP = (unsigned long long)ytemp_FindOptiSyncFP;
        u3_FindOptiSyncFP = (unsigned long long)ytemp_FindOptiSyncFP;
        sMultiWordMul_FindOptiSyncFP(&u2_FindOptiSyncFP, 1, &u3_FindOptiSyncFP,
          1, &r4_FindOptiSyncFP.chunks_FindOptiSyncFP[0U], 2);
        uMultiWord2MultiWord_FindOptiSy
          (&xfi_abs_sq_FindOptiSyncFP[k_FindOptiSyncFP].chunks_FindOptiSyncFP[0U],
           2, &r5_FindOptiSyncFP.chunks_FindOptiSyncFP[0U], 2);
        if (sMultiWordLe_FindOptiSyncFP
            (&r4_FindOptiSyncFP.chunks_FindOptiSyncFP[0U],
             &r5_FindOptiSyncFP.chunks_FindOptiSyncFP[0U], 2)) {
          b_yreturn_FindOptiSyncFP = ytemp_FindOptiSyncFP;
        }

        yreturn_FindOptiSyncFP[k_FindOptiSyncFP] = b_yreturn_FindOptiSyncFP;
      }
    }
  }
}

/*
 * Arguments    : void
 * Return Type  : void
 */
static void b_colontype_FindOptiSyncFP(void)
{
}

/*
 * Arguments    : const unsigned short x0_FindOptiSyncFP[7]
 *                unsigned short *maxval_FindOptiSyncFP
 *                double *indx_FindOptiSyncFP
 * Return Type  : void
 */
static void b_max_FindOptiSyncFP(const unsigned short x0_FindOptiSyncFP[7],
  unsigned short *maxval_FindOptiSyncFP, double *indx_FindOptiSyncFP)
{
  int itmp_FindOptiSyncFP;
  int ix_FindOptiSyncFP;
  *maxval_FindOptiSyncFP = x0_FindOptiSyncFP[0];
  itmp_FindOptiSyncFP = -1;
  for (ix_FindOptiSyncFP = 0; ix_FindOptiSyncFP < 6; ix_FindOptiSyncFP++) {
    if (x0_FindOptiSyncFP[ix_FindOptiSyncFP + 1] > *maxval_FindOptiSyncFP) {
      *maxval_FindOptiSyncFP = x0_FindOptiSyncFP[ix_FindOptiSyncFP + 1];
      itmp_FindOptiSyncFP = ix_FindOptiSyncFP;
    }
  }

  *indx_FindOptiSyncFP = (double)itmp_FindOptiSyncFP + 2.0;
}

/*
 * Arguments    : short varargin_1_FindOptiSyncFP
 * Return Type  : int
 */
static int c_colontype_FindOptiSyncFP(short varargin_1_FindOptiSyncFP)
{
  int y_FindOptiSyncFP;
  int i18_FindOptiSyncFP;
  i18_FindOptiSyncFP = varargin_1_FindOptiSyncFP;
  if ((i18_FindOptiSyncFP & 65536) != 0) {
    y_FindOptiSyncFP = i18_FindOptiSyncFP | -65536;
  } else {
    y_FindOptiSyncFP = i18_FindOptiSyncFP & 65535;
  }

  return y_FindOptiSyncFP;
}

/*
 * Arguments    : int varargin_1_FindOptiSyncFP
 * Return Type  : int
 */
static int colontype_FindOptiSyncFP(int varargin_1_FindOptiSyncFP)
{
  return varargin_1_FindOptiSyncFP;
}

/*
 * Arguments    : void
 * Return Type  : void
 */
static void d_colontype_FindOptiSyncFP(void)
{
}

/*
 * Arguments    : const int128m_T_FindOptiSyncFP xfi_FindOptiSyncFP[28]
 *                uint128m_T_FindOptiSyncFP yfi_FindOptiSyncFP[28]
 * Return Type  : void
 */
static void eml_reinterpretcast_FindOptiSyn(const int128m_T_FindOptiSyncFP
  xfi_FindOptiSyncFP[28], uint128m_T_FindOptiSyncFP yfi_FindOptiSyncFP[28])
{
  int i27_FindOptiSyncFP;
  int128m_T_FindOptiSyncFP r6_FindOptiSyncFP;
  uint128m_T_FindOptiSyncFP r7_FindOptiSyncFP;
  uint128m_T_FindOptiSyncFP r8_FindOptiSyncFP;
  for (i27_FindOptiSyncFP = 0; i27_FindOptiSyncFP < 28; i27_FindOptiSyncFP++) {
    r6_FindOptiSyncFP = xfi_FindOptiSyncFP[i27_FindOptiSyncFP];
    sMultiWord2MultiWord_FindOptiSy(&r6_FindOptiSyncFP.chunks_FindOptiSyncFP[0U],
      2, &r7_FindOptiSyncFP.chunks_FindOptiSyncFP[0U], 2);
    MultiWordUnsignedWrap_FindOptiS(&r7_FindOptiSyncFP.chunks_FindOptiSyncFP[0U],
      2, 16U, &r8_FindOptiSyncFP.chunks_FindOptiSyncFP[0U]);
    yfi_FindOptiSyncFP[i27_FindOptiSyncFP] = r8_FindOptiSyncFP;
  }
}

/*
 * Arguments    : const long long x0_FindOptiSyncFP[28]
 *                long long maxval_FindOptiSyncFP[4]
 *                double indx_FindOptiSyncFP[4]
 * Return Type  : void
 */
static void max_FindOptiSyncFP(const long long x0_FindOptiSyncFP[28], long long
  maxval_FindOptiSyncFP[4], double indx_FindOptiSyncFP[4])
{
  int iindx_FindOptiSyncFP[4];
  int j_FindOptiSyncFP;
  int i_FindOptiSyncFP;
  long long b_maxval_FindOptiSyncFP;
  for (j_FindOptiSyncFP = 0; j_FindOptiSyncFP < 4; j_FindOptiSyncFP++) {
    maxval_FindOptiSyncFP[j_FindOptiSyncFP] = x0_FindOptiSyncFP[7 *
      j_FindOptiSyncFP];
    iindx_FindOptiSyncFP[j_FindOptiSyncFP] = 1;
    for (i_FindOptiSyncFP = 0; i_FindOptiSyncFP < 6; i_FindOptiSyncFP++) {
      b_maxval_FindOptiSyncFP = maxval_FindOptiSyncFP[j_FindOptiSyncFP];
      if (x0_FindOptiSyncFP[(i_FindOptiSyncFP + 7 * j_FindOptiSyncFP) + 1] >
          maxval_FindOptiSyncFP[j_FindOptiSyncFP]) {
        b_maxval_FindOptiSyncFP = x0_FindOptiSyncFP[(i_FindOptiSyncFP + 7 *
          j_FindOptiSyncFP) + 1];
        iindx_FindOptiSyncFP[j_FindOptiSyncFP] = i_FindOptiSyncFP + 2;
      }

      maxval_FindOptiSyncFP[j_FindOptiSyncFP] = b_maxval_FindOptiSyncFP;
    }

    indx_FindOptiSyncFP[j_FindOptiSyncFP] =
      iindx_FindOptiSyncFP[j_FindOptiSyncFP];
  }
}

/*
 * Arguments    : const cint16_T a0_FindOptiSyncFP[6144]
 *                const cint16_T b0_FindOptiSyncFP[10752]
 *                cint64_T c_FindOptiSyncFP[28]
 * Return Type  : void
 */
static void mtimes_FindOptiSyncFP(const cint16_T a0_FindOptiSyncFP[6144], const
  cint16_T b0_FindOptiSyncFP[10752], cint64_T c_FindOptiSyncFP[28])
{
  int l_FindOptiSyncFP;
  int m_FindOptiSyncFP;
  int k_FindOptiSyncFP;
  short ar_FindOptiSyncFP;
  short ai_FindOptiSyncFP;
  short br_FindOptiSyncFP;
  short bi_FindOptiSyncFP;
  long long i19_FindOptiSyncFP;
  long long i20_FindOptiSyncFP;
  long long i21_FindOptiSyncFP;
  long long i22_FindOptiSyncFP;
  long long i23_FindOptiSyncFP;
  long long i24_FindOptiSyncFP;
  long long i25_FindOptiSyncFP;
  long long i26_FindOptiSyncFP;
  memset(&c_FindOptiSyncFP[0], 0, 28U * sizeof(cint64_T));
  for (l_FindOptiSyncFP = 0; l_FindOptiSyncFP < 4; l_FindOptiSyncFP++) {
    for (m_FindOptiSyncFP = 0; m_FindOptiSyncFP < 7; m_FindOptiSyncFP++) {
      for (k_FindOptiSyncFP = 0; k_FindOptiSyncFP < 1536; k_FindOptiSyncFP++) {
        ar_FindOptiSyncFP = a0_FindOptiSyncFP[l_FindOptiSyncFP +
          (k_FindOptiSyncFP << 2)].re;
        ai_FindOptiSyncFP = a0_FindOptiSyncFP[l_FindOptiSyncFP +
          (k_FindOptiSyncFP << 2)].im;
        br_FindOptiSyncFP = b0_FindOptiSyncFP[k_FindOptiSyncFP + 1536 *
          m_FindOptiSyncFP].re;
        bi_FindOptiSyncFP = b0_FindOptiSyncFP[k_FindOptiSyncFP + 1536 *
          m_FindOptiSyncFP].im;
        i19_FindOptiSyncFP = ar_FindOptiSyncFP * br_FindOptiSyncFP;
        i20_FindOptiSyncFP = ai_FindOptiSyncFP * bi_FindOptiSyncFP;
        if ((i19_FindOptiSyncFP & 4398046511104LL) != 0LL) {
          i21_FindOptiSyncFP = i19_FindOptiSyncFP | -4398046511104LL;
        } else {
          i21_FindOptiSyncFP = i19_FindOptiSyncFP & 4398046511103LL;
        }

        if ((i20_FindOptiSyncFP & 4398046511104LL) != 0LL) {
          i22_FindOptiSyncFP = i20_FindOptiSyncFP | -4398046511104LL;
        } else {
          i22_FindOptiSyncFP = i20_FindOptiSyncFP & 4398046511103LL;
        }

        i19_FindOptiSyncFP = i21_FindOptiSyncFP - i22_FindOptiSyncFP;
        if ((i19_FindOptiSyncFP & 4398046511104LL) != 0LL) {
          i23_FindOptiSyncFP = i19_FindOptiSyncFP | -4398046511104LL;
        } else {
          i23_FindOptiSyncFP = i19_FindOptiSyncFP & 4398046511103LL;
        }

        i19_FindOptiSyncFP = c_FindOptiSyncFP[l_FindOptiSyncFP +
          (m_FindOptiSyncFP << 2)].re + i23_FindOptiSyncFP;
        if (i19_FindOptiSyncFP > 4398046511103LL) {
          i19_FindOptiSyncFP = 4398046511103LL;
        } else {
          if (i19_FindOptiSyncFP < -4398046511104LL) {
            i19_FindOptiSyncFP = -4398046511104LL;
          }
        }

        c_FindOptiSyncFP[l_FindOptiSyncFP + (m_FindOptiSyncFP << 2)].re =
          i19_FindOptiSyncFP;
        i19_FindOptiSyncFP = ar_FindOptiSyncFP * bi_FindOptiSyncFP;
        i20_FindOptiSyncFP = ai_FindOptiSyncFP * br_FindOptiSyncFP;
        if ((i19_FindOptiSyncFP & 4398046511104LL) != 0LL) {
          i24_FindOptiSyncFP = i19_FindOptiSyncFP | -4398046511104LL;
        } else {
          i24_FindOptiSyncFP = i19_FindOptiSyncFP & 4398046511103LL;
        }

        if ((i20_FindOptiSyncFP & 4398046511104LL) != 0LL) {
          i25_FindOptiSyncFP = i20_FindOptiSyncFP | -4398046511104LL;
        } else {
          i25_FindOptiSyncFP = i20_FindOptiSyncFP & 4398046511103LL;
        }

        i19_FindOptiSyncFP = i24_FindOptiSyncFP + i25_FindOptiSyncFP;
        if ((i19_FindOptiSyncFP & 4398046511104LL) != 0LL) {
          i26_FindOptiSyncFP = i19_FindOptiSyncFP | -4398046511104LL;
        } else {
          i26_FindOptiSyncFP = i19_FindOptiSyncFP & 4398046511103LL;
        }

        i19_FindOptiSyncFP = c_FindOptiSyncFP[l_FindOptiSyncFP +
          (m_FindOptiSyncFP << 2)].im + i26_FindOptiSyncFP;
        if (i19_FindOptiSyncFP > 4398046511103LL) {
          i19_FindOptiSyncFP = 4398046511103LL;
        } else {
          if (i19_FindOptiSyncFP < -4398046511104LL) {
            i19_FindOptiSyncFP = -4398046511104LL;
          }
        }

        c_FindOptiSyncFP[l_FindOptiSyncFP + (m_FindOptiSyncFP << 2)].im =
          i19_FindOptiSyncFP;
      }
    }
  }
}

/*
 * Arguments    : char * aBuf_FindOptiSyncFP
 *                const int aDim_FindOptiSyncFP
 * Return Type  : void
 */
static void rtAddSizeString_FindOptiSyncFP(char * aBuf_FindOptiSyncFP, const int
  aDim_FindOptiSyncFP)
{
  char dimStr_FindOptiSyncFP[1024];
  sprintf(dimStr_FindOptiSyncFP, "[%d]", aDim_FindOptiSyncFP);
  if (strlen(aBuf_FindOptiSyncFP) + strlen(dimStr_FindOptiSyncFP) < 1024) {
    strcat(aBuf_FindOptiSyncFP, dimStr_FindOptiSyncFP);
  }
}

/*
 * Arguments    : int aIndexValue_FindOptiSyncFP
 *                int aLoBound_FindOptiSyncFP
 *                int aHiBound_FindOptiSyncFP
 *                const rtBoundsCheckInfo_FindOptiSyncF *aInfo_FindOptiSyncFP
 * Return Type  : void
 */
static void rtDynamicBoundsError_FindOptiSy(int aIndexValue_FindOptiSyncFP, int
  aLoBound_FindOptiSyncFP, int aHiBound_FindOptiSyncFP, const
  rtBoundsCheckInfo_FindOptiSyncF *aInfo_FindOptiSyncFP)
{
  if (aLoBound_FindOptiSyncFP == 0) {
    aIndexValue_FindOptiSyncFP++;
    aLoBound_FindOptiSyncFP = 1;
    aHiBound_FindOptiSyncFP++;
  }

  if (rtIsNullOrEmptyString_FindOptiS(aInfo_FindOptiSyncFP->aName_FindOptiSyncFP))
  {
    fprintf(stderr,
            "Index exceeds array dimensions.  Index value %d exceeds valid range [%d-%d].",
            aIndexValue_FindOptiSyncFP, aLoBound_FindOptiSyncFP,
            aHiBound_FindOptiSyncFP);
    fprintf(stderr, "\n");
  } else {
    fprintf(stderr,
            "Index exceeds array dimensions.  Index value %d exceeds valid range [%d-%d] of array %s.",
            aIndexValue_FindOptiSyncFP, aLoBound_FindOptiSyncFP,
            aHiBound_FindOptiSyncFP, aInfo_FindOptiSyncFP->aName_FindOptiSyncFP);
    fprintf(stderr, "\n");
  }

  if (aInfo_FindOptiSyncFP != NULL) {
    rtReportErrorLocation_FindOptiS(aInfo_FindOptiSyncFP->fName_FindOptiSyncFP,
      aInfo_FindOptiSyncFP->lineNo_FindOptiSyncFP);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const int aNDims_FindOptiSyncFP
 *                const int *aDims_FindOptiSyncFP
 *                char *aBuf_FindOptiSyncFP
 * Return Type  : void
 */
static void rtGenSizeString_FindOptiSyncFP(const int aNDims_FindOptiSyncFP,
  const int *aDims_FindOptiSyncFP, char *aBuf_FindOptiSyncFP)
{
  int i_FindOptiSyncFP;
  aBuf_FindOptiSyncFP[0] = '\x00';
  for (i_FindOptiSyncFP = 0; i_FindOptiSyncFP < aNDims_FindOptiSyncFP;
       i_FindOptiSyncFP++) {
    rtAddSizeString_FindOptiSyncFP(aBuf_FindOptiSyncFP,
      aDims_FindOptiSyncFP[i_FindOptiSyncFP]);
  }
}

/*
 * Arguments    : const char *aString_FindOptiSyncFP
 * Return Type  : boolean_T
 */
static boolean_T rtIsNullOrEmptyString_FindOptiS(const char
  *aString_FindOptiSyncFP)
{
  return (aString_FindOptiSyncFP == NULL) || (*aString_FindOptiSyncFP == '\x00');
}

/*
 * Arguments    : const char * aFcnName_FindOptiSyncFP
 *                const int aLineNo_FindOptiSyncFP
 * Return Type  : void
 */
static void rtReportErrorLocation_FindOptiS(const char * aFcnName_FindOptiSyncFP,
  const int aLineNo_FindOptiSyncFP)
{
  fprintf(stderr, "Error in %s (line %d)", aFcnName_FindOptiSyncFP,
          aLineNo_FindOptiSyncFP);
  fprintf(stderr, "\n");
}

/*
 * Arguments    : const int *aDims1_FindOptiSyncFP
 *                const int aNDims1_FindOptiSyncFP
 *                const int *aDims2_FindOptiSyncFP
 *                const int aNDims2_FindOptiSyncFP
 *                const rtEqualityCheckInfo_FindOptiSyn *aInfo_FindOptiSyncFP
 * Return Type  : void
 */
static void rtSubAssignSizeCheck_FindOptiSy(const int *aDims1_FindOptiSyncFP,
  const int aNDims1_FindOptiSyncFP, const int *aDims2_FindOptiSyncFP, const int
  aNDims2_FindOptiSyncFP, const rtEqualityCheckInfo_FindOptiSyn
  *aInfo_FindOptiSyncFP)
{
  int i_FindOptiSyncFP;
  int j_FindOptiSyncFP;
  char dims1Str_FindOptiSyncFP[1024];
  char dims2Str_FindOptiSyncFP[1024];
  i_FindOptiSyncFP = 0;
  j_FindOptiSyncFP = 0;
  while ((i_FindOptiSyncFP < aNDims1_FindOptiSyncFP) && (j_FindOptiSyncFP <
          aNDims2_FindOptiSyncFP)) {
    while ((i_FindOptiSyncFP < aNDims1_FindOptiSyncFP) &&
           (aDims1_FindOptiSyncFP[i_FindOptiSyncFP] == 1)) {
      i_FindOptiSyncFP++;
    }

    while ((j_FindOptiSyncFP < aNDims2_FindOptiSyncFP) &&
           (aDims2_FindOptiSyncFP[j_FindOptiSyncFP] == 1)) {
      j_FindOptiSyncFP++;
    }

    if (((i_FindOptiSyncFP < aNDims1_FindOptiSyncFP) || (j_FindOptiSyncFP <
          aNDims2_FindOptiSyncFP)) && ((i_FindOptiSyncFP ==
          aNDims1_FindOptiSyncFP) || ((j_FindOptiSyncFP ==
           aNDims2_FindOptiSyncFP) || ((aDims1_FindOptiSyncFP[i_FindOptiSyncFP]
            != -1) && ((aDims2_FindOptiSyncFP[j_FindOptiSyncFP] != -1) &&
                       (aDims1_FindOptiSyncFP[i_FindOptiSyncFP] !=
                        aDims2_FindOptiSyncFP[j_FindOptiSyncFP])))))) {
      rtGenSizeString_FindOptiSyncFP(aNDims1_FindOptiSyncFP,
        aDims1_FindOptiSyncFP, dims1Str_FindOptiSyncFP);
      rtGenSizeString_FindOptiSyncFP(aNDims2_FindOptiSyncFP,
        aDims2_FindOptiSyncFP, dims2Str_FindOptiSyncFP);
      fprintf(stderr, "Subscripted assignment dimension mismatch: %s ~= %s.",
              dims1Str_FindOptiSyncFP, dims2Str_FindOptiSyncFP);
      fprintf(stderr, "\n");
      if (aInfo_FindOptiSyncFP != NULL) {
        rtReportErrorLocation_FindOptiS
          (aInfo_FindOptiSyncFP->fName_FindOptiSyncFP,
           aInfo_FindOptiSyncFP->lineNo_FindOptiSyncFP);
      }

      fflush(stderr);
      abort();
    }

    i_FindOptiSyncFP++;
    j_FindOptiSyncFP++;
  }
}

/*
 * Arguments    : const unsigned long long u1_FindOptiSyncFP[]
 *                int n1_FindOptiSyncFP
 *                unsigned long long y_FindOptiSyncFP[]
 *                int n_FindOptiSyncFP
 * Return Type  : void
 */
static void sMultiWord2MultiWord_FindOptiSy(const unsigned long long
  u1_FindOptiSyncFP[], int n1_FindOptiSyncFP, unsigned long long
  y_FindOptiSyncFP[], int n_FindOptiSyncFP)
{
  int nm_FindOptiSyncFP;
  int i_FindOptiSyncFP;
  unsigned long long u1i_FindOptiSyncFP;
  if (n1_FindOptiSyncFP <= n_FindOptiSyncFP) {
    nm_FindOptiSyncFP = n1_FindOptiSyncFP;
  } else {
    nm_FindOptiSyncFP = n_FindOptiSyncFP;
  }

  for (i_FindOptiSyncFP = 0; i_FindOptiSyncFP < nm_FindOptiSyncFP;
       i_FindOptiSyncFP++) {
    y_FindOptiSyncFP[i_FindOptiSyncFP] = u1_FindOptiSyncFP[i_FindOptiSyncFP];
  }

  if (n_FindOptiSyncFP > n1_FindOptiSyncFP) {
    if ((u1_FindOptiSyncFP[n1_FindOptiSyncFP - 1] & 9223372036854775808ULL) !=
        0ULL) {
      u1i_FindOptiSyncFP = MAX_uint64_T;
    } else {
      u1i_FindOptiSyncFP = 0ULL;
    }

    for (i_FindOptiSyncFP = nm_FindOptiSyncFP; i_FindOptiSyncFP <
         n_FindOptiSyncFP; i_FindOptiSyncFP++) {
      y_FindOptiSyncFP[i_FindOptiSyncFP] = u1i_FindOptiSyncFP;
    }
  }
}

/*
 * Arguments    : const unsigned long long u1_FindOptiSyncFP[]
 *                const unsigned long long u2_FindOptiSyncFP[]
 *                int n_FindOptiSyncFP
 * Return Type  : int
 */
static int sMultiWordCmp_FindOptiSyncFP(const unsigned long long
  u1_FindOptiSyncFP[], const unsigned long long u2_FindOptiSyncFP[], int
  n_FindOptiSyncFP)
{
  int y_FindOptiSyncFP;
  unsigned long long su1_FindOptiSyncFP;
  unsigned long long su2_FindOptiSyncFP;
  int i_FindOptiSyncFP;
  su1_FindOptiSyncFP = u1_FindOptiSyncFP[n_FindOptiSyncFP - 1] &
    9223372036854775808ULL;
  su2_FindOptiSyncFP = u2_FindOptiSyncFP[n_FindOptiSyncFP - 1] &
    9223372036854775808ULL;
  if ((su1_FindOptiSyncFP ^ su2_FindOptiSyncFP) != 0ULL) {
    if (su1_FindOptiSyncFP != 0ULL) {
      y_FindOptiSyncFP = -1;
    } else {
      y_FindOptiSyncFP = 1;
    }
  } else {
    y_FindOptiSyncFP = 0;
    i_FindOptiSyncFP = n_FindOptiSyncFP;
    while ((y_FindOptiSyncFP == 0) && (i_FindOptiSyncFP > 0)) {
      i_FindOptiSyncFP--;
      su1_FindOptiSyncFP = u1_FindOptiSyncFP[i_FindOptiSyncFP];
      su2_FindOptiSyncFP = u2_FindOptiSyncFP[i_FindOptiSyncFP];
      if (su1_FindOptiSyncFP != su2_FindOptiSyncFP) {
        if (su1_FindOptiSyncFP > su2_FindOptiSyncFP) {
          y_FindOptiSyncFP = 1;
        } else {
          y_FindOptiSyncFP = -1;
        }
      }
    }
  }

  return y_FindOptiSyncFP;
}

/*
 * Arguments    : const unsigned long long u1_FindOptiSyncFP[]
 *                const unsigned long long u2_FindOptiSyncFP[]
 *                int n_FindOptiSyncFP
 * Return Type  : boolean_T
 */
static boolean_T sMultiWordLe_FindOptiSyncFP(const unsigned long long
  u1_FindOptiSyncFP[], const unsigned long long u2_FindOptiSyncFP[], int
  n_FindOptiSyncFP)
{
  return sMultiWordCmp_FindOptiSyncFP(u1_FindOptiSyncFP, u2_FindOptiSyncFP,
    n_FindOptiSyncFP) <= 0;
}

/*
 * Arguments    : const unsigned long long u1_FindOptiSyncFP[]
 *                int n1_FindOptiSyncFP
 *                const unsigned long long u2_FindOptiSyncFP[]
 *                int n2_FindOptiSyncFP
 *                unsigned long long y_FindOptiSyncFP[]
 *                int n_FindOptiSyncFP
 * Return Type  : void
 */
static void sMultiWordMul_FindOptiSyncFP(const unsigned long long
  u1_FindOptiSyncFP[], int n1_FindOptiSyncFP, const unsigned long long
  u2_FindOptiSyncFP[], int n2_FindOptiSyncFP, unsigned long long
  y_FindOptiSyncFP[], int n_FindOptiSyncFP)
{
  boolean_T isNegative1_FindOptiSyncFP;
  boolean_T isNegative2_FindOptiSyncFP;
  unsigned long long cb1_FindOptiSyncFP;
  int k_FindOptiSyncFP;
  int i_FindOptiSyncFP;
  unsigned long long cb_FindOptiSyncFP;
  unsigned long long u1i_FindOptiSyncFP;
  unsigned long long a1_FindOptiSyncFP;
  unsigned long long yk_FindOptiSyncFP;
  unsigned long long a0_FindOptiSyncFP;
  unsigned long long cb2_FindOptiSyncFP;
  int nj_FindOptiSyncFP;
  int j_FindOptiSyncFP;
  unsigned long long b1_FindOptiSyncFP;
  unsigned long long w10_FindOptiSyncFP;
  unsigned long long w01_FindOptiSyncFP;
  isNegative1_FindOptiSyncFP = ((u1_FindOptiSyncFP[n1_FindOptiSyncFP - 1] &
    9223372036854775808ULL) != 0ULL);
  isNegative2_FindOptiSyncFP = ((u2_FindOptiSyncFP[n2_FindOptiSyncFP - 1] &
    9223372036854775808ULL) != 0ULL);
  cb1_FindOptiSyncFP = 1ULL;

  /* Initialize output to zero */
  for (k_FindOptiSyncFP = 0; k_FindOptiSyncFP < n_FindOptiSyncFP;
       k_FindOptiSyncFP++) {
    y_FindOptiSyncFP[k_FindOptiSyncFP] = 0ULL;
  }

  for (i_FindOptiSyncFP = 0; i_FindOptiSyncFP < n1_FindOptiSyncFP;
       i_FindOptiSyncFP++) {
    cb_FindOptiSyncFP = 0ULL;
    u1i_FindOptiSyncFP = u1_FindOptiSyncFP[i_FindOptiSyncFP];
    if (isNegative1_FindOptiSyncFP) {
      u1i_FindOptiSyncFP = ~u1i_FindOptiSyncFP + cb1_FindOptiSyncFP;
      cb1_FindOptiSyncFP = (unsigned long long)(u1i_FindOptiSyncFP <
        cb1_FindOptiSyncFP);
    }

    a1_FindOptiSyncFP = u1i_FindOptiSyncFP >> 32U;
    a0_FindOptiSyncFP = u1i_FindOptiSyncFP & 4294967295ULL;
    cb2_FindOptiSyncFP = 1ULL;
    k_FindOptiSyncFP = n_FindOptiSyncFP - i_FindOptiSyncFP;
    if (n2_FindOptiSyncFP <= k_FindOptiSyncFP) {
      nj_FindOptiSyncFP = n2_FindOptiSyncFP;
    } else {
      nj_FindOptiSyncFP = k_FindOptiSyncFP;
    }

    k_FindOptiSyncFP = i_FindOptiSyncFP;
    for (j_FindOptiSyncFP = 0; j_FindOptiSyncFP < nj_FindOptiSyncFP;
         j_FindOptiSyncFP++) {
      yk_FindOptiSyncFP = y_FindOptiSyncFP[k_FindOptiSyncFP];
      u1i_FindOptiSyncFP = u2_FindOptiSyncFP[j_FindOptiSyncFP];
      if (isNegative2_FindOptiSyncFP) {
        u1i_FindOptiSyncFP = ~u1i_FindOptiSyncFP + cb2_FindOptiSyncFP;
        cb2_FindOptiSyncFP = (unsigned long long)(u1i_FindOptiSyncFP <
          cb2_FindOptiSyncFP);
      }

      b1_FindOptiSyncFP = u1i_FindOptiSyncFP >> 32U;
      u1i_FindOptiSyncFP &= 4294967295ULL;
      w10_FindOptiSyncFP = a1_FindOptiSyncFP * u1i_FindOptiSyncFP;
      w01_FindOptiSyncFP = a0_FindOptiSyncFP * b1_FindOptiSyncFP;
      yk_FindOptiSyncFP += cb_FindOptiSyncFP;
      cb_FindOptiSyncFP = (unsigned long long)(yk_FindOptiSyncFP <
        cb_FindOptiSyncFP);
      u1i_FindOptiSyncFP *= a0_FindOptiSyncFP;
      yk_FindOptiSyncFP += u1i_FindOptiSyncFP;
      cb_FindOptiSyncFP += (yk_FindOptiSyncFP < u1i_FindOptiSyncFP);
      u1i_FindOptiSyncFP = w10_FindOptiSyncFP << 32U;
      yk_FindOptiSyncFP += u1i_FindOptiSyncFP;
      cb_FindOptiSyncFP += (yk_FindOptiSyncFP < u1i_FindOptiSyncFP);
      u1i_FindOptiSyncFP = w01_FindOptiSyncFP << 32U;
      yk_FindOptiSyncFP += u1i_FindOptiSyncFP;
      cb_FindOptiSyncFP += (yk_FindOptiSyncFP < u1i_FindOptiSyncFP);
      y_FindOptiSyncFP[k_FindOptiSyncFP] = yk_FindOptiSyncFP;
      cb_FindOptiSyncFP += w10_FindOptiSyncFP >> 32U;
      cb_FindOptiSyncFP += w01_FindOptiSyncFP >> 32U;
      cb_FindOptiSyncFP += a1_FindOptiSyncFP * b1_FindOptiSyncFP;
      k_FindOptiSyncFP++;
    }

    if (k_FindOptiSyncFP < n_FindOptiSyncFP) {
      y_FindOptiSyncFP[k_FindOptiSyncFP] = cb_FindOptiSyncFP;
    }
  }

  /* Apply sign */
  if (isNegative1_FindOptiSyncFP != isNegative2_FindOptiSyncFP) {
    cb_FindOptiSyncFP = 1ULL;
    for (k_FindOptiSyncFP = 0; k_FindOptiSyncFP < n_FindOptiSyncFP;
         k_FindOptiSyncFP++) {
      yk_FindOptiSyncFP = ~y_FindOptiSyncFP[k_FindOptiSyncFP] +
        cb_FindOptiSyncFP;
      y_FindOptiSyncFP[k_FindOptiSyncFP] = yk_FindOptiSyncFP;
      cb_FindOptiSyncFP = (unsigned long long)(yk_FindOptiSyncFP <
        cb_FindOptiSyncFP);
    }
  }
}

/*
 * Arguments    : const unsigned char X_FindOptiSyncFP[28]
 *                unsigned short Y_FindOptiSyncFP[7]
 * Return Type  : void
 */
static void sum_FindOptiSyncFP(const unsigned char X_FindOptiSyncFP[28],
  unsigned short Y_FindOptiSyncFP[7])
{
  int ix_FindOptiSyncFP;
  int iy_FindOptiSyncFP;
  int i_FindOptiSyncFP;
  int ixstart_FindOptiSyncFP;
  unsigned short s_FindOptiSyncFP;
  int i28_FindOptiSyncFP;
  ix_FindOptiSyncFP = 0;
  iy_FindOptiSyncFP = 0;
  for (i_FindOptiSyncFP = 0; i_FindOptiSyncFP < 7; i_FindOptiSyncFP++) {
    ixstart_FindOptiSyncFP = ix_FindOptiSyncFP + 1;
    ix_FindOptiSyncFP++;
    if (!((ixstart_FindOptiSyncFP >= 1) && (ixstart_FindOptiSyncFP <= 28))) {
      rtDynamicBoundsError_FindOptiSy(ixstart_FindOptiSyncFP, 1, 28,
        &g_emlrtBCI_FindOptiSyncFP);
    }

    s_FindOptiSyncFP = X_FindOptiSyncFP[ixstart_FindOptiSyncFP - 1];
    for (ixstart_FindOptiSyncFP = 0; ixstart_FindOptiSyncFP < 3;
         ixstart_FindOptiSyncFP++) {
      ix_FindOptiSyncFP++;
      if (!((ix_FindOptiSyncFP >= 1) && (ix_FindOptiSyncFP <= 28))) {
        rtDynamicBoundsError_FindOptiSy(ix_FindOptiSyncFP, 1, 28,
          &h_emlrtBCI_FindOptiSyncFP);
      }

      i28_FindOptiSyncFP = (int)((unsigned int)s_FindOptiSyncFP +
        X_FindOptiSyncFP[ix_FindOptiSyncFP - 1]);
      if ((unsigned int)i28_FindOptiSyncFP > 1023U) {
        i28_FindOptiSyncFP = 1023;
      }

      s_FindOptiSyncFP = (unsigned short)i28_FindOptiSyncFP;
    }

    iy_FindOptiSyncFP++;
    if (!((iy_FindOptiSyncFP >= 1) && (iy_FindOptiSyncFP <= 7))) {
      rtDynamicBoundsError_FindOptiSy(iy_FindOptiSyncFP, 1, 7,
        &f_emlrtBCI_FindOptiSyncFP);
    }

    Y_FindOptiSyncFP[iy_FindOptiSyncFP - 1] = s_FindOptiSyncFP;
  }
}

/*
 * Arguments    : const unsigned long long u1_FindOptiSyncFP[]
 *                int n1_FindOptiSyncFP
 *                unsigned long long y_FindOptiSyncFP[]
 *                int n_FindOptiSyncFP
 * Return Type  : void
 */
static void uMultiWord2MultiWord_FindOptiSy(const unsigned long long
  u1_FindOptiSyncFP[], int n1_FindOptiSyncFP, unsigned long long
  y_FindOptiSyncFP[], int n_FindOptiSyncFP)
{
  int nm_FindOptiSyncFP;
  int i_FindOptiSyncFP;
  if (n1_FindOptiSyncFP <= n_FindOptiSyncFP) {
    nm_FindOptiSyncFP = n1_FindOptiSyncFP;
  } else {
    nm_FindOptiSyncFP = n_FindOptiSyncFP;
  }

  for (i_FindOptiSyncFP = 0; i_FindOptiSyncFP < nm_FindOptiSyncFP;
       i_FindOptiSyncFP++) {
    y_FindOptiSyncFP[i_FindOptiSyncFP] = u1_FindOptiSyncFP[i_FindOptiSyncFP];
  }

  if (n_FindOptiSyncFP > n1_FindOptiSyncFP) {
    for (i_FindOptiSyncFP = nm_FindOptiSyncFP; i_FindOptiSyncFP <
         n_FindOptiSyncFP; i_FindOptiSyncFP++) {
      y_FindOptiSyncFP[i_FindOptiSyncFP] = 0ULL;
    }
  }
}

/*
 * Arguments    : const unsigned long long u1_FindOptiSyncFP[]
 *                const unsigned long long u2_FindOptiSyncFP[]
 *                int n_FindOptiSyncFP
 * Return Type  : int
 */
static int uMultiWordCmp_FindOptiSyncFP(const unsigned long long
  u1_FindOptiSyncFP[], const unsigned long long u2_FindOptiSyncFP[], int
  n_FindOptiSyncFP)
{
  int y_FindOptiSyncFP;
  int i_FindOptiSyncFP;
  unsigned long long u1i_FindOptiSyncFP;
  unsigned long long u2i_FindOptiSyncFP;
  y_FindOptiSyncFP = 0;
  i_FindOptiSyncFP = n_FindOptiSyncFP;
  while ((y_FindOptiSyncFP == 0) && (i_FindOptiSyncFP > 0)) {
    i_FindOptiSyncFP--;
    u1i_FindOptiSyncFP = u1_FindOptiSyncFP[i_FindOptiSyncFP];
    u2i_FindOptiSyncFP = u2_FindOptiSyncFP[i_FindOptiSyncFP];
    if (u1i_FindOptiSyncFP != u2i_FindOptiSyncFP) {
      if (u1i_FindOptiSyncFP > u2i_FindOptiSyncFP) {
        y_FindOptiSyncFP = 1;
      } else {
        y_FindOptiSyncFP = -1;
      }
    }
  }

  return y_FindOptiSyncFP;
}

/*
 * Arguments    : const unsigned long long u1_FindOptiSyncFP[]
 *                const unsigned long long u2_FindOptiSyncFP[]
 *                int n_FindOptiSyncFP
 * Return Type  : boolean_T
 */
static boolean_T uMultiWordLe_FindOptiSyncFP(const unsigned long long
  u1_FindOptiSyncFP[], const unsigned long long u2_FindOptiSyncFP[], int
  n_FindOptiSyncFP)
{
  return uMultiWordCmp_FindOptiSyncFP(u1_FindOptiSyncFP, u2_FindOptiSyncFP,
    n_FindOptiSyncFP) <= 0;
}

/*
 * Arguments    : const cint16_T x_FindOptiSyncFP[2048]
 *                cint16_T y_FindOptiSyncFP[6144]
 * Return Type  : void
 */
static void upsample_FindOptiSyncFP(const cint16_T x_FindOptiSyncFP[2048],
  cint16_T y_FindOptiSyncFP[6144])
{
  int xstart_FindOptiSyncFP;
  int ystart_FindOptiSyncFP;
  int i_FindOptiSyncFP;
  int ix_FindOptiSyncFP;
  int iy_FindOptiSyncFP;
  int k_FindOptiSyncFP;
  memset(&y_FindOptiSyncFP[0], 0, 6144U * sizeof(cint16_T));
  xstart_FindOptiSyncFP = 1;
  ystart_FindOptiSyncFP = 1;
  for (i_FindOptiSyncFP = 0; i_FindOptiSyncFP < 4; i_FindOptiSyncFP++) {
    ix_FindOptiSyncFP = xstart_FindOptiSyncFP;
    iy_FindOptiSyncFP = ystart_FindOptiSyncFP;
    for (k_FindOptiSyncFP = 0; k_FindOptiSyncFP < 512; k_FindOptiSyncFP++) {
      if (!((iy_FindOptiSyncFP >= 1) && (iy_FindOptiSyncFP <= 6144))) {
        rtDynamicBoundsError_FindOptiSy(iy_FindOptiSyncFP, 1, 6144,
          &d_emlrtBCI_FindOptiSyncFP);
      }

      if (!((ix_FindOptiSyncFP >= 1) && (ix_FindOptiSyncFP <= 2048))) {
        rtDynamicBoundsError_FindOptiSy(ix_FindOptiSyncFP, 1, 2048,
          &e_emlrtBCI_FindOptiSyncFP);
      }

      y_FindOptiSyncFP[iy_FindOptiSyncFP - 1].re =
        x_FindOptiSyncFP[ix_FindOptiSyncFP - 1].re;
      if (!((ix_FindOptiSyncFP >= 1) && (ix_FindOptiSyncFP <= 2048))) {
        rtDynamicBoundsError_FindOptiSy(ix_FindOptiSyncFP, 1, 2048,
          &c_emlrtBCI_FindOptiSyncFP);
      }

      if (!((iy_FindOptiSyncFP >= 1) && (iy_FindOptiSyncFP <= 6144))) {
        rtDynamicBoundsError_FindOptiSy(iy_FindOptiSyncFP, 1, 6144,
          &d_emlrtBCI_FindOptiSyncFP);
      }

      y_FindOptiSyncFP[iy_FindOptiSyncFP - 1].im =
        x_FindOptiSyncFP[ix_FindOptiSyncFP - 1].im;
      ix_FindOptiSyncFP++;
      iy_FindOptiSyncFP += 3;
    }

    xstart_FindOptiSyncFP += 512;
    ystart_FindOptiSyncFP += 1536;
  }
}

/*
 * Find Optimum Synchronization Sample Point.
 *  input:
 *     % rxSigNoise: NxM complex, N is the number of snapshots, M is the number of channel. each colum is one snapshot
 *     % pilotSequenceUpSample: (UpSampleTimesxN)x1 complex, N is the length of pilot.
 *     % UpSampleTimes: 1x1 integer, upsample factor.Fixed 3 for fixed point.
 *     % LenSearch: 1x1 odd integer, search range of finding optimum synchronization sample point under upsampled symbols.Fixed 7 for fixed point.
 *  output:
 *     % pilotSequence, Nx1 complex, N is the length of pilot, pilot sequence downsampled according to optimum synchronization sample.
 *     % numSyncChannel: 1x1 integer, number of synchronized channel after adjust optimum synchronization sample.
 *     % circShiftSelect: 1x1 integer, pilot circle shift index.
 *
 *  2018-01-25 V1.0 Wayne Zhang. draft.
 * Arguments    : const cint16_T rxSigNoise_FindOptiSyncFP[2048]
 *                const cint16_T pilotSequenceUpSample_FindOptiS[1536]
 *                cint16_T pilotSequence_FindOptiSyncFP[512]
 *                unsigned char *numSyncChannel_FindOptiSyncFP
 *                signed char *circShiftSelect_FindOptiSyncFP
 * Return Type  : void
 */
void FindOptiSyncFixedPointImplement_fixpt(const cint16_T
  rxSigNoise_FindOptiSyncFP[2048], const cint16_T
  pilotSequenceUpSample_FindOptiS[1536], cint16_T pilotSequence_FindOptiSyncFP
  [512], unsigned char *numSyncChannel_FindOptiSyncFP, signed char
  *circShiftSelect_FindOptiSyncFP)
{
  boolean_T b0_FindOptiSyncFP;
  boolean_T b1_FindOptiSyncFP;
  unsigned char syncIndexMat_FindOptiSyncFP[28];
  int i0_FindOptiSyncFP;
  cint16_T pilotSequenceUpSampleShift_data[3327];
  cint16_T varargin_1_FindOptiSyncFP[6144];
  cint16_T pilotSequenceUpSampleMat_FindOp[10752];
  int idxShift_iter_FindOptiSyncFP;
  unsigned char idxShift_FindOptiSyncFP;
  cint16_T b_varargin_1_FindOptiSyncFP[6144];
  static const signed char iv0_FindOptiSyncFP[7] = { -3, -2, -1, 0, 1, 2, 3 };

  cint64_T icv0_FindOptiSyncFP[28];
  int i1_FindOptiSyncFP;
  cint64_T icv1_FindOptiSyncFP[28];
  int idxChannel_FindOptiSyncFP;
  long long iv1_FindOptiSyncFP[28];
  int i2_FindOptiSyncFP;
  long long unusedU0_FindOptiSyncFP[4];
  double fmo_3_FindOptiSyncFP[4];
  long long i3_FindOptiSyncFP;
  unsigned char idxSyncIndexVec_FindOptiSyncFP[4];
  short i4_FindOptiSyncFP;
  double d0_FindOptiSyncFP;
  int i5_FindOptiSyncFP;
  unsigned char b_idxChannel_FindOptiSyncFP;
  unsigned char u0_FindOptiSyncFP;
  unsigned short uv0_FindOptiSyncFP[7];
  unsigned short fmo_4_FindOptiSyncFP;
  double fmo_5_FindOptiSyncFP;
  int i6_FindOptiSyncFP;
  unsigned short u1_FindOptiSyncFP;
  int i7_FindOptiSyncFP;
  short i8_FindOptiSyncFP;
  int i9_FindOptiSyncFP;
  int i10_FindOptiSyncFP;
  int i11_FindOptiSyncFP;
  int tmp_size_FindOptiSyncFP[1];
  int loop_ub_FindOptiSyncFP;
  cint16_T tmp_data_FindOptiSyncFP[3072];
  int i12_FindOptiSyncFP;
  int iv2_FindOptiSyncFP[1];
  int b_tmp_size_FindOptiSyncFP[1];
  cint16_T b_tmp_data_FindOptiSyncFP[1791];
  int iv3_FindOptiSyncFP[1];
  unsigned short idxDownSample_FindOptiSyncFP;
  int i13_FindOptiSyncFP;
  int i14_FindOptiSyncFP;
  int i15_FindOptiSyncFP;
  int i16_FindOptiSyncFP;
  int i17_FindOptiSyncFP;
  b0_FindOptiSyncFP = false;
  b1_FindOptiSyncFP = false;

  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /*                                                                           % */
  /*            Generated by MATLAB 9.0 and Fixed-Point Designer 5.2           % */
  /*                                                                           % */
  /* %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% */
  /* 'FindOptiSyncFixedPointImplement_fixpt:21' fm = get_fimath(); */
  /* 'FindOptiSyncFixedPointImplement_fixpt:23' circShiftPattern = fi(-3:3, 1, 8, 0, fm); */
  /* 'FindOptiSyncFixedPointImplement_fixpt:25' [fmo_1, fmo_2] = size(rxSigNoise); */
  /* 'FindOptiSyncFixedPointImplement_fixpt:26' LenPilot = fi(fmo_1, 0, 16, 0, fm); */
  /* 'FindOptiSyncFixedPointImplement_fixpt:27' NumChannel = fi(fmo_2, 0, 8, 0, fm); */
  /* 'FindOptiSyncFixedPointImplement_fixpt:28' syncIndexMat = fi(zeros(fi_toint(NumChannel), 7), 0, 8, 0, fm); */
  for (i0_FindOptiSyncFP = 0; i0_FindOptiSyncFP < 28; i0_FindOptiSyncFP++) {
    syncIndexMat_FindOptiSyncFP[i0_FindOptiSyncFP] = 0;
  }

  /* 'FindOptiSyncFixedPointImplement_fixpt:29' pilotSequenceUpSampleShift = fi(zeros(fi_toint(LenPilot*fi(3, 0, 8, 0, fm)), 1), 1, 16, 0, fm); */
  for (i0_FindOptiSyncFP = 0; i0_FindOptiSyncFP < 1536; i0_FindOptiSyncFP++) {
    pilotSequenceUpSampleShift_data[i0_FindOptiSyncFP].re = 0;
    pilotSequenceUpSampleShift_data[i0_FindOptiSyncFP].im = 0;
  }

  /* 'FindOptiSyncFixedPointImplement_fixpt:30' rxSigNoiseUpSample = fi(upsample(rxSigNoise, fi(3, 0, 8, 0, fm)), 1, 16, 0, fm); */
  upsample_FindOptiSyncFP(rxSigNoise_FindOptiSyncFP, varargin_1_FindOptiSyncFP);

  /* 'FindOptiSyncFixedPointImplement_fixpt:32' pilotSequenceUpSampleMat = fi(complex(zeros(fi_toint(LenPilot*fi(3, 0, 8, 0, fm)), 7)), 1, 16, 0, fm); */
  memset(&pilotSequenceUpSampleMat_FindOp[0], 0, 10752U * sizeof(cint16_T));

  /* 'FindOptiSyncFixedPointImplement_fixpt:33' for idxShift_iter = 1:7 */
  for (idxShift_iter_FindOptiSyncFP = 0; idxShift_iter_FindOptiSyncFP < 7;
       idxShift_iter_FindOptiSyncFP++) {
    /* 'FindOptiSyncFixedPointImplement_fixpt:34' idxShift = fi(idxShift_iter, 0, 8, 0, fm); */
    idxShift_FindOptiSyncFP = (unsigned char)(1 + idxShift_iter_FindOptiSyncFP);

    /* 'FindOptiSyncFixedPointImplement_fixpt:35' circShiftCurr = fi(circShiftPattern(idxShift), 1, 8, 0, fm); */
    /* 'FindOptiSyncFixedPointImplement_fixpt:36' if circShiftCurr == fi(0, 0, 8, 0, fm) */
    if (iv0_FindOptiSyncFP[idxShift_FindOptiSyncFP - 1] == 0) {
      /* 'FindOptiSyncFixedPointImplement_fixpt:37' pilotSequenceUpSampleMat(:,idxShift) = pilotSequenceUpSample; */
      memcpy(&pilotSequenceUpSampleMat_FindOp[idxShift_FindOptiSyncFP * 1536 +
             -1536], &pilotSequenceUpSample_FindOptiS[0], 1536U * sizeof
             (cint16_T));
    } else if (iv0_FindOptiSyncFP[idxShift_FindOptiSyncFP - 1] > 0) {
      /* 'FindOptiSyncFixedPointImplement_fixpt:38' elseif circShiftCurr > fi(0, 0, 8, 0, fm) */
      /* 'FindOptiSyncFixedPointImplement_fixpt:39' pilotSequenceUpSampleMat(:,idxShift) = [fi(pilotSequenceUpSample(fi(end, 0, 16, 0, fm) - circShiftCurr + fi(1, 0, 8, 0, fm):fi(end, 0, 16, 0, fm)), 1, 16, 0, fm);pilotSequenceUpSample(fi(1, 0, 8, 0, fm):fi(end, 0, 16, 0, fm) - circShiftCurr)]; */
      i0_FindOptiSyncFP = iv0_FindOptiSyncFP[idxShift_FindOptiSyncFP - 1];
      if ((i0_FindOptiSyncFP & 131072) != 0) {
        i2_FindOptiSyncFP = i0_FindOptiSyncFP | -131072;
      } else {
        i2_FindOptiSyncFP = i0_FindOptiSyncFP & 131071;
      }

      i0_FindOptiSyncFP = 1536 - i2_FindOptiSyncFP;
      if ((i0_FindOptiSyncFP & 131072) != 0) {
        i0_FindOptiSyncFP |= -131072;
      } else {
        i0_FindOptiSyncFP &= 131071;
      }

      if ((i0_FindOptiSyncFP & 524288) != 0) {
        i5_FindOptiSyncFP = i0_FindOptiSyncFP | -524288;
      } else {
        i5_FindOptiSyncFP = i0_FindOptiSyncFP & 524287;
      }

      i0_FindOptiSyncFP = i5_FindOptiSyncFP + 1;
      if ((i0_FindOptiSyncFP & 524288) != 0) {
        i0_FindOptiSyncFP |= -524288;
      } else {
        i0_FindOptiSyncFP &= 524287;
      }

      colontype_FindOptiSyncFP(i0_FindOptiSyncFP);
      b_colontype_FindOptiSyncFP();
      i1_FindOptiSyncFP = iv0_FindOptiSyncFP[idxShift_FindOptiSyncFP - 1];
      if ((i1_FindOptiSyncFP & 131072) != 0) {
        i7_FindOptiSyncFP = i1_FindOptiSyncFP | -131072;
      } else {
        i7_FindOptiSyncFP = i1_FindOptiSyncFP & 131071;
      }

      i1_FindOptiSyncFP = 1536 - i7_FindOptiSyncFP;
      if ((i1_FindOptiSyncFP & 131072) != 0) {
        idxChannel_FindOptiSyncFP = i1_FindOptiSyncFP | -131072;
      } else {
        idxChannel_FindOptiSyncFP = i1_FindOptiSyncFP & 131071;
      }

      i1_FindOptiSyncFP = iv0_FindOptiSyncFP[idxShift_FindOptiSyncFP - 1];
      if ((i1_FindOptiSyncFP & 131072) != 0) {
        i9_FindOptiSyncFP = i1_FindOptiSyncFP | -131072;
      } else {
        i9_FindOptiSyncFP = i1_FindOptiSyncFP & 131071;
      }

      i1_FindOptiSyncFP = 1536 - i9_FindOptiSyncFP;
      if ((i1_FindOptiSyncFP & 131072) != 0) {
        i10_FindOptiSyncFP = i1_FindOptiSyncFP | -131072;
      } else {
        i10_FindOptiSyncFP = i1_FindOptiSyncFP & 131071;
      }

      tmp_size_FindOptiSyncFP[0] = (i10_FindOptiSyncFP - i0_FindOptiSyncFP) +
        1537;
      loop_ub_FindOptiSyncFP = 1537 - i0_FindOptiSyncFP;
      for (i1_FindOptiSyncFP = 0; i1_FindOptiSyncFP < loop_ub_FindOptiSyncFP;
           i1_FindOptiSyncFP++) {
        tmp_data_FindOptiSyncFP[i1_FindOptiSyncFP].re =
          pilotSequenceUpSample_FindOptiS[(i0_FindOptiSyncFP + i1_FindOptiSyncFP)
          - 1].re;
        tmp_data_FindOptiSyncFP[i1_FindOptiSyncFP].im =
          pilotSequenceUpSample_FindOptiS[(i0_FindOptiSyncFP + i1_FindOptiSyncFP)
          - 1].im;
      }

      for (i1_FindOptiSyncFP = 0; i1_FindOptiSyncFP < idxChannel_FindOptiSyncFP;
           i1_FindOptiSyncFP++) {
        tmp_data_FindOptiSyncFP[(i1_FindOptiSyncFP - i0_FindOptiSyncFP) + 1537].
          re = pilotSequenceUpSample_FindOptiS[i1_FindOptiSyncFP].re;
        tmp_data_FindOptiSyncFP[(i1_FindOptiSyncFP - i0_FindOptiSyncFP) + 1537].
          im = pilotSequenceUpSample_FindOptiS[i1_FindOptiSyncFP].im;
      }

      if (!b0_FindOptiSyncFP) {
        iv2_FindOptiSyncFP[0] = 1536;
        b0_FindOptiSyncFP = true;
      }

      rtSubAssignSizeCheck_FindOptiSy(iv2_FindOptiSyncFP, 1,
        tmp_size_FindOptiSyncFP, 1, &emlrtECI_FindOptiSyncFP);
      for (i0_FindOptiSyncFP = 0; i0_FindOptiSyncFP < 1536; i0_FindOptiSyncFP++)
      {
        pilotSequenceUpSampleMat_FindOp[i0_FindOptiSyncFP + 1536 *
          (idxShift_FindOptiSyncFP - 1)].re =
          tmp_data_FindOptiSyncFP[i0_FindOptiSyncFP].re;
        pilotSequenceUpSampleMat_FindOp[i0_FindOptiSyncFP + 1536 *
          (idxShift_FindOptiSyncFP - 1)].im =
          tmp_data_FindOptiSyncFP[i0_FindOptiSyncFP].im;
      }
    } else {
      if (iv0_FindOptiSyncFP[idxShift_FindOptiSyncFP - 1] < 0) {
        /* 'FindOptiSyncFixedPointImplement_fixpt:40' elseif circShiftCurr < fi(0, 0, 8, 0, fm) */
        /* 'FindOptiSyncFixedPointImplement_fixpt:41' pilotSequenceUpSampleMat(:,idxShift) = [fi(pilotSequenceUpSample(fi_uminus(circShiftCurr) + fi(1, 0, 8, 0, fm):fi(end, 0, 16, 0, fm)), 1, 16, 0, fm);pilotSequenceUpSample(fi(1, 0, 8, 0, fm):fi_uminus(circShiftCurr))]; */
        /* 'FindOptiSyncFixedPointImplement_fixpt:89' coder.inline( 'always' ); */
        /* 'FindOptiSyncFixedPointImplement_fixpt:90' if isfi( a ) */
        /* 'FindOptiSyncFixedPointImplement_fixpt:91' nt = numerictype( a ); */
        /* 'FindOptiSyncFixedPointImplement_fixpt:92' new_nt = numerictype( 1, nt.WordLength + 1, nt.FractionLength ); */
        /* 'FindOptiSyncFixedPointImplement_fixpt:93' y = -fi( a, new_nt, fimath( a ) ); */
        i4_FindOptiSyncFP = iv0_FindOptiSyncFP[idxShift_FindOptiSyncFP - 1];
        if ((short)(i4_FindOptiSyncFP & 256) != 0) {
          i4_FindOptiSyncFP = (short)-(short)(i4_FindOptiSyncFP | -256);
        } else {
          i4_FindOptiSyncFP = (short)-(short)(i4_FindOptiSyncFP & 255);
        }

        if ((short)(i4_FindOptiSyncFP & 256) != 0) {
          i4_FindOptiSyncFP |= -256;
        } else {
          i4_FindOptiSyncFP &= 255;
        }

        if ((short)(i4_FindOptiSyncFP & 1024) != 0) {
          i6_FindOptiSyncFP = (short)(i4_FindOptiSyncFP | -1024);
        } else {
          i6_FindOptiSyncFP = (short)(i4_FindOptiSyncFP & 1023);
        }

        i4_FindOptiSyncFP = (short)(i6_FindOptiSyncFP + 1);
        if ((short)(i4_FindOptiSyncFP & 1024) != 0) {
          i4_FindOptiSyncFP |= -1024;
        } else {
          i4_FindOptiSyncFP &= 1023;
        }

        c_colontype_FindOptiSyncFP(i4_FindOptiSyncFP);

        /* 'FindOptiSyncFixedPointImplement_fixpt:89' coder.inline( 'always' ); */
        /* 'FindOptiSyncFixedPointImplement_fixpt:90' if isfi( a ) */
        /* 'FindOptiSyncFixedPointImplement_fixpt:91' nt = numerictype( a ); */
        /* 'FindOptiSyncFixedPointImplement_fixpt:92' new_nt = numerictype( 1, nt.WordLength + 1, nt.FractionLength ); */
        /* 'FindOptiSyncFixedPointImplement_fixpt:93' y = -fi( a, new_nt, fimath( a ) ); */
        d_colontype_FindOptiSyncFP();
        i8_FindOptiSyncFP = iv0_FindOptiSyncFP[idxShift_FindOptiSyncFP - 1];
        if ((short)(i8_FindOptiSyncFP & 256) != 0) {
          i8_FindOptiSyncFP = (short)-(short)(i8_FindOptiSyncFP | -256);
        } else {
          i8_FindOptiSyncFP = (short)-(short)(i8_FindOptiSyncFP & 255);
        }

        if ((short)(i8_FindOptiSyncFP & 256) != 0) {
          i11_FindOptiSyncFP = (short)(i8_FindOptiSyncFP | -256);
        } else {
          i11_FindOptiSyncFP = (short)(i8_FindOptiSyncFP & 255);
        }

        idxChannel_FindOptiSyncFP = i11_FindOptiSyncFP - 1;
        i8_FindOptiSyncFP = iv0_FindOptiSyncFP[idxShift_FindOptiSyncFP - 1];
        if ((short)(i8_FindOptiSyncFP & 256) != 0) {
          i8_FindOptiSyncFP = (short)-(short)(i8_FindOptiSyncFP | -256);
        } else {
          i8_FindOptiSyncFP = (short)-(short)(i8_FindOptiSyncFP & 255);
        }

        if ((short)(i8_FindOptiSyncFP & 256) != 0) {
          i12_FindOptiSyncFP = (short)(i8_FindOptiSyncFP | -256);
        } else {
          i12_FindOptiSyncFP = (short)(i8_FindOptiSyncFP & 255);
        }

        b_tmp_size_FindOptiSyncFP[0] = (i12_FindOptiSyncFP - i4_FindOptiSyncFP)
          + 1537;
        loop_ub_FindOptiSyncFP = -i4_FindOptiSyncFP;
        for (i0_FindOptiSyncFP = 0; i0_FindOptiSyncFP <= loop_ub_FindOptiSyncFP
             + 1536; i0_FindOptiSyncFP++) {
          b_tmp_data_FindOptiSyncFP[i0_FindOptiSyncFP].re =
            pilotSequenceUpSample_FindOptiS[(i4_FindOptiSyncFP +
            i0_FindOptiSyncFP) - 1].re;
          b_tmp_data_FindOptiSyncFP[i0_FindOptiSyncFP].im =
            pilotSequenceUpSample_FindOptiS[(i4_FindOptiSyncFP +
            i0_FindOptiSyncFP) - 1].im;
        }

        for (i0_FindOptiSyncFP = 0; i0_FindOptiSyncFP <=
             idxChannel_FindOptiSyncFP; i0_FindOptiSyncFP++) {
          b_tmp_data_FindOptiSyncFP[(i0_FindOptiSyncFP - i4_FindOptiSyncFP) +
            1537].re = pilotSequenceUpSample_FindOptiS[i0_FindOptiSyncFP].re;
          b_tmp_data_FindOptiSyncFP[(i0_FindOptiSyncFP - i4_FindOptiSyncFP) +
            1537].im = pilotSequenceUpSample_FindOptiS[i0_FindOptiSyncFP].im;
        }

        if (!b1_FindOptiSyncFP) {
          iv3_FindOptiSyncFP[0] = 1536;
          b1_FindOptiSyncFP = true;
        }

        rtSubAssignSizeCheck_FindOptiSy(iv3_FindOptiSyncFP, 1,
          b_tmp_size_FindOptiSyncFP, 1, &b_emlrtECI_FindOptiSyncFP);
        for (i0_FindOptiSyncFP = 0; i0_FindOptiSyncFP < 1536; i0_FindOptiSyncFP
             ++) {
          pilotSequenceUpSampleMat_FindOp[i0_FindOptiSyncFP + 1536 *
            (idxShift_FindOptiSyncFP - 1)].re =
            b_tmp_data_FindOptiSyncFP[i0_FindOptiSyncFP].re;
          pilotSequenceUpSampleMat_FindOp[i0_FindOptiSyncFP + 1536 *
            (idxShift_FindOptiSyncFP - 1)].im =
            b_tmp_data_FindOptiSyncFP[i0_FindOptiSyncFP].im;
        }
      }
    }
  }

  /* 'FindOptiSyncFixedPointImplement_fixpt:45' xcorrMat = fi(rxSigNoiseUpSample'*pilotSequenceUpSampleMat, 1, 56, 0, fm); */
  /* 'FindOptiSyncFixedPointImplement_fixpt:46' [~, fmo_3] = max(abs(xcorrMat.')); */
  for (i0_FindOptiSyncFP = 0; i0_FindOptiSyncFP < 1536; i0_FindOptiSyncFP++) {
    for (i1_FindOptiSyncFP = 0; i1_FindOptiSyncFP < 4; i1_FindOptiSyncFP++) {
      b_varargin_1_FindOptiSyncFP[i1_FindOptiSyncFP + (i0_FindOptiSyncFP << 2)].
        re = varargin_1_FindOptiSyncFP[i0_FindOptiSyncFP + 1536 *
        i1_FindOptiSyncFP].re;
      idxChannel_FindOptiSyncFP = -varargin_1_FindOptiSyncFP[i0_FindOptiSyncFP +
        1536 * i1_FindOptiSyncFP].im;
      if (idxChannel_FindOptiSyncFP > 32767) {
        idxChannel_FindOptiSyncFP = 32767;
      }

      b_varargin_1_FindOptiSyncFP[i1_FindOptiSyncFP + (i0_FindOptiSyncFP << 2)].
        im = (short)idxChannel_FindOptiSyncFP;
    }
  }

  mtimes_FindOptiSyncFP(b_varargin_1_FindOptiSyncFP,
                        pilotSequenceUpSampleMat_FindOp, icv0_FindOptiSyncFP);
  for (i0_FindOptiSyncFP = 0; i0_FindOptiSyncFP < 4; i0_FindOptiSyncFP++) {
    for (i1_FindOptiSyncFP = 0; i1_FindOptiSyncFP < 7; i1_FindOptiSyncFP++) {
      i3_FindOptiSyncFP = icv0_FindOptiSyncFP[i0_FindOptiSyncFP +
        (i1_FindOptiSyncFP << 2)].re;
      if ((i3_FindOptiSyncFP & 36028797018963968LL) != 0LL) {
        icv1_FindOptiSyncFP[i1_FindOptiSyncFP + 7 * i0_FindOptiSyncFP].re =
          i3_FindOptiSyncFP | -36028797018963968LL;
      } else {
        icv1_FindOptiSyncFP[i1_FindOptiSyncFP + 7 * i0_FindOptiSyncFP].re =
          i3_FindOptiSyncFP & 36028797018963967LL;
      }

      i3_FindOptiSyncFP = icv0_FindOptiSyncFP[i0_FindOptiSyncFP +
        (i1_FindOptiSyncFP << 2)].im;
      if ((i3_FindOptiSyncFP & 36028797018963968LL) != 0LL) {
        icv1_FindOptiSyncFP[i1_FindOptiSyncFP + 7 * i0_FindOptiSyncFP].im =
          i3_FindOptiSyncFP | -36028797018963968LL;
      } else {
        icv1_FindOptiSyncFP[i1_FindOptiSyncFP + 7 * i0_FindOptiSyncFP].im =
          i3_FindOptiSyncFP & 36028797018963967LL;
      }
    }
  }

  abs_FindOptiSyncFP(icv1_FindOptiSyncFP, iv1_FindOptiSyncFP);
  max_FindOptiSyncFP(iv1_FindOptiSyncFP, unusedU0_FindOptiSyncFP,
                     fmo_3_FindOptiSyncFP);

  /* 'FindOptiSyncFixedPointImplement_fixpt:46' ~ */
  /* 'FindOptiSyncFixedPointImplement_fixpt:47' idxSyncIndexVec = fi(fmo_3, 0, 8, 0, fm); */
  for (i0_FindOptiSyncFP = 0; i0_FindOptiSyncFP < 4; i0_FindOptiSyncFP++) {
    d0_FindOptiSyncFP = fmo_3_FindOptiSyncFP[i0_FindOptiSyncFP];
    if (d0_FindOptiSyncFP < 256.0) {
      if (d0_FindOptiSyncFP >= 0.0) {
        u0_FindOptiSyncFP = (unsigned char)d0_FindOptiSyncFP;
      } else {
        u0_FindOptiSyncFP = 0;
      }
    } else if (d0_FindOptiSyncFP >= 256.0) {
      u0_FindOptiSyncFP = MAX_uint8_T;
    } else {
      u0_FindOptiSyncFP = 0;
    }

    idxSyncIndexVec_FindOptiSyncFP[i0_FindOptiSyncFP] = u0_FindOptiSyncFP;
  }

  /* 'FindOptiSyncFixedPointImplement_fixpt:49' for idxChannel = fi(1, 0, 8, 0, fm):NumChannel */
  for (idxChannel_FindOptiSyncFP = 0; idxChannel_FindOptiSyncFP < 4;
       idxChannel_FindOptiSyncFP++) {
    b_idxChannel_FindOptiSyncFP = (unsigned char)(idxChannel_FindOptiSyncFP + 1);

    /* 'FindOptiSyncFixedPointImplement_fixpt:50' syncIndexMat(idxChannel,idxSyncIndexVec(idxChannel)) = 1; */
    i0_FindOptiSyncFP =
      idxSyncIndexVec_FindOptiSyncFP[b_idxChannel_FindOptiSyncFP - 1];
    if (!((i0_FindOptiSyncFP >= 1) && (i0_FindOptiSyncFP <= 7))) {
      rtDynamicBoundsError_FindOptiSy(i0_FindOptiSyncFP, 1, 7,
        &b_emlrtBCI_FindOptiSyncFP);
    }

    syncIndexMat_FindOptiSyncFP[(b_idxChannel_FindOptiSyncFP +
      ((i0_FindOptiSyncFP - 1) << 2)) - 1] = 1;
  }

  /* 'FindOptiSyncFixedPointImplement_fixpt:53' [fmo_4, fmo_5] = max(sum(syncIndexMat)); */
  sum_FindOptiSyncFP(syncIndexMat_FindOptiSyncFP, uv0_FindOptiSyncFP);
  b_max_FindOptiSyncFP(uv0_FindOptiSyncFP, &fmo_4_FindOptiSyncFP,
                       &fmo_5_FindOptiSyncFP);

  /* 'FindOptiSyncFixedPointImplement_fixpt:54' numSyncChannel = fi(fmo_4, 0, 8, 0, fm); */
  u1_FindOptiSyncFP = fmo_4_FindOptiSyncFP;
  if (u1_FindOptiSyncFP > 255) {
    u1_FindOptiSyncFP = 255;
  }

  *numSyncChannel_FindOptiSyncFP = (unsigned char)u1_FindOptiSyncFP;

  /* 'FindOptiSyncFixedPointImplement_fixpt:55' idxShift = fi(fmo_5, 0, 8, 0, fm); */
  /* 'FindOptiSyncFixedPointImplement_fixpt:56' circShiftSelect = fi(circShiftPattern(idxShift), 1, 8, 0, fm); */
  d0_FindOptiSyncFP = fmo_5_FindOptiSyncFP;
  if (d0_FindOptiSyncFP < 256.0) {
    if (d0_FindOptiSyncFP >= 0.0) {
      u0_FindOptiSyncFP = (unsigned char)d0_FindOptiSyncFP;
    } else {
      u0_FindOptiSyncFP = 0;
    }
  } else if (d0_FindOptiSyncFP >= 256.0) {
    u0_FindOptiSyncFP = MAX_uint8_T;
  } else {
    u0_FindOptiSyncFP = 0;
  }

  i0_FindOptiSyncFP = u0_FindOptiSyncFP;
  if (!((i0_FindOptiSyncFP >= 1) && (i0_FindOptiSyncFP <= 7))) {
    rtDynamicBoundsError_FindOptiSy(i0_FindOptiSyncFP, 1, 7,
      &emlrtBCI_FindOptiSyncFP);
  }

  if (d0_FindOptiSyncFP < 256.0) {
    if (d0_FindOptiSyncFP >= 0.0) {
      u0_FindOptiSyncFP = (unsigned char)d0_FindOptiSyncFP;
    } else {
      u0_FindOptiSyncFP = 0;
    }
  } else if (d0_FindOptiSyncFP >= 256.0) {
    u0_FindOptiSyncFP = MAX_uint8_T;
  } else {
    u0_FindOptiSyncFP = 0;
  }

  *circShiftSelect_FindOptiSyncFP = iv0_FindOptiSyncFP[u0_FindOptiSyncFP - 1];

  /* 'FindOptiSyncFixedPointImplement_fixpt:57' if circShiftSelect == fi(0, 0, 8, 0, fm) */
  if (d0_FindOptiSyncFP < 256.0) {
    if (d0_FindOptiSyncFP >= 0.0) {
      u0_FindOptiSyncFP = (unsigned char)d0_FindOptiSyncFP;
    } else {
      u0_FindOptiSyncFP = 0;
    }
  } else if (d0_FindOptiSyncFP >= 256.0) {
    u0_FindOptiSyncFP = MAX_uint8_T;
  } else {
    u0_FindOptiSyncFP = 0;
  }

  if (iv0_FindOptiSyncFP[u0_FindOptiSyncFP - 1] == 0) {
    /* 'FindOptiSyncFixedPointImplement_fixpt:58' pilotSequenceUpSampleShift = fi(pilotSequenceUpSample, 1, 16, 0, fm); */
    for (i0_FindOptiSyncFP = 0; i0_FindOptiSyncFP < 1536; i0_FindOptiSyncFP++) {
      pilotSequenceUpSampleShift_data[i0_FindOptiSyncFP].re =
        pilotSequenceUpSample_FindOptiS[i0_FindOptiSyncFP].re;
      pilotSequenceUpSampleShift_data[i0_FindOptiSyncFP].im =
        pilotSequenceUpSample_FindOptiS[i0_FindOptiSyncFP].im;
    }
  } else {
    if (d0_FindOptiSyncFP < 256.0) {
      if (d0_FindOptiSyncFP >= 0.0) {
        u0_FindOptiSyncFP = (unsigned char)d0_FindOptiSyncFP;
      } else {
        u0_FindOptiSyncFP = 0;
      }
    } else if (d0_FindOptiSyncFP >= 256.0) {
      u0_FindOptiSyncFP = MAX_uint8_T;
    } else {
      u0_FindOptiSyncFP = 0;
    }

    if (iv0_FindOptiSyncFP[u0_FindOptiSyncFP - 1] > 0) {
      /* 'FindOptiSyncFixedPointImplement_fixpt:59' elseif circShiftSelect > fi(0, 0, 8, 0, fm) */
      /* 'FindOptiSyncFixedPointImplement_fixpt:60' pilotSequenceUpSampleShift = fi([fi(pilotSequenceUpSample(fi(end, 0, 16, 0, fm) - circShiftSelect + fi(1, 0, 8, 0, fm):fi(end, 0, 16, 0, fm)), 1, 16, 0, fm);pilotSequenceUpSample(fi(1, 0, 8, 0, fm):fi(end, 0, 16, 0, fm) - circShiftSelect)], 1, 16, 0, fm); */
      if (d0_FindOptiSyncFP < 256.0) {
        if (d0_FindOptiSyncFP >= 0.0) {
          u0_FindOptiSyncFP = (unsigned char)d0_FindOptiSyncFP;
        } else {
          u0_FindOptiSyncFP = 0;
        }
      } else if (d0_FindOptiSyncFP >= 256.0) {
        u0_FindOptiSyncFP = MAX_uint8_T;
      } else {
        u0_FindOptiSyncFP = 0;
      }

      i0_FindOptiSyncFP = iv0_FindOptiSyncFP[u0_FindOptiSyncFP - 1];
      if ((i0_FindOptiSyncFP & 131072) != 0) {
        i13_FindOptiSyncFP = i0_FindOptiSyncFP | -131072;
      } else {
        i13_FindOptiSyncFP = i0_FindOptiSyncFP & 131071;
      }

      i0_FindOptiSyncFP = 1536 - i13_FindOptiSyncFP;
      if ((i0_FindOptiSyncFP & 131072) != 0) {
        i0_FindOptiSyncFP |= -131072;
      } else {
        i0_FindOptiSyncFP &= 131071;
      }

      if ((i0_FindOptiSyncFP & 524288) != 0) {
        i14_FindOptiSyncFP = i0_FindOptiSyncFP | -524288;
      } else {
        i14_FindOptiSyncFP = i0_FindOptiSyncFP & 524287;
      }

      i0_FindOptiSyncFP = i14_FindOptiSyncFP + 1;
      if ((i0_FindOptiSyncFP & 524288) != 0) {
        i0_FindOptiSyncFP |= -524288;
      } else {
        i0_FindOptiSyncFP &= 524287;
      }

      colontype_FindOptiSyncFP(i0_FindOptiSyncFP);
      b_colontype_FindOptiSyncFP();
      if (d0_FindOptiSyncFP < 256.0) {
        if (d0_FindOptiSyncFP >= 0.0) {
          u0_FindOptiSyncFP = (unsigned char)d0_FindOptiSyncFP;
        } else {
          u0_FindOptiSyncFP = 0;
        }
      } else if (d0_FindOptiSyncFP >= 256.0) {
        u0_FindOptiSyncFP = MAX_uint8_T;
      } else {
        u0_FindOptiSyncFP = 0;
      }

      i1_FindOptiSyncFP = iv0_FindOptiSyncFP[u0_FindOptiSyncFP - 1];
      if ((i1_FindOptiSyncFP & 131072) != 0) {
        i16_FindOptiSyncFP = i1_FindOptiSyncFP | -131072;
      } else {
        i16_FindOptiSyncFP = i1_FindOptiSyncFP & 131071;
      }

      i1_FindOptiSyncFP = 1536 - i16_FindOptiSyncFP;
      if ((i1_FindOptiSyncFP & 131072) != 0) {
        idxChannel_FindOptiSyncFP = i1_FindOptiSyncFP | -131072;
      } else {
        idxChannel_FindOptiSyncFP = i1_FindOptiSyncFP & 131071;
      }

      loop_ub_FindOptiSyncFP = 1537 - i0_FindOptiSyncFP;
      for (i1_FindOptiSyncFP = 0; i1_FindOptiSyncFP < loop_ub_FindOptiSyncFP;
           i1_FindOptiSyncFP++) {
        pilotSequenceUpSampleShift_data[i1_FindOptiSyncFP].re =
          pilotSequenceUpSample_FindOptiS[(i0_FindOptiSyncFP + i1_FindOptiSyncFP)
          - 1].re;
        pilotSequenceUpSampleShift_data[i1_FindOptiSyncFP].im =
          pilotSequenceUpSample_FindOptiS[(i0_FindOptiSyncFP + i1_FindOptiSyncFP)
          - 1].im;
      }

      for (i1_FindOptiSyncFP = 0; i1_FindOptiSyncFP < idxChannel_FindOptiSyncFP;
           i1_FindOptiSyncFP++) {
        pilotSequenceUpSampleShift_data[(i1_FindOptiSyncFP - i0_FindOptiSyncFP)
          + 1537].re = pilotSequenceUpSample_FindOptiS[i1_FindOptiSyncFP].re;
        pilotSequenceUpSampleShift_data[(i1_FindOptiSyncFP - i0_FindOptiSyncFP)
          + 1537].im = pilotSequenceUpSample_FindOptiS[i1_FindOptiSyncFP].im;
      }
    } else {
      if (d0_FindOptiSyncFP < 256.0) {
        if (d0_FindOptiSyncFP >= 0.0) {
          u0_FindOptiSyncFP = (unsigned char)d0_FindOptiSyncFP;
        } else {
          u0_FindOptiSyncFP = 0;
        }
      } else if (d0_FindOptiSyncFP >= 256.0) {
        u0_FindOptiSyncFP = MAX_uint8_T;
      } else {
        u0_FindOptiSyncFP = 0;
      }

      if (iv0_FindOptiSyncFP[u0_FindOptiSyncFP - 1] < 0) {
        /* 'FindOptiSyncFixedPointImplement_fixpt:61' elseif circShiftSelect < fi(0, 0, 8, 0, fm) */
        /* 'FindOptiSyncFixedPointImplement_fixpt:62' pilotSequenceUpSampleShift = fi([fi(pilotSequenceUpSample(fi_uminus(circShiftSelect) + fi(1, 0, 8, 0, fm):fi(end, 0, 16, 0, fm)), 1, 16, 0, fm);pilotSequenceUpSample(fi(1, 0, 8, 0, fm):fi_uminus(circShiftSelect))], 1, 16, 0, fm); */
        /* 'FindOptiSyncFixedPointImplement_fixpt:89' coder.inline( 'always' ); */
        /* 'FindOptiSyncFixedPointImplement_fixpt:90' if isfi( a ) */
        /* 'FindOptiSyncFixedPointImplement_fixpt:91' nt = numerictype( a ); */
        /* 'FindOptiSyncFixedPointImplement_fixpt:92' new_nt = numerictype( 1, nt.WordLength + 1, nt.FractionLength ); */
        /* 'FindOptiSyncFixedPointImplement_fixpt:93' y = -fi( a, new_nt, fimath( a ) ); */
        if (d0_FindOptiSyncFP < 256.0) {
          if (d0_FindOptiSyncFP >= 0.0) {
            u0_FindOptiSyncFP = (unsigned char)d0_FindOptiSyncFP;
          } else {
            u0_FindOptiSyncFP = 0;
          }
        } else if (d0_FindOptiSyncFP >= 256.0) {
          u0_FindOptiSyncFP = MAX_uint8_T;
        } else {
          u0_FindOptiSyncFP = 0;
        }

        i4_FindOptiSyncFP = iv0_FindOptiSyncFP[u0_FindOptiSyncFP - 1];
        if ((short)(i4_FindOptiSyncFP & 256) != 0) {
          i4_FindOptiSyncFP = (short)-(short)(i4_FindOptiSyncFP | -256);
        } else {
          i4_FindOptiSyncFP = (short)-(short)(i4_FindOptiSyncFP & 255);
        }

        if ((short)(i4_FindOptiSyncFP & 256) != 0) {
          i4_FindOptiSyncFP |= -256;
        } else {
          i4_FindOptiSyncFP &= 255;
        }

        if ((short)(i4_FindOptiSyncFP & 1024) != 0) {
          i15_FindOptiSyncFP = (short)(i4_FindOptiSyncFP | -1024);
        } else {
          i15_FindOptiSyncFP = (short)(i4_FindOptiSyncFP & 1023);
        }

        i4_FindOptiSyncFP = (short)(i15_FindOptiSyncFP + 1);
        if ((short)(i4_FindOptiSyncFP & 1024) != 0) {
          i4_FindOptiSyncFP |= -1024;
        } else {
          i4_FindOptiSyncFP &= 1023;
        }

        c_colontype_FindOptiSyncFP(i4_FindOptiSyncFP);

        /* 'FindOptiSyncFixedPointImplement_fixpt:89' coder.inline( 'always' ); */
        /* 'FindOptiSyncFixedPointImplement_fixpt:90' if isfi( a ) */
        /* 'FindOptiSyncFixedPointImplement_fixpt:91' nt = numerictype( a ); */
        /* 'FindOptiSyncFixedPointImplement_fixpt:92' new_nt = numerictype( 1, nt.WordLength + 1, nt.FractionLength ); */
        /* 'FindOptiSyncFixedPointImplement_fixpt:93' y = -fi( a, new_nt, fimath( a ) ); */
        d_colontype_FindOptiSyncFP();
        if (d0_FindOptiSyncFP < 256.0) {
          if (d0_FindOptiSyncFP >= 0.0) {
            u0_FindOptiSyncFP = (unsigned char)d0_FindOptiSyncFP;
          } else {
            u0_FindOptiSyncFP = 0;
          }
        } else if (d0_FindOptiSyncFP >= 256.0) {
          u0_FindOptiSyncFP = MAX_uint8_T;
        } else {
          u0_FindOptiSyncFP = 0;
        }

        i8_FindOptiSyncFP = iv0_FindOptiSyncFP[u0_FindOptiSyncFP - 1];
        if ((short)(i8_FindOptiSyncFP & 256) != 0) {
          i8_FindOptiSyncFP = (short)-(short)(i8_FindOptiSyncFP | -256);
        } else {
          i8_FindOptiSyncFP = (short)-(short)(i8_FindOptiSyncFP & 255);
        }

        if ((short)(i8_FindOptiSyncFP & 256) != 0) {
          i17_FindOptiSyncFP = (short)(i8_FindOptiSyncFP | -256);
        } else {
          i17_FindOptiSyncFP = (short)(i8_FindOptiSyncFP & 255);
        }

        idxChannel_FindOptiSyncFP = i17_FindOptiSyncFP - 1;
        loop_ub_FindOptiSyncFP = -i4_FindOptiSyncFP;
        for (i0_FindOptiSyncFP = 0; i0_FindOptiSyncFP <= loop_ub_FindOptiSyncFP
             + 1536; i0_FindOptiSyncFP++) {
          pilotSequenceUpSampleShift_data[i0_FindOptiSyncFP].re =
            pilotSequenceUpSample_FindOptiS[(i4_FindOptiSyncFP +
            i0_FindOptiSyncFP) - 1].re;
          pilotSequenceUpSampleShift_data[i0_FindOptiSyncFP].im =
            pilotSequenceUpSample_FindOptiS[(i4_FindOptiSyncFP +
            i0_FindOptiSyncFP) - 1].im;
        }

        for (i0_FindOptiSyncFP = 0; i0_FindOptiSyncFP <=
             idxChannel_FindOptiSyncFP; i0_FindOptiSyncFP++) {
          pilotSequenceUpSampleShift_data[(i0_FindOptiSyncFP - i4_FindOptiSyncFP)
            + 1537].re = pilotSequenceUpSample_FindOptiS[i0_FindOptiSyncFP].re;
          pilotSequenceUpSampleShift_data[(i0_FindOptiSyncFP - i4_FindOptiSyncFP)
            + 1537].im = pilotSequenceUpSample_FindOptiS[i0_FindOptiSyncFP].im;
        }
      }
    }
  }

  /*  for fixed point */
  /* 'FindOptiSyncFixedPointImplement_fixpt:65' pilotSequence = fi(complex(zeros(fi_toint(LenPilot), 1)), 1, 16, 0, fm); */
  memset(&pilotSequence_FindOptiSyncFP[0], 0, sizeof(cint16_T) << 9);

  /* 'FindOptiSyncFixedPointImplement_fixpt:66' for idxDownSample = fi(1, 0, 8, 0, fm):LenPilot */
  for (idxChannel_FindOptiSyncFP = 0; idxChannel_FindOptiSyncFP < 512;
       idxChannel_FindOptiSyncFP++) {
    idxDownSample_FindOptiSyncFP = (unsigned short)(idxChannel_FindOptiSyncFP +
      1);

    /* 'FindOptiSyncFixedPointImplement_fixpt:67' pilotSequence(idxDownSample) = pilotSequenceUpSampleShift(fi(idxDownSample, 0, 16, 0, fm)*fi(3, 0, 8, 0, fm) - fi(2, 0, 8, 0, fm)); */
    pilotSequence_FindOptiSyncFP[idxDownSample_FindOptiSyncFP - 1].re =
      pilotSequenceUpSampleShift_data[(int)((idxDownSample_FindOptiSyncFP * 3U -
      2U) & 33554431U) - 1].re;
    pilotSequence_FindOptiSyncFP[idxDownSample_FindOptiSyncFP - 1].im =
      pilotSequenceUpSampleShift_data[(int)((idxDownSample_FindOptiSyncFP * 3U -
      2U) & 33554431U) - 1].im;
  }
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void FindOptiSyncFixedPointImplement_fixpt_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void FindOptiSyncFixedPointImplement_fixpt_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for FindOptiSyncFixedPointImplement_fixpt.c
 *
 * [EOF]
 */
