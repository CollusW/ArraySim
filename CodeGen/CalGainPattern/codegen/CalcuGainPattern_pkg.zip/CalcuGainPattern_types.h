/*
 * File: CalcuGainPattern_types.h
 *
 * MATLAB Coder version            : 3.4
 * C/C++ source code generated on  : 18-Jan-2018 15:38:59
 */

#ifndef CALCUGAINPATTERN_TYPES_H
#define CALCUGAINPATTERN_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for CalcuGainPattern_types.h
 *
 * [EOF]
 */
