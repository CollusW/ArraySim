/*
 * File: FindOptiSyncImplement.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 25-Jan-2018 15:37:24
 */

#ifndef FINDOPTISYNCIMPLEMENT_H
#define FINDOPTISYNCIMPLEMENT_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "FindOptiSyncImplement_types.h"

/* Function Declarations */
extern void FindOptiSyncImplement(const creal_T rxSigNoise_FindOptiSync[2048],
  const creal_T pilotSequenceUpSample_FindOptiS[1536], double
  UpSampleTimes_FindOptiSync, double LenSearch_FindOptiSync, creal_T
  pilotSequence_data_FindOptiSync[], int pilotSequence_size_FindOptiSync[1],
  double *numSyncChannel_FindOptiSync, double *circShiftSelect_FindOptiSync);
extern void FindOptiSyncImplement_initialize(void);
extern void FindOptiSyncImplement_terminate(void);

#endif

/*
 * File trailer for FindOptiSyncImplement.h
 *
 * [EOF]
 */
