/*
 * File: FindOptiSyncImplement.h
 *
 * MATLAB Coder version            : 3.4
 * C/C++ source code generated on  : 25-May-2018 11:36:01
 */

#ifndef FINDOPTISYNCIMPLEMENT_H
#define FINDOPTISYNCIMPLEMENT_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "FindOptiSyncImplement_types.h"

/* Function Declarations */
extern void FindOptiSyncImplement(const creal_T rxSigNoise_FindOptSync[2048],
  const creal_T pilotSequenceUpSample_FindOptSync[1536], double
  UpSampleTimes_FindOptSync, double LenSearch_FindOptSync, creal_T
  pilotSequence_data_FindOptSync[], int pilotSequence_size_FindOptSync[1],
  double *numSyncChannel_FindOptSync, double *circShiftSelect_FindOptSync);
extern void FindOptiSyncImplement_initialize(void);
extern void FindOptiSyncImplement_terminate(void);

#endif

/*
 * File trailer for FindOptiSyncImplement.h
 *
 * [EOF]
 */
