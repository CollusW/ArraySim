/*
 * File: FindOptiSyncImplement_types.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 25-Jan-2018 15:37:24
 */

#ifndef FINDOPTISYNCIMPLEMENT_TYPES_H
#define FINDOPTISYNCIMPLEMENT_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for FindOptiSyncImplement_types.h
 *
 * [EOF]
 */
