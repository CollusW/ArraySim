/*
 * File: FindOptiSyncImplement_types.h
 *
 * MATLAB Coder version            : 3.4
 * C/C++ source code generated on  : 25-May-2018 11:36:01
 */

#ifndef FINDOPTISYNCIMPLEMENT_TYPES_H
#define FINDOPTISYNCIMPLEMENT_TYPES_H

/* Include Files */
#include "rtwtypes.h"

/* Type Definitions */
#ifndef struct_emxArray_creal_T_FindOptSync
#define struct_emxArray_creal_T_FindOptSync

struct emxArray_creal_T_FindOptSync
{
  creal_T *data_FindOptSync;
  int *size_FindOptSync;
  int allocatedSize_FindOptSync;
  int numDimensions_FindOptSync;
  boolean_T canFreeData_FindOptSync;
};

#endif                                 /*struct_emxArray_creal_T_FindOptSync*/

#ifndef typedef_emxArray_creal_T_FindOptSync
#define typedef_emxArray_creal_T_FindOptSync

typedef struct emxArray_creal_T_FindOptSync emxArray_creal_T_FindOptSync;

#endif                                 /*typedef_emxArray_creal_T_FindOptSync*/

#ifndef struct_emxArray_int32_T_FindOptSync
#define struct_emxArray_int32_T_FindOptSync

struct emxArray_int32_T_FindOptSync
{
  int *data_FindOptSync;
  int *size_FindOptSync;
  int allocatedSize_FindOptSync;
  int numDimensions_FindOptSync;
  boolean_T canFreeData_FindOptSync;
};

#endif                                 /*struct_emxArray_int32_T_FindOptSync*/

#ifndef typedef_emxArray_int32_T_FindOptSync
#define typedef_emxArray_int32_T_FindOptSync

typedef struct emxArray_int32_T_FindOptSync emxArray_int32_T_FindOptSync;

#endif                                 /*typedef_emxArray_int32_T_FindOptSync*/

#ifndef struct_emxArray_int8_T_FindOptSync
#define struct_emxArray_int8_T_FindOptSync

struct emxArray_int8_T_FindOptSync
{
  signed char *data_FindOptSync;
  int *size_FindOptSync;
  int allocatedSize_FindOptSync;
  int numDimensions_FindOptSync;
  boolean_T canFreeData_FindOptSync;
};

#endif                                 /*struct_emxArray_int8_T_FindOptSync*/

#ifndef typedef_emxArray_int8_T_FindOptSync
#define typedef_emxArray_int8_T_FindOptSync

typedef struct emxArray_int8_T_FindOptSync emxArray_int8_T_FindOptSync;

#endif                                 /*typedef_emxArray_int8_T_FindOptSync*/

#ifndef struct_emxArray_real_T_FindOptSync
#define struct_emxArray_real_T_FindOptSync

struct emxArray_real_T_FindOptSync
{
  double *data_FindOptSync;
  int *size_FindOptSync;
  int allocatedSize_FindOptSync;
  int numDimensions_FindOptSync;
  boolean_T canFreeData_FindOptSync;
};

#endif                                 /*struct_emxArray_real_T_FindOptSync*/

#ifndef typedef_emxArray_real_T_FindOptSync
#define typedef_emxArray_real_T_FindOptSync

typedef struct emxArray_real_T_FindOptSync emxArray_real_T_FindOptSync;

#endif                                 /*typedef_emxArray_real_T_FindOptSync*/
#endif

/*
 * File trailer for FindOptiSyncImplement_types.h
 *
 * [EOF]
 */
