/*
 * File: FindOptiSyncImplement.c
 *
 * MATLAB Coder version            : 3.4
 * C/C++ source code generated on  : 25-May-2018 11:36:01
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "FindOptiSyncImplement.h"
#include "FindOptiSyncImplement_emxutil.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Type Definitions */
#ifndef typedef_rtBoundsCheckInfo_FindOptSync
#define typedef_rtBoundsCheckInfo_FindOptSync

typedef struct {
  int iFirst_FindOptSync;
  int iLast_FindOptSync;
  int lineNo_FindOptSync;
  int colNo_FindOptSync;
  const char * aName_FindOptSync;
  const char * fName_FindOptSync;
  const char * pName_FindOptSync;
  int checkKind_FindOptSync;
} rtBoundsCheckInfo_FindOptSync;

#endif                                 /*typedef_rtBoundsCheckInfo_FindOptSync*/

#ifndef typedef_rtDoubleCheckInfo_FindOptSync
#define typedef_rtDoubleCheckInfo_FindOptSync

typedef struct {
  int lineNo_FindOptSync;
  int colNo_FindOptSync;
  const char * fName_FindOptSync;
  const char * pName_FindOptSync;
  int checkKind_FindOptSync;
} rtDoubleCheckInfo_FindOptSync;

#endif                                 /*typedef_rtDoubleCheckInfo_FindOptSync*/

#ifndef typedef_rtEqualityCheckInfo_FindOptSync
#define typedef_rtEqualityCheckInfo_FindOptSync

typedef struct {
  int nDims_FindOptSync;
  int lineNo_FindOptSync;
  int colNo_FindOptSync;
  const char * fName_FindOptSync;
  const char * pName_FindOptSync;
} rtEqualityCheckInfo_FindOptSync;

#endif                                 /*typedef_rtEqualityCheckInfo_FindOptSync*/

#ifndef typedef_rtRunTimeErrorInfo_FindOptSync
#define typedef_rtRunTimeErrorInfo_FindOptSync

typedef struct {
  int lineNo_FindOptSync;
  int colNo_FindOptSync;
  const char * fName_FindOptSync;
  const char * pName_FindOptSync;
} rtRunTimeErrorInfo_FindOptSync;

#endif                                 /*typedef_rtRunTimeErrorInfo_FindOptSync*/

/* Variable Definitions */
static rtRunTimeErrorInfo_FindOptSync emlrtRTEI_FindOptSync = { 86,/* lineNo_FindOptSync */
  1,                                   /* colNo_FindOptSync */
  "downsample",                        /* fName_FindOptSync */
  "D:\\Program Files\\MATLAB\\R2017b\\toolbox\\signal\\eml\\downsample.m"/* pName_FindOptSync */
};

static rtRunTimeErrorInfo_FindOptSync b_emlrtRTEI_FindOptSync = { 33,/* lineNo_FindOptSync */
  5,                                   /* colNo_FindOptSync */
  "downsample",                        /* fName_FindOptSync */
  "D:\\Program Files\\MATLAB\\R2017b\\toolbox\\signal\\eml\\downsample.m"/* pName_FindOptSync */
};

static rtRunTimeErrorInfo_FindOptSync c_emlrtRTEI_FindOptSync = { 24,/* lineNo_FindOptSync */
  5,                                   /* colNo_FindOptSync */
  "downsample",                        /* fName_FindOptSync */
  "D:\\Program Files\\MATLAB\\R2017b\\toolbox\\signal\\eml\\downsample.m"/* pName_FindOptSync */
};

static rtRunTimeErrorInfo_FindOptSync d_emlrtRTEI_FindOptSync = { 121,/* lineNo_FindOptSync */
  27,                                  /* colNo_FindOptSync */
  "minOrMax",                          /* fName_FindOptSync */
  "D:\\Program Files\\MATLAB\\R2017b\\toolbox\\eml\\eml\\+coder\\+internal\\minOrMax.m"/* pName_FindOptSync */
};

static rtRunTimeErrorInfo_FindOptSync e_emlrtRTEI_FindOptSync = { 39,/* lineNo_FindOptSync */
  27,                                  /* colNo_FindOptSync */
  "minOrMax",                          /* fName_FindOptSync */
  "D:\\Program Files\\MATLAB\\R2017b\\toolbox\\eml\\eml\\+coder\\+internal\\minOrMax.m"/* pName_FindOptSync */
};

static rtRunTimeErrorInfo_FindOptSync f_emlrtRTEI_FindOptSync = { 99,/* lineNo_FindOptSync */
  23,                                  /* colNo_FindOptSync */
  "eml_mtimes_helper",                 /* fName_FindOptSync */
  "D:\\Program Files\\MATLAB\\R2017b\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_helper.m"/* pName_FindOptSync */
};

static rtRunTimeErrorInfo_FindOptSync g_emlrtRTEI_FindOptSync = { 104,/* lineNo_FindOptSync */
  23,                                  /* colNo_FindOptSync */
  "eml_mtimes_helper",                 /* fName_FindOptSync */
  "D:\\Program Files\\MATLAB\\R2017b\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_helper.m"/* pName_FindOptSync */
};

static rtDoubleCheckInfo_FindOptSync emlrtDCI_FindOptSync = { 29,/* lineNo_FindOptSync */
  100,                                 /* colNo_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  1                                    /* checkKind_FindOptSync */
};

static rtBoundsCheckInfo_FindOptSync emlrtBCI_FindOptSync = { -1,/* iFirst_FindOptSync */
  -1,                                  /* iLast_FindOptSync */
  29,                                  /* lineNo_FindOptSync */
  114,                                 /* colNo_FindOptSync */
  "pilotSequenceUpSampleMat",          /* aName_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  0                                    /* checkKind_FindOptSync */
};

static rtDoubleCheckInfo_FindOptSync b_emlrtDCI_FindOptSync = { 29,/* lineNo_FindOptSync */
  114,                                 /* colNo_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  1                                    /* checkKind_FindOptSync */
};

static rtBoundsCheckInfo_FindOptSync b_emlrtBCI_FindOptSync = { -1,/* iFirst_FindOptSync */
  -1,                                  /* iLast_FindOptSync */
  29,                                  /* lineNo_FindOptSync */
  98,                                  /* colNo_FindOptSync */
  "pilotSequenceUpSampleMat",          /* aName_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  0                                    /* checkKind_FindOptSync */
};

static rtEqualityCheckInfo_FindOptSync emlrtECI_FindOptSync = { -1,/* nDims_FindOptSync */
  26,                                  /* lineNo_FindOptSync */
  5,                                   /* colNo_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m"/* pName_FindOptSync */
};

static rtBoundsCheckInfo_FindOptSync c_emlrtBCI_FindOptSync = { -1,/* iFirst_FindOptSync */
  -1,                                  /* iLast_FindOptSync */
  26,                                  /* lineNo_FindOptSync */
  32,                                  /* colNo_FindOptSync */
  "pilotSequenceUpSampleMat",          /* aName_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  0                                    /* checkKind_FindOptSync */
};

static rtDoubleCheckInfo_FindOptSync c_emlrtDCI_FindOptSync = { 29,/* lineNo_FindOptSync */
  33,                                  /* colNo_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  1                                    /* checkKind_FindOptSync */
};

static rtBoundsCheckInfo_FindOptSync d_emlrtBCI_FindOptSync = { -1,/* iFirst_FindOptSync */
  -1,                                  /* iLast_FindOptSync */
  29,                                  /* lineNo_FindOptSync */
  47,                                  /* colNo_FindOptSync */
  "rxSigNoiseUpSample",                /* aName_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  0                                    /* checkKind_FindOptSync */
};

static rtDoubleCheckInfo_FindOptSync d_emlrtDCI_FindOptSync = { 29,/* lineNo_FindOptSync */
  47,                                  /* colNo_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  1                                    /* checkKind_FindOptSync */
};

static rtBoundsCheckInfo_FindOptSync e_emlrtBCI_FindOptSync = { -1,/* iFirst_FindOptSync */
  -1,                                  /* iLast_FindOptSync */
  29,                                  /* lineNo_FindOptSync */
  31,                                  /* colNo_FindOptSync */
  "rxSigNoiseUpSample",                /* aName_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  0                                    /* checkKind_FindOptSync */
};

static rtDoubleCheckInfo_FindOptSync e_emlrtDCI_FindOptSync = { 20,/* lineNo_FindOptSync */
  34,                                  /* colNo_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  1                                    /* checkKind_FindOptSync */
};

static rtDoubleCheckInfo_FindOptSync f_emlrtDCI_FindOptSync = { 20,/* lineNo_FindOptSync */
  34,                                  /* colNo_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  4                                    /* checkKind_FindOptSync */
};

static rtDoubleCheckInfo_FindOptSync g_emlrtDCI_FindOptSync = { 24,/* lineNo_FindOptSync */
  42,                                  /* colNo_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  1                                    /* checkKind_FindOptSync */
};

static rtDoubleCheckInfo_FindOptSync h_emlrtDCI_FindOptSync = { 24,/* lineNo_FindOptSync */
  42,                                  /* colNo_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  4                                    /* checkKind_FindOptSync */
};

static rtDoubleCheckInfo_FindOptSync i_emlrtDCI_FindOptSync = { 24,/* lineNo_FindOptSync */
  66,                                  /* colNo_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  1                                    /* checkKind_FindOptSync */
};

static rtDoubleCheckInfo_FindOptSync j_emlrtDCI_FindOptSync = { 20,/* lineNo_FindOptSync */
  1,                                   /* colNo_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  1                                    /* checkKind_FindOptSync */
};

static rtDoubleCheckInfo_FindOptSync k_emlrtDCI_FindOptSync = { 20,/* lineNo_FindOptSync */
  1,                                   /* colNo_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  4                                    /* checkKind_FindOptSync */
};

static rtDoubleCheckInfo_FindOptSync l_emlrtDCI_FindOptSync = { 24,/* lineNo_FindOptSync */
  1,                                   /* colNo_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  1                                    /* checkKind_FindOptSync */
};

static rtDoubleCheckInfo_FindOptSync m_emlrtDCI_FindOptSync = { 24,/* lineNo_FindOptSync */
  1,                                   /* colNo_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  4                                    /* checkKind_FindOptSync */
};

static rtBoundsCheckInfo_FindOptSync f_emlrtBCI_FindOptSync = { -1,/* iFirst_FindOptSync */
  -1,                                  /* iLast_FindOptSync */
  33,                                  /* lineNo_FindOptSync */
  5,                                   /* colNo_FindOptSync */
  "syncIndexMat",                      /* aName_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  0                                    /* checkKind_FindOptSync */
};

static rtBoundsCheckInfo_FindOptSync g_emlrtBCI_FindOptSync = { -1,/* iFirst_FindOptSync */
  -1,                                  /* iLast_FindOptSync */
  37,                                  /* lineNo_FindOptSync */
  19,                                  /* colNo_FindOptSync */
  "circShiftPattern",                  /* aName_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  0                                    /* checkKind_FindOptSync */
};

static rtDoubleCheckInfo_FindOptSync n_emlrtDCI_FindOptSync = { 89,/* lineNo_FindOptSync */
  33,                                  /* colNo_FindOptSync */
  "downsample",                        /* fName_FindOptSync */
  "D:\\Program Files\\MATLAB\\R2017b\\toolbox\\signal\\eml\\downsample.m",/* pName_FindOptSync */
  4                                    /* checkKind_FindOptSync */
};

static rtBoundsCheckInfo_FindOptSync h_emlrtBCI_FindOptSync = { 1,/* iFirst_FindOptSync */
  1536,                                /* iLast_FindOptSync */
  72,                                  /* lineNo_FindOptSync */
  17,                                  /* colNo_FindOptSync */
  "",                                  /* aName_FindOptSync */
  "downsample",                        /* fName_FindOptSync */
  "D:\\Program Files\\MATLAB\\R2017b\\toolbox\\signal\\eml\\downsample.m",/* pName_FindOptSync */
  0                                    /* checkKind_FindOptSync */
};

static rtBoundsCheckInfo_FindOptSync i_emlrtBCI_FindOptSync = { -1,/* iFirst_FindOptSync */
  -1,                                  /* iLast_FindOptSync */
  72,                                  /* lineNo_FindOptSync */
  9,                                   /* colNo_FindOptSync */
  "",                                  /* aName_FindOptSync */
  "downsample",                        /* fName_FindOptSync */
  "D:\\Program Files\\MATLAB\\R2017b\\toolbox\\signal\\eml\\downsample.m",/* pName_FindOptSync */
  0                                    /* checkKind_FindOptSync */
};

static rtBoundsCheckInfo_FindOptSync j_emlrtBCI_FindOptSync = { -1,/* iFirst_FindOptSync */
  -1,                                  /* iLast_FindOptSync */
  26,                                  /* lineNo_FindOptSync */
  77,                                  /* colNo_FindOptSync */
  "circShiftPattern",                  /* aName_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  0                                    /* checkKind_FindOptSync */
};

static rtBoundsCheckInfo_FindOptSync k_emlrtBCI_FindOptSync = { -1,/* iFirst_FindOptSync */
  -1,                                  /* iLast_FindOptSync */
  39,                                  /* lineNo_FindOptSync */
  1,                                   /* colNo_FindOptSync */
  "",                                  /* aName_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  0                                    /* checkKind_FindOptSync */
};

static rtBoundsCheckInfo_FindOptSync l_emlrtBCI_FindOptSync = { 1,/* iFirst_FindOptSync */
  1536,                                /* iLast_FindOptSync */
  39,                                  /* lineNo_FindOptSync */
  1,                                   /* colNo_FindOptSync */
  "",                                  /* aName_FindOptSync */
  "FindOptiSyncImplement",             /* fName_FindOptSync */
  "E:\\Work\\Matlab\\SandboxArraySimGit\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",/* pName_FindOptSync */
  0                                    /* checkKind_FindOptSync */
};

static rtRunTimeErrorInfo_FindOptSync h_emlrtRTEI_FindOptSync = { 32,/* lineNo_FindOptSync */
  5,                                   /* colNo_FindOptSync */
  "upsample",                          /* fName_FindOptSync */
  "D:\\Program Files\\MATLAB\\R2017b\\toolbox\\signal\\eml\\upsample.m"/* pName_FindOptSync */
};

static rtRunTimeErrorInfo_FindOptSync i_emlrtRTEI_FindOptSync = { 44,/* lineNo_FindOptSync */
  5,                                   /* colNo_FindOptSync */
  "upsample",                          /* fName_FindOptSync */
  "D:\\Program Files\\MATLAB\\R2017b\\toolbox\\signal\\eml\\upsample.m"/* pName_FindOptSync */
};

static rtBoundsCheckInfo_FindOptSync m_emlrtBCI_FindOptSync = { 1,/* iFirst_FindOptSync */
  2048,                                /* iLast_FindOptSync */
  77,                                  /* lineNo_FindOptSync */
  17,                                  /* colNo_FindOptSync */
  "",                                  /* aName_FindOptSync */
  "upsample",                          /* fName_FindOptSync */
  "D:\\Program Files\\MATLAB\\R2017b\\toolbox\\signal\\eml\\upsample.m",/* pName_FindOptSync */
  0                                    /* checkKind_FindOptSync */
};

static rtBoundsCheckInfo_FindOptSync n_emlrtBCI_FindOptSync = { -1,/* iFirst_FindOptSync */
  -1,                                  /* iLast_FindOptSync */
  77,                                  /* lineNo_FindOptSync */
  9,                                   /* colNo_FindOptSync */
  "",                                  /* aName_FindOptSync */
  "upsample",                          /* fName_FindOptSync */
  "D:\\Program Files\\MATLAB\\R2017b\\toolbox\\signal\\eml\\upsample.m",/* pName_FindOptSync */
  0                                    /* checkKind_FindOptSync */
};

static rtBoundsCheckInfo_FindOptSync o_emlrtBCI_FindOptSync = { 1,/* iFirst_FindOptSync */
  2048,                                /* iLast_FindOptSync */
  77,                                  /* lineNo_FindOptSync */
  9,                                   /* colNo_FindOptSync */
  "",                                  /* aName_FindOptSync */
  "upsample",                          /* fName_FindOptSync */
  "D:\\Program Files\\MATLAB\\R2017b\\toolbox\\signal\\eml\\upsample.m",/* pName_FindOptSync */
  0                                    /* checkKind_FindOptSync */
};

static rtRunTimeErrorInfo_FindOptSync j_emlrtRTEI_FindOptSync = { 87,/* lineNo_FindOptSync */
  15,                                  /* colNo_FindOptSync */
  "eml_int_forloop_overflow_check",    /* fName_FindOptSync */
  "D:\\Program Files\\MATLAB\\R2017b\\toolbox\\eml\\lib\\matlab\\eml\\eml_int_forloop_overflow_check.m"/* pName_FindOptSync */
};

static rtRunTimeErrorInfo_FindOptSync k_emlrtRTEI_FindOptSync = { 29,/* lineNo_FindOptSync */
  48,                                  /* colNo_FindOptSync */
  "circshift",                         /* fName_FindOptSync */
  "D:\\Program Files\\MATLAB\\R2017b\\toolbox\\eml\\lib\\matlab\\elmat\\circshift.m"/* pName_FindOptSync */
};

/* Function Declarations */
static void abs_FindOptSync(const emxArray_creal_T_FindOptSync *x_FindOptSync,
  emxArray_real_T_FindOptSync *y_FindOptSync);
static void b_rtErrorWithMessageID_FindOptSync(const int b_FindOptSync, const
  char *c_FindOptSync, const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync);
static void c_rtErrorWithMessageID_FindOptSync(const int b_FindOptSync, const
  char *c_FindOptSync, const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync);
static void check_forloop_overflow_error_FindOptSync(void);
static void circshift_FindOptSync(creal_T a_FindOptSync[1536], double
  p_FindOptSync);
static void d_rtErrorWithMessageID_FindOptSync(const
  rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync);
static int div_s32_floor_FindOptSync(int numerator_FindOptSync, int
  denominator_FindOptSync);
static void e_rtErrorWithMessageID_FindOptSync(const
  rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync);
static void f_rtErrorWithMessageID_FindOptSync(const
  rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync);
static void g_rtErrorWithMessageID_FindOptSync(const
  rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync);
static void h_rtErrorWithMessageID_FindOptSync(const int b_FindOptSync, const
  char *c_FindOptSync, const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync);
static void i_rtErrorWithMessageID_FindOptSync(const int b_FindOptSync, const
  char *c_FindOptSync, const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync);
static boolean_T inrange_FindOptSync(double p_FindOptSync);
static void j_rtErrorWithMessageID_FindOptSync(const int b_FindOptSync, const
  char *c_FindOptSync, const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync);
static void k_rtErrorWithMessageID_FindOptSync(const int b_FindOptSync, const
  char *c_FindOptSync, const int d_FindOptSync, const char *e_FindOptSync, const
  rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync);
static void rtAddSizeString_FindOptSync(char *aBuf_FindOptSync, const int
  aDim_FindOptSync);
static void rtDivisionByZeroError_FindOptSync(const
  rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync);
static void rtDynamicBoundsError_FindOptSync(int aIndexValue_FindOptSync, int
  aLoBound_FindOptSync, int aHiBound_FindOptSync, const
  rtBoundsCheckInfo_FindOptSync *aInfo_FindOptSync);
static void rtErrorWithMessageID_FindOptSync(const
  rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync);
static void rtGenSizeString_FindOptSync(const int aNDims_FindOptSync, const int *
  aDims_FindOptSync, char *aBuf_FindOptSync);
static void rtIntegerError_FindOptSync(const double aInteger_FindOptSync, const
  rtDoubleCheckInfo_FindOptSync *aInfo_FindOptSync);
static boolean_T rtIsNullOrEmptyString_FindOptSync(const char
  *aString_FindOptSync);
static void rtNonNegativeError_FindOptSync(const double aPositive_FindOptSync,
  const rtDoubleCheckInfo_FindOptSync *aInfo_FindOptSync);
static void rtReportErrorLocation_FindOptSync(const char * aFcnName_FindOptSync,
  const int aLineNo_FindOptSync);
static void rtSubAssignSizeCheck_FindOptSync(const int *aDims1_FindOptSync,
  const int aNDims1_FindOptSync, const int *aDims2_FindOptSync, const int
  aNDims2_FindOptSync, const rtEqualityCheckInfo_FindOptSync *aInfo_FindOptSync);
static double rt_hypotd_snf_FindOptSync(double u0_FindOptSync, double
  u1_FindOptSync);
static void upsample_FindOptSync(const creal_T x_FindOptSync[2048], double
  N_FindOptSync, emxArray_creal_T_FindOptSync *y_FindOptSync);

/* Function Definitions */

/*
 * Arguments    : const emxArray_creal_T_FindOptSync *x_FindOptSync
 *                emxArray_real_T_FindOptSync *y_FindOptSync
 * Return Type  : void
 */
static void abs_FindOptSync(const emxArray_creal_T_FindOptSync *x_FindOptSync,
  emxArray_real_T_FindOptSync *y_FindOptSync)
{
  int nx_FindOptSync;
  int k_FindOptSync;
  nx_FindOptSync = x_FindOptSync->size_FindOptSync[0] << 2;
  k_FindOptSync = y_FindOptSync->size_FindOptSync[0] *
    y_FindOptSync->size_FindOptSync[1];
  y_FindOptSync->size_FindOptSync[0] = x_FindOptSync->size_FindOptSync[0];
  y_FindOptSync->size_FindOptSync[1] = 4;
  emxEnsureCapacity_real_T_FindOptSync(y_FindOptSync, k_FindOptSync);
  if ((!(1 > nx_FindOptSync)) && (nx_FindOptSync > 2147483646)) {
    check_forloop_overflow_error_FindOptSync();
  }

  for (k_FindOptSync = 0; k_FindOptSync + 1 <= nx_FindOptSync; k_FindOptSync++)
  {
    y_FindOptSync->data_FindOptSync[k_FindOptSync] = rt_hypotd_snf_FindOptSync
      (x_FindOptSync->data_FindOptSync[k_FindOptSync].re,
       x_FindOptSync->data_FindOptSync[k_FindOptSync].im);
  }
}

/*
 * Arguments    : const int b_FindOptSync
 *                const char *c_FindOptSync
 *                const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync
 * Return Type  : void
 */
static void b_rtErrorWithMessageID_FindOptSync(const int b_FindOptSync, const
  char *c_FindOptSync, const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync)
{
  fprintf(stderr, "%.*s", b_FindOptSync, c_FindOptSync);
  fprintf(stderr, "\n");
  if (aInfo_FindOptSync != NULL) {
    rtReportErrorLocation_FindOptSync(aInfo_FindOptSync->fName_FindOptSync,
      aInfo_FindOptSync->lineNo_FindOptSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const int b_FindOptSync
 *                const char *c_FindOptSync
 *                const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync
 * Return Type  : void
 */
static void c_rtErrorWithMessageID_FindOptSync(const int b_FindOptSync, const
  char *c_FindOptSync, const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync)
{
  fprintf(stderr, "%.*s", b_FindOptSync, c_FindOptSync);
  fprintf(stderr, "\n");
  if (aInfo_FindOptSync != NULL) {
    rtReportErrorLocation_FindOptSync(aInfo_FindOptSync->fName_FindOptSync,
      aInfo_FindOptSync->lineNo_FindOptSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : void
 * Return Type  : void
 */
static void check_forloop_overflow_error_FindOptSync(void)
{
  j_rtErrorWithMessageID_FindOptSync(5, "int32", &j_emlrtRTEI_FindOptSync);
}

/*
 * Arguments    : creal_T a_FindOptSync[1536]
 *                double p_FindOptSync
 * Return Type  : void
 */
static void circshift_FindOptSync(creal_T a_FindOptSync[1536], double
  p_FindOptSync)
{
  int ns_FindOptSync;
  boolean_T shiftright_FindOptSync;
  creal_T unusedU0_FindOptSync[768];
  int k_FindOptSync;
  if (!inrange_FindOptSync(p_FindOptSync)) {
    k_rtErrorWithMessageID_FindOptSync(5, "int32", 5, "int32",
      &k_emlrtRTEI_FindOptSync);
  }

  if (p_FindOptSync < 0.0) {
    ns_FindOptSync = (int)-p_FindOptSync;
    shiftright_FindOptSync = false;
  } else {
    ns_FindOptSync = (int)p_FindOptSync;
    shiftright_FindOptSync = true;
  }

  if (ns_FindOptSync > 1536) {
    ns_FindOptSync -= ns_FindOptSync / 1536 * 1536;
  }

  if (ns_FindOptSync > 768) {
    ns_FindOptSync = 1536 - ns_FindOptSync;
    shiftright_FindOptSync = !shiftright_FindOptSync;
  }

  memset(&unusedU0_FindOptSync[0], 0, 768U * sizeof(creal_T));
  if (ns_FindOptSync > 0) {
    if (shiftright_FindOptSync) {
      for (k_FindOptSync = 1; k_FindOptSync <= ns_FindOptSync; k_FindOptSync++)
      {
        unusedU0_FindOptSync[k_FindOptSync - 1] = a_FindOptSync[(k_FindOptSync -
          ns_FindOptSync) + 1535];
      }

      for (k_FindOptSync = 1535; k_FindOptSync + 1 >= ns_FindOptSync + 1;
           k_FindOptSync--) {
        a_FindOptSync[k_FindOptSync] = a_FindOptSync[k_FindOptSync -
          ns_FindOptSync];
      }

      for (k_FindOptSync = 0; k_FindOptSync + 1 <= ns_FindOptSync; k_FindOptSync
           ++) {
        a_FindOptSync[k_FindOptSync] = unusedU0_FindOptSync[k_FindOptSync];
      }
    } else {
      for (k_FindOptSync = 0; k_FindOptSync + 1 <= ns_FindOptSync; k_FindOptSync
           ++) {
        unusedU0_FindOptSync[k_FindOptSync] = a_FindOptSync[k_FindOptSync];
      }

      for (k_FindOptSync = 0; k_FindOptSync + 1 <= 1536 - ns_FindOptSync;
           k_FindOptSync++) {
        a_FindOptSync[k_FindOptSync] = a_FindOptSync[k_FindOptSync +
          ns_FindOptSync];
      }

      for (k_FindOptSync = 1; k_FindOptSync <= ns_FindOptSync; k_FindOptSync++)
      {
        a_FindOptSync[(k_FindOptSync - ns_FindOptSync) + 1535] =
          unusedU0_FindOptSync[k_FindOptSync - 1];
      }
    }
  }
}

/*
 * Arguments    : const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync
 * Return Type  : void
 */
static void d_rtErrorWithMessageID_FindOptSync(const
  rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync)
{
  fprintf(stderr,
          "If the working dimension of MAX or MIN is variable in length, it must not have zero length at runtime.");
  fprintf(stderr, "\n");
  if (aInfo_FindOptSync != NULL) {
    rtReportErrorLocation_FindOptSync(aInfo_FindOptSync->fName_FindOptSync,
      aInfo_FindOptSync->lineNo_FindOptSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : int numerator_FindOptSync
 *                int denominator_FindOptSync
 * Return Type  : int
 */
static int div_s32_floor_FindOptSync(int numerator_FindOptSync, int
  denominator_FindOptSync)
{
  int quotient_FindOptSync;
  unsigned int absNumerator_FindOptSync;
  unsigned int absDenominator_FindOptSync;
  boolean_T quotientNeedsNegation_FindOptSync;
  unsigned int tempAbsQuotient_FindOptSync;
  if (denominator_FindOptSync == 0) {
    if (numerator_FindOptSync >= 0) {
      quotient_FindOptSync = MAX_int32_T;
    } else {
      quotient_FindOptSync = MIN_int32_T;
    }

    rtDivisionByZeroError_FindOptSync(NULL);
  } else {
    if (numerator_FindOptSync < 0) {
      absNumerator_FindOptSync = ~(unsigned int)numerator_FindOptSync + 1U;
    } else {
      absNumerator_FindOptSync = (unsigned int)numerator_FindOptSync;
    }

    if (denominator_FindOptSync < 0) {
      absDenominator_FindOptSync = ~(unsigned int)denominator_FindOptSync + 1U;
    } else {
      absDenominator_FindOptSync = (unsigned int)denominator_FindOptSync;
    }

    quotientNeedsNegation_FindOptSync = ((numerator_FindOptSync < 0) !=
      (denominator_FindOptSync < 0));
    tempAbsQuotient_FindOptSync = absNumerator_FindOptSync /
      absDenominator_FindOptSync;
    if (quotientNeedsNegation_FindOptSync) {
      absNumerator_FindOptSync %= absDenominator_FindOptSync;
      if (absNumerator_FindOptSync > 0U) {
        tempAbsQuotient_FindOptSync++;
      }

      quotient_FindOptSync = -(int)tempAbsQuotient_FindOptSync;
    } else {
      quotient_FindOptSync = (int)tempAbsQuotient_FindOptSync;
    }
  }

  return quotient_FindOptSync;
}

/*
 * Arguments    : const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync
 * Return Type  : void
 */
static void e_rtErrorWithMessageID_FindOptSync(const
  rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync)
{
  fprintf(stderr,
          "The working dimension was selected automatically, is variable-length, and has length 1 at run time. This is not supported. Manua"
          "lly select the working dimension by supplying the DIM argument.");
  fprintf(stderr, "\n");
  if (aInfo_FindOptSync != NULL) {
    rtReportErrorLocation_FindOptSync(aInfo_FindOptSync->fName_FindOptSync,
      aInfo_FindOptSync->lineNo_FindOptSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync
 * Return Type  : void
 */
static void f_rtErrorWithMessageID_FindOptSync(const
  rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync)
{
  fprintf(stderr,
          "Inner dimensions must agree. Generated code for a general matrix multiplication at this call site. If this should have been a sc"
          "alar times a variable-size matrix, the scalar input must be fixed-size.");
  fprintf(stderr, "\n");
  if (aInfo_FindOptSync != NULL) {
    rtReportErrorLocation_FindOptSync(aInfo_FindOptSync->fName_FindOptSync,
      aInfo_FindOptSync->lineNo_FindOptSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync
 * Return Type  : void
 */
static void g_rtErrorWithMessageID_FindOptSync(const
  rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync)
{
  fprintf(stderr, "Inner matrix dimensions must agree.");
  fprintf(stderr, "\n");
  if (aInfo_FindOptSync != NULL) {
    rtReportErrorLocation_FindOptSync(aInfo_FindOptSync->fName_FindOptSync,
      aInfo_FindOptSync->lineNo_FindOptSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const int b_FindOptSync
 *                const char *c_FindOptSync
 *                const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync
 * Return Type  : void
 */
static void h_rtErrorWithMessageID_FindOptSync(const int b_FindOptSync, const
  char *c_FindOptSync, const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync)
{
  fprintf(stderr, "%.*s", b_FindOptSync, c_FindOptSync);
  fprintf(stderr, "\n");
  if (aInfo_FindOptSync != NULL) {
    rtReportErrorLocation_FindOptSync(aInfo_FindOptSync->fName_FindOptSync,
      aInfo_FindOptSync->lineNo_FindOptSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const int b_FindOptSync
 *                const char *c_FindOptSync
 *                const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync
 * Return Type  : void
 */
static void i_rtErrorWithMessageID_FindOptSync(const int b_FindOptSync, const
  char *c_FindOptSync, const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync)
{
  fprintf(stderr, "%.*s", b_FindOptSync, c_FindOptSync);
  fprintf(stderr, "\n");
  if (aInfo_FindOptSync != NULL) {
    rtReportErrorLocation_FindOptSync(aInfo_FindOptSync->fName_FindOptSync,
      aInfo_FindOptSync->lineNo_FindOptSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : double p_FindOptSync
 * Return Type  : boolean_T
 */
static boolean_T inrange_FindOptSync(double p_FindOptSync)
{
  boolean_T pok_FindOptSync;
  pok_FindOptSync = true;
  if (((int)p_FindOptSync != p_FindOptSync) || ((int)p_FindOptSync ==
       MIN_int32_T)) {
    pok_FindOptSync = false;
  }

  return pok_FindOptSync;
}

/*
 * Arguments    : const int b_FindOptSync
 *                const char *c_FindOptSync
 *                const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync
 * Return Type  : void
 */
static void j_rtErrorWithMessageID_FindOptSync(const int b_FindOptSync, const
  char *c_FindOptSync, const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync)
{
  fprintf(stderr,
          "The loop variable of class %.*s might overflow on the last iteration of the for loop. This could lead to an infinite loop.",
          b_FindOptSync, c_FindOptSync);
  fprintf(stderr, "\n");
  if (aInfo_FindOptSync != NULL) {
    rtReportErrorLocation_FindOptSync(aInfo_FindOptSync->fName_FindOptSync,
      aInfo_FindOptSync->lineNo_FindOptSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const int b_FindOptSync
 *                const char *c_FindOptSync
 *                const int d_FindOptSync
 *                const char *e_FindOptSync
 *                const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync
 * Return Type  : void
 */
static void k_rtErrorWithMessageID_FindOptSync(const int b_FindOptSync, const
  char *c_FindOptSync, const int d_FindOptSync, const char *e_FindOptSync, const
  rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync)
{
  fprintf(stderr,
          "Invalid shift argument: must be a finite, real, integer vector with entries between -intmax(\'%.*s\') and intmax(\'%.*s\').",
          b_FindOptSync, c_FindOptSync, d_FindOptSync, e_FindOptSync);
  fprintf(stderr, "\n");
  if (aInfo_FindOptSync != NULL) {
    rtReportErrorLocation_FindOptSync(aInfo_FindOptSync->fName_FindOptSync,
      aInfo_FindOptSync->lineNo_FindOptSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : char *aBuf_FindOptSync
 *                const int aDim_FindOptSync
 * Return Type  : void
 */
static void rtAddSizeString_FindOptSync(char *aBuf_FindOptSync, const int
  aDim_FindOptSync)
{
  char dimStr_FindOptSync[1024];
  sprintf(dimStr_FindOptSync, "[%d]", aDim_FindOptSync);
  if (strlen(aBuf_FindOptSync) + strlen(dimStr_FindOptSync) < 1024) {
    strcat(aBuf_FindOptSync, dimStr_FindOptSync);
  }
}

/*
 * Arguments    : const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync
 * Return Type  : void
 */
static void rtDivisionByZeroError_FindOptSync(const
  rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync)
{
  fprintf(stderr,
          "Division by zero detected.\nEarly termination due to division by zero.");
  fprintf(stderr, "\n");
  if (aInfo_FindOptSync != NULL) {
    rtReportErrorLocation_FindOptSync(aInfo_FindOptSync->fName_FindOptSync,
      aInfo_FindOptSync->lineNo_FindOptSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : int aIndexValue_FindOptSync
 *                int aLoBound_FindOptSync
 *                int aHiBound_FindOptSync
 *                const rtBoundsCheckInfo_FindOptSync *aInfo_FindOptSync
 * Return Type  : void
 */
static void rtDynamicBoundsError_FindOptSync(int aIndexValue_FindOptSync, int
  aLoBound_FindOptSync, int aHiBound_FindOptSync, const
  rtBoundsCheckInfo_FindOptSync *aInfo_FindOptSync)
{
  if (aLoBound_FindOptSync == 0) {
    aIndexValue_FindOptSync++;
    aLoBound_FindOptSync = 1;
    aHiBound_FindOptSync++;
  }

  if (rtIsNullOrEmptyString_FindOptSync(aInfo_FindOptSync->aName_FindOptSync)) {
    fprintf(stderr,
            "Index exceeds array dimensions.  Index value %d exceeds valid range [%d-%d].",
            aIndexValue_FindOptSync, aLoBound_FindOptSync, aHiBound_FindOptSync);
    fprintf(stderr, "\n");
  } else {
    fprintf(stderr,
            "Index exceeds array dimensions.  Index value %d exceeds valid range [%d-%d] of array %s.",
            aIndexValue_FindOptSync, aLoBound_FindOptSync, aHiBound_FindOptSync,
            aInfo_FindOptSync->aName_FindOptSync);
    fprintf(stderr, "\n");
  }

  if (aInfo_FindOptSync != NULL) {
    rtReportErrorLocation_FindOptSync(aInfo_FindOptSync->fName_FindOptSync,
      aInfo_FindOptSync->lineNo_FindOptSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync
 * Return Type  : void
 */
static void rtErrorWithMessageID_FindOptSync(const
  rtRunTimeErrorInfo_FindOptSync *aInfo_FindOptSync)
{
  fprintf(stderr, "Assertion failed.");
  fprintf(stderr, "\n");
  if (aInfo_FindOptSync != NULL) {
    rtReportErrorLocation_FindOptSync(aInfo_FindOptSync->fName_FindOptSync,
      aInfo_FindOptSync->lineNo_FindOptSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const int aNDims_FindOptSync
 *                const int *aDims_FindOptSync
 *                char *aBuf_FindOptSync
 * Return Type  : void
 */
static void rtGenSizeString_FindOptSync(const int aNDims_FindOptSync, const int *
  aDims_FindOptSync, char *aBuf_FindOptSync)
{
  int i_FindOptSync;
  aBuf_FindOptSync[0] = '\x00';
  for (i_FindOptSync = 0; i_FindOptSync < aNDims_FindOptSync; i_FindOptSync++) {
    rtAddSizeString_FindOptSync(aBuf_FindOptSync,
      aDims_FindOptSync[i_FindOptSync]);
  }
}

/*
 * Arguments    : const double aInteger_FindOptSync
 *                const rtDoubleCheckInfo_FindOptSync *aInfo_FindOptSync
 * Return Type  : void
 */
static void rtIntegerError_FindOptSync(const double aInteger_FindOptSync, const
  rtDoubleCheckInfo_FindOptSync *aInfo_FindOptSync)
{
  fprintf(stderr,
          "Expected a value representable in the C type \'int\'.  Found %g instead.",
          aInteger_FindOptSync);
  fprintf(stderr, "\n");
  if (aInfo_FindOptSync != NULL) {
    rtReportErrorLocation_FindOptSync(aInfo_FindOptSync->fName_FindOptSync,
      aInfo_FindOptSync->lineNo_FindOptSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const char *aString_FindOptSync
 * Return Type  : boolean_T
 */
static boolean_T rtIsNullOrEmptyString_FindOptSync(const char
  *aString_FindOptSync)
{
  return (aString_FindOptSync == NULL) || (*aString_FindOptSync == '\x00');
}

/*
 * Arguments    : const double aPositive_FindOptSync
 *                const rtDoubleCheckInfo_FindOptSync *aInfo_FindOptSync
 * Return Type  : void
 */
static void rtNonNegativeError_FindOptSync(const double aPositive_FindOptSync,
  const rtDoubleCheckInfo_FindOptSync *aInfo_FindOptSync)
{
  fprintf(stderr,
          "Value %g is not greater than or equal to zero.\nExiting to prevent memory corruption.",
          aPositive_FindOptSync);
  fprintf(stderr, "\n");
  if (aInfo_FindOptSync != NULL) {
    rtReportErrorLocation_FindOptSync(aInfo_FindOptSync->fName_FindOptSync,
      aInfo_FindOptSync->lineNo_FindOptSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const char * aFcnName_FindOptSync
 *                const int aLineNo_FindOptSync
 * Return Type  : void
 */
static void rtReportErrorLocation_FindOptSync(const char * aFcnName_FindOptSync,
  const int aLineNo_FindOptSync)
{
  fprintf(stderr, "Error in %s (line %d)", aFcnName_FindOptSync,
          aLineNo_FindOptSync);
  fprintf(stderr, "\n");
}

/*
 * Arguments    : const int *aDims1_FindOptSync
 *                const int aNDims1_FindOptSync
 *                const int *aDims2_FindOptSync
 *                const int aNDims2_FindOptSync
 *                const rtEqualityCheckInfo_FindOptSync *aInfo_FindOptSync
 * Return Type  : void
 */
static void rtSubAssignSizeCheck_FindOptSync(const int *aDims1_FindOptSync,
  const int aNDims1_FindOptSync, const int *aDims2_FindOptSync, const int
  aNDims2_FindOptSync, const rtEqualityCheckInfo_FindOptSync *aInfo_FindOptSync)
{
  int i_FindOptSync;
  int j_FindOptSync;
  char dims1Str_FindOptSync[1024];
  char dims2Str_FindOptSync[1024];
  i_FindOptSync = 0;
  j_FindOptSync = 0;
  while ((i_FindOptSync < aNDims1_FindOptSync) && (j_FindOptSync <
          aNDims2_FindOptSync)) {
    while ((i_FindOptSync < aNDims1_FindOptSync) &&
           (aDims1_FindOptSync[i_FindOptSync] == 1)) {
      i_FindOptSync++;
    }

    while ((j_FindOptSync < aNDims2_FindOptSync) &&
           (aDims2_FindOptSync[j_FindOptSync] == 1)) {
      j_FindOptSync++;
    }

    if (((i_FindOptSync < aNDims1_FindOptSync) || (j_FindOptSync <
          aNDims2_FindOptSync)) && ((i_FindOptSync == aNDims1_FindOptSync) ||
         ((j_FindOptSync == aNDims2_FindOptSync) ||
          ((aDims1_FindOptSync[i_FindOptSync] != -1) &&
           ((aDims2_FindOptSync[j_FindOptSync] != -1) &&
            (aDims1_FindOptSync[i_FindOptSync] !=
             aDims2_FindOptSync[j_FindOptSync])))))) {
      rtGenSizeString_FindOptSync(aNDims1_FindOptSync, aDims1_FindOptSync,
        dims1Str_FindOptSync);
      rtGenSizeString_FindOptSync(aNDims2_FindOptSync, aDims2_FindOptSync,
        dims2Str_FindOptSync);
      fprintf(stderr, "Subscripted assignment dimension mismatch: %s ~= %s.",
              dims1Str_FindOptSync, dims2Str_FindOptSync);
      fprintf(stderr, "\n");
      if (aInfo_FindOptSync != NULL) {
        rtReportErrorLocation_FindOptSync(aInfo_FindOptSync->fName_FindOptSync,
          aInfo_FindOptSync->lineNo_FindOptSync);
      }

      fflush(stderr);
      abort();
    }

    i_FindOptSync++;
    j_FindOptSync++;
  }
}

/*
 * Arguments    : double u0_FindOptSync
 *                double u1_FindOptSync
 * Return Type  : double
 */
static double rt_hypotd_snf_FindOptSync(double u0_FindOptSync, double
  u1_FindOptSync)
{
  double y_FindOptSync;
  double a_FindOptSync;
  double b_FindOptSync;
  a_FindOptSync = fabs(u0_FindOptSync);
  b_FindOptSync = fabs(u1_FindOptSync);
  if (a_FindOptSync < b_FindOptSync) {
    a_FindOptSync /= b_FindOptSync;
    y_FindOptSync = b_FindOptSync * sqrt(a_FindOptSync * a_FindOptSync + 1.0);
  } else if (a_FindOptSync > b_FindOptSync) {
    b_FindOptSync /= a_FindOptSync;
    y_FindOptSync = a_FindOptSync * sqrt(b_FindOptSync * b_FindOptSync + 1.0);
  } else if (rtIsNaN(b_FindOptSync)) {
    y_FindOptSync = b_FindOptSync;
  } else {
    y_FindOptSync = a_FindOptSync * 1.4142135623730951;
  }

  return y_FindOptSync;
}

/*
 * Arguments    : const creal_T x_FindOptSync[2048]
 *                double N_FindOptSync
 *                emxArray_creal_T_FindOptSync *y_FindOptSync
 * Return Type  : void
 */
static void upsample_FindOptSync(const creal_T x_FindOptSync[2048], double
  N_FindOptSync, emxArray_creal_T_FindOptSync *y_FindOptSync)
{
  double b_N_FindOptSync;
  boolean_T b0_FindOptSync;
  int vleny_FindOptSync;
  int i0_FindOptSync;
  int xstart_FindOptSync;
  int ystart_FindOptSync;
  int i_FindOptSync;
  int ix_FindOptSync;
  int iy_FindOptSync;
  int k_FindOptSync;
  if (N_FindOptSync < 0.0) {
    b_N_FindOptSync = ceil(N_FindOptSync);
  } else {
    b_N_FindOptSync = floor(N_FindOptSync);
  }

  if ((b_N_FindOptSync == N_FindOptSync) && (N_FindOptSync > 0.0)) {
    b0_FindOptSync = true;
  } else {
    b0_FindOptSync = false;
  }

  if (!b0_FindOptSync) {
    h_rtErrorWithMessageID_FindOptSync(43,
      "Upsample factor must be a positive integer.", &h_emlrtRTEI_FindOptSync);
  }

  if (!(0.0 <= N_FindOptSync - 1.0)) {
    i_rtErrorWithMessageID_FindOptSync(40,
      "Offset must be an integer from 0 to N-1.", &i_emlrtRTEI_FindOptSync);
  }

  vleny_FindOptSync = (int)N_FindOptSync << 9;
  i0_FindOptSync = y_FindOptSync->size_FindOptSync[0] *
    y_FindOptSync->size_FindOptSync[1];
  y_FindOptSync->size_FindOptSync[0] = vleny_FindOptSync;
  y_FindOptSync->size_FindOptSync[1] = 4;
  emxEnsureCapacity_creal_T_FindOptSync(y_FindOptSync, i0_FindOptSync);
  xstart_FindOptSync = vleny_FindOptSync << 2;
  for (i0_FindOptSync = 0; i0_FindOptSync < xstart_FindOptSync; i0_FindOptSync++)
  {
    y_FindOptSync->data_FindOptSync[i0_FindOptSync].re = 0.0;
    y_FindOptSync->data_FindOptSync[i0_FindOptSync].im = 0.0;
  }

  xstart_FindOptSync = 1;
  ystart_FindOptSync = 1;
  for (i_FindOptSync = 0; i_FindOptSync < 4; i_FindOptSync++) {
    ix_FindOptSync = xstart_FindOptSync;
    iy_FindOptSync = ystart_FindOptSync;
    for (k_FindOptSync = 0; k_FindOptSync < 512; k_FindOptSync++) {
      i0_FindOptSync = y_FindOptSync->size_FindOptSync[0] << 2;
      if (!((iy_FindOptSync >= 1) && (iy_FindOptSync <= i0_FindOptSync))) {
        rtDynamicBoundsError_FindOptSync(iy_FindOptSync, 1, i0_FindOptSync,
          &n_emlrtBCI_FindOptSync);
      }

      if (!((ix_FindOptSync >= 1) && (ix_FindOptSync <= 2048))) {
        rtDynamicBoundsError_FindOptSync(ix_FindOptSync, 1, 2048,
          &o_emlrtBCI_FindOptSync);
      }

      y_FindOptSync->data_FindOptSync[iy_FindOptSync - 1].re =
        x_FindOptSync[ix_FindOptSync - 1].re;
      if (!((ix_FindOptSync >= 1) && (ix_FindOptSync <= 2048))) {
        rtDynamicBoundsError_FindOptSync(ix_FindOptSync, 1, 2048,
          &m_emlrtBCI_FindOptSync);
      }

      i0_FindOptSync = y_FindOptSync->size_FindOptSync[0] << 2;
      if (!((iy_FindOptSync >= 1) && (iy_FindOptSync <= i0_FindOptSync))) {
        rtDynamicBoundsError_FindOptSync(iy_FindOptSync, 1, i0_FindOptSync,
          &n_emlrtBCI_FindOptSync);
      }

      y_FindOptSync->data_FindOptSync[iy_FindOptSync - 1].im =
        x_FindOptSync[ix_FindOptSync - 1].im;
      ix_FindOptSync++;
      iy_FindOptSync += (int)N_FindOptSync;
    }

    xstart_FindOptSync += 512;
    ystart_FindOptSync += vleny_FindOptSync;
  }
}

/*
 * function [pilotSequence, numSyncChannel, circShiftSelect] = FindOptiSyncImplement(rxSigNoise, pilotSequenceUpSample, UpSampleTimes, LenSearch)
 * Find Optimum Synchronization Sample Point.
 *  input:
 *     % rxSigNoise: NxM complex, N is the number of snapshots, M is the number of channel. each colum is one snapshot
 *     % pilotSequenceUpSample: (UpSampleTimesxN)x1 complex, N is the length of pilot.
 *     % UpSampleTimes: 1x1 integer, upsample factor.
 *     % LenSearch: 1x1 odd integer, search range of finding optimum synchronization sample point under upsampled symbols.
 *  output:
 *     % pilotSequence, Nx1 complex, N is the length of pilot, pilot sequence downsampled according to optimum synchronization sample.
 *     % numSyncChannel: 1x1 integer, number of synchronized channel after adjust optimum synchronization sample.
 *     % circShiftSelect: 1x1 integer, pilot circle shift index.
 *
 *  2018-01-25 V1.0 Wayne Zhang. draft.
 *  2018-05-25 V1.1 Collus Wang. remove unnecessary multiplication operations for speed. 30ms->10ms.
 * Arguments    : const creal_T rxSigNoise_FindOptSync[2048]
 *                const creal_T pilotSequenceUpSample_FindOptSync[1536]
 *                double UpSampleTimes_FindOptSync
 *                double LenSearch_FindOptSync
 *                creal_T pilotSequence_data_FindOptSync[]
 *                int pilotSequence_size_FindOptSync[1]
 *                double *numSyncChannel_FindOptSync
 *                double *circShiftSelect_FindOptSync
 * Return Type  : void
 */
void FindOptiSyncImplement(const creal_T rxSigNoise_FindOptSync[2048], const
  creal_T pilotSequenceUpSample_FindOptSync[1536], double
  UpSampleTimes_FindOptSync, double LenSearch_FindOptSync, creal_T
  pilotSequence_data_FindOptSync[], int pilotSequence_size_FindOptSync[1],
  double *numSyncChannel_FindOptSync, double *circShiftSelect_FindOptSync)
{
  boolean_T overflow_FindOptSync;
  emxArray_real_T_FindOptSync *circShiftPattern_FindOptSync;
  int ia_FindOptSync;
  int cindx_FindOptSync;
  double temp_re_FindOptSync;
  int br_FindOptSync;
  int iy_FindOptSync;
  emxArray_int8_T_FindOptSync *syncIndexMat_FindOptSync;
  emxArray_creal_T_FindOptSync *rxSigNoiseUpSample_FindOptSync;
  emxArray_creal_T_FindOptSync *pilotSequenceUpSampleMat_FindOptSync;
  emxArray_int32_T_FindOptSync *r0_FindOptSync;
  int ib_FindOptSync;
  int ar_FindOptSync;
  int iv0_FindOptSync[1];
  emxArray_creal_T_FindOptSync *a_FindOptSync;
  int iv1_FindOptSync[1];
  creal_T pilotSequenceUpSampleShift_FindOptSync[1536];
  emxArray_creal_T_FindOptSync *b_FindOptSync;
  emxArray_creal_T_FindOptSync *xcorrMat_FindOptSync;
  int k_FindOptSync;
  int c_FindOptSync;
  double temp_im_FindOptSync;
  emxArray_real_T_FindOptSync *varargin_1_FindOptSync;
  int ix_FindOptSync;
  int indx_FindOptSync[4];
  int iindx_FindOptSync[4];
  emxArray_real_T_FindOptSync *y_FindOptSync;
  boolean_T exitg1_FindOptSync;
  double b_temp_re_FindOptSync;
  double b_temp_im_FindOptSync;
  double b_UpSampleTimes_FindOptSync;
  int b_ia_FindOptSync;
  int sz_FindOptSync[2];
  overflow_FindOptSync = false;

  /* 'FindOptiSyncImplement:16' LenCorr = 64*2; */
  /* 'FindOptiSyncImplement:17' circShiftPattern = (1:LenSearch) - (LenSearch + 1)/2; */
  emxInit_real_T_FindOptSync(&circShiftPattern_FindOptSync, 2);
  if (rtIsNaN(LenSearch_FindOptSync)) {
    ia_FindOptSync = circShiftPattern_FindOptSync->size_FindOptSync[0] *
      circShiftPattern_FindOptSync->size_FindOptSync[1];
    circShiftPattern_FindOptSync->size_FindOptSync[0] = 1;
    circShiftPattern_FindOptSync->size_FindOptSync[1] = 1;
    emxEnsureCapacity_real_T_FindOptSync(circShiftPattern_FindOptSync,
      ia_FindOptSync);
    circShiftPattern_FindOptSync->data_FindOptSync[0] = rtNaN;
  } else if (LenSearch_FindOptSync < 1.0) {
    ia_FindOptSync = circShiftPattern_FindOptSync->size_FindOptSync[0] *
      circShiftPattern_FindOptSync->size_FindOptSync[1];
    circShiftPattern_FindOptSync->size_FindOptSync[0] = 1;
    circShiftPattern_FindOptSync->size_FindOptSync[1] = 0;
    emxEnsureCapacity_real_T_FindOptSync(circShiftPattern_FindOptSync,
      ia_FindOptSync);
  } else if (rtIsInf(LenSearch_FindOptSync) && (1.0 == LenSearch_FindOptSync)) {
    ia_FindOptSync = circShiftPattern_FindOptSync->size_FindOptSync[0] *
      circShiftPattern_FindOptSync->size_FindOptSync[1];
    circShiftPattern_FindOptSync->size_FindOptSync[0] = 1;
    circShiftPattern_FindOptSync->size_FindOptSync[1] = 1;
    emxEnsureCapacity_real_T_FindOptSync(circShiftPattern_FindOptSync,
      ia_FindOptSync);
    circShiftPattern_FindOptSync->data_FindOptSync[0] = rtNaN;
  } else {
    ia_FindOptSync = circShiftPattern_FindOptSync->size_FindOptSync[0] *
      circShiftPattern_FindOptSync->size_FindOptSync[1];
    circShiftPattern_FindOptSync->size_FindOptSync[0] = 1;
    circShiftPattern_FindOptSync->size_FindOptSync[1] = (int)floor
      (LenSearch_FindOptSync - 1.0) + 1;
    emxEnsureCapacity_real_T_FindOptSync(circShiftPattern_FindOptSync,
      ia_FindOptSync);
    cindx_FindOptSync = (int)floor(LenSearch_FindOptSync - 1.0);
    for (ia_FindOptSync = 0; ia_FindOptSync <= cindx_FindOptSync; ia_FindOptSync
         ++) {
      circShiftPattern_FindOptSync->
        data_FindOptSync[circShiftPattern_FindOptSync->size_FindOptSync[0] *
        ia_FindOptSync] = 1.0 + (double)ia_FindOptSync;
    }
  }

  temp_re_FindOptSync = (LenSearch_FindOptSync + 1.0) / 2.0;
  ia_FindOptSync = circShiftPattern_FindOptSync->size_FindOptSync[0] *
    circShiftPattern_FindOptSync->size_FindOptSync[1];
  circShiftPattern_FindOptSync->size_FindOptSync[0] = 1;
  emxEnsureCapacity_real_T_FindOptSync(circShiftPattern_FindOptSync,
    ia_FindOptSync);
  br_FindOptSync = circShiftPattern_FindOptSync->size_FindOptSync[0];
  iy_FindOptSync = circShiftPattern_FindOptSync->size_FindOptSync[1];
  cindx_FindOptSync = br_FindOptSync * iy_FindOptSync;
  for (ia_FindOptSync = 0; ia_FindOptSync < cindx_FindOptSync; ia_FindOptSync++)
  {
    circShiftPattern_FindOptSync->data_FindOptSync[ia_FindOptSync] -=
      temp_re_FindOptSync;
  }

  emxInit_int8_T_FindOptSync(&syncIndexMat_FindOptSync, 2);

  /* 'FindOptiSyncImplement:19' [LenPilot, NumChannel] = size(rxSigNoise); */
  /* 'FindOptiSyncImplement:20' syncIndexMat = zeros(NumChannel, LenSearch); */
  ia_FindOptSync = syncIndexMat_FindOptSync->size_FindOptSync[0] *
    syncIndexMat_FindOptSync->size_FindOptSync[1];
  syncIndexMat_FindOptSync->size_FindOptSync[0] = 4;
  if (!(LenSearch_FindOptSync >= 0.0)) {
    rtNonNegativeError_FindOptSync(LenSearch_FindOptSync,
      &f_emlrtDCI_FindOptSync);
  }

  if (LenSearch_FindOptSync != (int)floor(LenSearch_FindOptSync)) {
    rtIntegerError_FindOptSync(LenSearch_FindOptSync, &e_emlrtDCI_FindOptSync);
  }

  syncIndexMat_FindOptSync->size_FindOptSync[1] = (int)LenSearch_FindOptSync;
  emxEnsureCapacity_int8_T_FindOptSync(syncIndexMat_FindOptSync, ia_FindOptSync);
  if (!(LenSearch_FindOptSync >= 0.0)) {
    rtNonNegativeError_FindOptSync(LenSearch_FindOptSync,
      &k_emlrtDCI_FindOptSync);
  }

  if (LenSearch_FindOptSync != (int)floor(LenSearch_FindOptSync)) {
    rtIntegerError_FindOptSync(LenSearch_FindOptSync, &j_emlrtDCI_FindOptSync);
  }

  cindx_FindOptSync = (int)LenSearch_FindOptSync << 2;
  for (ia_FindOptSync = 0; ia_FindOptSync < cindx_FindOptSync; ia_FindOptSync++)
  {
    syncIndexMat_FindOptSync->data_FindOptSync[ia_FindOptSync] = 0;
  }

  emxInit_creal_T_FindOptSync(&rxSigNoiseUpSample_FindOptSync, 2);
  emxInit_creal_T_FindOptSync(&pilotSequenceUpSampleMat_FindOptSync, 2);

  /* 'FindOptiSyncImplement:21' rxSigNoiseUpSample = upsample(rxSigNoise, UpSampleTimes); */
  upsample_FindOptSync(rxSigNoise_FindOptSync, UpSampleTimes_FindOptSync,
                       rxSigNoiseUpSample_FindOptSync);

  /* 'FindOptiSyncImplement:24' pilotSequenceUpSampleMat = complex(zeros(LenPilot*UpSampleTimes, LenSearch)); */
  ia_FindOptSync = pilotSequenceUpSampleMat_FindOptSync->size_FindOptSync[0] *
    pilotSequenceUpSampleMat_FindOptSync->size_FindOptSync[1];
  temp_re_FindOptSync = 512.0 * UpSampleTimes_FindOptSync;
  if (!(temp_re_FindOptSync >= 0.0)) {
    rtNonNegativeError_FindOptSync(temp_re_FindOptSync, &h_emlrtDCI_FindOptSync);
  }

  if (temp_re_FindOptSync != (int)floor(temp_re_FindOptSync)) {
    rtIntegerError_FindOptSync(temp_re_FindOptSync, &g_emlrtDCI_FindOptSync);
  }

  pilotSequenceUpSampleMat_FindOptSync->size_FindOptSync[0] = (int)
    temp_re_FindOptSync;
  if (LenSearch_FindOptSync != (int)floor(LenSearch_FindOptSync)) {
    rtIntegerError_FindOptSync(LenSearch_FindOptSync, &i_emlrtDCI_FindOptSync);
  }

  pilotSequenceUpSampleMat_FindOptSync->size_FindOptSync[1] = (int)
    LenSearch_FindOptSync;
  emxEnsureCapacity_creal_T_FindOptSync(pilotSequenceUpSampleMat_FindOptSync,
    ia_FindOptSync);
  temp_re_FindOptSync = 512.0 * UpSampleTimes_FindOptSync;
  if (!(temp_re_FindOptSync >= 0.0)) {
    rtNonNegativeError_FindOptSync(temp_re_FindOptSync, &m_emlrtDCI_FindOptSync);
  }

  if (temp_re_FindOptSync != (int)floor(temp_re_FindOptSync)) {
    rtIntegerError_FindOptSync(temp_re_FindOptSync, &l_emlrtDCI_FindOptSync);
  }

  if (LenSearch_FindOptSync != (int)floor(LenSearch_FindOptSync)) {
    rtIntegerError_FindOptSync(LenSearch_FindOptSync, &l_emlrtDCI_FindOptSync);
  }

  cindx_FindOptSync = (int)temp_re_FindOptSync * (int)LenSearch_FindOptSync;
  for (ia_FindOptSync = 0; ia_FindOptSync < cindx_FindOptSync; ia_FindOptSync++)
  {
    pilotSequenceUpSampleMat_FindOptSync->data_FindOptSync[ia_FindOptSync].re =
      0.0;
    pilotSequenceUpSampleMat_FindOptSync->data_FindOptSync[ia_FindOptSync].im =
      0.0;
  }

  /* 'FindOptiSyncImplement:25' for idxShift = 1:LenSearch */
  br_FindOptSync = 0;
  emxInit_int32_T_FindOptSync(&r0_FindOptSync, 1);
  while (br_FindOptSync <= (int)LenSearch_FindOptSync - 1) {
    /* 'FindOptiSyncImplement:26' pilotSequenceUpSampleMat(:,idxShift) = circshift(pilotSequenceUpSample, circShiftPattern(idxShift)); */
    cindx_FindOptSync = pilotSequenceUpSampleMat_FindOptSync->size_FindOptSync[0];
    ia_FindOptSync = r0_FindOptSync->size_FindOptSync[0];
    r0_FindOptSync->size_FindOptSync[0] = cindx_FindOptSync;
    emxEnsureCapacity_int32_T_FindOptSync(r0_FindOptSync, ia_FindOptSync);
    for (ia_FindOptSync = 0; ia_FindOptSync < cindx_FindOptSync; ia_FindOptSync
         ++) {
      r0_FindOptSync->data_FindOptSync[ia_FindOptSync] = ia_FindOptSync;
    }

    ia_FindOptSync = pilotSequenceUpSampleMat_FindOptSync->size_FindOptSync[1];
    ib_FindOptSync = br_FindOptSync + 1;
    if (!((ib_FindOptSync >= 1) && (ib_FindOptSync <= ia_FindOptSync))) {
      rtDynamicBoundsError_FindOptSync(ib_FindOptSync, 1, ia_FindOptSync,
        &c_emlrtBCI_FindOptSync);
    }

    iv0_FindOptSync[0] = r0_FindOptSync->size_FindOptSync[0];
    if (!overflow_FindOptSync) {
      iv1_FindOptSync[0] = 1536;
      overflow_FindOptSync = true;
    }

    rtSubAssignSizeCheck_FindOptSync(&iv0_FindOptSync[0], 1, &iv1_FindOptSync[0],
      1, &emlrtECI_FindOptSync);
    memcpy(&pilotSequenceUpSampleShift_FindOptSync[0],
           &pilotSequenceUpSample_FindOptSync[0], 1536U * sizeof(creal_T));
    ia_FindOptSync = circShiftPattern_FindOptSync->size_FindOptSync[1];
    if (!((br_FindOptSync + 1 >= 1) && (br_FindOptSync + 1 <= ia_FindOptSync)))
    {
      rtDynamicBoundsError_FindOptSync(br_FindOptSync + 1, 1, ia_FindOptSync,
        &j_emlrtBCI_FindOptSync);
    }

    circshift_FindOptSync(pilotSequenceUpSampleShift_FindOptSync,
                          circShiftPattern_FindOptSync->
                          data_FindOptSync[br_FindOptSync]);
    iy_FindOptSync = r0_FindOptSync->size_FindOptSync[0];
    for (ia_FindOptSync = 0; ia_FindOptSync < iy_FindOptSync; ia_FindOptSync++)
    {
      pilotSequenceUpSampleMat_FindOptSync->data_FindOptSync
        [r0_FindOptSync->data_FindOptSync[ia_FindOptSync] +
        pilotSequenceUpSampleMat_FindOptSync->size_FindOptSync[0] *
        br_FindOptSync] = pilotSequenceUpSampleShift_FindOptSync[ia_FindOptSync];
    }

    br_FindOptSync++;
  }

  emxFree_int32_T_FindOptSync(&r0_FindOptSync);

  /* 'FindOptiSyncImplement:29' xcorrMat = rxSigNoiseUpSample(1:UpSampleTimes:LenCorr*UpSampleTimes,:)'*pilotSequenceUpSampleMat(1:UpSampleTimes:LenCorr*UpSampleTimes,:); */
  temp_re_FindOptSync = 128.0 * UpSampleTimes_FindOptSync;
  if ((UpSampleTimes_FindOptSync == 0.0) || (((UpSampleTimes_FindOptSync > 0.0) &&
        (1.0 > temp_re_FindOptSync)) || ((0.0 > UpSampleTimes_FindOptSync) &&
        (temp_re_FindOptSync > 1.0)))) {
    ia_FindOptSync = 1;
    ib_FindOptSync = -1;
  } else {
    ia_FindOptSync = rxSigNoiseUpSample_FindOptSync->size_FindOptSync[0];
    if (!(1 <= ia_FindOptSync)) {
      rtDynamicBoundsError_FindOptSync(1, 1, ia_FindOptSync,
        &e_emlrtBCI_FindOptSync);
    }

    if (UpSampleTimes_FindOptSync != (int)floor(UpSampleTimes_FindOptSync)) {
      rtIntegerError_FindOptSync(UpSampleTimes_FindOptSync,
        &c_emlrtDCI_FindOptSync);
    }

    ia_FindOptSync = (int)UpSampleTimes_FindOptSync;
    ib_FindOptSync = rxSigNoiseUpSample_FindOptSync->size_FindOptSync[0];
    if (temp_re_FindOptSync != (int)floor(temp_re_FindOptSync)) {
      rtIntegerError_FindOptSync(temp_re_FindOptSync, &d_emlrtDCI_FindOptSync);
    }

    iy_FindOptSync = (int)temp_re_FindOptSync;
    if (!((iy_FindOptSync >= 1) && (iy_FindOptSync <= ib_FindOptSync))) {
      rtDynamicBoundsError_FindOptSync(iy_FindOptSync, 1, ib_FindOptSync,
        &d_emlrtBCI_FindOptSync);
    }

    ib_FindOptSync = iy_FindOptSync - 1;
  }

  temp_re_FindOptSync = 128.0 * UpSampleTimes_FindOptSync;
  if ((UpSampleTimes_FindOptSync == 0.0) || (((UpSampleTimes_FindOptSync > 0.0) &&
        (1.0 > temp_re_FindOptSync)) || ((0.0 > UpSampleTimes_FindOptSync) &&
        (temp_re_FindOptSync > 1.0)))) {
    iy_FindOptSync = 1;
    ar_FindOptSync = -1;
  } else {
    iy_FindOptSync = pilotSequenceUpSampleMat_FindOptSync->size_FindOptSync[0];
    if (!(1 <= iy_FindOptSync)) {
      rtDynamicBoundsError_FindOptSync(1, 1, iy_FindOptSync,
        &b_emlrtBCI_FindOptSync);
    }

    if (UpSampleTimes_FindOptSync != (int)floor(UpSampleTimes_FindOptSync)) {
      rtIntegerError_FindOptSync(UpSampleTimes_FindOptSync,
        &emlrtDCI_FindOptSync);
    }

    iy_FindOptSync = (int)UpSampleTimes_FindOptSync;
    ar_FindOptSync = pilotSequenceUpSampleMat_FindOptSync->size_FindOptSync[0];
    if (temp_re_FindOptSync != (int)floor(temp_re_FindOptSync)) {
      rtIntegerError_FindOptSync(temp_re_FindOptSync, &b_emlrtDCI_FindOptSync);
    }

    br_FindOptSync = (int)temp_re_FindOptSync;
    if (!((br_FindOptSync >= 1) && (br_FindOptSync <= ar_FindOptSync))) {
      rtDynamicBoundsError_FindOptSync(br_FindOptSync, 1, ar_FindOptSync,
        &emlrtBCI_FindOptSync);
    }

    ar_FindOptSync = br_FindOptSync - 1;
  }

  emxInit_creal_T_FindOptSync(&a_FindOptSync, 2);
  br_FindOptSync = a_FindOptSync->size_FindOptSync[0] *
    a_FindOptSync->size_FindOptSync[1];
  a_FindOptSync->size_FindOptSync[0] = 4;
  a_FindOptSync->size_FindOptSync[1] = div_s32_floor_FindOptSync(ib_FindOptSync,
    ia_FindOptSync) + 1;
  emxEnsureCapacity_creal_T_FindOptSync(a_FindOptSync, br_FindOptSync);
  cindx_FindOptSync = div_s32_floor_FindOptSync(ib_FindOptSync, ia_FindOptSync);
  for (ib_FindOptSync = 0; ib_FindOptSync <= cindx_FindOptSync; ib_FindOptSync++)
  {
    for (br_FindOptSync = 0; br_FindOptSync < 4; br_FindOptSync++) {
      a_FindOptSync->data_FindOptSync[br_FindOptSync +
        a_FindOptSync->size_FindOptSync[0] * ib_FindOptSync].re =
        rxSigNoiseUpSample_FindOptSync->data_FindOptSync[ia_FindOptSync *
        ib_FindOptSync + rxSigNoiseUpSample_FindOptSync->size_FindOptSync[0] *
        br_FindOptSync].re;
      a_FindOptSync->data_FindOptSync[br_FindOptSync +
        a_FindOptSync->size_FindOptSync[0] * ib_FindOptSync].im =
        -rxSigNoiseUpSample_FindOptSync->data_FindOptSync[ia_FindOptSync *
        ib_FindOptSync + rxSigNoiseUpSample_FindOptSync->size_FindOptSync[0] *
        br_FindOptSync].im;
    }
  }

  emxInit_creal_T_FindOptSync(&b_FindOptSync, 2);
  cindx_FindOptSync = pilotSequenceUpSampleMat_FindOptSync->size_FindOptSync[1];
  ia_FindOptSync = b_FindOptSync->size_FindOptSync[0] *
    b_FindOptSync->size_FindOptSync[1];
  b_FindOptSync->size_FindOptSync[0] = div_s32_floor_FindOptSync(ar_FindOptSync,
    iy_FindOptSync) + 1;
  b_FindOptSync->size_FindOptSync[1] = cindx_FindOptSync;
  emxEnsureCapacity_creal_T_FindOptSync(b_FindOptSync, ia_FindOptSync);
  for (ia_FindOptSync = 0; ia_FindOptSync < cindx_FindOptSync; ia_FindOptSync++)
  {
    br_FindOptSync = div_s32_floor_FindOptSync(ar_FindOptSync, iy_FindOptSync);
    for (ib_FindOptSync = 0; ib_FindOptSync <= br_FindOptSync; ib_FindOptSync++)
    {
      b_FindOptSync->data_FindOptSync[ib_FindOptSync +
        b_FindOptSync->size_FindOptSync[0] * ia_FindOptSync] =
        pilotSequenceUpSampleMat_FindOptSync->data_FindOptSync[iy_FindOptSync *
        ib_FindOptSync + pilotSequenceUpSampleMat_FindOptSync->size_FindOptSync
        [0] * ia_FindOptSync];
    }
  }

  if (!(a_FindOptSync->size_FindOptSync[1] == div_s32_floor_FindOptSync
        (ar_FindOptSync, iy_FindOptSync) + 1)) {
    ia_FindOptSync = pilotSequenceUpSampleMat_FindOptSync->size_FindOptSync[1];
    if ((div_s32_floor_FindOptSync(ar_FindOptSync, iy_FindOptSync) + 1 == 1) &&
        (ia_FindOptSync == 1)) {
      f_rtErrorWithMessageID_FindOptSync(&f_emlrtRTEI_FindOptSync);
    } else {
      g_rtErrorWithMessageID_FindOptSync(&g_emlrtRTEI_FindOptSync);
    }
  }

  emxInit_creal_T_FindOptSync(&xcorrMat_FindOptSync, 2);
  if ((a_FindOptSync->size_FindOptSync[1] == 1) || (div_s32_floor_FindOptSync
       (ar_FindOptSync, iy_FindOptSync) + 1 == 1)) {
    ia_FindOptSync = xcorrMat_FindOptSync->size_FindOptSync[0] *
      xcorrMat_FindOptSync->size_FindOptSync[1];
    xcorrMat_FindOptSync->size_FindOptSync[0] = 4;
    xcorrMat_FindOptSync->size_FindOptSync[1] = b_FindOptSync->size_FindOptSync
      [1];
    emxEnsureCapacity_creal_T_FindOptSync(xcorrMat_FindOptSync, ia_FindOptSync);
    for (ia_FindOptSync = 0; ia_FindOptSync < 4; ia_FindOptSync++) {
      cindx_FindOptSync = b_FindOptSync->size_FindOptSync[1];
      for (ib_FindOptSync = 0; ib_FindOptSync < cindx_FindOptSync;
           ib_FindOptSync++) {
        xcorrMat_FindOptSync->data_FindOptSync[ia_FindOptSync +
          xcorrMat_FindOptSync->size_FindOptSync[0] * ib_FindOptSync].re = 0.0;
        xcorrMat_FindOptSync->data_FindOptSync[ia_FindOptSync +
          xcorrMat_FindOptSync->size_FindOptSync[0] * ib_FindOptSync].im = 0.0;
        br_FindOptSync = a_FindOptSync->size_FindOptSync[1];
        for (iy_FindOptSync = 0; iy_FindOptSync < br_FindOptSync; iy_FindOptSync
             ++) {
          temp_re_FindOptSync = a_FindOptSync->data_FindOptSync[ia_FindOptSync +
            a_FindOptSync->size_FindOptSync[0] * iy_FindOptSync].re *
            b_FindOptSync->data_FindOptSync[iy_FindOptSync +
            b_FindOptSync->size_FindOptSync[0] * ib_FindOptSync].re -
            a_FindOptSync->data_FindOptSync[ia_FindOptSync +
            a_FindOptSync->size_FindOptSync[0] * iy_FindOptSync].im *
            b_FindOptSync->data_FindOptSync[iy_FindOptSync +
            b_FindOptSync->size_FindOptSync[0] * ib_FindOptSync].im;
          temp_im_FindOptSync = a_FindOptSync->data_FindOptSync[ia_FindOptSync +
            a_FindOptSync->size_FindOptSync[0] * iy_FindOptSync].re *
            b_FindOptSync->data_FindOptSync[iy_FindOptSync +
            b_FindOptSync->size_FindOptSync[0] * ib_FindOptSync].im +
            a_FindOptSync->data_FindOptSync[ia_FindOptSync +
            a_FindOptSync->size_FindOptSync[0] * iy_FindOptSync].im *
            b_FindOptSync->data_FindOptSync[iy_FindOptSync +
            b_FindOptSync->size_FindOptSync[0] * ib_FindOptSync].re;
          xcorrMat_FindOptSync->data_FindOptSync[ia_FindOptSync +
            xcorrMat_FindOptSync->size_FindOptSync[0] * ib_FindOptSync].re +=
            temp_re_FindOptSync;
          xcorrMat_FindOptSync->data_FindOptSync[ia_FindOptSync +
            xcorrMat_FindOptSync->size_FindOptSync[0] * ib_FindOptSync].im +=
            temp_im_FindOptSync;
        }
      }
    }
  } else {
    k_FindOptSync = a_FindOptSync->size_FindOptSync[1];
    ia_FindOptSync = pilotSequenceUpSampleMat_FindOptSync->size_FindOptSync[1];
    ib_FindOptSync = xcorrMat_FindOptSync->size_FindOptSync[0] *
      xcorrMat_FindOptSync->size_FindOptSync[1];
    xcorrMat_FindOptSync->size_FindOptSync[1] = ia_FindOptSync;
    xcorrMat_FindOptSync->size_FindOptSync[0] = 4;
    emxEnsureCapacity_creal_T_FindOptSync(xcorrMat_FindOptSync, ib_FindOptSync);
    cindx_FindOptSync = xcorrMat_FindOptSync->size_FindOptSync[1];
    for (ia_FindOptSync = 0; ia_FindOptSync < cindx_FindOptSync; ia_FindOptSync
         ++) {
      for (ib_FindOptSync = 0; ib_FindOptSync < 4; ib_FindOptSync++) {
        xcorrMat_FindOptSync->data_FindOptSync[ib_FindOptSync +
          xcorrMat_FindOptSync->size_FindOptSync[0] * ia_FindOptSync].re = 0.0;
        xcorrMat_FindOptSync->data_FindOptSync[ib_FindOptSync +
          xcorrMat_FindOptSync->size_FindOptSync[0] * ia_FindOptSync].im = 0.0;
      }
    }

    ia_FindOptSync = pilotSequenceUpSampleMat_FindOptSync->size_FindOptSync[1];
    if (ia_FindOptSync != 0) {
      ia_FindOptSync = pilotSequenceUpSampleMat_FindOptSync->size_FindOptSync[1]
        - 1;
      c_FindOptSync = ia_FindOptSync << 2;
      if (c_FindOptSync > 2147483643) {
        check_forloop_overflow_error_FindOptSync();
      }

      for (iy_FindOptSync = 4; iy_FindOptSync - 4 <= c_FindOptSync;
           iy_FindOptSync += 4) {
        if ((!(iy_FindOptSync - 3 > iy_FindOptSync)) && (iy_FindOptSync >
             2147483646)) {
          check_forloop_overflow_error_FindOptSync();
        }

        for (ix_FindOptSync = iy_FindOptSync - 3; ix_FindOptSync <=
             iy_FindOptSync; ix_FindOptSync++) {
          xcorrMat_FindOptSync->data_FindOptSync[ix_FindOptSync - 1].re = 0.0;
          xcorrMat_FindOptSync->data_FindOptSync[ix_FindOptSync - 1].im = 0.0;
        }
      }

      br_FindOptSync = 0;
      if (c_FindOptSync > 2147483643) {
        check_forloop_overflow_error_FindOptSync();
      }

      for (iy_FindOptSync = 4; iy_FindOptSync - 4 <= c_FindOptSync;
           iy_FindOptSync += 4) {
        ar_FindOptSync = 0;
        cindx_FindOptSync = br_FindOptSync + k_FindOptSync;
        if ((!(br_FindOptSync + 1 > cindx_FindOptSync)) && (cindx_FindOptSync >
             2147483646)) {
          check_forloop_overflow_error_FindOptSync();
        }

        for (ib_FindOptSync = br_FindOptSync; ib_FindOptSync + 1 <=
             cindx_FindOptSync; ib_FindOptSync++) {
          overflow_FindOptSync = ((b_FindOptSync->
            data_FindOptSync[ib_FindOptSync].re != 0.0) ||
            (b_FindOptSync->data_FindOptSync[ib_FindOptSync].im != 0.0));
          if (overflow_FindOptSync) {
            temp_re_FindOptSync = b_FindOptSync->data_FindOptSync[ib_FindOptSync]
              .re - 0.0 * b_FindOptSync->data_FindOptSync[ib_FindOptSync].im;
            temp_im_FindOptSync = b_FindOptSync->data_FindOptSync[ib_FindOptSync]
              .im + 0.0 * b_FindOptSync->data_FindOptSync[ib_FindOptSync].re;
            ia_FindOptSync = ar_FindOptSync;
            if ((!(iy_FindOptSync - 3 > iy_FindOptSync)) && (iy_FindOptSync >
                 2147483646)) {
              check_forloop_overflow_error_FindOptSync();
            }

            for (ix_FindOptSync = iy_FindOptSync - 4; ix_FindOptSync + 1 <=
                 iy_FindOptSync; ix_FindOptSync++) {
              ia_FindOptSync++;
              b_temp_re_FindOptSync = temp_re_FindOptSync *
                a_FindOptSync->data_FindOptSync[ia_FindOptSync - 1].re -
                temp_im_FindOptSync * a_FindOptSync->
                data_FindOptSync[ia_FindOptSync - 1].im;
              b_temp_im_FindOptSync = temp_re_FindOptSync *
                a_FindOptSync->data_FindOptSync[ia_FindOptSync - 1].im +
                temp_im_FindOptSync * a_FindOptSync->
                data_FindOptSync[ia_FindOptSync - 1].re;
              xcorrMat_FindOptSync->data_FindOptSync[ix_FindOptSync].re +=
                b_temp_re_FindOptSync;
              xcorrMat_FindOptSync->data_FindOptSync[ix_FindOptSync].im +=
                b_temp_im_FindOptSync;
            }
          }

          ar_FindOptSync += 4;
        }

        br_FindOptSync += k_FindOptSync;
      }
    }
  }

  emxFree_creal_T_FindOptSync(&b_FindOptSync);
  emxFree_creal_T_FindOptSync(&a_FindOptSync);
  emxFree_creal_T_FindOptSync(&pilotSequenceUpSampleMat_FindOptSync);

  /* 'FindOptiSyncImplement:30' [~, idxSyncIndexVec] = max(abs(xcorrMat.')); */
  ia_FindOptSync = rxSigNoiseUpSample_FindOptSync->size_FindOptSync[0] *
    rxSigNoiseUpSample_FindOptSync->size_FindOptSync[1];
  rxSigNoiseUpSample_FindOptSync->size_FindOptSync[0] =
    xcorrMat_FindOptSync->size_FindOptSync[1];
  rxSigNoiseUpSample_FindOptSync->size_FindOptSync[1] = 4;
  emxEnsureCapacity_creal_T_FindOptSync(rxSigNoiseUpSample_FindOptSync,
    ia_FindOptSync);
  for (ia_FindOptSync = 0; ia_FindOptSync < 4; ia_FindOptSync++) {
    cindx_FindOptSync = xcorrMat_FindOptSync->size_FindOptSync[1];
    for (ib_FindOptSync = 0; ib_FindOptSync < cindx_FindOptSync; ib_FindOptSync
         ++) {
      rxSigNoiseUpSample_FindOptSync->data_FindOptSync[ib_FindOptSync +
        rxSigNoiseUpSample_FindOptSync->size_FindOptSync[0] * ia_FindOptSync] =
        xcorrMat_FindOptSync->data_FindOptSync[ia_FindOptSync +
        xcorrMat_FindOptSync->size_FindOptSync[0] * ib_FindOptSync];
    }
  }

  emxFree_creal_T_FindOptSync(&xcorrMat_FindOptSync);
  emxInit_real_T_FindOptSync(&varargin_1_FindOptSync, 2);
  abs_FindOptSync(rxSigNoiseUpSample_FindOptSync, varargin_1_FindOptSync);
  emxFree_creal_T_FindOptSync(&rxSigNoiseUpSample_FindOptSync);
  overflow_FindOptSync = (varargin_1_FindOptSync->size_FindOptSync[0] != 1);
  if (!overflow_FindOptSync) {
    e_rtErrorWithMessageID_FindOptSync(&e_emlrtRTEI_FindOptSync);
  }

  if (!(varargin_1_FindOptSync->size_FindOptSync[0] > 0)) {
    d_rtErrorWithMessageID_FindOptSync(&d_emlrtRTEI_FindOptSync);
  }

  br_FindOptSync = varargin_1_FindOptSync->size_FindOptSync[0];
  for (ia_FindOptSync = 0; ia_FindOptSync < 4; ia_FindOptSync++) {
    ix_FindOptSync = ia_FindOptSync * br_FindOptSync;
    iy_FindOptSync = ia_FindOptSync * br_FindOptSync + 1;
    ar_FindOptSync = ix_FindOptSync + br_FindOptSync;
    temp_re_FindOptSync = varargin_1_FindOptSync->
      data_FindOptSync[ix_FindOptSync];
    ib_FindOptSync = 1;
    if (br_FindOptSync > 1) {
      cindx_FindOptSync = 1;
      if (rtIsNaN(varargin_1_FindOptSync->data_FindOptSync[ix_FindOptSync])) {
        if ((!(iy_FindOptSync + 1 > ar_FindOptSync)) && (ar_FindOptSync >
             2147483646)) {
          check_forloop_overflow_error_FindOptSync();
        }

        ix_FindOptSync = iy_FindOptSync;
        exitg1_FindOptSync = false;
        while ((!exitg1_FindOptSync) && (ix_FindOptSync + 1 <= ar_FindOptSync))
        {
          cindx_FindOptSync++;
          iy_FindOptSync = ix_FindOptSync + 1;
          if (!rtIsNaN(varargin_1_FindOptSync->data_FindOptSync[ix_FindOptSync]))
          {
            temp_re_FindOptSync = varargin_1_FindOptSync->
              data_FindOptSync[ix_FindOptSync];
            ib_FindOptSync = cindx_FindOptSync;
            exitg1_FindOptSync = true;
          } else {
            ix_FindOptSync++;
          }
        }
      }

      if (iy_FindOptSync < ar_FindOptSync) {
        if ((!(iy_FindOptSync + 1 > ar_FindOptSync)) && (ar_FindOptSync >
             2147483646)) {
          check_forloop_overflow_error_FindOptSync();
        }

        while (iy_FindOptSync + 1 <= ar_FindOptSync) {
          cindx_FindOptSync++;
          if (varargin_1_FindOptSync->data_FindOptSync[iy_FindOptSync] >
              temp_re_FindOptSync) {
            temp_re_FindOptSync = varargin_1_FindOptSync->
              data_FindOptSync[iy_FindOptSync];
            ib_FindOptSync = cindx_FindOptSync;
          }

          iy_FindOptSync++;
        }
      }
    }

    iindx_FindOptSync[ia_FindOptSync] = ib_FindOptSync;
  }

  emxFree_real_T_FindOptSync(&varargin_1_FindOptSync);
  for (ia_FindOptSync = 0; ia_FindOptSync < 4; ia_FindOptSync++) {
    indx_FindOptSync[ia_FindOptSync] = iindx_FindOptSync[ia_FindOptSync];
  }

  /* 'FindOptiSyncImplement:30' ~ */
  /* 'FindOptiSyncImplement:32' for idxChannel = 1:NumChannel */
  for (br_FindOptSync = 0; br_FindOptSync < 4; br_FindOptSync++) {
    /* 'FindOptiSyncImplement:33' syncIndexMat(idxChannel,idxSyncIndexVec(idxChannel)) = 1; */
    ia_FindOptSync = syncIndexMat_FindOptSync->size_FindOptSync[1];
    if (!((indx_FindOptSync[br_FindOptSync] >= 1) &&
          (indx_FindOptSync[br_FindOptSync] <= ia_FindOptSync))) {
      rtDynamicBoundsError_FindOptSync(indx_FindOptSync[br_FindOptSync], 1,
        ia_FindOptSync, &f_emlrtBCI_FindOptSync);
    }

    syncIndexMat_FindOptSync->data_FindOptSync[br_FindOptSync +
      syncIndexMat_FindOptSync->size_FindOptSync[0] *
      (indx_FindOptSync[br_FindOptSync] - 1)] = 1;
  }

  /* 'FindOptiSyncImplement:36' [numSyncChannel, idxShift] = max(sum(syncIndexMat)); */
  emxInit_real_T_FindOptSync(&y_FindOptSync, 2);
  if (syncIndexMat_FindOptSync->size_FindOptSync[1] == 0) {
    ia_FindOptSync = y_FindOptSync->size_FindOptSync[0] *
      y_FindOptSync->size_FindOptSync[1];
    y_FindOptSync->size_FindOptSync[0] = 1;
    y_FindOptSync->size_FindOptSync[1] = 0;
    emxEnsureCapacity_real_T_FindOptSync(y_FindOptSync, ia_FindOptSync);
  } else {
    ia_FindOptSync = y_FindOptSync->size_FindOptSync[0] *
      y_FindOptSync->size_FindOptSync[1];
    y_FindOptSync->size_FindOptSync[0] = 1;
    y_FindOptSync->size_FindOptSync[1] =
      syncIndexMat_FindOptSync->size_FindOptSync[1];
    emxEnsureCapacity_real_T_FindOptSync(y_FindOptSync, ia_FindOptSync);
    overflow_FindOptSync = (syncIndexMat_FindOptSync->size_FindOptSync[1] >
      2147483646);
    if (overflow_FindOptSync) {
      check_forloop_overflow_error_FindOptSync();
    }

    for (ia_FindOptSync = 0; ia_FindOptSync + 1 <=
         syncIndexMat_FindOptSync->size_FindOptSync[1]; ia_FindOptSync++) {
      br_FindOptSync = ia_FindOptSync << 2;
      y_FindOptSync->data_FindOptSync[ia_FindOptSync] =
        syncIndexMat_FindOptSync->data_FindOptSync[br_FindOptSync];
      for (k_FindOptSync = 0; k_FindOptSync < 3; k_FindOptSync++) {
        y_FindOptSync->data_FindOptSync[ia_FindOptSync] += (double)
          syncIndexMat_FindOptSync->data_FindOptSync[(br_FindOptSync +
          k_FindOptSync) + 1];
      }
    }
  }

  emxFree_int8_T_FindOptSync(&syncIndexMat_FindOptSync);
  if ((y_FindOptSync->size_FindOptSync[1] == 1) ||
      (y_FindOptSync->size_FindOptSync[1] != 1)) {
    overflow_FindOptSync = true;
  } else {
    overflow_FindOptSync = false;
  }

  if (!overflow_FindOptSync) {
    e_rtErrorWithMessageID_FindOptSync(&e_emlrtRTEI_FindOptSync);
  }

  if (!(y_FindOptSync->size_FindOptSync[1] > 0)) {
    d_rtErrorWithMessageID_FindOptSync(&d_emlrtRTEI_FindOptSync);
  }

  br_FindOptSync = y_FindOptSync->size_FindOptSync[1];
  *numSyncChannel_FindOptSync = y_FindOptSync->data_FindOptSync[0];
  ib_FindOptSync = 1;
  if (y_FindOptSync->size_FindOptSync[1] > 1) {
    overflow_FindOptSync = (y_FindOptSync->size_FindOptSync[1] > 2147483646);
    if (overflow_FindOptSync) {
      check_forloop_overflow_error_FindOptSync();
    }

    for (ix_FindOptSync = 2; ix_FindOptSync <= br_FindOptSync; ix_FindOptSync++)
    {
      if (y_FindOptSync->data_FindOptSync[ix_FindOptSync - 1] >
          *numSyncChannel_FindOptSync) {
        *numSyncChannel_FindOptSync = y_FindOptSync->
          data_FindOptSync[ix_FindOptSync - 1];
        ib_FindOptSync = ix_FindOptSync;
      }
    }
  }

  emxFree_real_T_FindOptSync(&y_FindOptSync);

  /* 'FindOptiSyncImplement:37' circShiftSelect = circShiftPattern(idxShift); */
  ia_FindOptSync = circShiftPattern_FindOptSync->size_FindOptSync[1];
  if (!((ib_FindOptSync >= 1) && (ib_FindOptSync <= ia_FindOptSync))) {
    rtDynamicBoundsError_FindOptSync(ib_FindOptSync, 1, ia_FindOptSync,
      &g_emlrtBCI_FindOptSync);
  }

  *circShiftSelect_FindOptSync = circShiftPattern_FindOptSync->
    data_FindOptSync[ib_FindOptSync - 1];

  /* 'FindOptiSyncImplement:38' pilotSequenceUpSampleShift = circshift(pilotSequenceUpSample, circShiftSelect); */
  memcpy(&pilotSequenceUpSampleShift_FindOptSync[0],
         &pilotSequenceUpSample_FindOptSync[0], 1536U * sizeof(creal_T));
  circshift_FindOptSync(pilotSequenceUpSampleShift_FindOptSync,
                        circShiftPattern_FindOptSync->
                        data_FindOptSync[ib_FindOptSync - 1]);

  /* 'FindOptiSyncImplement:39' pilotSequence = downsample(pilotSequenceUpSampleShift, UpSampleTimes); */
  emxFree_real_T_FindOptSync(&circShiftPattern_FindOptSync);
  if (UpSampleTimes_FindOptSync < 0.0) {
    b_UpSampleTimes_FindOptSync = ceil(UpSampleTimes_FindOptSync);
  } else {
    b_UpSampleTimes_FindOptSync = floor(UpSampleTimes_FindOptSync);
  }

  if ((b_UpSampleTimes_FindOptSync == UpSampleTimes_FindOptSync) &&
      (UpSampleTimes_FindOptSync > 0.0)) {
    overflow_FindOptSync = true;
  } else {
    overflow_FindOptSync = false;
  }

  if (!overflow_FindOptSync) {
    c_rtErrorWithMessageID_FindOptSync(45,
      "Downsample factor must be a positive integer.", &c_emlrtRTEI_FindOptSync);
  }

  if (!(0.0 <= UpSampleTimes_FindOptSync - 1.0)) {
    b_rtErrorWithMessageID_FindOptSync(40,
      "Offset must be an integer from 0 to N-1.", &b_emlrtRTEI_FindOptSync);
  }

  ia_FindOptSync = (int)UpSampleTimes_FindOptSync;
  if (ia_FindOptSync == 0) {
    b_ia_FindOptSync = MAX_int32_T;
  } else {
    b_ia_FindOptSync = 1535 / ia_FindOptSync;
  }

  c_FindOptSync = b_ia_FindOptSync + 1;
  if (!(c_FindOptSync <= 1536)) {
    rtErrorWithMessageID_FindOptSync(&emlrtRTEI_FindOptSync);
  }

  for (ia_FindOptSync = 0; ia_FindOptSync < 2; ia_FindOptSync++) {
    sz_FindOptSync[ia_FindOptSync] = 1536 + -1535 * ia_FindOptSync;
  }

  sz_FindOptSync[0] = c_FindOptSync;
  for (ia_FindOptSync = 0; ia_FindOptSync < 2; ia_FindOptSync++) {
    ib_FindOptSync = sz_FindOptSync[ia_FindOptSync];
    if (!(ib_FindOptSync >= 0)) {
      rtNonNegativeError_FindOptSync(ib_FindOptSync, &n_emlrtDCI_FindOptSync);
    }
  }

  pilotSequence_size_FindOptSync[0] = c_FindOptSync;
  ix_FindOptSync = 1;
  iy_FindOptSync = 1;
  if ((!(1 > c_FindOptSync)) && (c_FindOptSync > 2147483646)) {
    check_forloop_overflow_error_FindOptSync();
  }

  for (k_FindOptSync = 1; k_FindOptSync <= c_FindOptSync; k_FindOptSync++) {
    if (!((iy_FindOptSync >= 1) && (iy_FindOptSync <= c_FindOptSync))) {
      rtDynamicBoundsError_FindOptSync(iy_FindOptSync, 1, c_FindOptSync,
        &k_emlrtBCI_FindOptSync);
    }

    if (!((ix_FindOptSync >= 1) && (ix_FindOptSync <= 1536))) {
      rtDynamicBoundsError_FindOptSync(ix_FindOptSync, 1, 1536,
        &l_emlrtBCI_FindOptSync);
    }

    pilotSequence_data_FindOptSync[iy_FindOptSync - 1].re =
      pilotSequenceUpSampleShift_FindOptSync[ix_FindOptSync - 1].re;
    if (!((ix_FindOptSync >= 1) && (ix_FindOptSync <= 1536))) {
      rtDynamicBoundsError_FindOptSync(ix_FindOptSync, 1, 1536,
        &h_emlrtBCI_FindOptSync);
    }

    if (!((iy_FindOptSync >= 1) && (iy_FindOptSync <= c_FindOptSync))) {
      rtDynamicBoundsError_FindOptSync(iy_FindOptSync, 1, c_FindOptSync,
        &i_emlrtBCI_FindOptSync);
    }

    pilotSequence_data_FindOptSync[iy_FindOptSync - 1].im =
      pilotSequenceUpSampleShift_FindOptSync[ix_FindOptSync - 1].im;
    ix_FindOptSync += (int)UpSampleTimes_FindOptSync;
    iy_FindOptSync++;
  }
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void FindOptiSyncImplement_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void FindOptiSyncImplement_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for FindOptiSyncImplement.c
 *
 * [EOF]
 */
