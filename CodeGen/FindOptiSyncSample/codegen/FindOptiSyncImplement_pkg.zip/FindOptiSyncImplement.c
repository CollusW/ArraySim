/*
 * File: FindOptiSyncImplement.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 25-Jan-2018 15:37:24
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "FindOptiSyncImplement.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Type Definitions */
#ifndef struct_emxArray__common_FindOptiSync
#define struct_emxArray__common_FindOptiSync

struct emxArray__common_FindOptiSync
{
  void *data_FindOptiSync;
  int *size_FindOptiSync;
  int allocatedSize_FindOptiSync;
  int numDimensions_FindOptiSync;
  boolean_T canFreeData_FindOptiSync;
};

#endif                                 /*struct_emxArray__common_FindOptiSync*/

#ifndef typedef_emxArray__common_FindOptiSync
#define typedef_emxArray__common_FindOptiSync

typedef struct emxArray__common_FindOptiSync emxArray__common_FindOptiSync;

#endif                                 /*typedef_emxArray__common_FindOptiSync*/

#ifndef struct_emxArray_creal_T_FindOptiSync
#define struct_emxArray_creal_T_FindOptiSync

struct emxArray_creal_T_FindOptiSync
{
  creal_T *data_FindOptiSync;
  int *size_FindOptiSync;
  int allocatedSize_FindOptiSync;
  int numDimensions_FindOptiSync;
  boolean_T canFreeData_FindOptiSync;
};

#endif                                 /*struct_emxArray_creal_T_FindOptiSync*/

#ifndef typedef_emxArray_creal_T_FindOptiSync
#define typedef_emxArray_creal_T_FindOptiSync

typedef struct emxArray_creal_T_FindOptiSync emxArray_creal_T_FindOptiSync;

#endif                                 /*typedef_emxArray_creal_T_FindOptiSync*/

#ifndef struct_emxArray_int32_T_FindOptiSync
#define struct_emxArray_int32_T_FindOptiSync

struct emxArray_int32_T_FindOptiSync
{
  int *data_FindOptiSync;
  int *size_FindOptiSync;
  int allocatedSize_FindOptiSync;
  int numDimensions_FindOptiSync;
  boolean_T canFreeData_FindOptiSync;
};

#endif                                 /*struct_emxArray_int32_T_FindOptiSync*/

#ifndef typedef_emxArray_int32_T_FindOptiSync
#define typedef_emxArray_int32_T_FindOptiSync

typedef struct emxArray_int32_T_FindOptiSync emxArray_int32_T_FindOptiSync;

#endif                                 /*typedef_emxArray_int32_T_FindOptiSync*/

#ifndef struct_emxArray_real_T_FindOptiSync
#define struct_emxArray_real_T_FindOptiSync

struct emxArray_real_T_FindOptiSync
{
  double *data_FindOptiSync;
  int *size_FindOptiSync;
  int allocatedSize_FindOptiSync;
  int numDimensions_FindOptiSync;
  boolean_T canFreeData_FindOptiSync;
};

#endif                                 /*struct_emxArray_real_T_FindOptiSync*/

#ifndef typedef_emxArray_real_T_FindOptiSync
#define typedef_emxArray_real_T_FindOptiSync

typedef struct emxArray_real_T_FindOptiSync emxArray_real_T_FindOptiSync;

#endif                                 /*typedef_emxArray_real_T_FindOptiSync*/

#ifndef typedef_rtBoundsCheckInfo_FindOptiSync
#define typedef_rtBoundsCheckInfo_FindOptiSync

typedef struct {
  int iFirst_FindOptiSync;
  int iLast_FindOptiSync;
  int lineNo_FindOptiSync;
  int colNo_FindOptiSync;
  const char * aName_FindOptiSync;
  const char * fName_FindOptiSync;
  const char * pName_FindOptiSync;
  int checkKind_FindOptiSync;
} rtBoundsCheckInfo_FindOptiSync;

#endif                                 /*typedef_rtBoundsCheckInfo_FindOptiSync*/

#ifndef typedef_rtDoubleCheckInfo_FindOptiSync
#define typedef_rtDoubleCheckInfo_FindOptiSync

typedef struct {
  int lineNo_FindOptiSync;
  int colNo_FindOptiSync;
  const char * fName_FindOptiSync;
  const char * pName_FindOptiSync;
  int checkKind_FindOptiSync;
} rtDoubleCheckInfo_FindOptiSync;

#endif                                 /*typedef_rtDoubleCheckInfo_FindOptiSync*/

#ifndef typedef_rtEqualityCheckInfo_FindOptiSyn
#define typedef_rtEqualityCheckInfo_FindOptiSyn

typedef struct {
  int nDims_FindOptiSync;
  int lineNo_FindOptiSync;
  int colNo_FindOptiSync;
  const char * fName_FindOptiSync;
  const char * pName_FindOptiSync;
} rtEqualityCheckInfo_FindOptiSyn;

#endif                                 /*typedef_rtEqualityCheckInfo_FindOptiSyn*/

#ifndef typedef_rtRunTimeErrorInfo_FindOptiSync
#define typedef_rtRunTimeErrorInfo_FindOptiSync

typedef struct {
  int lineNo_FindOptiSync;
  int colNo_FindOptiSync;
  const char * fName_FindOptiSync;
  const char * pName_FindOptiSync;
} rtRunTimeErrorInfo_FindOptiSync;

#endif                                 /*typedef_rtRunTimeErrorInfo_FindOptiSync*/

/* Variable Definitions */
static rtRunTimeErrorInfo_FindOptiSync emlrtRTEI_FindOptiSync = { 86, 1,
  "downsample",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\eml\\downsample.m" };

static rtRunTimeErrorInfo_FindOptiSync b_emlrtRTEI_FindOptiSync = { 33, 5,
  "downsample",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\eml\\downsample.m" };

static rtRunTimeErrorInfo_FindOptiSync c_emlrtRTEI_FindOptiSync = { 24, 5,
  "downsample",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\eml\\downsample.m" };

static rtBoundsCheckInfo_FindOptiSync emlrtBCI_FindOptiSync = { -1, -1, 394, 47,
  "", "minOrMax",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\minOrMax.m",
  0 };

static rtRunTimeErrorInfo_FindOptiSync d_emlrtRTEI_FindOptiSync = { 121, 27,
  "minOrMax",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\minOrMax.m"
};

static rtRunTimeErrorInfo_FindOptiSync e_emlrtRTEI_FindOptiSync = { 39, 27,
  "minOrMax",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\minOrMax.m"
};

static rtRunTimeErrorInfo_FindOptiSync f_emlrtRTEI_FindOptiSync = { 48, 9,
  "sumprod",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\datafun\\private\\sumprod.m"
};

static rtBoundsCheckInfo_FindOptiSync b_emlrtBCI_FindOptiSync = { -1, -1, 353,
  27, "", "minOrMax",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\minOrMax.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync c_emlrtBCI_FindOptiSync = { -1, -1, 68, 35,
  "", "applyScalarFunction",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\applyScalarFunction.m",
  0 };

static rtRunTimeErrorInfo_FindOptiSync g_emlrtRTEI_FindOptiSync = { 98, 23,
  "eml_mtimes_helper",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_helper.m"
};

static rtRunTimeErrorInfo_FindOptiSync h_emlrtRTEI_FindOptiSync = { 103, 23,
  "eml_mtimes_helper",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_helper.m"
};

static rtRunTimeErrorInfo_FindOptiSync i_emlrtRTEI_FindOptiSync = { 404, 15,
  "colon",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\colon.m" };

static rtBoundsCheckInfo_FindOptiSync d_emlrtBCI_FindOptiSync = { -1, -1, 286, 5,
  "", "colon",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\colon.m",
  0 };

static rtEqualityCheckInfo_FindOptiSyn emlrtECI_FindOptiSync = { -1, 24, 5,
  "FindOptiSyncImplement",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m"
};

static rtBoundsCheckInfo_FindOptiSync e_emlrtBCI_FindOptiSync = { -1, -1, 24, 32,
  "pilotSequenceUpSampleMat", "FindOptiSyncImplement",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",
  0 };

static rtDoubleCheckInfo_FindOptiSync emlrtDCI_FindOptiSync = { 18, 34,
  "FindOptiSyncImplement",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",
  1 };

static rtDoubleCheckInfo_FindOptiSync b_emlrtDCI_FindOptiSync = { 18, 34,
  "FindOptiSyncImplement",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",
  4 };

static rtDoubleCheckInfo_FindOptiSync c_emlrtDCI_FindOptiSync = { 22, 42,
  "FindOptiSyncImplement",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",
  1 };

static rtDoubleCheckInfo_FindOptiSync d_emlrtDCI_FindOptiSync = { 22, 42,
  "FindOptiSyncImplement",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",
  4 };

static rtBoundsCheckInfo_FindOptiSync f_emlrtBCI_FindOptiSync = { -1, -1, 288, 9,
  "", "colon",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\colon.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync g_emlrtBCI_FindOptiSync = { -1, -1, 300,
  13, "", "colon",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\colon.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync h_emlrtBCI_FindOptiSync = { -1, -1, 301,
  13, "", "colon",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\colon.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync i_emlrtBCI_FindOptiSync = { -1, -1, 297,
  13, "", "colon",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\colon.m",
  0 };

static rtDoubleCheckInfo_FindOptiSync e_emlrtDCI_FindOptiSync = { 18, 1,
  "FindOptiSyncImplement",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",
  1 };

static rtDoubleCheckInfo_FindOptiSync f_emlrtDCI_FindOptiSync = { 18, 1,
  "FindOptiSyncImplement",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",
  4 };

static rtDoubleCheckInfo_FindOptiSync g_emlrtDCI_FindOptiSync = { 22, 1,
  "FindOptiSyncImplement",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",
  1 };

static rtDoubleCheckInfo_FindOptiSync h_emlrtDCI_FindOptiSync = { 22, 1,
  "FindOptiSyncImplement",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",
  4 };

static rtBoundsCheckInfo_FindOptiSync j_emlrtBCI_FindOptiSync = { -1, -1, 92, 33,
  "", "xgemm",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\xgemm.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync k_emlrtBCI_FindOptiSync = { -1, -1, 92, 25,
  "", "xgemm",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\xgemm.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync l_emlrtBCI_FindOptiSync = { -1, -1, 65, 13,
  "", "xgemm",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\xgemm.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync m_emlrtBCI_FindOptiSync = { -1, -1, 108,
  30, "", "combine_vector_elements",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\datafun\\private\\combine_vector_elements.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync n_emlrtBCI_FindOptiSync = { -1, -1, 121,
  17, "", "combine_vector_elements",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\datafun\\private\\combine_vector_elements.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync o_emlrtBCI_FindOptiSync = { -1, -1, 115,
  38, "", "combine_vector_elements",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\datafun\\private\\combine_vector_elements.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync p_emlrtBCI_FindOptiSync = { -1, -1, 35, 19,
  "circShiftPattern", "FindOptiSyncImplement",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",
  0 };

static rtDoubleCheckInfo_FindOptiSync i_emlrtDCI_FindOptiSync = { 89, 33,
  "downsample",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\eml\\downsample.m", 4 };

static rtBoundsCheckInfo_FindOptiSync q_emlrtBCI_FindOptiSync = { 1, 1536, 72,
  17, "", "downsample",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\eml\\downsample.m", 0 };

static rtBoundsCheckInfo_FindOptiSync r_emlrtBCI_FindOptiSync = { -1, -1, 72, 9,
  "", "downsample",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\eml\\downsample.m", 0 };

static rtBoundsCheckInfo_FindOptiSync s_emlrtBCI_FindOptiSync = { -1, -1, 395,
  28, "", "minOrMax",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\minOrMax.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync t_emlrtBCI_FindOptiSync = { -1, -1, 31, 5,
  "syncIndexMat", "FindOptiSyncImplement",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync u_emlrtBCI_FindOptiSync = { -1, -1, 333,
  12, "", "minOrMax",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\minOrMax.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync v_emlrtBCI_FindOptiSync = { -1, -1, 354,
  32, "", "minOrMax",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\minOrMax.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync w_emlrtBCI_FindOptiSync = { -1, -1, 68, 17,
  "", "applyScalarFunction",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\applyScalarFunction.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync x_emlrtBCI_FindOptiSync = { -1, -1, 24, 77,
  "circShiftPattern", "FindOptiSyncImplement",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync y_emlrtBCI_FindOptiSync = { -1, -1, 293,
  13, "", "colon",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\colon.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync ab_emlrtBCI_FindOptiSync = { -1, -1, 294,
  13, "", "colon",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\colon.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync bb_emlrtBCI_FindOptiSync = { -1, -1, 88,
  21, "", "xgemm",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\xgemm.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync cb_emlrtBCI_FindOptiSync = { -1, -1, 87,
  20, "", "xgemm",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\xgemm.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync db_emlrtBCI_FindOptiSync = { -1, -1, 92,
  41, "", "xgemm",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\xgemm.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync eb_emlrtBCI_FindOptiSync = { -1, -1, 27, 1,
  "", "FindOptiSyncImplement",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync fb_emlrtBCI_FindOptiSync = { -1, -1, 37, 1,
  "", "FindOptiSyncImplement",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync gb_emlrtBCI_FindOptiSync = { 1, 1536, 37,
  1, "", "FindOptiSyncImplement",
  "C:\\Users\\WaynEArcheR\\Desktop\\ArraySim\\CodeGen\\FindOptiSyncSample\\FindOptiSyncImplement.m",
  0 };

static rtRunTimeErrorInfo_FindOptiSync j_emlrtRTEI_FindOptiSync = { 86, 15,
  "eml_int_forloop_overflow_check",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\eml\\eml_int_forloop_overflow_check.m"
};

static rtRunTimeErrorInfo_FindOptiSync k_emlrtRTEI_FindOptiSync = { 32, 5,
  "upsample",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\eml\\upsample.m" };

static rtRunTimeErrorInfo_FindOptiSync l_emlrtRTEI_FindOptiSync = { 44, 5,
  "upsample",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\eml\\upsample.m" };

static rtBoundsCheckInfo_FindOptiSync hb_emlrtBCI_FindOptiSync = { 1, 2048, 77,
  17, "", "upsample",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\eml\\upsample.m", 0 };

static rtBoundsCheckInfo_FindOptiSync ib_emlrtBCI_FindOptiSync = { -1, -1, 77, 9,
  "", "upsample",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\eml\\upsample.m", 0 };

static rtBoundsCheckInfo_FindOptiSync jb_emlrtBCI_FindOptiSync = { 1, 2048, 77,
  9, "", "upsample",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\eml\\upsample.m", 0 };

static rtRunTimeErrorInfo_FindOptiSync m_emlrtRTEI_FindOptiSync = { 24, 48,
  "circshift",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\elmat\\circshift.m"
};

static rtBoundsCheckInfo_FindOptiSync kb_emlrtBCI_FindOptiSync = { 1, 1536, 122,
  21, "", "circshift",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\elmat\\circshift.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync lb_emlrtBCI_FindOptiSync = { 1, 1536, 118,
  46, "", "circshift",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\elmat\\circshift.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync mb_emlrtBCI_FindOptiSync = { 1, 1536, 105,
  46, "", "circshift",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\elmat\\circshift.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync nb_emlrtBCI_FindOptiSync = { 1, 1536, 101,
  33, "", "circshift",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\elmat\\circshift.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync ob_emlrtBCI_FindOptiSync = { 1, 1536, 101,
  21, "", "circshift",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\elmat\\circshift.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync pb_emlrtBCI_FindOptiSync = { 1, 1536, 105,
  21, "", "circshift",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\elmat\\circshift.m",
  0 };

static rtBoundsCheckInfo_FindOptiSync qb_emlrtBCI_FindOptiSync = { 1, 1536, 118,
  21, "", "circshift",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\elmat\\circshift.m",
  0 };

/* Function Declarations */
static void b_rtErrorWithMessageID_FindOpti(const int b_FindOptiSync, const char
  *c_FindOptiSync, const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync);
static void c_rtErrorWithMessageID_FindOpti(const int b_FindOptiSync, const char
  *c_FindOptiSync, const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync);
static void check_forloop_overflow_error_Fi(void);
static void circshift_FindOptiSync(creal_T a_FindOptiSync[1536], double
  p_FindOptiSync);
static void d_rtErrorWithMessageID_FindOpti(const
  rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync);
static void e_rtErrorWithMessageID_FindOpti(const
  rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync);
static void emxEnsureCapacity_FindOptiSync(emxArray__common_FindOptiSync
  *emxArray_FindOptiSync, int oldNumel_FindOptiSync, int
  elementSize_FindOptiSync);
static void emxFree_creal_T_FindOptiSync(emxArray_creal_T_FindOptiSync
  **pEmxArray_FindOptiSync);
static void emxFree_int32_T_FindOptiSync(emxArray_int32_T_FindOptiSync
  **pEmxArray_FindOptiSync);
static void emxFree_real_T_FindOptiSync(emxArray_real_T_FindOptiSync
  **pEmxArray_FindOptiSync);
static void emxInit_creal_T_FindOptiSync(emxArray_creal_T_FindOptiSync
  **pEmxArray_FindOptiSync, int numDimensions_FindOptiSync);
static void emxInit_int32_T_FindOptiSync(emxArray_int32_T_FindOptiSync
  **pEmxArray_FindOptiSync, int numDimensions_FindOptiSync);
static void emxInit_real_T_FindOptiSync(emxArray_real_T_FindOptiSync
  **pEmxArray_FindOptiSync, int numDimensions_FindOptiSync);
static void f_rtErrorWithMessageID_FindOpti(const
  rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync);
static void g_rtErrorWithMessageID_FindOpti(const
  rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync);
static void h_rtErrorWithMessageID_FindOpti(const
  rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync);
static void i_rtErrorWithMessageID_FindOpti(const
  rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync);
static boolean_T inrange_FindOptiSync(double p_FindOptiSync);
static void j_rtErrorWithMessageID_FindOpti(const int b_FindOptiSync, const char
  *c_FindOptiSync, const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync);
static void k_rtErrorWithMessageID_FindOpti(const int b_FindOptiSync, const char
  *c_FindOptiSync, const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync);
static void l_rtErrorWithMessageID_FindOpti(const int b_FindOptiSync, const char
  *c_FindOptiSync, const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync);
static void m_rtErrorWithMessageID_FindOpti(const int b_FindOptiSync, const char
  *c_FindOptiSync, const int d_FindOptiSync, const char *e_FindOptiSync, const
  rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync);
static void reduce_FindOptiSync(double p_FindOptiSync, int *absp_FindOptiSync,
  boolean_T *shiftright_FindOptiSync);
static void rtAddSizeString_FindOptiSync(char * aBuf_FindOptiSync, const int
  aDim_FindOptiSync);
static void rtDynamicBoundsError_FindOptiSy(int aIndexValue_FindOptiSync, int
  aLoBound_FindOptiSync, int aHiBound_FindOptiSync, const
  rtBoundsCheckInfo_FindOptiSync *aInfo_FindOptiSync);
static void rtErrorWithMessageID_FindOptiSy(const
  rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync);
static void rtGenSizeString_FindOptiSync(const int aNDims_FindOptiSync, const
  int *aDims_FindOptiSync, char *aBuf_FindOptiSync);
static void rtIntegerError_FindOptiSync(const double aInteger_FindOptiSync,
  const rtDoubleCheckInfo_FindOptiSync *aInfo_FindOptiSync);
static boolean_T rtIsNullOrEmptyString_FindOptiS(const char
  *aString_FindOptiSync);
static void rtNonNegativeError_FindOptiSync(const double aPositive_FindOptiSync,
  const rtDoubleCheckInfo_FindOptiSync *aInfo_FindOptiSync);
static void rtReportErrorLocation_FindOptiS(const char * aFcnName_FindOptiSync,
  const int aLineNo_FindOptiSync);
static void rtSubAssignSizeCheck_FindOptiSy(const int *aDims1_FindOptiSync,
  const int aNDims1_FindOptiSync, const int *aDims2_FindOptiSync, const int
  aNDims2_FindOptiSync, const rtEqualityCheckInfo_FindOptiSyn
  *aInfo_FindOptiSync);
static double rt_hypotd_snf_FindOptiSync(double u0_FindOptiSync, double
  u1_FindOptiSync);
static void upsample_FindOptiSync(const creal_T x_FindOptiSync[2048], double
  N_FindOptiSync, emxArray_creal_T_FindOptiSync *y_FindOptiSync);

/* Function Definitions */

/*
 * Arguments    : const int b_FindOptiSync
 *                const char *c_FindOptiSync
 *                const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync
 * Return Type  : void
 */
static void b_rtErrorWithMessageID_FindOpti(const int b_FindOptiSync, const char
  *c_FindOptiSync, const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync)
{
  fprintf(stderr, "%.*s", b_FindOptiSync, c_FindOptiSync);
  fprintf(stderr, "\n");
  if (aInfo_FindOptiSync != NULL) {
    rtReportErrorLocation_FindOptiS(aInfo_FindOptiSync->fName_FindOptiSync,
      aInfo_FindOptiSync->lineNo_FindOptiSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const int b_FindOptiSync
 *                const char *c_FindOptiSync
 *                const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync
 * Return Type  : void
 */
static void c_rtErrorWithMessageID_FindOpti(const int b_FindOptiSync, const char
  *c_FindOptiSync, const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync)
{
  fprintf(stderr, "%.*s", b_FindOptiSync, c_FindOptiSync);
  fprintf(stderr, "\n");
  if (aInfo_FindOptiSync != NULL) {
    rtReportErrorLocation_FindOptiS(aInfo_FindOptiSync->fName_FindOptiSync,
      aInfo_FindOptiSync->lineNo_FindOptiSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : void
 * Return Type  : void
 */
static void check_forloop_overflow_error_Fi(void)
{
  j_rtErrorWithMessageID_FindOpti(5, "int32", &j_emlrtRTEI_FindOptiSync);
}

/*
 * Arguments    : creal_T a_FindOptiSync[1536]
 *                double p_FindOptiSync
 * Return Type  : void
 */
static void circshift_FindOptiSync(creal_T a_FindOptiSync[1536], double
  p_FindOptiSync)
{
  int absp_FindOptiSync;
  boolean_T shiftright_FindOptiSync;
  creal_T buffer_FindOptiSync[768];
  int k_FindOptiSync;
  int i3_FindOptiSync;
  if (inrange_FindOptiSync(p_FindOptiSync)) {
  } else {
    m_rtErrorWithMessageID_FindOpti(5, "int32", 5, "int32",
      &m_emlrtRTEI_FindOptiSync);
  }

  reduce_FindOptiSync(p_FindOptiSync, &absp_FindOptiSync,
                      &shiftright_FindOptiSync);
  if (absp_FindOptiSync > 0) {
    if (shiftright_FindOptiSync) {
      if (absp_FindOptiSync > 2147483646) {
        check_forloop_overflow_error_Fi();
      }

      for (k_FindOptiSync = 1; k_FindOptiSync <= absp_FindOptiSync;
           k_FindOptiSync++) {
        i3_FindOptiSync = (k_FindOptiSync - absp_FindOptiSync) + 1536;
        if (!((i3_FindOptiSync >= 1) && (i3_FindOptiSync <= 1536))) {
          rtDynamicBoundsError_FindOptiSy(i3_FindOptiSync, 1, 1536,
            &ob_emlrtBCI_FindOptiSync);
        }

        buffer_FindOptiSync[k_FindOptiSync - 1].re =
          a_FindOptiSync[i3_FindOptiSync - 1].re;
        i3_FindOptiSync = (k_FindOptiSync - absp_FindOptiSync) + 1536;
        if (!((i3_FindOptiSync >= 1) && (i3_FindOptiSync <= 1536))) {
          rtDynamicBoundsError_FindOptiSy(i3_FindOptiSync, 1, 1536,
            &nb_emlrtBCI_FindOptiSync);
        }

        buffer_FindOptiSync[k_FindOptiSync - 1].im =
          a_FindOptiSync[i3_FindOptiSync - 1].im;
      }

      for (k_FindOptiSync = 1536; k_FindOptiSync >= absp_FindOptiSync + 1;
           k_FindOptiSync--) {
        i3_FindOptiSync = k_FindOptiSync - absp_FindOptiSync;
        if (!(i3_FindOptiSync >= 1)) {
          rtDynamicBoundsError_FindOptiSy(i3_FindOptiSync, 1, 1536,
            &pb_emlrtBCI_FindOptiSync);
        }

        a_FindOptiSync[k_FindOptiSync - 1].re = a_FindOptiSync[i3_FindOptiSync -
          1].re;
        i3_FindOptiSync = k_FindOptiSync - absp_FindOptiSync;
        if (!(i3_FindOptiSync >= 1)) {
          rtDynamicBoundsError_FindOptiSy(i3_FindOptiSync, 1, 1536,
            &mb_emlrtBCI_FindOptiSync);
        }

        a_FindOptiSync[k_FindOptiSync - 1].im = a_FindOptiSync[i3_FindOptiSync -
          1].im;
      }

      for (k_FindOptiSync = 0; k_FindOptiSync + 1 <= absp_FindOptiSync;
           k_FindOptiSync++) {
        a_FindOptiSync[k_FindOptiSync] = buffer_FindOptiSync[k_FindOptiSync];
      }
    } else {
      if (absp_FindOptiSync > 2147483646) {
        check_forloop_overflow_error_Fi();
      }

      for (k_FindOptiSync = 0; k_FindOptiSync + 1 <= absp_FindOptiSync;
           k_FindOptiSync++) {
        buffer_FindOptiSync[k_FindOptiSync] = a_FindOptiSync[k_FindOptiSync];
      }

      for (k_FindOptiSync = 1; k_FindOptiSync <= 1536 - absp_FindOptiSync;
           k_FindOptiSync++) {
        i3_FindOptiSync = k_FindOptiSync + absp_FindOptiSync;
        if (!((i3_FindOptiSync >= 1) && (i3_FindOptiSync <= 1536))) {
          rtDynamicBoundsError_FindOptiSy(i3_FindOptiSync, 1, 1536,
            &qb_emlrtBCI_FindOptiSync);
        }

        a_FindOptiSync[k_FindOptiSync - 1].re = a_FindOptiSync[i3_FindOptiSync -
          1].re;
        i3_FindOptiSync = k_FindOptiSync + absp_FindOptiSync;
        if (!((i3_FindOptiSync >= 1) && (i3_FindOptiSync <= 1536))) {
          rtDynamicBoundsError_FindOptiSy(i3_FindOptiSync, 1, 1536,
            &lb_emlrtBCI_FindOptiSync);
        }

        a_FindOptiSync[k_FindOptiSync - 1].im = a_FindOptiSync[i3_FindOptiSync -
          1].im;
      }

      for (k_FindOptiSync = 1; k_FindOptiSync <= absp_FindOptiSync;
           k_FindOptiSync++) {
        i3_FindOptiSync = (k_FindOptiSync - absp_FindOptiSync) + 1536;
        if (!((i3_FindOptiSync >= 1) && (i3_FindOptiSync <= 1536))) {
          rtDynamicBoundsError_FindOptiSy(i3_FindOptiSync, 1, 1536,
            &kb_emlrtBCI_FindOptiSync);
        }

        a_FindOptiSync[i3_FindOptiSync - 1].re =
          buffer_FindOptiSync[k_FindOptiSync - 1].re;
        i3_FindOptiSync = (k_FindOptiSync - absp_FindOptiSync) + 1536;
        if (!((i3_FindOptiSync >= 1) && (i3_FindOptiSync <= 1536))) {
          rtDynamicBoundsError_FindOptiSy(i3_FindOptiSync, 1, 1536,
            &kb_emlrtBCI_FindOptiSync);
        }

        a_FindOptiSync[i3_FindOptiSync - 1].im =
          buffer_FindOptiSync[k_FindOptiSync - 1].im;
      }
    }
  }
}

/*
 * Arguments    : const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync
 * Return Type  : void
 */
static void d_rtErrorWithMessageID_FindOpti(const
  rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync)
{
  fprintf(stderr,
          "If the working dimension of MAX or MIN is variable in length, it must not have zero length at runtime.");
  fprintf(stderr, "\n");
  if (aInfo_FindOptiSync != NULL) {
    rtReportErrorLocation_FindOptiS(aInfo_FindOptiSync->fName_FindOptiSync,
      aInfo_FindOptiSync->lineNo_FindOptiSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync
 * Return Type  : void
 */
static void e_rtErrorWithMessageID_FindOpti(const
  rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync)
{
  fprintf(stderr,
          "The working dimension was selected automatically, is variable-length, and has length 1 at run time. This is not supported. Manua"
          "lly select the working dimension by supplying the DIM argument.");
  fprintf(stderr, "\n");
  if (aInfo_FindOptiSync != NULL) {
    rtReportErrorLocation_FindOptiS(aInfo_FindOptiSync->fName_FindOptiSync,
      aInfo_FindOptiSync->lineNo_FindOptiSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : emxArray__common_FindOptiSync *emxArray_FindOptiSync
 *                int oldNumel_FindOptiSync
 *                int elementSize_FindOptiSync
 * Return Type  : void
 */
static void emxEnsureCapacity_FindOptiSync(emxArray__common_FindOptiSync
  *emxArray_FindOptiSync, int oldNumel_FindOptiSync, int
  elementSize_FindOptiSync)
{
  int newNumel_FindOptiSync;
  int i_FindOptiSync;
  void *newData_FindOptiSync;
  newNumel_FindOptiSync = 1;
  for (i_FindOptiSync = 0; i_FindOptiSync <
       emxArray_FindOptiSync->numDimensions_FindOptiSync; i_FindOptiSync++) {
    newNumel_FindOptiSync *= emxArray_FindOptiSync->
      size_FindOptiSync[i_FindOptiSync];
  }

  if (newNumel_FindOptiSync > emxArray_FindOptiSync->allocatedSize_FindOptiSync)
  {
    i_FindOptiSync = emxArray_FindOptiSync->allocatedSize_FindOptiSync;
    if (i_FindOptiSync < 16) {
      i_FindOptiSync = 16;
    }

    while (i_FindOptiSync < newNumel_FindOptiSync) {
      if (i_FindOptiSync > 1073741823) {
        i_FindOptiSync = MAX_int32_T;
      } else {
        i_FindOptiSync <<= 1;
      }
    }

    newData_FindOptiSync = calloc((unsigned int)i_FindOptiSync, (unsigned int)
      elementSize_FindOptiSync);
    if (emxArray_FindOptiSync->data_FindOptiSync != NULL) {
      memcpy(newData_FindOptiSync, emxArray_FindOptiSync->data_FindOptiSync,
             (unsigned int)(elementSize_FindOptiSync * oldNumel_FindOptiSync));
      if (emxArray_FindOptiSync->canFreeData_FindOptiSync) {
        free(emxArray_FindOptiSync->data_FindOptiSync);
      }
    }

    emxArray_FindOptiSync->data_FindOptiSync = newData_FindOptiSync;
    emxArray_FindOptiSync->allocatedSize_FindOptiSync = i_FindOptiSync;
    emxArray_FindOptiSync->canFreeData_FindOptiSync = true;
  }
}

/*
 * Arguments    : emxArray_creal_T_FindOptiSync **pEmxArray_FindOptiSync
 * Return Type  : void
 */
static void emxFree_creal_T_FindOptiSync(emxArray_creal_T_FindOptiSync
  **pEmxArray_FindOptiSync)
{
  if (*pEmxArray_FindOptiSync != (emxArray_creal_T_FindOptiSync *)NULL) {
    if (((*pEmxArray_FindOptiSync)->data_FindOptiSync != (creal_T *)NULL) &&
        (*pEmxArray_FindOptiSync)->canFreeData_FindOptiSync) {
      free((void *)(*pEmxArray_FindOptiSync)->data_FindOptiSync);
    }

    free((void *)(*pEmxArray_FindOptiSync)->size_FindOptiSync);
    free((void *)*pEmxArray_FindOptiSync);
    *pEmxArray_FindOptiSync = (emxArray_creal_T_FindOptiSync *)NULL;
  }
}

/*
 * Arguments    : emxArray_int32_T_FindOptiSync **pEmxArray_FindOptiSync
 * Return Type  : void
 */
static void emxFree_int32_T_FindOptiSync(emxArray_int32_T_FindOptiSync
  **pEmxArray_FindOptiSync)
{
  if (*pEmxArray_FindOptiSync != (emxArray_int32_T_FindOptiSync *)NULL) {
    if (((*pEmxArray_FindOptiSync)->data_FindOptiSync != (int *)NULL) &&
        (*pEmxArray_FindOptiSync)->canFreeData_FindOptiSync) {
      free((void *)(*pEmxArray_FindOptiSync)->data_FindOptiSync);
    }

    free((void *)(*pEmxArray_FindOptiSync)->size_FindOptiSync);
    free((void *)*pEmxArray_FindOptiSync);
    *pEmxArray_FindOptiSync = (emxArray_int32_T_FindOptiSync *)NULL;
  }
}

/*
 * Arguments    : emxArray_real_T_FindOptiSync **pEmxArray_FindOptiSync
 * Return Type  : void
 */
static void emxFree_real_T_FindOptiSync(emxArray_real_T_FindOptiSync
  **pEmxArray_FindOptiSync)
{
  if (*pEmxArray_FindOptiSync != (emxArray_real_T_FindOptiSync *)NULL) {
    if (((*pEmxArray_FindOptiSync)->data_FindOptiSync != (double *)NULL) &&
        (*pEmxArray_FindOptiSync)->canFreeData_FindOptiSync) {
      free((void *)(*pEmxArray_FindOptiSync)->data_FindOptiSync);
    }

    free((void *)(*pEmxArray_FindOptiSync)->size_FindOptiSync);
    free((void *)*pEmxArray_FindOptiSync);
    *pEmxArray_FindOptiSync = (emxArray_real_T_FindOptiSync *)NULL;
  }
}

/*
 * Arguments    : emxArray_creal_T_FindOptiSync **pEmxArray_FindOptiSync
 *                int numDimensions_FindOptiSync
 * Return Type  : void
 */
static void emxInit_creal_T_FindOptiSync(emxArray_creal_T_FindOptiSync
  **pEmxArray_FindOptiSync, int numDimensions_FindOptiSync)
{
  emxArray_creal_T_FindOptiSync *emxArray_FindOptiSync;
  int i_FindOptiSync;
  *pEmxArray_FindOptiSync = (emxArray_creal_T_FindOptiSync *)malloc(sizeof
    (emxArray_creal_T_FindOptiSync));
  emxArray_FindOptiSync = *pEmxArray_FindOptiSync;
  emxArray_FindOptiSync->data_FindOptiSync = (creal_T *)NULL;
  emxArray_FindOptiSync->numDimensions_FindOptiSync = numDimensions_FindOptiSync;
  emxArray_FindOptiSync->size_FindOptiSync = (int *)malloc((unsigned int)(sizeof
    (int) * numDimensions_FindOptiSync));
  emxArray_FindOptiSync->allocatedSize_FindOptiSync = 0;
  emxArray_FindOptiSync->canFreeData_FindOptiSync = true;
  for (i_FindOptiSync = 0; i_FindOptiSync < numDimensions_FindOptiSync;
       i_FindOptiSync++) {
    emxArray_FindOptiSync->size_FindOptiSync[i_FindOptiSync] = 0;
  }
}

/*
 * Arguments    : emxArray_int32_T_FindOptiSync **pEmxArray_FindOptiSync
 *                int numDimensions_FindOptiSync
 * Return Type  : void
 */
static void emxInit_int32_T_FindOptiSync(emxArray_int32_T_FindOptiSync
  **pEmxArray_FindOptiSync, int numDimensions_FindOptiSync)
{
  emxArray_int32_T_FindOptiSync *emxArray_FindOptiSync;
  int i_FindOptiSync;
  *pEmxArray_FindOptiSync = (emxArray_int32_T_FindOptiSync *)malloc(sizeof
    (emxArray_int32_T_FindOptiSync));
  emxArray_FindOptiSync = *pEmxArray_FindOptiSync;
  emxArray_FindOptiSync->data_FindOptiSync = (int *)NULL;
  emxArray_FindOptiSync->numDimensions_FindOptiSync = numDimensions_FindOptiSync;
  emxArray_FindOptiSync->size_FindOptiSync = (int *)malloc((unsigned int)(sizeof
    (int) * numDimensions_FindOptiSync));
  emxArray_FindOptiSync->allocatedSize_FindOptiSync = 0;
  emxArray_FindOptiSync->canFreeData_FindOptiSync = true;
  for (i_FindOptiSync = 0; i_FindOptiSync < numDimensions_FindOptiSync;
       i_FindOptiSync++) {
    emxArray_FindOptiSync->size_FindOptiSync[i_FindOptiSync] = 0;
  }
}

/*
 * Arguments    : emxArray_real_T_FindOptiSync **pEmxArray_FindOptiSync
 *                int numDimensions_FindOptiSync
 * Return Type  : void
 */
static void emxInit_real_T_FindOptiSync(emxArray_real_T_FindOptiSync
  **pEmxArray_FindOptiSync, int numDimensions_FindOptiSync)
{
  emxArray_real_T_FindOptiSync *emxArray_FindOptiSync;
  int i_FindOptiSync;
  *pEmxArray_FindOptiSync = (emxArray_real_T_FindOptiSync *)malloc(sizeof
    (emxArray_real_T_FindOptiSync));
  emxArray_FindOptiSync = *pEmxArray_FindOptiSync;
  emxArray_FindOptiSync->data_FindOptiSync = (double *)NULL;
  emxArray_FindOptiSync->numDimensions_FindOptiSync = numDimensions_FindOptiSync;
  emxArray_FindOptiSync->size_FindOptiSync = (int *)malloc((unsigned int)(sizeof
    (int) * numDimensions_FindOptiSync));
  emxArray_FindOptiSync->allocatedSize_FindOptiSync = 0;
  emxArray_FindOptiSync->canFreeData_FindOptiSync = true;
  for (i_FindOptiSync = 0; i_FindOptiSync < numDimensions_FindOptiSync;
       i_FindOptiSync++) {
    emxArray_FindOptiSync->size_FindOptiSync[i_FindOptiSync] = 0;
  }
}

/*
 * Arguments    : const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync
 * Return Type  : void
 */
static void f_rtErrorWithMessageID_FindOpti(const
  rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync)
{
  fprintf(stderr,
          "If the input is a variable-size array, it cannot be 0-by-0 at run time.");
  fprintf(stderr, "\n");
  if (aInfo_FindOptiSync != NULL) {
    rtReportErrorLocation_FindOptiS(aInfo_FindOptiSync->fName_FindOptiSync,
      aInfo_FindOptiSync->lineNo_FindOptiSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync
 * Return Type  : void
 */
static void g_rtErrorWithMessageID_FindOpti(const
  rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync)
{
  fprintf(stderr,
          "Inner dimensions must agree. Generated code for a general matrix multiplication at this call site. If this should have been a sc"
          "alar times a variable-size matrix, the scalar input must be fixed-size.");
  fprintf(stderr, "\n");
  if (aInfo_FindOptiSync != NULL) {
    rtReportErrorLocation_FindOptiS(aInfo_FindOptiSync->fName_FindOptiSync,
      aInfo_FindOptiSync->lineNo_FindOptiSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync
 * Return Type  : void
 */
static void h_rtErrorWithMessageID_FindOpti(const
  rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync)
{
  fprintf(stderr, "Inner matrix dimensions must agree.");
  fprintf(stderr, "\n");
  if (aInfo_FindOptiSync != NULL) {
    rtReportErrorLocation_FindOptiS(aInfo_FindOptiSync->fName_FindOptiSync,
      aInfo_FindOptiSync->lineNo_FindOptiSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync
 * Return Type  : void
 */
static void i_rtErrorWithMessageID_FindOpti(const
  rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync)
{
  fprintf(stderr, "Maximum variable size allowed by the program is exceeded.");
  fprintf(stderr, "\n");
  if (aInfo_FindOptiSync != NULL) {
    rtReportErrorLocation_FindOptiS(aInfo_FindOptiSync->fName_FindOptiSync,
      aInfo_FindOptiSync->lineNo_FindOptiSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : double p_FindOptiSync
 * Return Type  : boolean_T
 */
static boolean_T inrange_FindOptiSync(double p_FindOptiSync)
{
  boolean_T pok_FindOptiSync;
  pok_FindOptiSync = true;
  if (((int)p_FindOptiSync != p_FindOptiSync) || ((int)p_FindOptiSync ==
       MIN_int32_T)) {
    pok_FindOptiSync = false;
  }

  return pok_FindOptiSync;
}

/*
 * Arguments    : const int b_FindOptiSync
 *                const char *c_FindOptiSync
 *                const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync
 * Return Type  : void
 */
static void j_rtErrorWithMessageID_FindOpti(const int b_FindOptiSync, const char
  *c_FindOptiSync, const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync)
{
  fprintf(stderr,
          "The loop variable of class %.*s might overflow on the last iteration of the for loop. This could lead to an infinite loop.",
          b_FindOptiSync, c_FindOptiSync);
  fprintf(stderr, "\n");
  if (aInfo_FindOptiSync != NULL) {
    rtReportErrorLocation_FindOptiS(aInfo_FindOptiSync->fName_FindOptiSync,
      aInfo_FindOptiSync->lineNo_FindOptiSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const int b_FindOptiSync
 *                const char *c_FindOptiSync
 *                const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync
 * Return Type  : void
 */
static void k_rtErrorWithMessageID_FindOpti(const int b_FindOptiSync, const char
  *c_FindOptiSync, const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync)
{
  fprintf(stderr, "%.*s", b_FindOptiSync, c_FindOptiSync);
  fprintf(stderr, "\n");
  if (aInfo_FindOptiSync != NULL) {
    rtReportErrorLocation_FindOptiS(aInfo_FindOptiSync->fName_FindOptiSync,
      aInfo_FindOptiSync->lineNo_FindOptiSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const int b_FindOptiSync
 *                const char *c_FindOptiSync
 *                const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync
 * Return Type  : void
 */
static void l_rtErrorWithMessageID_FindOpti(const int b_FindOptiSync, const char
  *c_FindOptiSync, const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync)
{
  fprintf(stderr, "%.*s", b_FindOptiSync, c_FindOptiSync);
  fprintf(stderr, "\n");
  if (aInfo_FindOptiSync != NULL) {
    rtReportErrorLocation_FindOptiS(aInfo_FindOptiSync->fName_FindOptiSync,
      aInfo_FindOptiSync->lineNo_FindOptiSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const int b_FindOptiSync
 *                const char *c_FindOptiSync
 *                const int d_FindOptiSync
 *                const char *e_FindOptiSync
 *                const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync
 * Return Type  : void
 */
static void m_rtErrorWithMessageID_FindOpti(const int b_FindOptiSync, const char
  *c_FindOptiSync, const int d_FindOptiSync, const char *e_FindOptiSync, const
  rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync)
{
  fprintf(stderr,
          "Invalid shift argument: must be a finite, real, integer vector with entries between -intmax(\'%.*s\') and intmax(\'%.*s\').",
          b_FindOptiSync, c_FindOptiSync, d_FindOptiSync, e_FindOptiSync);
  fprintf(stderr, "\n");
  if (aInfo_FindOptiSync != NULL) {
    rtReportErrorLocation_FindOptiS(aInfo_FindOptiSync->fName_FindOptiSync,
      aInfo_FindOptiSync->lineNo_FindOptiSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : double p_FindOptiSync
 *                int *absp_FindOptiSync
 *                boolean_T *shiftright_FindOptiSync
 * Return Type  : void
 */
static void reduce_FindOptiSync(double p_FindOptiSync, int *absp_FindOptiSync,
  boolean_T *shiftright_FindOptiSync)
{
  if (p_FindOptiSync < 0.0) {
    *absp_FindOptiSync = (int)-p_FindOptiSync;
    *shiftright_FindOptiSync = false;
  } else {
    *absp_FindOptiSync = (int)p_FindOptiSync;
    *shiftright_FindOptiSync = true;
  }

  if (*absp_FindOptiSync > 1536) {
    *absp_FindOptiSync -= *absp_FindOptiSync / 1536 * 1536;
  }

  if (*absp_FindOptiSync > 768) {
    *absp_FindOptiSync = 1536 - *absp_FindOptiSync;
    *shiftright_FindOptiSync = !*shiftright_FindOptiSync;
  }
}

/*
 * Arguments    : char * aBuf_FindOptiSync
 *                const int aDim_FindOptiSync
 * Return Type  : void
 */
static void rtAddSizeString_FindOptiSync(char * aBuf_FindOptiSync, const int
  aDim_FindOptiSync)
{
  char dimStr_FindOptiSync[1024];
  sprintf(dimStr_FindOptiSync, "[%d]", aDim_FindOptiSync);
  if (strlen(aBuf_FindOptiSync) + strlen(dimStr_FindOptiSync) < 1024) {
    strcat(aBuf_FindOptiSync, dimStr_FindOptiSync);
  }
}

/*
 * Arguments    : int aIndexValue_FindOptiSync
 *                int aLoBound_FindOptiSync
 *                int aHiBound_FindOptiSync
 *                const rtBoundsCheckInfo_FindOptiSync *aInfo_FindOptiSync
 * Return Type  : void
 */
static void rtDynamicBoundsError_FindOptiSy(int aIndexValue_FindOptiSync, int
  aLoBound_FindOptiSync, int aHiBound_FindOptiSync, const
  rtBoundsCheckInfo_FindOptiSync *aInfo_FindOptiSync)
{
  if (aLoBound_FindOptiSync == 0) {
    aIndexValue_FindOptiSync++;
    aLoBound_FindOptiSync = 1;
    aHiBound_FindOptiSync++;
  }

  if (rtIsNullOrEmptyString_FindOptiS(aInfo_FindOptiSync->aName_FindOptiSync)) {
    fprintf(stderr,
            "Index exceeds array dimensions.  Index value %d exceeds valid range [%d-%d].",
            aIndexValue_FindOptiSync, aLoBound_FindOptiSync,
            aHiBound_FindOptiSync);
    fprintf(stderr, "\n");
  } else {
    fprintf(stderr,
            "Index exceeds array dimensions.  Index value %d exceeds valid range [%d-%d] of array %s.",
            aIndexValue_FindOptiSync, aLoBound_FindOptiSync,
            aHiBound_FindOptiSync, aInfo_FindOptiSync->aName_FindOptiSync);
    fprintf(stderr, "\n");
  }

  if (aInfo_FindOptiSync != NULL) {
    rtReportErrorLocation_FindOptiS(aInfo_FindOptiSync->fName_FindOptiSync,
      aInfo_FindOptiSync->lineNo_FindOptiSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync
 * Return Type  : void
 */
static void rtErrorWithMessageID_FindOptiSy(const
  rtRunTimeErrorInfo_FindOptiSync *aInfo_FindOptiSync)
{
  fprintf(stderr, "Assertion failed.");
  fprintf(stderr, "\n");
  if (aInfo_FindOptiSync != NULL) {
    rtReportErrorLocation_FindOptiS(aInfo_FindOptiSync->fName_FindOptiSync,
      aInfo_FindOptiSync->lineNo_FindOptiSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const int aNDims_FindOptiSync
 *                const int *aDims_FindOptiSync
 *                char *aBuf_FindOptiSync
 * Return Type  : void
 */
static void rtGenSizeString_FindOptiSync(const int aNDims_FindOptiSync, const
  int *aDims_FindOptiSync, char *aBuf_FindOptiSync)
{
  int i_FindOptiSync;
  aBuf_FindOptiSync[0] = '\x00';
  for (i_FindOptiSync = 0; i_FindOptiSync < aNDims_FindOptiSync; i_FindOptiSync
       ++) {
    rtAddSizeString_FindOptiSync(aBuf_FindOptiSync,
      aDims_FindOptiSync[i_FindOptiSync]);
  }
}

/*
 * Arguments    : const double aInteger_FindOptiSync
 *                const rtDoubleCheckInfo_FindOptiSync *aInfo_FindOptiSync
 * Return Type  : void
 */
static void rtIntegerError_FindOptiSync(const double aInteger_FindOptiSync,
  const rtDoubleCheckInfo_FindOptiSync *aInfo_FindOptiSync)
{
  fprintf(stderr,
          "Expected a value representable in the C type \'int\'.  Found %g instead.",
          aInteger_FindOptiSync);
  fprintf(stderr, "\n");
  if (aInfo_FindOptiSync != NULL) {
    rtReportErrorLocation_FindOptiS(aInfo_FindOptiSync->fName_FindOptiSync,
      aInfo_FindOptiSync->lineNo_FindOptiSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const char *aString_FindOptiSync
 * Return Type  : boolean_T
 */
static boolean_T rtIsNullOrEmptyString_FindOptiS(const char
  *aString_FindOptiSync)
{
  return (aString_FindOptiSync == NULL) || (*aString_FindOptiSync == '\x00');
}

/*
 * Arguments    : const double aPositive_FindOptiSync
 *                const rtDoubleCheckInfo_FindOptiSync *aInfo_FindOptiSync
 * Return Type  : void
 */
static void rtNonNegativeError_FindOptiSync(const double aPositive_FindOptiSync,
  const rtDoubleCheckInfo_FindOptiSync *aInfo_FindOptiSync)
{
  fprintf(stderr,
          "Value %g is not greater than or equal to zero.\nExiting to prevent memory corruption.",
          aPositive_FindOptiSync);
  fprintf(stderr, "\n");
  if (aInfo_FindOptiSync != NULL) {
    rtReportErrorLocation_FindOptiS(aInfo_FindOptiSync->fName_FindOptiSync,
      aInfo_FindOptiSync->lineNo_FindOptiSync);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const char * aFcnName_FindOptiSync
 *                const int aLineNo_FindOptiSync
 * Return Type  : void
 */
static void rtReportErrorLocation_FindOptiS(const char * aFcnName_FindOptiSync,
  const int aLineNo_FindOptiSync)
{
  fprintf(stderr, "Error in %s (line %d)", aFcnName_FindOptiSync,
          aLineNo_FindOptiSync);
  fprintf(stderr, "\n");
}

/*
 * Arguments    : const int *aDims1_FindOptiSync
 *                const int aNDims1_FindOptiSync
 *                const int *aDims2_FindOptiSync
 *                const int aNDims2_FindOptiSync
 *                const rtEqualityCheckInfo_FindOptiSyn *aInfo_FindOptiSync
 * Return Type  : void
 */
static void rtSubAssignSizeCheck_FindOptiSy(const int *aDims1_FindOptiSync,
  const int aNDims1_FindOptiSync, const int *aDims2_FindOptiSync, const int
  aNDims2_FindOptiSync, const rtEqualityCheckInfo_FindOptiSyn
  *aInfo_FindOptiSync)
{
  int i_FindOptiSync;
  int j_FindOptiSync;
  char dims1Str_FindOptiSync[1024];
  char dims2Str_FindOptiSync[1024];
  i_FindOptiSync = 0;
  j_FindOptiSync = 0;
  while ((i_FindOptiSync < aNDims1_FindOptiSync) && (j_FindOptiSync <
          aNDims2_FindOptiSync)) {
    while ((i_FindOptiSync < aNDims1_FindOptiSync) &&
           (aDims1_FindOptiSync[i_FindOptiSync] == 1)) {
      i_FindOptiSync++;
    }

    while ((j_FindOptiSync < aNDims2_FindOptiSync) &&
           (aDims2_FindOptiSync[j_FindOptiSync] == 1)) {
      j_FindOptiSync++;
    }

    if (((i_FindOptiSync < aNDims1_FindOptiSync) || (j_FindOptiSync <
          aNDims2_FindOptiSync)) && ((i_FindOptiSync == aNDims1_FindOptiSync) ||
         ((j_FindOptiSync == aNDims2_FindOptiSync) ||
          ((aDims1_FindOptiSync[i_FindOptiSync] != -1) &&
           ((aDims2_FindOptiSync[j_FindOptiSync] != -1) &&
            (aDims1_FindOptiSync[i_FindOptiSync] !=
             aDims2_FindOptiSync[j_FindOptiSync])))))) {
      rtGenSizeString_FindOptiSync(aNDims1_FindOptiSync, aDims1_FindOptiSync,
        dims1Str_FindOptiSync);
      rtGenSizeString_FindOptiSync(aNDims2_FindOptiSync, aDims2_FindOptiSync,
        dims2Str_FindOptiSync);
      fprintf(stderr, "Subscripted assignment dimension mismatch: %s ~= %s.",
              dims1Str_FindOptiSync, dims2Str_FindOptiSync);
      fprintf(stderr, "\n");
      if (aInfo_FindOptiSync != NULL) {
        rtReportErrorLocation_FindOptiS(aInfo_FindOptiSync->fName_FindOptiSync,
          aInfo_FindOptiSync->lineNo_FindOptiSync);
      }

      fflush(stderr);
      abort();
    }

    i_FindOptiSync++;
    j_FindOptiSync++;
  }
}

/*
 * Arguments    : double u0_FindOptiSync
 *                double u1_FindOptiSync
 * Return Type  : double
 */
static double rt_hypotd_snf_FindOptiSync(double u0_FindOptiSync, double
  u1_FindOptiSync)
{
  double y_FindOptiSync;
  double a_FindOptiSync;
  double b_FindOptiSync;
  a_FindOptiSync = fabs(u0_FindOptiSync);
  b_FindOptiSync = fabs(u1_FindOptiSync);
  if (a_FindOptiSync < b_FindOptiSync) {
    a_FindOptiSync /= b_FindOptiSync;
    y_FindOptiSync = b_FindOptiSync * sqrt(a_FindOptiSync * a_FindOptiSync + 1.0);
  } else if (a_FindOptiSync > b_FindOptiSync) {
    b_FindOptiSync /= a_FindOptiSync;
    y_FindOptiSync = a_FindOptiSync * sqrt(b_FindOptiSync * b_FindOptiSync + 1.0);
  } else if (rtIsNaN(b_FindOptiSync)) {
    y_FindOptiSync = b_FindOptiSync;
  } else {
    y_FindOptiSync = a_FindOptiSync * 1.4142135623730951;
  }

  return y_FindOptiSync;
}

/*
 * Arguments    : const creal_T x_FindOptiSync[2048]
 *                double N_FindOptiSync
 *                emxArray_creal_T_FindOptiSync *y_FindOptiSync
 * Return Type  : void
 */
static void upsample_FindOptiSync(const creal_T x_FindOptiSync[2048], double
  N_FindOptiSync, emxArray_creal_T_FindOptiSync *y_FindOptiSync)
{
  double b_N_FindOptiSync;
  boolean_T b0_FindOptiSync;
  int vleny_FindOptiSync;
  int i2_FindOptiSync;
  int xstart_FindOptiSync;
  int ystart_FindOptiSync;
  int i_FindOptiSync;
  int ix_FindOptiSync;
  int iy_FindOptiSync;
  int k_FindOptiSync;
  if (N_FindOptiSync < 0.0) {
    b_N_FindOptiSync = ceil(N_FindOptiSync);
  } else {
    b_N_FindOptiSync = floor(N_FindOptiSync);
  }

  if ((b_N_FindOptiSync == N_FindOptiSync) && (N_FindOptiSync > 0.0)) {
    b0_FindOptiSync = true;
  } else {
    b0_FindOptiSync = false;
  }

  if (b0_FindOptiSync) {
  } else {
    k_rtErrorWithMessageID_FindOpti(43,
      "Upsample factor must be a positive integer.", &k_emlrtRTEI_FindOptiSync);
  }

  if (0.0 <= N_FindOptiSync - 1.0) {
  } else {
    l_rtErrorWithMessageID_FindOpti(40,
      "Offset must be an integer from 0 to N-1.", &l_emlrtRTEI_FindOptiSync);
  }

  vleny_FindOptiSync = (int)N_FindOptiSync << 9;
  i2_FindOptiSync = y_FindOptiSync->size_FindOptiSync[0] *
    y_FindOptiSync->size_FindOptiSync[1];
  y_FindOptiSync->size_FindOptiSync[0] = vleny_FindOptiSync;
  y_FindOptiSync->size_FindOptiSync[1] = 4;
  emxEnsureCapacity_FindOptiSync((emxArray__common_FindOptiSync *)y_FindOptiSync,
    i2_FindOptiSync, (int)sizeof(creal_T));
  xstart_FindOptiSync = vleny_FindOptiSync << 2;
  for (i2_FindOptiSync = 0; i2_FindOptiSync < xstart_FindOptiSync;
       i2_FindOptiSync++) {
    y_FindOptiSync->data_FindOptiSync[i2_FindOptiSync].re = 0.0;
    y_FindOptiSync->data_FindOptiSync[i2_FindOptiSync].im = 0.0;
  }

  xstart_FindOptiSync = 1;
  ystart_FindOptiSync = 1;
  for (i_FindOptiSync = 0; i_FindOptiSync < 4; i_FindOptiSync++) {
    ix_FindOptiSync = xstart_FindOptiSync;
    iy_FindOptiSync = ystart_FindOptiSync;
    for (k_FindOptiSync = 0; k_FindOptiSync < 512; k_FindOptiSync++) {
      i2_FindOptiSync = y_FindOptiSync->size_FindOptiSync[0] << 2;
      if (!((iy_FindOptiSync >= 1) && (iy_FindOptiSync <= i2_FindOptiSync))) {
        rtDynamicBoundsError_FindOptiSy(iy_FindOptiSync, 1, i2_FindOptiSync,
          &ib_emlrtBCI_FindOptiSync);
      }

      if (!((ix_FindOptiSync >= 1) && (ix_FindOptiSync <= 2048))) {
        rtDynamicBoundsError_FindOptiSy(ix_FindOptiSync, 1, 2048,
          &jb_emlrtBCI_FindOptiSync);
      }

      y_FindOptiSync->data_FindOptiSync[iy_FindOptiSync - 1].re =
        x_FindOptiSync[ix_FindOptiSync - 1].re;
      if (!((ix_FindOptiSync >= 1) && (ix_FindOptiSync <= 2048))) {
        rtDynamicBoundsError_FindOptiSy(ix_FindOptiSync, 1, 2048,
          &hb_emlrtBCI_FindOptiSync);
      }

      i2_FindOptiSync = y_FindOptiSync->size_FindOptiSync[0] << 2;
      if (!((iy_FindOptiSync >= 1) && (iy_FindOptiSync <= i2_FindOptiSync))) {
        rtDynamicBoundsError_FindOptiSy(iy_FindOptiSync, 1, i2_FindOptiSync,
          &ib_emlrtBCI_FindOptiSync);
      }

      y_FindOptiSync->data_FindOptiSync[iy_FindOptiSync - 1].im =
        x_FindOptiSync[ix_FindOptiSync - 1].im;
      ix_FindOptiSync++;
      iy_FindOptiSync += (int)N_FindOptiSync;
    }

    xstart_FindOptiSync += 512;
    ystart_FindOptiSync += vleny_FindOptiSync;
  }
}

/*
 * Find Optimum Synchronization Sample Point.
 *  input:
 *     % rxSigNoise: NxM complex, N is the number of snapshots, M is the number of channel. each colum is one snapshot
 *     % pilotSequenceUpSample: (UpSampleTimesxN)x1 complex, N is the length of pilot.
 *     % UpSampleTimes: 1x1 integer, upsample factor.
 *     % LenSearch: 1x1 odd integer, search range of finding optimum synchronization sample point under upsampled symbols.
 *  output:
 *     % pilotSequence, Nx1 complex, N is the length of pilot, pilot sequence downsampled according to optimum synchronization sample.
 *     % numSyncChannel: 1x1 integer, number of synchronized channel after adjust optimum synchronization sample.
 *     % circShiftSelect: 1x1 integer, pilot circle shift index.
 *
 *  2018-01-25 V1.0 Wayne Zhang. draft.
 * Arguments    : const creal_T rxSigNoise_FindOptiSync[2048]
 *                const creal_T pilotSequenceUpSample_FindOptiS[1536]
 *                double UpSampleTimes_FindOptiSync
 *                double LenSearch_FindOptiSync
 *                creal_T pilotSequence_data_FindOptiSync[]
 *                int pilotSequence_size_FindOptiSync[1]
 *                double *numSyncChannel_FindOptiSync
 *                double *circShiftSelect_FindOptiSync
 * Return Type  : void
 */
void FindOptiSyncImplement(const creal_T rxSigNoise_FindOptiSync[2048], const
  creal_T pilotSequenceUpSample_FindOptiS[1536], double
  UpSampleTimes_FindOptiSync, double LenSearch_FindOptiSync, creal_T
  pilotSequence_data_FindOptiSync[], int pilotSequence_size_FindOptiSync[1],
  double *numSyncChannel_FindOptiSync, double *circShiftSelect_FindOptiSync)
{
  boolean_T overflow_FindOptiSync;
  int n_FindOptiSync;
  double temp_re_FindOptiSync;
  double apnd_FindOptiSync;
  double ndbl_FindOptiSync;
  boolean_T n_too_large_FindOptiSync;
  double cdiff_FindOptiSync;
  emxArray_real_T_FindOptiSync *circShiftPattern_FindOptiSync;
  int i0_FindOptiSync;
  int br_FindOptiSync;
  int nm1d2_FindOptiSync;
  int ar_FindOptiSync;
  emxArray_real_T_FindOptiSync *syncIndexMat_FindOptiSync;
  int k_FindOptiSync;
  int ix_FindOptiSync;
  emxArray_creal_T_FindOptiSync *rxSigNoiseUpSample_FindOptiSync;
  emxArray_creal_T_FindOptiSync *pilotSequenceUpSampleMat_FindOp;
  int idxShift_FindOptiSync;
  emxArray_int32_T_FindOptiSync *r0_FindOptiSync;
  emxArray_creal_T_FindOptiSync *a_FindOptiSync;
  int iv0_FindOptiSync[1];
  emxArray_creal_T_FindOptiSync *xcorrMat_FindOptiSync;
  int iv1_FindOptiSync[1];
  unsigned int unnamed_idx_1_FindOptiSync;
  creal_T pilotSequenceUpSampleShift_Find[1536];
  int c_FindOptiSync;
  emxArray_real_T_FindOptiSync *y_FindOptiSync;
  int ic_FindOptiSync;
  int iindx_FindOptiSync[4];
  int ia_FindOptiSync;
  int indx_FindOptiSync[4];
  int idxChannel_FindOptiSync;
  int exitg1_FindOptiSync;
  boolean_T exitg2_FindOptiSync;
  emxArray_real_T_FindOptiSync *b_y_FindOptiSync;
  double b_UpSampleTimes_FindOptiSync;
  int i1_FindOptiSync;
  int sz_FindOptiSync[2];
  overflow_FindOptiSync = false;

  /* 'FindOptiSyncImplement:15' circShiftPattern = (1:LenSearch) - (LenSearch + 1)/2; */
  if (rtIsNaN(LenSearch_FindOptiSync)) {
    n_FindOptiSync = 1;
    temp_re_FindOptiSync = rtNaN;
    apnd_FindOptiSync = LenSearch_FindOptiSync;
    n_too_large_FindOptiSync = false;
  } else if (LenSearch_FindOptiSync < 1.0) {
    n_FindOptiSync = 0;
    temp_re_FindOptiSync = 1.0;
    apnd_FindOptiSync = LenSearch_FindOptiSync;
    n_too_large_FindOptiSync = false;
  } else if (rtIsInf(LenSearch_FindOptiSync)) {
    n_FindOptiSync = 1;
    temp_re_FindOptiSync = rtNaN;
    apnd_FindOptiSync = LenSearch_FindOptiSync;
    n_too_large_FindOptiSync = !(1.0 == LenSearch_FindOptiSync);
  } else {
    temp_re_FindOptiSync = 1.0;
    ndbl_FindOptiSync = floor((LenSearch_FindOptiSync - 1.0) + 0.5);
    apnd_FindOptiSync = 1.0 + ndbl_FindOptiSync;
    cdiff_FindOptiSync = (1.0 + ndbl_FindOptiSync) - LenSearch_FindOptiSync;
    if (fabs(cdiff_FindOptiSync) < 4.4408920985006262E-16 *
        LenSearch_FindOptiSync) {
      ndbl_FindOptiSync++;
      apnd_FindOptiSync = LenSearch_FindOptiSync;
    } else if (cdiff_FindOptiSync > 0.0) {
      apnd_FindOptiSync = 1.0 + (ndbl_FindOptiSync - 1.0);
    } else {
      ndbl_FindOptiSync++;
    }

    n_too_large_FindOptiSync = (2.147483647E+9 < ndbl_FindOptiSync);
    if (ndbl_FindOptiSync >= 0.0) {
      n_FindOptiSync = (int)ndbl_FindOptiSync;
    } else {
      n_FindOptiSync = 0;
    }
  }

  if (!n_too_large_FindOptiSync) {
  } else {
    i_rtErrorWithMessageID_FindOpti(&i_emlrtRTEI_FindOptiSync);
  }

  emxInit_real_T_FindOptiSync(&circShiftPattern_FindOptiSync, 2);
  i0_FindOptiSync = circShiftPattern_FindOptiSync->size_FindOptiSync[0] *
    circShiftPattern_FindOptiSync->size_FindOptiSync[1];
  circShiftPattern_FindOptiSync->size_FindOptiSync[0] = 1;
  circShiftPattern_FindOptiSync->size_FindOptiSync[1] = n_FindOptiSync;
  emxEnsureCapacity_FindOptiSync((emxArray__common_FindOptiSync *)
    circShiftPattern_FindOptiSync, i0_FindOptiSync, (int)sizeof(double));
  if (n_FindOptiSync > 0) {
    i0_FindOptiSync = circShiftPattern_FindOptiSync->size_FindOptiSync[1];
    if (!(1 <= i0_FindOptiSync)) {
      rtDynamicBoundsError_FindOptiSy(1, 1, i0_FindOptiSync,
        &d_emlrtBCI_FindOptiSync);
    }

    circShiftPattern_FindOptiSync->data_FindOptiSync[0] = temp_re_FindOptiSync;
    if (n_FindOptiSync > 1) {
      i0_FindOptiSync = circShiftPattern_FindOptiSync->size_FindOptiSync[1];
      if (!(n_FindOptiSync <= i0_FindOptiSync)) {
        rtDynamicBoundsError_FindOptiSy(n_FindOptiSync, 1, i0_FindOptiSync,
          &f_emlrtBCI_FindOptiSync);
      }

      circShiftPattern_FindOptiSync->data_FindOptiSync[n_FindOptiSync - 1] =
        apnd_FindOptiSync;
      nm1d2_FindOptiSync = (n_FindOptiSync - 1) / 2;
      for (k_FindOptiSync = 1; k_FindOptiSync < nm1d2_FindOptiSync;
           k_FindOptiSync++) {
        i0_FindOptiSync = circShiftPattern_FindOptiSync->size_FindOptiSync[1];
        if (!(k_FindOptiSync + 1 <= i0_FindOptiSync)) {
          rtDynamicBoundsError_FindOptiSy(k_FindOptiSync + 1, 1, i0_FindOptiSync,
            &y_emlrtBCI_FindOptiSync);
        }

        circShiftPattern_FindOptiSync->data_FindOptiSync[k_FindOptiSync] =
          temp_re_FindOptiSync + (double)k_FindOptiSync;
        i0_FindOptiSync = circShiftPattern_FindOptiSync->size_FindOptiSync[1];
        ix_FindOptiSync = n_FindOptiSync - k_FindOptiSync;
        if (!((ix_FindOptiSync >= 1) && (ix_FindOptiSync <= i0_FindOptiSync))) {
          rtDynamicBoundsError_FindOptiSy(ix_FindOptiSync, 1, i0_FindOptiSync,
            &ab_emlrtBCI_FindOptiSync);
        }

        circShiftPattern_FindOptiSync->data_FindOptiSync[ix_FindOptiSync - 1] =
          apnd_FindOptiSync - (double)k_FindOptiSync;
      }

      if (nm1d2_FindOptiSync << 1 == n_FindOptiSync - 1) {
        i0_FindOptiSync = circShiftPattern_FindOptiSync->size_FindOptiSync[1];
        if (!(nm1d2_FindOptiSync + 1 <= i0_FindOptiSync)) {
          rtDynamicBoundsError_FindOptiSy(nm1d2_FindOptiSync + 1, 1,
            i0_FindOptiSync, &i_emlrtBCI_FindOptiSync);
        }

        circShiftPattern_FindOptiSync->data_FindOptiSync[nm1d2_FindOptiSync] =
          (temp_re_FindOptiSync + apnd_FindOptiSync) / 2.0;
      } else {
        i0_FindOptiSync = circShiftPattern_FindOptiSync->size_FindOptiSync[1];
        if (!(nm1d2_FindOptiSync + 1 <= i0_FindOptiSync)) {
          rtDynamicBoundsError_FindOptiSy(nm1d2_FindOptiSync + 1, 1,
            i0_FindOptiSync, &g_emlrtBCI_FindOptiSync);
        }

        circShiftPattern_FindOptiSync->data_FindOptiSync[nm1d2_FindOptiSync] =
          temp_re_FindOptiSync + (double)nm1d2_FindOptiSync;
        i0_FindOptiSync = circShiftPattern_FindOptiSync->size_FindOptiSync[1];
        if (!(nm1d2_FindOptiSync + 2 <= i0_FindOptiSync)) {
          rtDynamicBoundsError_FindOptiSy(nm1d2_FindOptiSync + 2, 1,
            i0_FindOptiSync, &h_emlrtBCI_FindOptiSync);
        }

        circShiftPattern_FindOptiSync->data_FindOptiSync[nm1d2_FindOptiSync + 1]
          = apnd_FindOptiSync - (double)nm1d2_FindOptiSync;
      }
    }
  }

  temp_re_FindOptiSync = (LenSearch_FindOptiSync + 1.0) / 2.0;
  i0_FindOptiSync = circShiftPattern_FindOptiSync->size_FindOptiSync[0] *
    circShiftPattern_FindOptiSync->size_FindOptiSync[1];
  circShiftPattern_FindOptiSync->size_FindOptiSync[0] = 1;
  emxEnsureCapacity_FindOptiSync((emxArray__common_FindOptiSync *)
    circShiftPattern_FindOptiSync, i0_FindOptiSync, (int)sizeof(double));
  br_FindOptiSync = circShiftPattern_FindOptiSync->size_FindOptiSync[0];
  nm1d2_FindOptiSync = circShiftPattern_FindOptiSync->size_FindOptiSync[1];
  ar_FindOptiSync = br_FindOptiSync * nm1d2_FindOptiSync;
  for (i0_FindOptiSync = 0; i0_FindOptiSync < ar_FindOptiSync; i0_FindOptiSync++)
  {
    circShiftPattern_FindOptiSync->data_FindOptiSync[i0_FindOptiSync] -=
      temp_re_FindOptiSync;
  }

  emxInit_real_T_FindOptiSync(&syncIndexMat_FindOptiSync, 2);

  /* 'FindOptiSyncImplement:17' [LenPilot, NumChannel] = size(rxSigNoise); */
  /* 'FindOptiSyncImplement:18' syncIndexMat = zeros(NumChannel, LenSearch); */
  i0_FindOptiSync = syncIndexMat_FindOptiSync->size_FindOptiSync[0] *
    syncIndexMat_FindOptiSync->size_FindOptiSync[1];
  syncIndexMat_FindOptiSync->size_FindOptiSync[0] = 4;
  if (!(LenSearch_FindOptiSync >= 0.0)) {
    rtNonNegativeError_FindOptiSync(LenSearch_FindOptiSync,
      &b_emlrtDCI_FindOptiSync);
  }

  temp_re_FindOptiSync = LenSearch_FindOptiSync;
  if (temp_re_FindOptiSync != (int)floor(temp_re_FindOptiSync)) {
    rtIntegerError_FindOptiSync(temp_re_FindOptiSync, &emlrtDCI_FindOptiSync);
  }

  syncIndexMat_FindOptiSync->size_FindOptiSync[1] = (int)temp_re_FindOptiSync;
  emxEnsureCapacity_FindOptiSync((emxArray__common_FindOptiSync *)
    syncIndexMat_FindOptiSync, i0_FindOptiSync, (int)sizeof(double));
  if (!(LenSearch_FindOptiSync >= 0.0)) {
    rtNonNegativeError_FindOptiSync(LenSearch_FindOptiSync,
      &f_emlrtDCI_FindOptiSync);
  }

  if (temp_re_FindOptiSync != (int)floor(temp_re_FindOptiSync)) {
    rtIntegerError_FindOptiSync(temp_re_FindOptiSync, &e_emlrtDCI_FindOptiSync);
  }

  ar_FindOptiSync = (int)temp_re_FindOptiSync << 2;
  for (i0_FindOptiSync = 0; i0_FindOptiSync < ar_FindOptiSync; i0_FindOptiSync++)
  {
    syncIndexMat_FindOptiSync->data_FindOptiSync[i0_FindOptiSync] = 0.0;
  }

  emxInit_creal_T_FindOptiSync(&rxSigNoiseUpSample_FindOptiSync, 2);
  emxInit_creal_T_FindOptiSync(&pilotSequenceUpSampleMat_FindOp, 2);

  /* 'FindOptiSyncImplement:19' rxSigNoiseUpSample = upsample(rxSigNoise, UpSampleTimes); */
  upsample_FindOptiSync(rxSigNoise_FindOptiSync, UpSampleTimes_FindOptiSync,
                        rxSigNoiseUpSample_FindOptiSync);

  /* 'FindOptiSyncImplement:22' pilotSequenceUpSampleMat = complex(zeros(LenPilot*UpSampleTimes, LenSearch)); */
  i0_FindOptiSync = pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[0] *
    pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[1];
  temp_re_FindOptiSync = 512.0 * UpSampleTimes_FindOptiSync;
  if (!(temp_re_FindOptiSync >= 0.0)) {
    rtNonNegativeError_FindOptiSync(temp_re_FindOptiSync,
      &d_emlrtDCI_FindOptiSync);
  }

  if (temp_re_FindOptiSync != (int)floor(temp_re_FindOptiSync)) {
    rtIntegerError_FindOptiSync(temp_re_FindOptiSync, &c_emlrtDCI_FindOptiSync);
  }

  pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[0] = (int)
    temp_re_FindOptiSync;
  pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[1] = (int)
    LenSearch_FindOptiSync;
  emxEnsureCapacity_FindOptiSync((emxArray__common_FindOptiSync *)
    pilotSequenceUpSampleMat_FindOp, i0_FindOptiSync, (int)sizeof(creal_T));
  temp_re_FindOptiSync = 512.0 * UpSampleTimes_FindOptiSync;
  if (!(temp_re_FindOptiSync >= 0.0)) {
    rtNonNegativeError_FindOptiSync(temp_re_FindOptiSync,
      &h_emlrtDCI_FindOptiSync);
  }

  if (temp_re_FindOptiSync != (int)floor(temp_re_FindOptiSync)) {
    rtIntegerError_FindOptiSync(temp_re_FindOptiSync, &g_emlrtDCI_FindOptiSync);
  }

  ar_FindOptiSync = (int)temp_re_FindOptiSync * (int)LenSearch_FindOptiSync;
  for (i0_FindOptiSync = 0; i0_FindOptiSync < ar_FindOptiSync; i0_FindOptiSync++)
  {
    pilotSequenceUpSampleMat_FindOp->data_FindOptiSync[i0_FindOptiSync].re = 0.0;
    pilotSequenceUpSampleMat_FindOp->data_FindOptiSync[i0_FindOptiSync].im = 0.0;
  }

  /* 'FindOptiSyncImplement:23' for idxShift = 1:LenSearch */
  idxShift_FindOptiSync = 0;
  emxInit_int32_T_FindOptiSync(&r0_FindOptiSync, 1);
  while (idxShift_FindOptiSync <= (int)LenSearch_FindOptiSync - 1) {
    /* 'FindOptiSyncImplement:24' pilotSequenceUpSampleMat(:,idxShift) = circshift(pilotSequenceUpSample, circShiftPattern(idxShift)); */
    ar_FindOptiSync = pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[0];
    i0_FindOptiSync = r0_FindOptiSync->size_FindOptiSync[0];
    r0_FindOptiSync->size_FindOptiSync[0] = ar_FindOptiSync;
    emxEnsureCapacity_FindOptiSync((emxArray__common_FindOptiSync *)
      r0_FindOptiSync, i0_FindOptiSync, (int)sizeof(int));
    for (i0_FindOptiSync = 0; i0_FindOptiSync < ar_FindOptiSync; i0_FindOptiSync
         ++) {
      r0_FindOptiSync->data_FindOptiSync[i0_FindOptiSync] = i0_FindOptiSync;
    }

    i0_FindOptiSync = pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[1];
    ix_FindOptiSync = idxShift_FindOptiSync + 1;
    if (!((ix_FindOptiSync >= 1) && (ix_FindOptiSync <= i0_FindOptiSync))) {
      rtDynamicBoundsError_FindOptiSy(ix_FindOptiSync, 1, i0_FindOptiSync,
        &e_emlrtBCI_FindOptiSync);
    }

    iv0_FindOptiSync[0] = r0_FindOptiSync->size_FindOptiSync[0];
    if (!overflow_FindOptiSync) {
      iv1_FindOptiSync[0] = 1536;
      overflow_FindOptiSync = true;
    }

    rtSubAssignSizeCheck_FindOptiSy(iv0_FindOptiSync, 1, iv1_FindOptiSync, 1,
      &emlrtECI_FindOptiSync);
    memcpy(&pilotSequenceUpSampleShift_Find[0],
           &pilotSequenceUpSample_FindOptiS[0], 1536U * sizeof(creal_T));
    i0_FindOptiSync = circShiftPattern_FindOptiSync->size_FindOptiSync[1];
    if (!((idxShift_FindOptiSync + 1 >= 1) && (idxShift_FindOptiSync + 1 <=
          i0_FindOptiSync))) {
      rtDynamicBoundsError_FindOptiSy(idxShift_FindOptiSync + 1, 1,
        i0_FindOptiSync, &x_emlrtBCI_FindOptiSync);
    }

    circshift_FindOptiSync(pilotSequenceUpSampleShift_Find,
      circShiftPattern_FindOptiSync->data_FindOptiSync[idxShift_FindOptiSync]);
    br_FindOptiSync = r0_FindOptiSync->size_FindOptiSync[0];
    for (i0_FindOptiSync = 0; i0_FindOptiSync < br_FindOptiSync; i0_FindOptiSync
         ++) {
      pilotSequenceUpSampleMat_FindOp->data_FindOptiSync
        [r0_FindOptiSync->data_FindOptiSync[i0_FindOptiSync] +
        pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[0] *
        idxShift_FindOptiSync] = pilotSequenceUpSampleShift_Find[i0_FindOptiSync];
    }

    idxShift_FindOptiSync++;
  }

  emxFree_int32_T_FindOptiSync(&r0_FindOptiSync);
  emxInit_creal_T_FindOptiSync(&a_FindOptiSync, 2);

  /* 'FindOptiSyncImplement:27' xcorrMat = rxSigNoiseUpSample'*pilotSequenceUpSampleMat; */
  i0_FindOptiSync = a_FindOptiSync->size_FindOptiSync[0] *
    a_FindOptiSync->size_FindOptiSync[1];
  a_FindOptiSync->size_FindOptiSync[0] = 4;
  a_FindOptiSync->size_FindOptiSync[1] =
    rxSigNoiseUpSample_FindOptiSync->size_FindOptiSync[0];
  emxEnsureCapacity_FindOptiSync((emxArray__common_FindOptiSync *)a_FindOptiSync,
    i0_FindOptiSync, (int)sizeof(creal_T));
  ar_FindOptiSync = rxSigNoiseUpSample_FindOptiSync->size_FindOptiSync[0];
  for (i0_FindOptiSync = 0; i0_FindOptiSync < ar_FindOptiSync; i0_FindOptiSync++)
  {
    for (ix_FindOptiSync = 0; ix_FindOptiSync < 4; ix_FindOptiSync++) {
      a_FindOptiSync->data_FindOptiSync[ix_FindOptiSync +
        a_FindOptiSync->size_FindOptiSync[0] * i0_FindOptiSync].re =
        rxSigNoiseUpSample_FindOptiSync->data_FindOptiSync[i0_FindOptiSync +
        rxSigNoiseUpSample_FindOptiSync->size_FindOptiSync[0] * ix_FindOptiSync]
        .re;
      a_FindOptiSync->data_FindOptiSync[ix_FindOptiSync +
        a_FindOptiSync->size_FindOptiSync[0] * i0_FindOptiSync].im =
        -rxSigNoiseUpSample_FindOptiSync->data_FindOptiSync[i0_FindOptiSync +
        rxSigNoiseUpSample_FindOptiSync->size_FindOptiSync[0] * ix_FindOptiSync]
        .im;
    }
  }

  if (!(a_FindOptiSync->size_FindOptiSync[1] ==
        pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[0])) {
    if ((pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[0] == 1) &&
        (pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[1] == 1)) {
      g_rtErrorWithMessageID_FindOpti(&g_emlrtRTEI_FindOptiSync);
    } else {
      h_rtErrorWithMessageID_FindOpti(&h_emlrtRTEI_FindOptiSync);
    }
  }

  emxInit_creal_T_FindOptiSync(&xcorrMat_FindOptiSync, 2);
  if ((a_FindOptiSync->size_FindOptiSync[1] == 1) ||
      (pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[0] == 1)) {
    i0_FindOptiSync = xcorrMat_FindOptiSync->size_FindOptiSync[0] *
      xcorrMat_FindOptiSync->size_FindOptiSync[1];
    xcorrMat_FindOptiSync->size_FindOptiSync[0] = 4;
    xcorrMat_FindOptiSync->size_FindOptiSync[1] =
      pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[1];
    emxEnsureCapacity_FindOptiSync((emxArray__common_FindOptiSync *)
      xcorrMat_FindOptiSync, i0_FindOptiSync, (int)sizeof(creal_T));
    for (i0_FindOptiSync = 0; i0_FindOptiSync < 4; i0_FindOptiSync++) {
      ar_FindOptiSync = pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[1];
      for (ix_FindOptiSync = 0; ix_FindOptiSync < ar_FindOptiSync;
           ix_FindOptiSync++) {
        xcorrMat_FindOptiSync->data_FindOptiSync[i0_FindOptiSync +
          xcorrMat_FindOptiSync->size_FindOptiSync[0] * ix_FindOptiSync].re =
          0.0;
        xcorrMat_FindOptiSync->data_FindOptiSync[i0_FindOptiSync +
          xcorrMat_FindOptiSync->size_FindOptiSync[0] * ix_FindOptiSync].im =
          0.0;
        nm1d2_FindOptiSync = a_FindOptiSync->size_FindOptiSync[1];
        for (br_FindOptiSync = 0; br_FindOptiSync < nm1d2_FindOptiSync;
             br_FindOptiSync++) {
          temp_re_FindOptiSync = a_FindOptiSync->
            data_FindOptiSync[i0_FindOptiSync +
            a_FindOptiSync->size_FindOptiSync[0] * br_FindOptiSync].re *
            pilotSequenceUpSampleMat_FindOp->data_FindOptiSync[br_FindOptiSync +
            pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[0] *
            ix_FindOptiSync].re - a_FindOptiSync->
            data_FindOptiSync[i0_FindOptiSync +
            a_FindOptiSync->size_FindOptiSync[0] * br_FindOptiSync].im *
            pilotSequenceUpSampleMat_FindOp->data_FindOptiSync[br_FindOptiSync +
            pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[0] *
            ix_FindOptiSync].im;
          ndbl_FindOptiSync = a_FindOptiSync->data_FindOptiSync[i0_FindOptiSync
            + a_FindOptiSync->size_FindOptiSync[0] * br_FindOptiSync].re *
            pilotSequenceUpSampleMat_FindOp->data_FindOptiSync[br_FindOptiSync +
            pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[0] *
            ix_FindOptiSync].im + a_FindOptiSync->
            data_FindOptiSync[i0_FindOptiSync +
            a_FindOptiSync->size_FindOptiSync[0] * br_FindOptiSync].im *
            pilotSequenceUpSampleMat_FindOp->data_FindOptiSync[br_FindOptiSync +
            pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[0] *
            ix_FindOptiSync].re;
          xcorrMat_FindOptiSync->data_FindOptiSync[i0_FindOptiSync +
            xcorrMat_FindOptiSync->size_FindOptiSync[0] * ix_FindOptiSync].re +=
            temp_re_FindOptiSync;
          xcorrMat_FindOptiSync->data_FindOptiSync[i0_FindOptiSync +
            xcorrMat_FindOptiSync->size_FindOptiSync[0] * ix_FindOptiSync].im +=
            ndbl_FindOptiSync;
        }
      }
    }
  } else {
    k_FindOptiSync = a_FindOptiSync->size_FindOptiSync[1];
    unnamed_idx_1_FindOptiSync = (unsigned int)
      pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[1];
    i0_FindOptiSync = xcorrMat_FindOptiSync->size_FindOptiSync[0] *
      xcorrMat_FindOptiSync->size_FindOptiSync[1];
    xcorrMat_FindOptiSync->size_FindOptiSync[0] = 4;
    xcorrMat_FindOptiSync->size_FindOptiSync[1] = (int)
      unnamed_idx_1_FindOptiSync;
    xcorrMat_FindOptiSync->size_FindOptiSync[0] = 4;
    emxEnsureCapacity_FindOptiSync((emxArray__common_FindOptiSync *)
      xcorrMat_FindOptiSync, i0_FindOptiSync, (int)sizeof(creal_T));
    ar_FindOptiSync = xcorrMat_FindOptiSync->size_FindOptiSync[1];
    for (i0_FindOptiSync = 0; i0_FindOptiSync < ar_FindOptiSync; i0_FindOptiSync
         ++) {
      for (ix_FindOptiSync = 0; ix_FindOptiSync < 4; ix_FindOptiSync++) {
        xcorrMat_FindOptiSync->data_FindOptiSync[ix_FindOptiSync +
          xcorrMat_FindOptiSync->size_FindOptiSync[0] * i0_FindOptiSync].re =
          0.0;
        xcorrMat_FindOptiSync->data_FindOptiSync[ix_FindOptiSync +
          xcorrMat_FindOptiSync->size_FindOptiSync[0] * i0_FindOptiSync].im =
          0.0;
      }
    }

    if (pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[1] == 0) {
    } else {
      c_FindOptiSync = (pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[1] -
                        1) << 2;
      if (c_FindOptiSync > 2147483643) {
        check_forloop_overflow_error_Fi();
      }

      for (nm1d2_FindOptiSync = 4; nm1d2_FindOptiSync - 4 <= c_FindOptiSync;
           nm1d2_FindOptiSync += 4) {
        if ((!(nm1d2_FindOptiSync - 3 > nm1d2_FindOptiSync)) &&
            (nm1d2_FindOptiSync > 2147483646)) {
          check_forloop_overflow_error_Fi();
        }

        for (ic_FindOptiSync = nm1d2_FindOptiSync - 3; ic_FindOptiSync <=
             nm1d2_FindOptiSync; ic_FindOptiSync++) {
          i0_FindOptiSync = xcorrMat_FindOptiSync->size_FindOptiSync[1] << 2;
          if (!((ic_FindOptiSync >= 1) && (ic_FindOptiSync <= i0_FindOptiSync)))
          {
            rtDynamicBoundsError_FindOptiSy(ic_FindOptiSync, 1, i0_FindOptiSync,
              &eb_emlrtBCI_FindOptiSync);
          }

          xcorrMat_FindOptiSync->data_FindOptiSync[ic_FindOptiSync - 1].re = 0.0;
          i0_FindOptiSync = xcorrMat_FindOptiSync->size_FindOptiSync[1] << 2;
          if (!((ic_FindOptiSync >= 1) && (ic_FindOptiSync <= i0_FindOptiSync)))
          {
            rtDynamicBoundsError_FindOptiSy(ic_FindOptiSync, 1, i0_FindOptiSync,
              &l_emlrtBCI_FindOptiSync);
          }

          xcorrMat_FindOptiSync->data_FindOptiSync[ic_FindOptiSync - 1].im = 0.0;
        }
      }

      br_FindOptiSync = 1;
      if (c_FindOptiSync > 2147483643) {
        check_forloop_overflow_error_Fi();
      }

      for (nm1d2_FindOptiSync = 4; nm1d2_FindOptiSync - 4 <= c_FindOptiSync;
           nm1d2_FindOptiSync += 4) {
        ar_FindOptiSync = 0;
        ix_FindOptiSync = (br_FindOptiSync + k_FindOptiSync) - 1;
        if ((!(br_FindOptiSync > ix_FindOptiSync)) && (ix_FindOptiSync >
             2147483646)) {
          check_forloop_overflow_error_Fi();
        }

        for (n_FindOptiSync = br_FindOptiSync; n_FindOptiSync <= ix_FindOptiSync;
             n_FindOptiSync++) {
          i0_FindOptiSync = pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[0]
            * pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[1];
          if (!((n_FindOptiSync >= 1) && (n_FindOptiSync <= i0_FindOptiSync))) {
            rtDynamicBoundsError_FindOptiSy(n_FindOptiSync, 1, i0_FindOptiSync,
              &cb_emlrtBCI_FindOptiSync);
          }

          i0_FindOptiSync = pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[0]
            * pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[1];
          if (!((n_FindOptiSync >= 1) && (n_FindOptiSync <= i0_FindOptiSync))) {
            rtDynamicBoundsError_FindOptiSy(n_FindOptiSync, 1, i0_FindOptiSync,
              &cb_emlrtBCI_FindOptiSync);
          }

          overflow_FindOptiSync =
            ((pilotSequenceUpSampleMat_FindOp->data_FindOptiSync[n_FindOptiSync
              - 1].re != 0.0) ||
             (pilotSequenceUpSampleMat_FindOp->data_FindOptiSync[n_FindOptiSync
              - 1].im != 0.0));
          if (overflow_FindOptiSync) {
            i0_FindOptiSync = pilotSequenceUpSampleMat_FindOp->
              size_FindOptiSync[0] *
              pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[1];
            if (!((n_FindOptiSync >= 1) && (n_FindOptiSync <= i0_FindOptiSync)))
            {
              rtDynamicBoundsError_FindOptiSy(n_FindOptiSync, 1, i0_FindOptiSync,
                &bb_emlrtBCI_FindOptiSync);
            }

            i0_FindOptiSync = pilotSequenceUpSampleMat_FindOp->
              size_FindOptiSync[0] *
              pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[1];
            if (!((n_FindOptiSync >= 1) && (n_FindOptiSync <= i0_FindOptiSync)))
            {
              rtDynamicBoundsError_FindOptiSy(n_FindOptiSync, 1, i0_FindOptiSync,
                &bb_emlrtBCI_FindOptiSync);
            }

            temp_re_FindOptiSync =
              pilotSequenceUpSampleMat_FindOp->data_FindOptiSync[n_FindOptiSync
              - 1].re - 0.0 * pilotSequenceUpSampleMat_FindOp->
              data_FindOptiSync[n_FindOptiSync - 1].im;
            i0_FindOptiSync = pilotSequenceUpSampleMat_FindOp->
              size_FindOptiSync[0] *
              pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[1];
            if (!((n_FindOptiSync >= 1) && (n_FindOptiSync <= i0_FindOptiSync)))
            {
              rtDynamicBoundsError_FindOptiSy(n_FindOptiSync, 1, i0_FindOptiSync,
                &bb_emlrtBCI_FindOptiSync);
            }

            i0_FindOptiSync = pilotSequenceUpSampleMat_FindOp->
              size_FindOptiSync[0] *
              pilotSequenceUpSampleMat_FindOp->size_FindOptiSync[1];
            if (!((n_FindOptiSync >= 1) && (n_FindOptiSync <= i0_FindOptiSync)))
            {
              rtDynamicBoundsError_FindOptiSy(n_FindOptiSync, 1, i0_FindOptiSync,
                &bb_emlrtBCI_FindOptiSync);
            }

            ndbl_FindOptiSync =
              pilotSequenceUpSampleMat_FindOp->data_FindOptiSync[n_FindOptiSync
              - 1].im + 0.0 * pilotSequenceUpSampleMat_FindOp->
              data_FindOptiSync[n_FindOptiSync - 1].re;
            ia_FindOptiSync = ar_FindOptiSync;
            if ((!(nm1d2_FindOptiSync - 3 > nm1d2_FindOptiSync)) &&
                (nm1d2_FindOptiSync > 2147483646)) {
              check_forloop_overflow_error_Fi();
            }

            for (ic_FindOptiSync = nm1d2_FindOptiSync - 3; ic_FindOptiSync <=
                 nm1d2_FindOptiSync; ic_FindOptiSync++) {
              ia_FindOptiSync++;
              i0_FindOptiSync = a_FindOptiSync->size_FindOptiSync[1] << 2;
              if (!((ia_FindOptiSync >= 1) && (ia_FindOptiSync <=
                    i0_FindOptiSync))) {
                rtDynamicBoundsError_FindOptiSy(ia_FindOptiSync, 1,
                  i0_FindOptiSync, &db_emlrtBCI_FindOptiSync);
              }

              i0_FindOptiSync = a_FindOptiSync->size_FindOptiSync[1] << 2;
              if (!((ia_FindOptiSync >= 1) && (ia_FindOptiSync <=
                    i0_FindOptiSync))) {
                rtDynamicBoundsError_FindOptiSy(ia_FindOptiSync, 1,
                  i0_FindOptiSync, &db_emlrtBCI_FindOptiSync);
              }

              apnd_FindOptiSync = temp_re_FindOptiSync *
                a_FindOptiSync->data_FindOptiSync[ia_FindOptiSync - 1].re -
                ndbl_FindOptiSync * a_FindOptiSync->
                data_FindOptiSync[ia_FindOptiSync - 1].im;
              i0_FindOptiSync = a_FindOptiSync->size_FindOptiSync[1] << 2;
              if (!((ia_FindOptiSync >= 1) && (ia_FindOptiSync <=
                    i0_FindOptiSync))) {
                rtDynamicBoundsError_FindOptiSy(ia_FindOptiSync, 1,
                  i0_FindOptiSync, &db_emlrtBCI_FindOptiSync);
              }

              i0_FindOptiSync = a_FindOptiSync->size_FindOptiSync[1] << 2;
              if (!((ia_FindOptiSync >= 1) && (ia_FindOptiSync <=
                    i0_FindOptiSync))) {
                rtDynamicBoundsError_FindOptiSy(ia_FindOptiSync, 1,
                  i0_FindOptiSync, &db_emlrtBCI_FindOptiSync);
              }

              cdiff_FindOptiSync = temp_re_FindOptiSync *
                a_FindOptiSync->data_FindOptiSync[ia_FindOptiSync - 1].im +
                ndbl_FindOptiSync * a_FindOptiSync->
                data_FindOptiSync[ia_FindOptiSync - 1].re;
              i0_FindOptiSync = xcorrMat_FindOptiSync->size_FindOptiSync[1] << 2;
              if (!((ic_FindOptiSync >= 1) && (ic_FindOptiSync <=
                    i0_FindOptiSync))) {
                rtDynamicBoundsError_FindOptiSy(ic_FindOptiSync, 1,
                  i0_FindOptiSync, &eb_emlrtBCI_FindOptiSync);
              }

              i0_FindOptiSync = xcorrMat_FindOptiSync->size_FindOptiSync[1] << 2;
              if (!((ic_FindOptiSync >= 1) && (ic_FindOptiSync <=
                    i0_FindOptiSync))) {
                rtDynamicBoundsError_FindOptiSy(ic_FindOptiSync, 1,
                  i0_FindOptiSync, &eb_emlrtBCI_FindOptiSync);
              }

              xcorrMat_FindOptiSync->data_FindOptiSync[ic_FindOptiSync - 1].re +=
                apnd_FindOptiSync;
              i0_FindOptiSync = xcorrMat_FindOptiSync->size_FindOptiSync[1] << 2;
              if (!((ic_FindOptiSync >= 1) && (ic_FindOptiSync <=
                    i0_FindOptiSync))) {
                rtDynamicBoundsError_FindOptiSy(ic_FindOptiSync, 1,
                  i0_FindOptiSync, &j_emlrtBCI_FindOptiSync);
              }

              i0_FindOptiSync = xcorrMat_FindOptiSync->size_FindOptiSync[1] << 2;
              if (!((ic_FindOptiSync >= 1) && (ic_FindOptiSync <=
                    i0_FindOptiSync))) {
                rtDynamicBoundsError_FindOptiSy(ic_FindOptiSync, 1,
                  i0_FindOptiSync, &k_emlrtBCI_FindOptiSync);
              }

              xcorrMat_FindOptiSync->data_FindOptiSync[ic_FindOptiSync - 1].im +=
                cdiff_FindOptiSync;
            }
          }

          ar_FindOptiSync += 4;
        }

        br_FindOptiSync += k_FindOptiSync;
      }
    }
  }

  emxFree_creal_T_FindOptiSync(&a_FindOptiSync);
  emxFree_creal_T_FindOptiSync(&pilotSequenceUpSampleMat_FindOp);

  /* 'FindOptiSyncImplement:28' [~, idxSyncIndexVec] = max(abs(xcorrMat.')); */
  i0_FindOptiSync = rxSigNoiseUpSample_FindOptiSync->size_FindOptiSync[0] *
    rxSigNoiseUpSample_FindOptiSync->size_FindOptiSync[1];
  rxSigNoiseUpSample_FindOptiSync->size_FindOptiSync[0] =
    xcorrMat_FindOptiSync->size_FindOptiSync[1];
  rxSigNoiseUpSample_FindOptiSync->size_FindOptiSync[1] = 4;
  emxEnsureCapacity_FindOptiSync((emxArray__common_FindOptiSync *)
    rxSigNoiseUpSample_FindOptiSync, i0_FindOptiSync, (int)sizeof(creal_T));
  for (i0_FindOptiSync = 0; i0_FindOptiSync < 4; i0_FindOptiSync++) {
    ar_FindOptiSync = xcorrMat_FindOptiSync->size_FindOptiSync[1];
    for (ix_FindOptiSync = 0; ix_FindOptiSync < ar_FindOptiSync; ix_FindOptiSync
         ++) {
      rxSigNoiseUpSample_FindOptiSync->data_FindOptiSync[ix_FindOptiSync +
        rxSigNoiseUpSample_FindOptiSync->size_FindOptiSync[0] * i0_FindOptiSync]
        = xcorrMat_FindOptiSync->data_FindOptiSync[i0_FindOptiSync +
        xcorrMat_FindOptiSync->size_FindOptiSync[0] * ix_FindOptiSync];
    }
  }

  emxFree_creal_T_FindOptiSync(&xcorrMat_FindOptiSync);
  emxInit_real_T_FindOptiSync(&y_FindOptiSync, 2);
  i0_FindOptiSync = y_FindOptiSync->size_FindOptiSync[0] *
    y_FindOptiSync->size_FindOptiSync[1];
  y_FindOptiSync->size_FindOptiSync[0] =
    rxSigNoiseUpSample_FindOptiSync->size_FindOptiSync[0];
  y_FindOptiSync->size_FindOptiSync[1] = 4;
  emxEnsureCapacity_FindOptiSync((emxArray__common_FindOptiSync *)y_FindOptiSync,
    i0_FindOptiSync, (int)sizeof(double));
  n_FindOptiSync = rxSigNoiseUpSample_FindOptiSync->size_FindOptiSync[0] << 2;
  if ((!(1 > n_FindOptiSync)) && (n_FindOptiSync > 2147483646)) {
    check_forloop_overflow_error_Fi();
  }

  for (k_FindOptiSync = 1; k_FindOptiSync <= n_FindOptiSync; k_FindOptiSync++) {
    i0_FindOptiSync = rxSigNoiseUpSample_FindOptiSync->size_FindOptiSync[0] << 2;
    if (!((k_FindOptiSync >= 1) && (k_FindOptiSync <= i0_FindOptiSync))) {
      rtDynamicBoundsError_FindOptiSy(k_FindOptiSync, 1, i0_FindOptiSync,
        &c_emlrtBCI_FindOptiSync);
    }

    i0_FindOptiSync = y_FindOptiSync->size_FindOptiSync[0] << 2;
    if (!((k_FindOptiSync >= 1) && (k_FindOptiSync <= i0_FindOptiSync))) {
      rtDynamicBoundsError_FindOptiSy(k_FindOptiSync, 1, i0_FindOptiSync,
        &w_emlrtBCI_FindOptiSync);
    }

    y_FindOptiSync->data_FindOptiSync[k_FindOptiSync - 1] =
      rt_hypotd_snf_FindOptiSync
      (rxSigNoiseUpSample_FindOptiSync->data_FindOptiSync[k_FindOptiSync - 1].re,
       rxSigNoiseUpSample_FindOptiSync->data_FindOptiSync[k_FindOptiSync - 1].im);
  }

  emxFree_creal_T_FindOptiSync(&rxSigNoiseUpSample_FindOptiSync);
  overflow_FindOptiSync = (y_FindOptiSync->size_FindOptiSync[0] != 1);
  if (overflow_FindOptiSync) {
  } else {
    e_rtErrorWithMessageID_FindOpti(&e_emlrtRTEI_FindOptiSync);
  }

  if (y_FindOptiSync->size_FindOptiSync[0] > 0) {
  } else {
    d_rtErrorWithMessageID_FindOpti(&d_emlrtRTEI_FindOptiSync);
  }

  n_FindOptiSync = y_FindOptiSync->size_FindOptiSync[0];
  for (ia_FindOptiSync = 0; ia_FindOptiSync < 4; ia_FindOptiSync++) {
    ic_FindOptiSync = ia_FindOptiSync * n_FindOptiSync;
    ix_FindOptiSync = ia_FindOptiSync * n_FindOptiSync + 2;
    br_FindOptiSync = ic_FindOptiSync + n_FindOptiSync;
    i0_FindOptiSync = y_FindOptiSync->size_FindOptiSync[0] << 2;
    if (!((ic_FindOptiSync + 1 >= 1) && (ic_FindOptiSync + 1 <= i0_FindOptiSync)))
    {
      rtDynamicBoundsError_FindOptiSy(ic_FindOptiSync + 1, 1, i0_FindOptiSync,
        &u_emlrtBCI_FindOptiSync);
    }

    temp_re_FindOptiSync = y_FindOptiSync->data_FindOptiSync[ic_FindOptiSync];
    nm1d2_FindOptiSync = 1;
    if (n_FindOptiSync > 1) {
      ar_FindOptiSync = 1;
      if (rtIsNaN(y_FindOptiSync->data_FindOptiSync[ic_FindOptiSync])) {
        if ((!(ix_FindOptiSync > br_FindOptiSync)) && (br_FindOptiSync >
             2147483646)) {
          check_forloop_overflow_error_Fi();
        }

        ic_FindOptiSync = ix_FindOptiSync;
        exitg2_FindOptiSync = false;
        while ((!exitg2_FindOptiSync) && (ic_FindOptiSync <= br_FindOptiSync)) {
          ar_FindOptiSync++;
          ix_FindOptiSync = ic_FindOptiSync + 1;
          i0_FindOptiSync = y_FindOptiSync->size_FindOptiSync[0] << 2;
          if (!((ic_FindOptiSync >= 1) && (ic_FindOptiSync <= i0_FindOptiSync)))
          {
            rtDynamicBoundsError_FindOptiSy(ic_FindOptiSync, 1, i0_FindOptiSync,
              &b_emlrtBCI_FindOptiSync);
          }

          if (!rtIsNaN(y_FindOptiSync->data_FindOptiSync[ic_FindOptiSync - 1]))
          {
            i0_FindOptiSync = y_FindOptiSync->size_FindOptiSync[0] << 2;
            if (!((ic_FindOptiSync >= 1) && (ic_FindOptiSync <= i0_FindOptiSync)))
            {
              rtDynamicBoundsError_FindOptiSy(ic_FindOptiSync, 1,
                i0_FindOptiSync, &v_emlrtBCI_FindOptiSync);
            }

            temp_re_FindOptiSync = y_FindOptiSync->
              data_FindOptiSync[ic_FindOptiSync - 1];
            nm1d2_FindOptiSync = ar_FindOptiSync;
            exitg2_FindOptiSync = true;
          } else {
            ic_FindOptiSync++;
          }
        }
      }

      if (ix_FindOptiSync - 1 < br_FindOptiSync) {
        if ((!(ix_FindOptiSync > br_FindOptiSync)) && (br_FindOptiSync >
             2147483646)) {
          check_forloop_overflow_error_Fi();
        }

        while (ix_FindOptiSync <= br_FindOptiSync) {
          ar_FindOptiSync++;
          i0_FindOptiSync = y_FindOptiSync->size_FindOptiSync[0] << 2;
          if (!((ix_FindOptiSync >= 1) && (ix_FindOptiSync <= i0_FindOptiSync)))
          {
            rtDynamicBoundsError_FindOptiSy(ix_FindOptiSync, 1, i0_FindOptiSync,
              &emlrtBCI_FindOptiSync);
          }

          if (y_FindOptiSync->data_FindOptiSync[ix_FindOptiSync - 1] >
              temp_re_FindOptiSync) {
            i0_FindOptiSync = y_FindOptiSync->size_FindOptiSync[0] << 2;
            if (!((ix_FindOptiSync >= 1) && (ix_FindOptiSync <= i0_FindOptiSync)))
            {
              rtDynamicBoundsError_FindOptiSy(ix_FindOptiSync, 1,
                i0_FindOptiSync, &s_emlrtBCI_FindOptiSync);
            }

            temp_re_FindOptiSync = y_FindOptiSync->
              data_FindOptiSync[ix_FindOptiSync - 1];
            nm1d2_FindOptiSync = ar_FindOptiSync;
          }

          ix_FindOptiSync++;
        }
      }
    }

    iindx_FindOptiSync[ia_FindOptiSync] = nm1d2_FindOptiSync;
  }

  emxFree_real_T_FindOptiSync(&y_FindOptiSync);
  for (i0_FindOptiSync = 0; i0_FindOptiSync < 4; i0_FindOptiSync++) {
    indx_FindOptiSync[i0_FindOptiSync] = iindx_FindOptiSync[i0_FindOptiSync];
  }

  /* 'FindOptiSyncImplement:28' ~ */
  /* 'FindOptiSyncImplement:30' for idxChannel = 1:NumChannel */
  for (idxChannel_FindOptiSync = 0; idxChannel_FindOptiSync < 4;
       idxChannel_FindOptiSync++) {
    /* 'FindOptiSyncImplement:31' syncIndexMat(idxChannel,idxSyncIndexVec(idxChannel)) = 1; */
    i0_FindOptiSync = syncIndexMat_FindOptiSync->size_FindOptiSync[1];
    if (!((indx_FindOptiSync[idxChannel_FindOptiSync] >= 1) &&
          (indx_FindOptiSync[idxChannel_FindOptiSync] <= i0_FindOptiSync))) {
      rtDynamicBoundsError_FindOptiSy(indx_FindOptiSync[idxChannel_FindOptiSync],
        1, i0_FindOptiSync, &t_emlrtBCI_FindOptiSync);
    }

    syncIndexMat_FindOptiSync->data_FindOptiSync[idxChannel_FindOptiSync +
      syncIndexMat_FindOptiSync->size_FindOptiSync[0] *
      (indx_FindOptiSync[idxChannel_FindOptiSync] - 1)] = 1.0;
  }

  /* 'FindOptiSyncImplement:34' [numSyncChannel, idxShift] = max(sum(syncIndexMat)); */
  overflow_FindOptiSync = false;
  n_too_large_FindOptiSync = false;
  k_FindOptiSync = 0;
  do {
    exitg1_FindOptiSync = 0;
    if (k_FindOptiSync < 2) {
      if (syncIndexMat_FindOptiSync->size_FindOptiSync[k_FindOptiSync] != 0) {
        exitg1_FindOptiSync = 1;
      } else {
        k_FindOptiSync++;
      }
    } else {
      n_too_large_FindOptiSync = true;
      exitg1_FindOptiSync = 1;
    }
  } while (exitg1_FindOptiSync == 0);

  if (!n_too_large_FindOptiSync) {
  } else {
    overflow_FindOptiSync = true;
  }

  if (!overflow_FindOptiSync) {
  } else {
    f_rtErrorWithMessageID_FindOpti(&f_emlrtRTEI_FindOptiSync);
  }

  emxInit_real_T_FindOptiSync(&b_y_FindOptiSync, 2);
  i0_FindOptiSync = b_y_FindOptiSync->size_FindOptiSync[0] *
    b_y_FindOptiSync->size_FindOptiSync[1];
  b_y_FindOptiSync->size_FindOptiSync[0] = 1;
  b_y_FindOptiSync->size_FindOptiSync[1] =
    syncIndexMat_FindOptiSync->size_FindOptiSync[1];
  emxEnsureCapacity_FindOptiSync((emxArray__common_FindOptiSync *)
    b_y_FindOptiSync, i0_FindOptiSync, (int)sizeof(double));
  if (syncIndexMat_FindOptiSync->size_FindOptiSync[1] == 0) {
    i0_FindOptiSync = b_y_FindOptiSync->size_FindOptiSync[0] *
      b_y_FindOptiSync->size_FindOptiSync[1];
    b_y_FindOptiSync->size_FindOptiSync[0] = 1;
    emxEnsureCapacity_FindOptiSync((emxArray__common_FindOptiSync *)
      b_y_FindOptiSync, i0_FindOptiSync, (int)sizeof(double));
    ar_FindOptiSync = b_y_FindOptiSync->size_FindOptiSync[1];
    for (i0_FindOptiSync = 0; i0_FindOptiSync < ar_FindOptiSync; i0_FindOptiSync
         ++) {
      b_y_FindOptiSync->data_FindOptiSync[b_y_FindOptiSync->size_FindOptiSync[0]
        * i0_FindOptiSync] = 0.0;
    }
  } else {
    overflow_FindOptiSync = (syncIndexMat_FindOptiSync->size_FindOptiSync[1] >
      2147483646);
    if (overflow_FindOptiSync) {
      check_forloop_overflow_error_Fi();
    }

    for (ia_FindOptiSync = 1; ia_FindOptiSync <=
         syncIndexMat_FindOptiSync->size_FindOptiSync[1]; ia_FindOptiSync++) {
      br_FindOptiSync = ((ia_FindOptiSync - 1) << 2) + 1;
      i0_FindOptiSync = syncIndexMat_FindOptiSync->size_FindOptiSync[1] << 2;
      if (!((br_FindOptiSync >= 1) && (br_FindOptiSync <= i0_FindOptiSync))) {
        rtDynamicBoundsError_FindOptiSy(br_FindOptiSync, 1, i0_FindOptiSync,
          &m_emlrtBCI_FindOptiSync);
      }

      temp_re_FindOptiSync = syncIndexMat_FindOptiSync->
        data_FindOptiSync[br_FindOptiSync - 1];
      for (k_FindOptiSync = 0; k_FindOptiSync < 3; k_FindOptiSync++) {
        i0_FindOptiSync = syncIndexMat_FindOptiSync->size_FindOptiSync[1] << 2;
        ix_FindOptiSync = (br_FindOptiSync + k_FindOptiSync) + 1;
        if (!((ix_FindOptiSync >= 1) && (ix_FindOptiSync <= i0_FindOptiSync))) {
          rtDynamicBoundsError_FindOptiSy(ix_FindOptiSync, 1, i0_FindOptiSync,
            &o_emlrtBCI_FindOptiSync);
        }

        temp_re_FindOptiSync += syncIndexMat_FindOptiSync->
          data_FindOptiSync[ix_FindOptiSync - 1];
      }

      i0_FindOptiSync = b_y_FindOptiSync->size_FindOptiSync[1];
      if (!((ia_FindOptiSync >= 1) && (ia_FindOptiSync <= i0_FindOptiSync))) {
        rtDynamicBoundsError_FindOptiSy(ia_FindOptiSync, 1, i0_FindOptiSync,
          &n_emlrtBCI_FindOptiSync);
      }

      b_y_FindOptiSync->data_FindOptiSync[ia_FindOptiSync - 1] =
        temp_re_FindOptiSync;
    }
  }

  emxFree_real_T_FindOptiSync(&syncIndexMat_FindOptiSync);
  if ((b_y_FindOptiSync->size_FindOptiSync[1] == 1) ||
      (b_y_FindOptiSync->size_FindOptiSync[1] != 1)) {
    overflow_FindOptiSync = true;
  } else {
    overflow_FindOptiSync = false;
  }

  if (overflow_FindOptiSync) {
  } else {
    e_rtErrorWithMessageID_FindOpti(&e_emlrtRTEI_FindOptiSync);
  }

  if (b_y_FindOptiSync->size_FindOptiSync[1] > 0) {
  } else {
    d_rtErrorWithMessageID_FindOpti(&d_emlrtRTEI_FindOptiSync);
  }

  n_FindOptiSync = b_y_FindOptiSync->size_FindOptiSync[1];
  temp_re_FindOptiSync = b_y_FindOptiSync->data_FindOptiSync[0];
  nm1d2_FindOptiSync = 1;
  if (b_y_FindOptiSync->size_FindOptiSync[1] > 1) {
    overflow_FindOptiSync = (b_y_FindOptiSync->size_FindOptiSync[1] > 2147483646);
    if (overflow_FindOptiSync) {
      check_forloop_overflow_error_Fi();
    }

    for (ic_FindOptiSync = 2; ic_FindOptiSync <= n_FindOptiSync; ic_FindOptiSync
         ++) {
      i0_FindOptiSync = b_y_FindOptiSync->size_FindOptiSync[1];
      if (!((ic_FindOptiSync >= 1) && (ic_FindOptiSync <= i0_FindOptiSync))) {
        rtDynamicBoundsError_FindOptiSy(ic_FindOptiSync, 1, i0_FindOptiSync,
          &emlrtBCI_FindOptiSync);
      }

      if (b_y_FindOptiSync->data_FindOptiSync[ic_FindOptiSync - 1] >
          temp_re_FindOptiSync) {
        i0_FindOptiSync = b_y_FindOptiSync->size_FindOptiSync[1];
        if (!((ic_FindOptiSync >= 1) && (ic_FindOptiSync <= i0_FindOptiSync))) {
          rtDynamicBoundsError_FindOptiSy(ic_FindOptiSync, 1, i0_FindOptiSync,
            &s_emlrtBCI_FindOptiSync);
        }

        temp_re_FindOptiSync = b_y_FindOptiSync->
          data_FindOptiSync[ic_FindOptiSync - 1];
        nm1d2_FindOptiSync = ic_FindOptiSync;
      }
    }
  }

  emxFree_real_T_FindOptiSync(&b_y_FindOptiSync);
  *numSyncChannel_FindOptiSync = temp_re_FindOptiSync;

  /* 'FindOptiSyncImplement:35' circShiftSelect = circShiftPattern(idxShift); */
  i0_FindOptiSync = circShiftPattern_FindOptiSync->size_FindOptiSync[1];
  if (!((nm1d2_FindOptiSync >= 1) && (nm1d2_FindOptiSync <= i0_FindOptiSync))) {
    rtDynamicBoundsError_FindOptiSy(nm1d2_FindOptiSync, 1, i0_FindOptiSync,
      &p_emlrtBCI_FindOptiSync);
  }

  *circShiftSelect_FindOptiSync =
    circShiftPattern_FindOptiSync->data_FindOptiSync[nm1d2_FindOptiSync - 1];

  /* 'FindOptiSyncImplement:36' pilotSequenceUpSampleShift = circshift(pilotSequenceUpSample, circShiftSelect); */
  memcpy(&pilotSequenceUpSampleShift_Find[0], &pilotSequenceUpSample_FindOptiS[0],
         1536U * sizeof(creal_T));
  circshift_FindOptiSync(pilotSequenceUpSampleShift_Find,
    circShiftPattern_FindOptiSync->data_FindOptiSync[nm1d2_FindOptiSync - 1]);

  /* 'FindOptiSyncImplement:37' pilotSequence = downsample(pilotSequenceUpSampleShift, UpSampleTimes); */
  emxFree_real_T_FindOptiSync(&circShiftPattern_FindOptiSync);
  if (UpSampleTimes_FindOptiSync < 0.0) {
    b_UpSampleTimes_FindOptiSync = ceil(UpSampleTimes_FindOptiSync);
  } else {
    b_UpSampleTimes_FindOptiSync = floor(UpSampleTimes_FindOptiSync);
  }

  if ((b_UpSampleTimes_FindOptiSync == UpSampleTimes_FindOptiSync) &&
      (UpSampleTimes_FindOptiSync > 0.0)) {
    overflow_FindOptiSync = true;
  } else {
    overflow_FindOptiSync = false;
  }

  if (overflow_FindOptiSync) {
  } else {
    c_rtErrorWithMessageID_FindOpti(45,
      "Downsample factor must be a positive integer.", &c_emlrtRTEI_FindOptiSync);
  }

  if (0.0 <= UpSampleTimes_FindOptiSync - 1.0) {
  } else {
    b_rtErrorWithMessageID_FindOpti(40,
      "Offset must be an integer from 0 to N-1.", &b_emlrtRTEI_FindOptiSync);
  }

  i0_FindOptiSync = (int)UpSampleTimes_FindOptiSync;
  if (i0_FindOptiSync == 0) {
    i1_FindOptiSync = MAX_int32_T;
  } else {
    i1_FindOptiSync = 1535 / i0_FindOptiSync;
  }

  c_FindOptiSync = i1_FindOptiSync + 1;
  if (c_FindOptiSync <= 1536) {
  } else {
    rtErrorWithMessageID_FindOptiSy(&emlrtRTEI_FindOptiSync);
  }

  for (i0_FindOptiSync = 0; i0_FindOptiSync < 2; i0_FindOptiSync++) {
    sz_FindOptiSync[i0_FindOptiSync] = 1536 + -1535 * i0_FindOptiSync;
  }

  sz_FindOptiSync[0] = c_FindOptiSync;
  for (i0_FindOptiSync = 0; i0_FindOptiSync < 2; i0_FindOptiSync++) {
    ix_FindOptiSync = sz_FindOptiSync[i0_FindOptiSync];
    if (!(ix_FindOptiSync >= 0)) {
      rtNonNegativeError_FindOptiSync(ix_FindOptiSync, &i_emlrtDCI_FindOptiSync);
    }
  }

  pilotSequence_size_FindOptiSync[0] = c_FindOptiSync;
  ic_FindOptiSync = 1;
  br_FindOptiSync = 1;
  if ((!(1 > c_FindOptiSync)) && (c_FindOptiSync > 2147483646)) {
    check_forloop_overflow_error_Fi();
  }

  for (k_FindOptiSync = 1; k_FindOptiSync <= c_FindOptiSync; k_FindOptiSync++) {
    if (!((br_FindOptiSync >= 1) && (br_FindOptiSync <= c_FindOptiSync))) {
      rtDynamicBoundsError_FindOptiSy(br_FindOptiSync, 1, c_FindOptiSync,
        &fb_emlrtBCI_FindOptiSync);
    }

    if (!((ic_FindOptiSync >= 1) && (ic_FindOptiSync <= 1536))) {
      rtDynamicBoundsError_FindOptiSy(ic_FindOptiSync, 1, 1536,
        &gb_emlrtBCI_FindOptiSync);
    }

    pilotSequence_data_FindOptiSync[br_FindOptiSync - 1].re =
      pilotSequenceUpSampleShift_Find[ic_FindOptiSync - 1].re;
    if (!((ic_FindOptiSync >= 1) && (ic_FindOptiSync <= 1536))) {
      rtDynamicBoundsError_FindOptiSy(ic_FindOptiSync, 1, 1536,
        &q_emlrtBCI_FindOptiSync);
    }

    if (!((br_FindOptiSync >= 1) && (br_FindOptiSync <= c_FindOptiSync))) {
      rtDynamicBoundsError_FindOptiSy(br_FindOptiSync, 1, c_FindOptiSync,
        &r_emlrtBCI_FindOptiSync);
    }

    pilotSequence_data_FindOptiSync[br_FindOptiSync - 1].im =
      pilotSequenceUpSampleShift_Find[ic_FindOptiSync - 1].im;
    ic_FindOptiSync += (int)UpSampleTimes_FindOptiSync;
    br_FindOptiSync++;
  }
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void FindOptiSyncImplement_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void FindOptiSyncImplement_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for FindOptiSyncImplement.c
 *
 * [EOF]
 */
