/*
 * File: FindOptiSyncImplement_emxutil.h
 *
 * MATLAB Coder version            : 3.4
 * C/C++ source code generated on  : 25-May-2018 10:36:46
 */

#ifndef FINDOPTISYNCIMPLEMENT_EMXUTIL_H
#define FINDOPTISYNCIMPLEMENT_EMXUTIL_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "FindOptiSyncImplement_types.h"

/* Function Declarations */
extern void emxEnsureCapacity_creal_T_FindOptSync(emxArray_creal_T_FindOptSync
  *emxArray_FindOptSync, int oldNumel_FindOptSync);
extern void emxEnsureCapacity_int32_T_FindOptSync(emxArray_int32_T_FindOptSync
  *emxArray_FindOptSync, int oldNumel_FindOptSync);
extern void emxEnsureCapacity_int8_T_FindOptSync(emxArray_int8_T_FindOptSync
  *emxArray_FindOptSync, int oldNumel_FindOptSync);
extern void emxEnsureCapacity_real_T_FindOptSync(emxArray_real_T_FindOptSync
  *emxArray_FindOptSync, int oldNumel_FindOptSync);
extern void emxFree_creal_T_FindOptSync(emxArray_creal_T_FindOptSync
  **pEmxArray_FindOptSync);
extern void emxFree_int32_T_FindOptSync(emxArray_int32_T_FindOptSync
  **pEmxArray_FindOptSync);
extern void emxFree_int8_T_FindOptSync(emxArray_int8_T_FindOptSync
  **pEmxArray_FindOptSync);
extern void emxFree_real_T_FindOptSync(emxArray_real_T_FindOptSync
  **pEmxArray_FindOptSync);
extern void emxInit_creal_T_FindOptSync(emxArray_creal_T_FindOptSync
  **pEmxArray_FindOptSync, int numDimensions_FindOptSync);
extern void emxInit_int32_T_FindOptSync(emxArray_int32_T_FindOptSync
  **pEmxArray_FindOptSync, int numDimensions_FindOptSync);
extern void emxInit_int8_T_FindOptSync(emxArray_int8_T_FindOptSync
  **pEmxArray_FindOptSync, int numDimensions_FindOptSync);
extern void emxInit_real_T_FindOptSync(emxArray_real_T_FindOptSync
  **pEmxArray_FindOptSync, int numDimensions_FindOptSync);

#endif

/*
 * File trailer for FindOptiSyncImplement_emxutil.h
 *
 * [EOF]
 */
