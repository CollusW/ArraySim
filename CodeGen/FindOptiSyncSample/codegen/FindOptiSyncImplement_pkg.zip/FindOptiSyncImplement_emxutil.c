/*
 * File: FindOptiSyncImplement_emxutil.c
 *
 * MATLAB Coder version            : 3.4
 * C/C++ source code generated on  : 25-May-2018 11:36:01
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "FindOptiSyncImplement.h"
#include "FindOptiSyncImplement_emxutil.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Function Definitions */

/*
 * Arguments    : emxArray_creal_T_FindOptSync *emxArray_FindOptSync
 *                int oldNumel_FindOptSync
 * Return Type  : void
 */
void emxEnsureCapacity_creal_T_FindOptSync(emxArray_creal_T_FindOptSync
  *emxArray_FindOptSync, int oldNumel_FindOptSync)
{
  int newNumel_FindOptSync;
  int i_FindOptSync;
  void *newData_FindOptSync;
  if (oldNumel_FindOptSync < 0) {
    oldNumel_FindOptSync = 0;
  }

  newNumel_FindOptSync = 1;
  for (i_FindOptSync = 0; i_FindOptSync <
       emxArray_FindOptSync->numDimensions_FindOptSync; i_FindOptSync++) {
    newNumel_FindOptSync *= emxArray_FindOptSync->size_FindOptSync[i_FindOptSync];
  }

  if (newNumel_FindOptSync > emxArray_FindOptSync->allocatedSize_FindOptSync) {
    i_FindOptSync = emxArray_FindOptSync->allocatedSize_FindOptSync;
    if (i_FindOptSync < 16) {
      i_FindOptSync = 16;
    }

    while (i_FindOptSync < newNumel_FindOptSync) {
      if (i_FindOptSync > 1073741823) {
        i_FindOptSync = MAX_int32_T;
      } else {
        i_FindOptSync <<= 1;
      }
    }

    newData_FindOptSync = calloc((unsigned int)i_FindOptSync, sizeof(creal_T));
    if (emxArray_FindOptSync->data_FindOptSync != NULL) {
      memcpy(newData_FindOptSync, (void *)emxArray_FindOptSync->data_FindOptSync,
             sizeof(creal_T) * oldNumel_FindOptSync);
      if (emxArray_FindOptSync->canFreeData_FindOptSync) {
        free((void *)emxArray_FindOptSync->data_FindOptSync);
      }
    }

    emxArray_FindOptSync->data_FindOptSync = (creal_T *)newData_FindOptSync;
    emxArray_FindOptSync->allocatedSize_FindOptSync = i_FindOptSync;
    emxArray_FindOptSync->canFreeData_FindOptSync = true;
  }
}

/*
 * Arguments    : emxArray_int32_T_FindOptSync *emxArray_FindOptSync
 *                int oldNumel_FindOptSync
 * Return Type  : void
 */
void emxEnsureCapacity_int32_T_FindOptSync(emxArray_int32_T_FindOptSync
  *emxArray_FindOptSync, int oldNumel_FindOptSync)
{
  int newNumel_FindOptSync;
  int i_FindOptSync;
  void *newData_FindOptSync;
  if (oldNumel_FindOptSync < 0) {
    oldNumel_FindOptSync = 0;
  }

  newNumel_FindOptSync = 1;
  for (i_FindOptSync = 0; i_FindOptSync <
       emxArray_FindOptSync->numDimensions_FindOptSync; i_FindOptSync++) {
    newNumel_FindOptSync *= emxArray_FindOptSync->size_FindOptSync[i_FindOptSync];
  }

  if (newNumel_FindOptSync > emxArray_FindOptSync->allocatedSize_FindOptSync) {
    i_FindOptSync = emxArray_FindOptSync->allocatedSize_FindOptSync;
    if (i_FindOptSync < 16) {
      i_FindOptSync = 16;
    }

    while (i_FindOptSync < newNumel_FindOptSync) {
      if (i_FindOptSync > 1073741823) {
        i_FindOptSync = MAX_int32_T;
      } else {
        i_FindOptSync <<= 1;
      }
    }

    newData_FindOptSync = calloc((unsigned int)i_FindOptSync, sizeof(int));
    if (emxArray_FindOptSync->data_FindOptSync != NULL) {
      memcpy(newData_FindOptSync, (void *)emxArray_FindOptSync->data_FindOptSync,
             sizeof(int) * oldNumel_FindOptSync);
      if (emxArray_FindOptSync->canFreeData_FindOptSync) {
        free((void *)emxArray_FindOptSync->data_FindOptSync);
      }
    }

    emxArray_FindOptSync->data_FindOptSync = (int *)newData_FindOptSync;
    emxArray_FindOptSync->allocatedSize_FindOptSync = i_FindOptSync;
    emxArray_FindOptSync->canFreeData_FindOptSync = true;
  }
}

/*
 * Arguments    : emxArray_int8_T_FindOptSync *emxArray_FindOptSync
 *                int oldNumel_FindOptSync
 * Return Type  : void
 */
void emxEnsureCapacity_int8_T_FindOptSync(emxArray_int8_T_FindOptSync
  *emxArray_FindOptSync, int oldNumel_FindOptSync)
{
  int newNumel_FindOptSync;
  int i_FindOptSync;
  void *newData_FindOptSync;
  if (oldNumel_FindOptSync < 0) {
    oldNumel_FindOptSync = 0;
  }

  newNumel_FindOptSync = 1;
  for (i_FindOptSync = 0; i_FindOptSync <
       emxArray_FindOptSync->numDimensions_FindOptSync; i_FindOptSync++) {
    newNumel_FindOptSync *= emxArray_FindOptSync->size_FindOptSync[i_FindOptSync];
  }

  if (newNumel_FindOptSync > emxArray_FindOptSync->allocatedSize_FindOptSync) {
    i_FindOptSync = emxArray_FindOptSync->allocatedSize_FindOptSync;
    if (i_FindOptSync < 16) {
      i_FindOptSync = 16;
    }

    while (i_FindOptSync < newNumel_FindOptSync) {
      if (i_FindOptSync > 1073741823) {
        i_FindOptSync = MAX_int32_T;
      } else {
        i_FindOptSync <<= 1;
      }
    }

    newData_FindOptSync = calloc((unsigned int)i_FindOptSync, sizeof(signed char));
    if (emxArray_FindOptSync->data_FindOptSync != NULL) {
      memcpy(newData_FindOptSync, (void *)emxArray_FindOptSync->data_FindOptSync,
             sizeof(signed char) * oldNumel_FindOptSync);
      if (emxArray_FindOptSync->canFreeData_FindOptSync) {
        free((void *)emxArray_FindOptSync->data_FindOptSync);
      }
    }

    emxArray_FindOptSync->data_FindOptSync = (signed char *)newData_FindOptSync;
    emxArray_FindOptSync->allocatedSize_FindOptSync = i_FindOptSync;
    emxArray_FindOptSync->canFreeData_FindOptSync = true;
  }
}

/*
 * Arguments    : emxArray_real_T_FindOptSync *emxArray_FindOptSync
 *                int oldNumel_FindOptSync
 * Return Type  : void
 */
void emxEnsureCapacity_real_T_FindOptSync(emxArray_real_T_FindOptSync
  *emxArray_FindOptSync, int oldNumel_FindOptSync)
{
  int newNumel_FindOptSync;
  int i_FindOptSync;
  void *newData_FindOptSync;
  if (oldNumel_FindOptSync < 0) {
    oldNumel_FindOptSync = 0;
  }

  newNumel_FindOptSync = 1;
  for (i_FindOptSync = 0; i_FindOptSync <
       emxArray_FindOptSync->numDimensions_FindOptSync; i_FindOptSync++) {
    newNumel_FindOptSync *= emxArray_FindOptSync->size_FindOptSync[i_FindOptSync];
  }

  if (newNumel_FindOptSync > emxArray_FindOptSync->allocatedSize_FindOptSync) {
    i_FindOptSync = emxArray_FindOptSync->allocatedSize_FindOptSync;
    if (i_FindOptSync < 16) {
      i_FindOptSync = 16;
    }

    while (i_FindOptSync < newNumel_FindOptSync) {
      if (i_FindOptSync > 1073741823) {
        i_FindOptSync = MAX_int32_T;
      } else {
        i_FindOptSync <<= 1;
      }
    }

    newData_FindOptSync = calloc((unsigned int)i_FindOptSync, sizeof(double));
    if (emxArray_FindOptSync->data_FindOptSync != NULL) {
      memcpy(newData_FindOptSync, (void *)emxArray_FindOptSync->data_FindOptSync,
             sizeof(double) * oldNumel_FindOptSync);
      if (emxArray_FindOptSync->canFreeData_FindOptSync) {
        free((void *)emxArray_FindOptSync->data_FindOptSync);
      }
    }

    emxArray_FindOptSync->data_FindOptSync = (double *)newData_FindOptSync;
    emxArray_FindOptSync->allocatedSize_FindOptSync = i_FindOptSync;
    emxArray_FindOptSync->canFreeData_FindOptSync = true;
  }
}

/*
 * Arguments    : emxArray_creal_T_FindOptSync **pEmxArray_FindOptSync
 * Return Type  : void
 */
void emxFree_creal_T_FindOptSync(emxArray_creal_T_FindOptSync
  **pEmxArray_FindOptSync)
{
  if (*pEmxArray_FindOptSync != (emxArray_creal_T_FindOptSync *)NULL) {
    if (((*pEmxArray_FindOptSync)->data_FindOptSync != (creal_T *)NULL) &&
        (*pEmxArray_FindOptSync)->canFreeData_FindOptSync) {
      free((void *)(*pEmxArray_FindOptSync)->data_FindOptSync);
    }

    free((void *)(*pEmxArray_FindOptSync)->size_FindOptSync);
    free((void *)*pEmxArray_FindOptSync);
    *pEmxArray_FindOptSync = (emxArray_creal_T_FindOptSync *)NULL;
  }
}

/*
 * Arguments    : emxArray_int32_T_FindOptSync **pEmxArray_FindOptSync
 * Return Type  : void
 */
void emxFree_int32_T_FindOptSync(emxArray_int32_T_FindOptSync
  **pEmxArray_FindOptSync)
{
  if (*pEmxArray_FindOptSync != (emxArray_int32_T_FindOptSync *)NULL) {
    if (((*pEmxArray_FindOptSync)->data_FindOptSync != (int *)NULL) &&
        (*pEmxArray_FindOptSync)->canFreeData_FindOptSync) {
      free((void *)(*pEmxArray_FindOptSync)->data_FindOptSync);
    }

    free((void *)(*pEmxArray_FindOptSync)->size_FindOptSync);
    free((void *)*pEmxArray_FindOptSync);
    *pEmxArray_FindOptSync = (emxArray_int32_T_FindOptSync *)NULL;
  }
}

/*
 * Arguments    : emxArray_int8_T_FindOptSync **pEmxArray_FindOptSync
 * Return Type  : void
 */
void emxFree_int8_T_FindOptSync(emxArray_int8_T_FindOptSync
  **pEmxArray_FindOptSync)
{
  if (*pEmxArray_FindOptSync != (emxArray_int8_T_FindOptSync *)NULL) {
    if (((*pEmxArray_FindOptSync)->data_FindOptSync != (signed char *)NULL) && (*
         pEmxArray_FindOptSync)->canFreeData_FindOptSync) {
      free((void *)(*pEmxArray_FindOptSync)->data_FindOptSync);
    }

    free((void *)(*pEmxArray_FindOptSync)->size_FindOptSync);
    free((void *)*pEmxArray_FindOptSync);
    *pEmxArray_FindOptSync = (emxArray_int8_T_FindOptSync *)NULL;
  }
}

/*
 * Arguments    : emxArray_real_T_FindOptSync **pEmxArray_FindOptSync
 * Return Type  : void
 */
void emxFree_real_T_FindOptSync(emxArray_real_T_FindOptSync
  **pEmxArray_FindOptSync)
{
  if (*pEmxArray_FindOptSync != (emxArray_real_T_FindOptSync *)NULL) {
    if (((*pEmxArray_FindOptSync)->data_FindOptSync != (double *)NULL) &&
        (*pEmxArray_FindOptSync)->canFreeData_FindOptSync) {
      free((void *)(*pEmxArray_FindOptSync)->data_FindOptSync);
    }

    free((void *)(*pEmxArray_FindOptSync)->size_FindOptSync);
    free((void *)*pEmxArray_FindOptSync);
    *pEmxArray_FindOptSync = (emxArray_real_T_FindOptSync *)NULL;
  }
}

/*
 * Arguments    : emxArray_creal_T_FindOptSync **pEmxArray_FindOptSync
 *                int numDimensions_FindOptSync
 * Return Type  : void
 */
void emxInit_creal_T_FindOptSync(emxArray_creal_T_FindOptSync
  **pEmxArray_FindOptSync, int numDimensions_FindOptSync)
{
  emxArray_creal_T_FindOptSync *emxArray_FindOptSync;
  int i_FindOptSync;
  *pEmxArray_FindOptSync = (emxArray_creal_T_FindOptSync *)malloc(sizeof
    (emxArray_creal_T_FindOptSync));
  emxArray_FindOptSync = *pEmxArray_FindOptSync;
  emxArray_FindOptSync->data_FindOptSync = (creal_T *)NULL;
  emxArray_FindOptSync->numDimensions_FindOptSync = numDimensions_FindOptSync;
  emxArray_FindOptSync->size_FindOptSync = (int *)malloc((unsigned int)(sizeof
    (int) * numDimensions_FindOptSync));
  emxArray_FindOptSync->allocatedSize_FindOptSync = 0;
  emxArray_FindOptSync->canFreeData_FindOptSync = true;
  for (i_FindOptSync = 0; i_FindOptSync < numDimensions_FindOptSync;
       i_FindOptSync++) {
    emxArray_FindOptSync->size_FindOptSync[i_FindOptSync] = 0;
  }
}

/*
 * Arguments    : emxArray_int32_T_FindOptSync **pEmxArray_FindOptSync
 *                int numDimensions_FindOptSync
 * Return Type  : void
 */
void emxInit_int32_T_FindOptSync(emxArray_int32_T_FindOptSync
  **pEmxArray_FindOptSync, int numDimensions_FindOptSync)
{
  emxArray_int32_T_FindOptSync *emxArray_FindOptSync;
  int i_FindOptSync;
  *pEmxArray_FindOptSync = (emxArray_int32_T_FindOptSync *)malloc(sizeof
    (emxArray_int32_T_FindOptSync));
  emxArray_FindOptSync = *pEmxArray_FindOptSync;
  emxArray_FindOptSync->data_FindOptSync = (int *)NULL;
  emxArray_FindOptSync->numDimensions_FindOptSync = numDimensions_FindOptSync;
  emxArray_FindOptSync->size_FindOptSync = (int *)malloc((unsigned int)(sizeof
    (int) * numDimensions_FindOptSync));
  emxArray_FindOptSync->allocatedSize_FindOptSync = 0;
  emxArray_FindOptSync->canFreeData_FindOptSync = true;
  for (i_FindOptSync = 0; i_FindOptSync < numDimensions_FindOptSync;
       i_FindOptSync++) {
    emxArray_FindOptSync->size_FindOptSync[i_FindOptSync] = 0;
  }
}

/*
 * Arguments    : emxArray_int8_T_FindOptSync **pEmxArray_FindOptSync
 *                int numDimensions_FindOptSync
 * Return Type  : void
 */
void emxInit_int8_T_FindOptSync(emxArray_int8_T_FindOptSync
  **pEmxArray_FindOptSync, int numDimensions_FindOptSync)
{
  emxArray_int8_T_FindOptSync *emxArray_FindOptSync;
  int i_FindOptSync;
  *pEmxArray_FindOptSync = (emxArray_int8_T_FindOptSync *)malloc(sizeof
    (emxArray_int8_T_FindOptSync));
  emxArray_FindOptSync = *pEmxArray_FindOptSync;
  emxArray_FindOptSync->data_FindOptSync = (signed char *)NULL;
  emxArray_FindOptSync->numDimensions_FindOptSync = numDimensions_FindOptSync;
  emxArray_FindOptSync->size_FindOptSync = (int *)malloc((unsigned int)(sizeof
    (int) * numDimensions_FindOptSync));
  emxArray_FindOptSync->allocatedSize_FindOptSync = 0;
  emxArray_FindOptSync->canFreeData_FindOptSync = true;
  for (i_FindOptSync = 0; i_FindOptSync < numDimensions_FindOptSync;
       i_FindOptSync++) {
    emxArray_FindOptSync->size_FindOptSync[i_FindOptSync] = 0;
  }
}

/*
 * Arguments    : emxArray_real_T_FindOptSync **pEmxArray_FindOptSync
 *                int numDimensions_FindOptSync
 * Return Type  : void
 */
void emxInit_real_T_FindOptSync(emxArray_real_T_FindOptSync
  **pEmxArray_FindOptSync, int numDimensions_FindOptSync)
{
  emxArray_real_T_FindOptSync *emxArray_FindOptSync;
  int i_FindOptSync;
  *pEmxArray_FindOptSync = (emxArray_real_T_FindOptSync *)malloc(sizeof
    (emxArray_real_T_FindOptSync));
  emxArray_FindOptSync = *pEmxArray_FindOptSync;
  emxArray_FindOptSync->data_FindOptSync = (double *)NULL;
  emxArray_FindOptSync->numDimensions_FindOptSync = numDimensions_FindOptSync;
  emxArray_FindOptSync->size_FindOptSync = (int *)malloc((unsigned int)(sizeof
    (int) * numDimensions_FindOptSync));
  emxArray_FindOptSync->allocatedSize_FindOptSync = 0;
  emxArray_FindOptSync->canFreeData_FindOptSync = true;
  for (i_FindOptSync = 0; i_FindOptSync < numDimensions_FindOptSync;
       i_FindOptSync++) {
    emxArray_FindOptSync->size_FindOptSync[i_FindOptSync] = 0;
  }
}

/*
 * File trailer for FindOptiSyncImplement_emxutil.c
 *
 * [EOF]
 */
