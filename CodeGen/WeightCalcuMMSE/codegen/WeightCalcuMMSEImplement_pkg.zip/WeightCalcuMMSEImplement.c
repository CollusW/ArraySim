/*
 * File: WeightCalcuMMSEImplement.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 02-Nov-2017 15:58:40
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "WeightCalcuMMSEImplement.h"
#include <stdio.h>
#include <stdlib.h>

/* Type Definitions */
#ifndef typedef_rtBoundsCheckInfo__WeightCalcuM
#define typedef_rtBoundsCheckInfo__WeightCalcuM

typedef struct {
  int iFirst_WeightCalcuMMSE;
  int iLast_WeightCalcuMMSE;
  int lineNo_WeightCalcuMMSE;
  int colNo_WeightCalcuMMSE;
  const char * aName_WeightCalcuMMSE;
  const char * fName_WeightCalcuMMSE;
  const char * pName_WeightCalcuMMSE;
  int checkKind_WeightCalcuMMSE;
} rtBoundsCheckInfo__WeightCalcuM;

#endif                                 /*typedef_rtBoundsCheckInfo__WeightCalcuM*/

#ifndef typedef_rtRunTimeErrorInfo__WeightCalcu
#define typedef_rtRunTimeErrorInfo__WeightCalcu

typedef struct {
  int lineNo_WeightCalcuMMSE;
  int colNo_WeightCalcuMMSE;
  const char * fName_WeightCalcuMMSE;
  const char * pName_WeightCalcuMMSE;
} rtRunTimeErrorInfo__WeightCalcu;

#endif                                 /*typedef_rtRunTimeErrorInfo__WeightCalcu*/

/* Variable Definitions */
static rtBoundsCheckInfo__WeightCalcuM emlrtBCI_WeightCalcuMMSE = { 1, 16, 26,
  47, "", "ixamax",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\ixamax.m",
  0 };

static rtBoundsCheckInfo__WeightCalcuM b_emlrtBCI_WeightCalcuMMSE = { 1, 16, 43,
  15, "", "xgerx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\xgerx.m",
  0 };

static rtBoundsCheckInfo__WeightCalcuM c_emlrtBCI_WeightCalcuMMSE = { 1, 4, 136,
  28, "", "lusolve",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m",
  0 };

static rtBoundsCheckInfo__WeightCalcuM d_emlrtBCI_WeightCalcuMMSE = { 1, 4, 137,
  17, "", "lusolve",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\lusolve.m",
  0 };

static rtBoundsCheckInfo__WeightCalcuM e_emlrtBCI_WeightCalcuMMSE = { 1, 16, 56,
  26, "", "xgerx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\xgerx.m",
  0 };

static rtBoundsCheckInfo__WeightCalcuM f_emlrtBCI_WeightCalcuMMSE = { 1, 16, 56,
  17, "", "xgerx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\xgerx.m",
  0 };

static rtBoundsCheckInfo__WeightCalcuM g_emlrtBCI_WeightCalcuMMSE = { 1, 16, 21,
  12, "", "xswap",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\xswap.m",
  0 };

static rtBoundsCheckInfo__WeightCalcuM h_emlrtBCI_WeightCalcuMMSE = { 1, 16, 23,
  17, "", "xswap",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\xswap.m",
  0 };

static rtBoundsCheckInfo__WeightCalcuM i_emlrtBCI_WeightCalcuMMSE = { 1, 16, 56,
  35, "", "xgerx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\xgerx.m",
  0 };

static rtBoundsCheckInfo__WeightCalcuM j_emlrtBCI_WeightCalcuMMSE = { 1, 16, 21,
  5, "", "xswap",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\xswap.m",
  0 };

static rtBoundsCheckInfo__WeightCalcuM k_emlrtBCI_WeightCalcuMMSE = { 1, 16, 23,
  9, "", "xswap",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\xswap.m",
  0 };

static rtBoundsCheckInfo__WeightCalcuM l_emlrtBCI_WeightCalcuMMSE = { 1, 16, 58,
  5, "", "xzgetrf",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzgetrf.m",
  0 };

static rtBoundsCheckInfo__WeightCalcuM m_emlrtBCI_WeightCalcuMMSE = { 1, 4, 1, 1,
  "", "mldivide",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\mldivide.p",
  0 };

static rtRunTimeErrorInfo__WeightCalcu emlrtRTEI_WeightCalcuMMSE = { 86, 15,
  "eml_int_forloop_overflow_check",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\eml\\eml_int_forloop_overflow_check.m"
};

/* Function Declarations */
static void check_forloop_overflow_error(boolean_T overflow);
static void mldivide(const creal_T A[16], const creal_T B[4], creal_T Y[4]);
static void rtDynamicBoundsError(int aIndexValue, int aLoBound, int aHiBound,
  const rtBoundsCheckInfo__WeightCalcuM *aInfo);
static void rtErrorWithMessageID(const int b, const char *c, const
  rtRunTimeErrorInfo__WeightCalcu *aInfo);
static boolean_T rtIsNullOrEmptyString(const char *aString);
static void rtReportErrorLocation(const char * aFcnName, const int aLineNo);
static double rt_hypotd_snf(double u0, double u1);

/* Function Definitions */

/*
 * Arguments    : boolean_T overflow
 * Return Type  : void
 */
static void check_forloop_overflow_error(boolean_T overflow)
{
  if (!overflow) {
  } else {
    rtErrorWithMessageID(5, "int32", &emlrtRTEI_WeightCalcuMMSE);
  }
}

/*
 * Arguments    : const creal_T A[16]
 *                const creal_T B[4]
 *                creal_T Y[4]
 * Return Type  : void
 */
static void mldivide(const creal_T A[16], const creal_T B[4], creal_T Y[4])
{
  creal_T b_A[16];
  signed char ipiv[4];
  int kAcol;
  int j;
  int c;
  int iy;
  int ix;
  double temp_re;
  int k;
  double temp_im;
  int b;
  double Y_re;
  double bi;
  double brm;
  int ijA;
  memcpy(&b_A[0], &A[0], sizeof(creal_T) << 4);
  for (kAcol = 0; kAcol < 4; kAcol++) {
    ipiv[kAcol] = (signed char)(1 + kAcol);
  }

  for (j = 0; j < 3; j++) {
    c = j * 5;
    iy = 1;
    ix = c;
    temp_re = fabs(b_A[c].re) + fabs(b_A[c].im);
    for (k = 2; k <= 4 - j; k++) {
      ix++;
      if (!((ix + 1 >= 1) && (ix + 1 <= 16))) {
        rtDynamicBoundsError(ix + 1, 1, 16, &emlrtBCI_WeightCalcuMMSE);
      }

      temp_im = fabs(b_A[ix].re) + fabs(b_A[ix].im);
      if (temp_im > temp_re) {
        iy = k;
        temp_re = temp_im;
      }
    }

    if ((b_A[(c + iy) - 1].re != 0.0) || (b_A[(c + iy) - 1].im != 0.0)) {
      if (iy - 1 != 0) {
        ipiv[j] = (signed char)(j + iy);
        ix = j;
        iy += j;
        for (k = 0; k < 4; k++) {
          if (!((ix + 1 >= 1) && (ix + 1 <= 16))) {
            rtDynamicBoundsError(ix + 1, 1, 16, &j_emlrtBCI_WeightCalcuMMSE);
          }

          temp_re = b_A[ix].re;
          if (!((ix + 1 >= 1) && (ix + 1 <= 16))) {
            rtDynamicBoundsError(ix + 1, 1, 16, &g_emlrtBCI_WeightCalcuMMSE);
          }

          temp_im = b_A[ix].im;
          if (!((iy >= 1) && (iy <= 16))) {
            rtDynamicBoundsError(iy, 1, 16, &k_emlrtBCI_WeightCalcuMMSE);
          }

          b_A[ix].re = b_A[iy - 1].re;
          if (!((iy >= 1) && (iy <= 16))) {
            rtDynamicBoundsError(iy, 1, 16, &h_emlrtBCI_WeightCalcuMMSE);
          }

          b_A[ix].im = b_A[iy - 1].im;
          b_A[iy - 1].re = temp_re;
          b_A[iy - 1].im = temp_im;
          ix += 4;
          iy += 4;
        }
      }

      b = (c - j) + 4;
      for (iy = c + 1; iy + 1 <= b; iy++) {
        bi = b_A[iy].re;
        temp_re = b_A[c].re;
        if (b_A[c].im == 0.0) {
          if (b_A[iy].im == 0.0) {
            b_A[iy].re /= b_A[c].re;
            b_A[iy].im = 0.0;
          } else if (b_A[iy].re == 0.0) {
            b_A[iy].re = 0.0;
            b_A[iy].im /= temp_re;
          } else {
            b_A[iy].re /= b_A[c].re;
            b_A[iy].im /= temp_re;
          }
        } else if (b_A[c].re == 0.0) {
          if (b_A[iy].re == 0.0) {
            b_A[iy].re = b_A[iy].im / b_A[c].im;
            b_A[iy].im = 0.0;
          } else if (b_A[iy].im == 0.0) {
            b_A[iy].re = 0.0;
            b_A[iy].im = -(bi / b_A[c].im);
          } else {
            b_A[iy].re = b_A[iy].im / b_A[c].im;
            b_A[iy].im = -(bi / b_A[c].im);
          }
        } else {
          brm = fabs(b_A[c].re);
          temp_im = fabs(b_A[c].im);
          if (brm > temp_im) {
            temp_im = b_A[c].im / b_A[c].re;
            temp_re = b_A[c].re + temp_im * b_A[c].im;
            b_A[iy].re = (b_A[iy].re + temp_im * b_A[iy].im) / temp_re;
            b_A[iy].im = (b_A[iy].im - temp_im * bi) / temp_re;
          } else if (temp_im == brm) {
            if (b_A[c].re > 0.0) {
              temp_im = 0.5;
            } else {
              temp_im = -0.5;
            }

            if (b_A[c].im > 0.0) {
              temp_re = 0.5;
            } else {
              temp_re = -0.5;
            }

            b_A[iy].re = (b_A[iy].re * temp_im + b_A[iy].im * temp_re) / brm;
            b_A[iy].im = (b_A[iy].im * temp_im - bi * temp_re) / brm;
          } else {
            temp_im = b_A[c].re / b_A[c].im;
            temp_re = b_A[c].im + temp_im * b_A[c].re;
            b_A[iy].re = (temp_im * b_A[iy].re + b_A[iy].im) / temp_re;
            b_A[iy].im = (temp_im * b_A[iy].im - bi) / temp_re;
          }
        }
      }
    }

    kAcol = c + 6;
    iy = c + 4;
    for (k = 1; k <= 3 - j; k++) {
      if (!((iy + 1 >= 1) && (iy + 1 <= 16))) {
        rtDynamicBoundsError(iy + 1, 1, 16, &b_emlrtBCI_WeightCalcuMMSE);
      }

      if ((b_A[iy].re != 0.0) || (b_A[iy].im != 0.0)) {
        temp_re = -b_A[iy].re - b_A[iy].im * 0.0;
        temp_im = b_A[iy].re * 0.0 + -b_A[iy].im;
        ix = c + 2;
        b = (kAcol - j) + 2;
        if ((!(kAcol > b)) && (b > 2147483646)) {
          check_forloop_overflow_error(true);
        }

        for (ijA = kAcol; ijA <= b; ijA++) {
          if (!((ix >= 1) && (ix <= 16))) {
            rtDynamicBoundsError(ix, 1, 16, &i_emlrtBCI_WeightCalcuMMSE);
          }

          if (!((ix >= 1) && (ix <= 16))) {
            rtDynamicBoundsError(ix, 1, 16, &i_emlrtBCI_WeightCalcuMMSE);
          }

          if (!((ix >= 1) && (ix <= 16))) {
            rtDynamicBoundsError(ix, 1, 16, &i_emlrtBCI_WeightCalcuMMSE);
          }

          if (!((ix >= 1) && (ix <= 16))) {
            rtDynamicBoundsError(ix, 1, 16, &i_emlrtBCI_WeightCalcuMMSE);
          }

          bi = b_A[ix - 1].re * temp_im + b_A[ix - 1].im * temp_re;
          if (!((ijA >= 1) && (ijA <= 16))) {
            rtDynamicBoundsError(ijA, 1, 16, &l_emlrtBCI_WeightCalcuMMSE);
          }

          if (!((ijA >= 1) && (ijA <= 16))) {
            rtDynamicBoundsError(ijA, 1, 16, &l_emlrtBCI_WeightCalcuMMSE);
          }

          b_A[ijA - 1].re += b_A[ix - 1].re * temp_re - b_A[ix - 1].im * temp_im;
          if (!((ijA >= 1) && (ijA <= 16))) {
            rtDynamicBoundsError(ijA, 1, 16, &e_emlrtBCI_WeightCalcuMMSE);
          }

          if (!((ijA >= 1) && (ijA <= 16))) {
            rtDynamicBoundsError(ijA, 1, 16, &f_emlrtBCI_WeightCalcuMMSE);
          }

          b_A[ijA - 1].im += bi;
          ix++;
        }
      }

      iy += 4;
      kAcol += 4;
    }
  }

  for (iy = 0; iy < 4; iy++) {
    Y[iy].re = B[iy].re;
    Y[iy].im = B[iy].im;
  }

  for (iy = 0; iy < 3; iy++) {
    if (ipiv[iy] != iy + 1) {
      temp_re = Y[iy].re;
      temp_im = Y[iy].im;
      kAcol = ipiv[iy];
      if (!(kAcol <= 4)) {
        rtDynamicBoundsError(kAcol, 1, 4, &m_emlrtBCI_WeightCalcuMMSE);
      }

      Y[iy].re = Y[kAcol - 1].re;
      kAcol = ipiv[iy];
      if (!(kAcol <= 4)) {
        rtDynamicBoundsError(kAcol, 1, 4, &c_emlrtBCI_WeightCalcuMMSE);
      }

      Y[iy].im = Y[kAcol - 1].im;
      kAcol = ipiv[iy];
      if (!(kAcol <= 4)) {
        rtDynamicBoundsError(kAcol, 1, 4, &m_emlrtBCI_WeightCalcuMMSE);
      }

      Y[kAcol - 1].re = temp_re;
      kAcol = ipiv[iy];
      if (!(kAcol <= 4)) {
        rtDynamicBoundsError(kAcol, 1, 4, &d_emlrtBCI_WeightCalcuMMSE);
      }

      Y[kAcol - 1].im = temp_im;
    }
  }

  for (k = 0; k < 4; k++) {
    kAcol = k << 2;
    if ((Y[k].re != 0.0) || (Y[k].im != 0.0)) {
      for (iy = k + 1; iy + 1 < 5; iy++) {
        temp_re = Y[k].re * b_A[iy + kAcol].im + Y[k].im * b_A[iy + kAcol].re;
        Y[iy].re -= Y[k].re * b_A[iy + kAcol].re - Y[k].im * b_A[iy + kAcol].im;
        Y[iy].im -= temp_re;
      }
    }
  }

  for (k = 3; k >= 0; k += -1) {
    kAcol = k << 2;
    if ((Y[k].re != 0.0) || (Y[k].im != 0.0)) {
      Y_re = Y[k].re;
      temp_re = b_A[k + kAcol].re;
      bi = b_A[k + kAcol].im;
      if (bi == 0.0) {
        if (Y[k].im == 0.0) {
          Y[k].re /= temp_re;
          Y[k].im = 0.0;
        } else if (Y[k].re == 0.0) {
          Y[k].re = 0.0;
          Y[k].im /= temp_re;
        } else {
          Y[k].re /= temp_re;
          Y[k].im /= temp_re;
        }
      } else if (temp_re == 0.0) {
        if (Y[k].re == 0.0) {
          Y[k].re = Y[k].im / bi;
          Y[k].im = 0.0;
        } else if (Y[k].im == 0.0) {
          Y[k].re = 0.0;
          Y[k].im = -(Y_re / bi);
        } else {
          Y[k].re = Y[k].im / bi;
          Y[k].im = -(Y_re / bi);
        }
      } else {
        brm = fabs(temp_re);
        temp_im = fabs(bi);
        if (brm > temp_im) {
          temp_im = bi / temp_re;
          temp_re += temp_im * bi;
          Y[k].re = (Y[k].re + temp_im * Y[k].im) / temp_re;
          Y[k].im = (Y[k].im - temp_im * Y_re) / temp_re;
        } else if (temp_im == brm) {
          if (temp_re > 0.0) {
            temp_im = 0.5;
          } else {
            temp_im = -0.5;
          }

          if (bi > 0.0) {
            temp_re = 0.5;
          } else {
            temp_re = -0.5;
          }

          Y[k].re = (Y[k].re * temp_im + Y[k].im * temp_re) / brm;
          Y[k].im = (Y[k].im * temp_im - Y_re * temp_re) / brm;
        } else {
          temp_im = temp_re / bi;
          temp_re = bi + temp_im * temp_re;
          Y[k].re = (temp_im * Y[k].re + Y[k].im) / temp_re;
          Y[k].im = (temp_im * Y[k].im - Y_re) / temp_re;
        }
      }

      for (iy = 0; iy + 1 <= k; iy++) {
        temp_re = Y[k].re * b_A[iy + kAcol].im + Y[k].im * b_A[iy + kAcol].re;
        Y[iy].re -= Y[k].re * b_A[iy + kAcol].re - Y[k].im * b_A[iy + kAcol].im;
        Y[iy].im -= temp_re;
      }
    }
  }
}

/*
 * Arguments    : int aIndexValue
 *                int aLoBound
 *                int aHiBound
 *                const rtBoundsCheckInfo__WeightCalcuM *aInfo
 * Return Type  : void
 */
static void rtDynamicBoundsError(int aIndexValue, int aLoBound, int aHiBound,
  const rtBoundsCheckInfo__WeightCalcuM *aInfo)
{
  if (aLoBound == 0) {
    aIndexValue++;
    aLoBound = 1;
    aHiBound++;
  }

  if (rtIsNullOrEmptyString(aInfo->aName_WeightCalcuMMSE)) {
    fprintf(stderr,
            "Index exceeds array dimensions.  Index value %d exceeds valid range [%d-%d].",
            aIndexValue, aLoBound, aHiBound);
    fprintf(stderr, "\n");
  } else {
    fprintf(stderr,
            "Index exceeds array dimensions.  Index value %d exceeds valid range [%d-%d] of array %s.",
            aIndexValue, aLoBound, aHiBound, aInfo->aName_WeightCalcuMMSE);
    fprintf(stderr, "\n");
  }

  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_WeightCalcuMMSE,
                          aInfo->lineNo_WeightCalcuMMSE);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const int b
 *                const char *c
 *                const rtRunTimeErrorInfo__WeightCalcu *aInfo
 * Return Type  : void
 */
static void rtErrorWithMessageID(const int b, const char *c, const
  rtRunTimeErrorInfo__WeightCalcu *aInfo)
{
  fprintf(stderr,
          "The loop variable of class %.*s might overflow on the last iteration of the for loop. This could lead to an infinite loop.",
          b, c);
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_WeightCalcuMMSE,
                          aInfo->lineNo_WeightCalcuMMSE);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const char *aString
 * Return Type  : boolean_T
 */
static boolean_T rtIsNullOrEmptyString(const char *aString)
{
  return (aString == NULL) || (*aString == '\x00');
}

/*
 * Arguments    : const char * aFcnName
 *                const int aLineNo
 * Return Type  : void
 */
static void rtReportErrorLocation(const char * aFcnName, const int aLineNo)
{
  fprintf(stderr, "Error in %s (line %d)", aFcnName, aLineNo);
  fprintf(stderr, "\n");
}

/*
 * Arguments    : double u0
 *                double u1
 * Return Type  : double
 */
static double rt_hypotd_snf(double u0, double u1)
{
  double y;
  double a;
  double b;
  a = fabs(u0);
  b = fabs(u1);
  if (a < b) {
    a /= b;
    y = b * sqrt(a * a + 1.0);
  } else if (a > b) {
    b /= a;
    y = a * sqrt(b * b + 1.0);
  } else if (rtIsNaN(b)) {
    y = b;
  } else {
    y = a * 1.4142135623730951;
  }

  return y;
}

/*
 * Weight calculation using MMSE critetion.
 *  input:
 *     % rxSigNoise: NxM complex, N is the number of snapshots, M is the number of channel. each colum is one snapshot
 *     % PilotSequence: Nx1 complex, N is the length of pilot.
 *     % SNRThreshold: 1x1 double, in dB, SNR threshold for diagnal load to lower high SNR.
 *  output:
 *     % weight, Mx1 complex, Adaptive receive weight .
 *  2017-10-18 V1.0 Collus Wang and Wayne Zhang. inherited from old repo.
 * Arguments    : const creal_T rxSigNoise[2048]
 *                const creal_T PilotSequence[512]
 *                double SNRThreshold
 *                creal_T weight[4]
 * Return Type  : void
 */
void WeightCalcuMMSEImplement(const creal_T rxSigNoise[2048], const creal_T
  PilotSequence[512], double SNRThreshold, creal_T weight[4])
{
  int ixstart;
  int ix;
  creal_T d[4];
  creal_T Rxx[16];
  int i0;
  double mtmp;
  double y_im;
  static const signed char b[16] = { 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0,
    1 };

  double y[4];
  boolean_T exitg1;

  /*  Cross correlation vector */
  /* 'WeightCalcuMMSEImplement:12' Pxs = rxSigNoise.'*conj(PilotSequence); */
  /*  Auto correlation matrix */
  /* 'WeightCalcuMMSEImplement:14' Rxx = rxSigNoise.'*conj(rxSigNoise); */
  for (ixstart = 0; ixstart < 4; ixstart++) {
    for (ix = 0; ix < 4; ix++) {
      Rxx[ixstart + (ix << 2)].re = 0.0;
      Rxx[ixstart + (ix << 2)].im = 0.0;
      for (i0 = 0; i0 < 512; i0++) {
        mtmp = rxSigNoise[i0 + (ix << 9)].re;
        y_im = -rxSigNoise[i0 + (ix << 9)].im;
        Rxx[ixstart + (ix << 2)].re += rxSigNoise[i0 + (ixstart << 9)].re * mtmp
          - rxSigNoise[i0 + (ixstart << 9)].im * y_im;
        Rxx[ixstart + (ix << 2)].im += rxSigNoise[i0 + (ixstart << 9)].re * y_im
          + rxSigNoise[i0 + (ixstart << 9)].im * mtmp;
      }
    }
  }

  /*  Diagnal load noise power to lower high SNR to specific threshold. */
  /* 'WeightCalcuMMSEImplement:16' Rxx = Rxx + sum(diag(Rxx))/length(Pxs)/SNRThreshold*eye(size(Rxx)); */
  for (ixstart = 0; ixstart < 4; ixstart++) {
    d[ixstart] = Rxx[ixstart * 5];
  }

  mtmp = d[0].re;
  y_im = d[0].im;
  for (ixstart = 0; ixstart < 3; ixstart++) {
    mtmp += d[ixstart + 1].re;
    y_im += d[ixstart + 1].im;
  }

  if (y_im == 0.0) {
    mtmp /= 4.0;
    y_im = 0.0;
  } else if (mtmp == 0.0) {
    mtmp = 0.0;
    y_im /= 4.0;
  } else {
    mtmp /= 4.0;
    y_im /= 4.0;
  }

  if (y_im == 0.0) {
    mtmp /= SNRThreshold;
    y_im = 0.0;
  } else if (mtmp == 0.0) {
    mtmp = 0.0;
    y_im /= SNRThreshold;
  } else {
    mtmp /= SNRThreshold;
    y_im /= SNRThreshold;
  }

  for (ixstart = 0; ixstart < 16; ixstart++) {
    Rxx[ixstart].re += mtmp * (double)b[ixstart];
    Rxx[ixstart].im += y_im * (double)b[ixstart];
  }

  /*  MMSE criterion */
  /* 'WeightCalcuMMSEImplement:18' weight = Rxx\Pxs; */
  for (ixstart = 0; ixstart < 4; ixstart++) {
    d[ixstart].re = 0.0;
    d[ixstart].im = 0.0;
    for (ix = 0; ix < 512; ix++) {
      d[ixstart].re += rxSigNoise[ix + (ixstart << 9)].re * PilotSequence[ix].re
        - rxSigNoise[ix + (ixstart << 9)].im * -PilotSequence[ix].im;
      d[ixstart].im += rxSigNoise[ix + (ixstart << 9)].re * -PilotSequence[ix].
        im + rxSigNoise[ix + (ixstart << 9)].im * PilotSequence[ix].re;
    }
  }

  mldivide(Rxx, d, weight);

  /*  Amplitude normalization */
  /* 'WeightCalcuMMSEImplement:20' weight = weight/max(abs(weight)); */
  for (ixstart = 0; ixstart < 4; ixstart++) {
    y[ixstart] = rt_hypotd_snf(weight[ixstart].re, weight[ixstart].im);
  }

  ixstart = 1;
  mtmp = y[0];
  if (rtIsNaN(y[0])) {
    ix = 2;
    exitg1 = false;
    while ((!exitg1) && (ix < 5)) {
      ixstart = ix;
      if (!rtIsNaN(y[ix - 1])) {
        mtmp = y[ix - 1];
        exitg1 = true;
      } else {
        ix++;
      }
    }
  }

  if (ixstart < 4) {
    while (ixstart + 1 < 5) {
      if (y[ixstart] > mtmp) {
        mtmp = y[ixstart];
      }

      ixstart++;
    }
  }

  for (ixstart = 0; ixstart < 4; ixstart++) {
    if (weight[ixstart].im == 0.0) {
      weight[ixstart].re /= mtmp;
      weight[ixstart].im = 0.0;
    } else if (weight[ixstart].re == 0.0) {
      weight[ixstart].re = 0.0;
      weight[ixstart].im /= mtmp;
    } else {
      weight[ixstart].re /= mtmp;
      weight[ixstart].im /= mtmp;
    }
  }
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void WeightCalcuMMSEImplement_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void WeightCalcuMMSEImplement_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for WeightCalcuMMSEImplement.c
 *
 * [EOF]
 */
