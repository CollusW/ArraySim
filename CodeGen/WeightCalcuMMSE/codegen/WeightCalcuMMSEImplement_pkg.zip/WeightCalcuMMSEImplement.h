/*
 * File: WeightCalcuMMSEImplement.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 02-Nov-2017 15:58:40
 */

#ifndef WEIGHTCALCUMMSEIMPLEMENT_H
#define WEIGHTCALCUMMSEIMPLEMENT_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "WeightCalcuMMSEImplement_types.h"

/* Function Declarations */
extern void WeightCalcuMMSEImplement(const creal_T rxSigNoise[2048], const
  creal_T PilotSequence[512], double SNRThreshold, creal_T weight[4]);
extern void WeightCalcuMMSEImplement_initialize(void);
extern void WeightCalcuMMSEImplement_terminate(void);

#endif

/*
 * File trailer for WeightCalcuMMSEImplement.h
 *
 * [EOF]
 */
