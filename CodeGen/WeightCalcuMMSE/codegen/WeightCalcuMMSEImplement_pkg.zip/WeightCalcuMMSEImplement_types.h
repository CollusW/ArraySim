/*
 * File: WeightCalcuMMSEImplement_types.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 02-Nov-2017 15:58:40
 */

#ifndef WEIGHTCALCUMMSEIMPLEMENT_TYPES_H
#define WEIGHTCALCUMMSEIMPLEMENT_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for WeightCalcuMMSEImplement_types.h
 *
 * [EOF]
 */
