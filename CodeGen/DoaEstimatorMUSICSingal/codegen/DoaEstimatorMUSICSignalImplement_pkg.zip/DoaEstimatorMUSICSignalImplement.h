/*
 * File: DoaEstimatorMUSICSignalImplement.h
 *
 * MATLAB Coder version            : 3.3
 * C/C++ source code generated on  : 20-Oct-2017 09:57:53
 */

#ifndef DOAESTIMATORMUSICSIGNALIMPLEMENT_H
#define DOAESTIMATORMUSICSIGNALIMPLEMENT_H

/* Include Files */
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "DoaEstimatorMUSICSignalImplement_types.h"

/* Function Declarations */
extern void DoaEstimatorMUSICSignalImplement(const creal_T recStvPartition[484],
  const creal_T rxSigNoise[2048], const double AzimuthScanAngles[121], double
  MaxNumSig, double spatialSpectrum[121], double doas_data[], int doas_size[1]);
extern void DoaEstimatorMUSICSignalImplement_initialize(void);
extern void DoaEstimatorMUSICSignalImplement_terminate(void);

#endif

/*
 * File trailer for DoaEstimatorMUSICSignalImplement.h
 *
 * [EOF]
 */
