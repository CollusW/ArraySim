/*
 * File: DoaEstimatorMUSICSignalImplement_types.h
 *
 * MATLAB Coder version            : 3.3
 * C/C++ source code generated on  : 20-Oct-2017 09:57:53
 */

#ifndef DOAESTIMATORMUSICSIGNALIMPLEMENT_TYPES_H
#define DOAESTIMATORMUSICSIGNALIMPLEMENT_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for DoaEstimatorMUSICSignalImplement_types.h
 *
 * [EOF]
 */
