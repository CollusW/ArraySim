/*
 * File: DoaEstimatorMUSICSignalImplement_types.h
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 21-Oct-2017 09:32:04
 */

#ifndef DOAESTIMATORMUSICSIGNALIMPLEMENT_TYPES_H
#define DOAESTIMATORMUSICSIGNALIMPLEMENT_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for DoaEstimatorMUSICSignalImplement_types.h
 *
 * [EOF]
 */
