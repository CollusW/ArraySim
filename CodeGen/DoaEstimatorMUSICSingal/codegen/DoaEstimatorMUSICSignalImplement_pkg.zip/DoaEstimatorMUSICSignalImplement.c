/*
 * File: DoaEstimatorMUSICSignalImplement.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 27-Oct-2017 14:55:07
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "DoaEstimatorMUSICSignalImplement.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Type Definitions */
#ifndef typedef_rtBoundsCheckInfo_DoaMusicSigna
#define typedef_rtBoundsCheckInfo_DoaMusicSigna

typedef struct {
  int iFirst_DoaMusicSignal;
  int iLast_DoaMusicSignal;
  int lineNo_DoaMusicSignal;
  int colNo_DoaMusicSignal;
  const char * aName_DoaMusicSignal;
  const char * fName_DoaMusicSignal;
  const char * pName_DoaMusicSignal;
  int checkKind_DoaMusicSignal;
} rtBoundsCheckInfo_DoaMusicSigna;

#endif                                 /*typedef_rtBoundsCheckInfo_DoaMusicSigna*/

#ifndef typedef_rtDoubleCheckInfo_DoaMusicSigna
#define typedef_rtDoubleCheckInfo_DoaMusicSigna

typedef struct {
  int lineNo_DoaMusicSignal;
  int colNo_DoaMusicSignal;
  const char * fName_DoaMusicSignal;
  const char * pName_DoaMusicSignal;
  int checkKind_DoaMusicSignal;
} rtDoubleCheckInfo_DoaMusicSigna;

#endif                                 /*typedef_rtDoubleCheckInfo_DoaMusicSigna*/

#ifndef typedef_rtEqualityCheckInfo_DoaMusicSig
#define typedef_rtEqualityCheckInfo_DoaMusicSig

typedef struct {
  int nDims_DoaMusicSignal;
  int lineNo_DoaMusicSignal;
  int colNo_DoaMusicSignal;
  const char * fName_DoaMusicSignal;
  const char * pName_DoaMusicSignal;
} rtEqualityCheckInfo_DoaMusicSig;

#endif                                 /*typedef_rtEqualityCheckInfo_DoaMusicSig*/

#ifndef typedef_rtRunTimeErrorInfo_DoaMusicSign
#define typedef_rtRunTimeErrorInfo_DoaMusicSign

typedef struct {
  int lineNo_DoaMusicSignal;
  int colNo_DoaMusicSignal;
  const char * fName_DoaMusicSignal;
  const char * pName_DoaMusicSignal;
} rtRunTimeErrorInfo_DoaMusicSign;

#endif                                 /*typedef_rtRunTimeErrorInfo_DoaMusicSign*/

/* Variable Definitions */
static rtRunTimeErrorInfo_DoaMusicSign emlrtRTEI_DoaMusicSignal = { 103, 23,
  "eml_mtimes_helper",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\eml_mtimes_helper.m"
};

static rtBoundsCheckInfo_DoaMusicSigna emlrtBCI_DoaMusicSignal = { 1, 4, 26, 8,
  "eigD", "DoaEstimatorMUSICSignalImplement",
  "F:\\matlab\\ArraySim\\CodeGen\\DoaEstimatorMUSICSingal\\DoaEstimatorMUSICSignalImplement.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna b_emlrtBCI_DoaMusicSignal = { 1, 121, 67,
  8, "AzimuthScanAngles", "DoaEstimatorMUSICSignalImplement",
  "F:\\matlab\\ArraySim\\CodeGen\\DoaEstimatorMUSICSingal\\DoaEstimatorMUSICSignalImplement.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna c_emlrtBCI_DoaMusicSignal = { -1, -1, 88,
  21, "", "xgemm",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\xgemm.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna d_emlrtBCI_DoaMusicSignal = { -1, -1, 87,
  20, "", "xgemm",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\xgemm.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna e_emlrtBCI_DoaMusicSignal = { -1, -1, 92,
  41, "", "xgemm",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+refblas\\xgemm.m",
  0 };

static rtRunTimeErrorInfo_DoaMusicSign b_emlrtRTEI_DoaMusicSignal = { 17, 9,
  "error",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\error.m"
};

static rtRunTimeErrorInfo_DoaMusicSign c_emlrtRTEI_DoaMusicSignal = { 86, 15,
  "eml_int_forloop_overflow_check",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\eml\\eml_int_forloop_overflow_check.m"
};

static rtRunTimeErrorInfo_DoaMusicSign d_emlrtRTEI_DoaMusicSignal = { 15, 27,
  "pow2db",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\pow2db.m" };

static rtDoubleCheckInfo_DoaMusicSigna emlrtDCI_DoaMusicSignal = { 165, 7,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 1 };

static rtBoundsCheckInfo_DoaMusicSigna f_emlrtBCI_DoaMusicSignal = { -1, -1, 165,
  7, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtRunTimeErrorInfo_DoaMusicSign e_emlrtRTEI_DoaMusicSignal = { 157, 28,
  "validateattributes",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\lang\\validateattributes.m"
};

static rtRunTimeErrorInfo_DoaMusicSign f_emlrtRTEI_DoaMusicSignal = { 271, 28,
  "validateattributes",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\lang\\validateattributes.m"
};

static rtRunTimeErrorInfo_DoaMusicSign g_emlrtRTEI_DoaMusicSignal = { 138, 28,
  "validateattributes",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\lang\\validateattributes.m"
};

static rtRunTimeErrorInfo_DoaMusicSign h_emlrtRTEI_DoaMusicSignal = { 152, 28,
  "validateattributes",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\lang\\validateattributes.m"
};

static rtRunTimeErrorInfo_DoaMusicSign i_emlrtRTEI_DoaMusicSignal = { 88, 9,
  "indexShapeCheck",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\indexShapeCheck.m"
};

static rtBoundsCheckInfo_DoaMusicSigna g_emlrtBCI_DoaMusicSignal = { -1, -1, 253,
  17, "", "find",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\elmat\\find.m",
  0 };

static rtRunTimeErrorInfo_DoaMusicSign j_emlrtRTEI_DoaMusicSignal = { 243, 9,
  "find",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\elmat\\find.m"
};

static rtEqualityCheckInfo_DoaMusicSig emlrtECI_DoaMusicSignal = { -1, 392, 17,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtBoundsCheckInfo_DoaMusicSigna h_emlrtBCI_DoaMusicSignal = { -1, -1, 392,
  17, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna i_emlrtBCI_DoaMusicSignal = { -1, -1, 235,
  33, "", "find",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\elmat\\find.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna j_emlrtBCI_DoaMusicSignal = { -1, -1, 237,
  17, "", "find",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\elmat\\find.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna k_emlrtBCI_DoaMusicSignal = { -1, -1, 395,
  12, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna l_emlrtBCI_DoaMusicSignal = { -1, -1, 396,
  7, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtRunTimeErrorInfo_DoaMusicSign k_emlrtRTEI_DoaMusicSignal = { 51, 19,
  "diff",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\datafun\\diff.m"
};

static rtBoundsCheckInfo_DoaMusicSigna m_emlrtBCI_DoaMusicSignal = { -1, -1, 107,
  27, "", "diff",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\datafun\\diff.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna n_emlrtBCI_DoaMusicSignal = { -1, -1, 114,
  17, "", "diff",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\datafun\\diff.m",
  0 };

static rtRunTimeErrorInfo_DoaMusicSign l_emlrtRTEI_DoaMusicSignal = { 17, 19,
  "scalexpAlloc",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\scalexpAlloc.m"
};

static rtBoundsCheckInfo_DoaMusicSigna o_emlrtBCI_DoaMusicSignal = { -1, -1, 271,
  14, "", "minOrMax",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\minOrMax.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna p_emlrtBCI_DoaMusicSignal = { -1, -1, 270,
  14, "", "minOrMax",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\minOrMax.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna q_emlrtBCI_DoaMusicSignal = { 1, 123, 444,
  16, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna r_emlrtBCI_DoaMusicSignal = { 1, 123, 444,
  33, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna s_emlrtBCI_DoaMusicSignal = { -1, -1, 272,
  9, "", "minOrMax",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\minOrMax.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna t_emlrtBCI_DoaMusicSignal = { -1, -1, 468,
  9, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna u_emlrtBCI_DoaMusicSignal = { -1, -1, 468,
  24, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna v_emlrtBCI_DoaMusicSignal = { 1, 123, 483,
  7, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna w_emlrtBCI_DoaMusicSignal = { -1, -1, 483,
  7, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna x_emlrtBCI_DoaMusicSignal = { -1, -1, 486,
  16, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna y_emlrtBCI_DoaMusicSignal = { -1, -1, 498,
  16, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna ab_emlrtBCI_DoaMusicSignal = { -1, -1,
  509, 3, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna bb_emlrtBCI_DoaMusicSignal = { -1, -1,
  510, 3, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna cb_emlrtBCI_DoaMusicSignal = { -1, -1,
  511, 3, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna db_emlrtBCI_DoaMusicSignal = { -1, -1,
  513, 6, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna eb_emlrtBCI_DoaMusicSignal = { -1, -1,
  513, 21, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna fb_emlrtBCI_DoaMusicSignal = { -1, -1,
  514, 5, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna gb_emlrtBCI_DoaMusicSignal = { -1, -1,
  515, 5, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna hb_emlrtBCI_DoaMusicSignal = { -1, -1,
  499, 8, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna ib_emlrtBCI_DoaMusicSignal = { -1, -1,
  500, 11, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna jb_emlrtBCI_DoaMusicSignal = { -1, -1,
  501, 12, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna kb_emlrtBCI_DoaMusicSignal = { -1, -1,
  487, 8, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna lb_emlrtBCI_DoaMusicSignal = { -1, -1,
  488, 11, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna mb_emlrtBCI_DoaMusicSignal = { -1, -1,
  489, 12, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna nb_emlrtBCI_DoaMusicSignal = { 1, 123,
  469, 9, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna ob_emlrtBCI_DoaMusicSignal = { -1, -1,
  469, 9, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna pb_emlrtBCI_DoaMusicSignal = { -1, -1,
  470, 10, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna qb_emlrtBCI_DoaMusicSignal = { -1, -1,
  476, 20, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtEqualityCheckInfo_DoaMusicSig b_emlrtECI_DoaMusicSignal = { -1, 692, 3,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtEqualityCheckInfo_DoaMusicSig c_emlrtECI_DoaMusicSignal = { -1, 691, 3,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtEqualityCheckInfo_DoaMusicSig d_emlrtECI_DoaMusicSignal = { -1, 690, 3,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtEqualityCheckInfo_DoaMusicSig e_emlrtECI_DoaMusicSignal = { -1, 689, 3,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtEqualityCheckInfo_DoaMusicSig f_emlrtECI_DoaMusicSignal = { -1, 677, 1,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtEqualityCheckInfo_DoaMusicSig g_emlrtECI_DoaMusicSignal = { -1, 715, 3,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtEqualityCheckInfo_DoaMusicSig h_emlrtECI_DoaMusicSignal = { -1, 714, 3,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtEqualityCheckInfo_DoaMusicSig i_emlrtECI_DoaMusicSignal = { -1, 713, 3,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtEqualityCheckInfo_DoaMusicSig j_emlrtECI_DoaMusicSignal = { -1, 706, 1,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtEqualityCheckInfo_DoaMusicSig k_emlrtECI_DoaMusicSignal = { -1, 705, 1,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtEqualityCheckInfo_DoaMusicSig l_emlrtECI_DoaMusicSignal = { -1, 704, 1,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtEqualityCheckInfo_DoaMusicSig m_emlrtECI_DoaMusicSignal = { -1, 703, 1,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtEqualityCheckInfo_DoaMusicSig n_emlrtECI_DoaMusicSignal = { -1, 715, 31,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtEqualityCheckInfo_DoaMusicSig o_emlrtECI_DoaMusicSignal = { -1, 714, 31,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtEqualityCheckInfo_DoaMusicSig p_emlrtECI_DoaMusicSignal = { -1, 692, 31,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtEqualityCheckInfo_DoaMusicSig q_emlrtECI_DoaMusicSignal = { -1, 691, 31,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtBoundsCheckInfo_DoaMusicSigna rb_emlrtBCI_DoaMusicSignal = { -1, -1,
  677, 1, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna sb_emlrtBCI_DoaMusicSignal = { -1, -1,
  678, 1, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna tb_emlrtBCI_DoaMusicSignal = { -1, -1,
  689, 11, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna ub_emlrtBCI_DoaMusicSignal = { 1, 123,
  689, 24, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna vb_emlrtBCI_DoaMusicSignal = { -1, -1,
  690, 11, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna wb_emlrtBCI_DoaMusicSignal = { 1, 123,
  690, 24, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna xb_emlrtBCI_DoaMusicSignal = { 1, 123,
  691, 39, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna yb_emlrtBCI_DoaMusicSignal = { -1, -1,
  691, 11, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna ac_emlrtBCI_DoaMusicSignal = { 1, 123,
  692, 39, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna bc_emlrtBCI_DoaMusicSignal = { -1, -1,
  692, 11, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna cc_emlrtBCI_DoaMusicSignal = { -1, -1,
  703, 9, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna dc_emlrtBCI_DoaMusicSignal = { -1, -1,
  704, 9, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna ec_emlrtBCI_DoaMusicSignal = { -1, -1,
  705, 9, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna fc_emlrtBCI_DoaMusicSignal = { -1, -1,
  706, 9, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna gc_emlrtBCI_DoaMusicSignal = { -1, -1,
  713, 11, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna hc_emlrtBCI_DoaMusicSignal = { -1, -1,
  714, 11, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna ic_emlrtBCI_DoaMusicSignal = { -1, -1,
  715, 11, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtRunTimeErrorInfo_DoaMusicSign m_emlrtRTEI_DoaMusicSignal = { 392, 5,
  "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m"
};

static rtBoundsCheckInfo_DoaMusicSigna jc_emlrtBCI_DoaMusicSignal = { -1, -1,
  398, 17, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtRunTimeErrorInfo_DoaMusicSign n_emlrtRTEI_DoaMusicSignal = { 403, 9,
  "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m"
};

static rtBoundsCheckInfo_DoaMusicSigna kc_emlrtBCI_DoaMusicSignal = { -1, -1,
  409, 21, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtRunTimeErrorInfo_DoaMusicSign o_emlrtRTEI_DoaMusicSignal = { 430, 5,
  "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m"
};

static rtBoundsCheckInfo_DoaMusicSigna lc_emlrtBCI_DoaMusicSignal = { -1, -1,
  432, 15, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna mc_emlrtBCI_DoaMusicSignal = { -1, -1,
  381, 13, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna nc_emlrtBCI_DoaMusicSignal = { -1, -1,
  382, 13, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna oc_emlrtBCI_DoaMusicSignal = { -1, -1,
  358, 13, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna pc_emlrtBCI_DoaMusicSignal = { -1, -1,
  359, 13, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna qc_emlrtBCI_DoaMusicSignal = { -1, -1,
  333, 17, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna rc_emlrtBCI_DoaMusicSignal = { -1, -1,
  334, 17, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna sc_emlrtBCI_DoaMusicSignal = { -1, -1,
  305, 17, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna tc_emlrtBCI_DoaMusicSignal = { -1, -1,
  306, 17, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna uc_emlrtBCI_DoaMusicSignal = { -1, -1,
  286, 17, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna vc_emlrtBCI_DoaMusicSignal = { -1, -1,
  288, 17, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna wc_emlrtBCI_DoaMusicSignal = { -1, -1, 20,
  44, "", "sortLE",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortLE.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna xc_emlrtBCI_DoaMusicSignal = { -1, -1, 20,
  35, "", "sortLE",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortLE.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna yc_emlrtBCI_DoaMusicSignal = { -1, -1,
  272, 17, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ad_emlrtBCI_DoaMusicSignal = { -1, -1,
  273, 17, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna bd_emlrtBCI_DoaMusicSignal = { -1, -1,
  274, 17, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtEqualityCheckInfo_DoaMusicSig r_emlrtECI_DoaMusicSignal = { -1, 746, 15,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtBoundsCheckInfo_DoaMusicSigna cd_emlrtBCI_DoaMusicSignal = { 1, 123,
  734, 7, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna dd_emlrtBCI_DoaMusicSignal = { -1, -1,
  739, 13, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna ed_emlrtBCI_DoaMusicSignal = { -1, -1,
  752, 12, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna fd_emlrtBCI_DoaMusicSignal = { -1, -1,
  743, 7, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna gd_emlrtBCI_DoaMusicSignal = { -1, -1,
  747, 5, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna hd_emlrtBCI_DoaMusicSignal = { -1, -1,
  300, 13, "", "colon",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\colon.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna id_emlrtBCI_DoaMusicSignal = { -1, -1,
  301, 13, "", "colon",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\colon.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna jd_emlrtBCI_DoaMusicSignal = { -1, -1,
  297, 13, "", "colon",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\colon.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna kd_emlrtBCI_DoaMusicSignal = { -1, -1,
  293, 13, "", "colon",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\colon.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ld_emlrtBCI_DoaMusicSignal = { -1, -1,
  294, 13, "", "colon",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\colon.m",
  0 };

static rtEqualityCheckInfo_DoaMusicSig s_emlrtECI_DoaMusicSignal = { -1, 816, 7,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtBoundsCheckInfo_DoaMusicSigna md_emlrtBCI_DoaMusicSignal = { 1, 123,
  811, 7, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna nd_emlrtBCI_DoaMusicSignal = { -1, -1, 93,
  23, "", "diff",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\datafun\\diff.m",
  0 };

static rtRunTimeErrorInfo_DoaMusicSign p_emlrtRTEI_DoaMusicSignal = { 20, 15,
  "sumprod",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\datafun\\private\\sumprod.m"
};

static rtRunTimeErrorInfo_DoaMusicSign q_emlrtRTEI_DoaMusicSignal = { 48, 9,
  "sumprod",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\datafun\\private\\sumprod.m"
};

static rtBoundsCheckInfo_DoaMusicSigna od_emlrtBCI_DoaMusicSignal = { -1, -1, 70,
  26, "", "combine_vector_elements",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\datafun\\private\\combine_vector_elements.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna pd_emlrtBCI_DoaMusicSignal = { 1, 4, 33,
  13, "", "xzggbak",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzggbak.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna qd_emlrtBCI_DoaMusicSignal = { 1, 4, 38,
  26, "", "xzggbak",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzggbak.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna rd_emlrtBCI_DoaMusicSignal = { 1, 4, 24,
  26, "", "xzggbak",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzggbak.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna sd_emlrtBCI_DoaMusicSignal = { 1, 4, 108,
  5, "", "xzggev",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzggev.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna td_emlrtBCI_DoaMusicSignal = { 1, 4, 40,
  5, "", "xzggbal",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzggbal.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ud_emlrtBCI_DoaMusicSignal = { 1, 4, 27,
  5, "", "xzggbal",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzggbal.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna vd_emlrtBCI_DoaMusicSignal = { 1, 4, 77,
  16, "", "xzggbal",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzggbal.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna wd_emlrtBCI_DoaMusicSignal = { 1, 4, 60,
  16, "", "xzggbal",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzggbal.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna xd_emlrtBCI_DoaMusicSignal = { 1, 4, 61,
  18, "", "xzggbal",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzggbal.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna yd_emlrtBCI_DoaMusicSignal = { 1, 4, 78,
  18, "", "xzggbal",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzggbal.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ae_emlrtBCI_DoaMusicSignal = { 1, 4, 60,
  9, "", "xzggbal",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzggbal.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna be_emlrtBCI_DoaMusicSignal = { 1, 4, 61,
  9, "", "xzggbal",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzggbal.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ce_emlrtBCI_DoaMusicSignal = { 1, 4, 77,
  9, "", "xzggbal",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzggbal.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna de_emlrtBCI_DoaMusicSignal = { 1, 4, 78,
  9, "", "xzggbal",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzggbal.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ee_emlrtBCI_DoaMusicSignal = { 1, 4, 119,
  23, "", "xzhgeqz",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzhgeqz.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna fe_emlrtBCI_DoaMusicSignal = { 1, 4, 119,
  29, "", "xzhgeqz",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzhgeqz.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ge_emlrtBCI_DoaMusicSignal = { 1, 4, 134,
  33, "", "xzhgeqz",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzhgeqz.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna he_emlrtBCI_DoaMusicSignal = { 1, 4, 333,
  38, "", "xzhgeqz",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzhgeqz.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ie_emlrtBCI_DoaMusicSignal = { 1, 4, 348,
  55, "", "xzhgeqz",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzhgeqz.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna je_emlrtBCI_DoaMusicSignal = { 1, 4, 364,
  39, "", "xzhgeqz",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzhgeqz.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ke_emlrtBCI_DoaMusicSignal = { 1, 4, 390,
  31, "", "xzhgeqz",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzhgeqz.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna le_emlrtBCI_DoaMusicSignal = { 1, 4, 425,
  13, "", "xzhgeqz",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzhgeqz.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna me_emlrtBCI_DoaMusicSignal = { 1, 4, 398,
  71, "", "xzhgeqz",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzhgeqz.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ne_emlrtBCI_DoaMusicSignal = { 1, 4, 398,
  80, "", "xzhgeqz",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzhgeqz.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna oe_emlrtBCI_DoaMusicSignal = { 1, 4, 75,
  17, "", "xzhgeqz",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzhgeqz.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna pe_emlrtBCI_DoaMusicSignal = { 1, 4, 75,
  5, "", "xzhgeqz",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xzhgeqz.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna qe_emlrtBCI_DoaMusicSignal = { 1, 4, 117,
  26, "", "xztgevc",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\+reflapack\\xztgevc.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna re_emlrtBCI_DoaMusicSignal = { 1, 4, 451,
  9, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna se_emlrtBCI_DoaMusicSignal = { 1, 4, 415,
  13, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna te_emlrtBCI_DoaMusicSignal = { 1, 4, 458,
  30, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ue_emlrtBCI_DoaMusicSignal = { 1, 4, 458,
  9, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ve_emlrtBCI_DoaMusicSignal = { 1, 4, 449,
  16, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna we_emlrtBCI_DoaMusicSignal = { 1, 4, 450,
  28, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna xe_emlrtBCI_DoaMusicSignal = { 1, 4, 450,
  9, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ye_emlrtBCI_DoaMusicSignal = { 1, 4, 452,
  26, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna af_emlrtBCI_DoaMusicSignal = { 1, 4, 452,
  9, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna bf_emlrtBCI_DoaMusicSignal = { 1, 4, 453,
  35, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna cf_emlrtBCI_DoaMusicSignal = { 1, 4, 453,
  9, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna df_emlrtBCI_DoaMusicSignal = { 1, 4, 442,
  37, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ef_emlrtBCI_DoaMusicSignal = { 1, 4, 442,
  13, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ff_emlrtBCI_DoaMusicSignal = { 1, 4, 443,
  35, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna gf_emlrtBCI_DoaMusicSignal = { 1, 4, 443,
  13, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna hf_emlrtBCI_DoaMusicSignal = { 1, 4, 425,
  17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna if_emlrtBCI_DoaMusicSignal = { 1, 4, 426,
  17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna jf_emlrtBCI_DoaMusicSignal = { 1, 4, 427,
  17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna kf_emlrtBCI_DoaMusicSignal = { 1, 4, 428,
  17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna lf_emlrtBCI_DoaMusicSignal = { 1, 4, 429,
  17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna mf_emlrtBCI_DoaMusicSignal = { 1, 4, 430,
  17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna nf_emlrtBCI_DoaMusicSignal = { 1, 4, 431,
  17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna of_emlrtBCI_DoaMusicSignal = { 1, 4, 432,
  17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna pf_emlrtBCI_DoaMusicSignal = { 1, 4, 416,
  13, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna qf_emlrtBCI_DoaMusicSignal = { 1, 4, 563,
  14, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna rf_emlrtBCI_DoaMusicSignal = { 1, 4, 563,
  23, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna sf_emlrtBCI_DoaMusicSignal = { 1, 4, 574,
  9, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna tf_emlrtBCI_DoaMusicSignal = { 1, 4, 583,
  36, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna uf_emlrtBCI_DoaMusicSignal = { 1, 4, 583,
  17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna vf_emlrtBCI_DoaMusicSignal = { 1, 4, 584,
  17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna wf_emlrtBCI_DoaMusicSignal = { 1, 4, 564,
  9, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna xf_emlrtBCI_DoaMusicSignal = { 1, 4, 552,
  16, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna yf_emlrtBCI_DoaMusicSignal = { 1, 4, 552,
  5, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ag_emlrtBCI_DoaMusicSignal = { 1, 4, 553,
  16, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna bg_emlrtBCI_DoaMusicSignal = { -1, -1, 25,
  26, "", "applyScalarFunctionInPlace",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\applyScalarFunctionInPlace.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna cg_emlrtBCI_DoaMusicSignal = { -1, -1, 25,
  9, "", "applyScalarFunctionInPlace",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\applyScalarFunctionInPlace.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna dg_emlrtBCI_DoaMusicSignal = { 1, 123,
  401, 13, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna eg_emlrtBCI_DoaMusicSignal = { -1, -1,
  401, 9, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtEqualityCheckInfo_DoaMusicSig t_emlrtECI_DoaMusicSignal = { -1, 413, 11,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtBoundsCheckInfo_DoaMusicSigna fg_emlrtBCI_DoaMusicSignal = { 1, 123,
  412, 12, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna gg_emlrtBCI_DoaMusicSignal = { 1, 123,
  412, 21, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna hg_emlrtBCI_DoaMusicSignal = { 1, 123,
  413, 11, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna ig_emlrtBCI_DoaMusicSignal = { -1, -1,
  413, 7, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna jg_emlrtBCI_DoaMusicSignal = { -1, -1, 23,
  20, "", "flipud",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\elmat\\flipud.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna kg_emlrtBCI_DoaMusicSignal = { -1, -1, 24,
  24, "", "flipud",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\elmat\\flipud.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna lg_emlrtBCI_DoaMusicSignal = { -1, -1, 24,
  13, "", "flipud",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\elmat\\flipud.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna mg_emlrtBCI_DoaMusicSignal = { -1, -1, 25,
  13, "", "flipud",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\elmat\\flipud.m",
  0 };

static rtEqualityCheckInfo_DoaMusicSig u_emlrtECI_DoaMusicSignal = { -1, 526, 7,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m" };

static rtBoundsCheckInfo_DoaMusicSigna ng_emlrtBCI_DoaMusicSignal = { -1, -1,
  530, 7, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna og_emlrtBCI_DoaMusicSignal = { -1, -1,
  531, 8, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna pg_emlrtBCI_DoaMusicSignal = { -1, -1,
  532, 7, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna qg_emlrtBCI_DoaMusicSignal = { -1, -1,
  533, 7, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna rg_emlrtBCI_DoaMusicSignal = { -1, -1,
  578, 18, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna sg_emlrtBCI_DoaMusicSignal = { -1, -1,
  578, 26, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna tg_emlrtBCI_DoaMusicSignal = { -1, -1,
  581, 32, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna ug_emlrtBCI_DoaMusicSignal = { -1, -1,
  581, 40, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna vg_emlrtBCI_DoaMusicSignal = { 1, 123,
  583, 13, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna wg_emlrtBCI_DoaMusicSignal = { 1, 123,
  585, 21, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna xg_emlrtBCI_DoaMusicSignal = { 1, 123,
  585, 30, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna yg_emlrtBCI_DoaMusicSignal = { 1, 123,
  585, 50, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna ah_emlrtBCI_DoaMusicSignal = { -1, -1,
  585, 63, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna bh_emlrtBCI_DoaMusicSignal = { -1, -1,
  585, 71, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna ch_emlrtBCI_DoaMusicSignal = { -1, -1,
  589, 34, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna dh_emlrtBCI_DoaMusicSignal = { -1, -1,
  589, 42, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna eh_emlrtBCI_DoaMusicSignal = { 1, 123,
  591, 14, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna fh_emlrtBCI_DoaMusicSignal = { 1, 123,
  593, 22, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna gh_emlrtBCI_DoaMusicSignal = { 1, 123,
  593, 33, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna hh_emlrtBCI_DoaMusicSignal = { 1, 123,
  593, 57, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna ih_emlrtBCI_DoaMusicSignal = { -1, -1,
  593, 72, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna jh_emlrtBCI_DoaMusicSignal = { -1, -1,
  593, 80, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna kh_emlrtBCI_DoaMusicSignal = { -1, -1,
  597, 10, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna lh_emlrtBCI_DoaMusicSignal = { 1, 123,
  604, 25, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna mh_emlrtBCI_DoaMusicSignal = { -1, -1,
  582, 14, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna nh_emlrtBCI_DoaMusicSignal = { -1, -1,
  583, 15, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna oh_emlrtBCI_DoaMusicSignal = { 1, 123,
  612, 25, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna ph_emlrtBCI_DoaMusicSignal = { -1, -1,
  590, 15, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna qh_emlrtBCI_DoaMusicSignal = { -1, -1,
  591, 16, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna rh_emlrtBCI_DoaMusicSignal = { -1, -1,
  457, 18, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna sh_emlrtBCI_DoaMusicSignal = { -1, -1,
  451, 10, "", "eml_setop",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\lib\\matlab\\ops\\private\\eml_setop.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna th_emlrtBCI_DoaMusicSignal = { -1, -1, 83,
  45, "", "sort",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sort.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna uh_emlrtBCI_DoaMusicSignal = { -1, -1, 83,
  17, "", "sort",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sort.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna vh_emlrtBCI_DoaMusicSignal = { -1, -1, 84,
  47, "", "sort",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sort.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna wh_emlrtBCI_DoaMusicSignal = { -1, -1, 84,
  17, "", "sort",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sort.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna xh_emlrtBCI_DoaMusicSignal = { -1, -1, 78,
  28, "", "sort",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sort.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna yh_emlrtBCI_DoaMusicSignal = { -1, -1, 78,
  17, "", "sort",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sort.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ai_emlrtBCI_DoaMusicSignal = { -1, -1,
  414, 18, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna bi_emlrtBCI_DoaMusicSignal = { -1, -1,
  458, 30, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ci_emlrtBCI_DoaMusicSignal = { -1, -1,
  458, 9, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna di_emlrtBCI_DoaMusicSignal = { -1, -1,
  385, 21, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ei_emlrtBCI_DoaMusicSignal = { -1, -1,
  385, 5, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna fi_emlrtBCI_DoaMusicSignal = { -1, -1,
  386, 23, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna gi_emlrtBCI_DoaMusicSignal = { -1, -1,
  386, 5, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna hi_emlrtBCI_DoaMusicSignal = { -1, -1,
  381, 29, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ii_emlrtBCI_DoaMusicSignal = { -1, -1,
  381, 5, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ji_emlrtBCI_DoaMusicSignal = { -1, -1,
  382, 31, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ki_emlrtBCI_DoaMusicSignal = { -1, -1,
  382, 5, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna li_emlrtBCI_DoaMusicSignal = { -1, -1,
  376, 16, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna mi_emlrtBCI_DoaMusicSignal = { -1, -1,
  376, 5, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ni_emlrtBCI_DoaMusicSignal = { -1, -1,
  377, 16, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna oi_emlrtBCI_DoaMusicSignal = { -1, -1,
  377, 5, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna pi_emlrtBCI_DoaMusicSignal = { -1, -1,
  449, 16, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna qi_emlrtBCI_DoaMusicSignal = { -1, -1,
  450, 28, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ri_emlrtBCI_DoaMusicSignal = { -1, -1,
  450, 9, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna si_emlrtBCI_DoaMusicSignal = { -1, -1,
  451, 9, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ti_emlrtBCI_DoaMusicSignal = { -1, -1,
  452, 26, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ui_emlrtBCI_DoaMusicSignal = { -1, -1,
  452, 9, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna vi_emlrtBCI_DoaMusicSignal = { -1, -1,
  453, 35, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna wi_emlrtBCI_DoaMusicSignal = { -1, -1,
  453, 9, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna xi_emlrtBCI_DoaMusicSignal = { -1, -1,
  442, 13, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna yi_emlrtBCI_DoaMusicSignal = { -1, -1,
  443, 13, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna aj_emlrtBCI_DoaMusicSignal = { -1, -1,
  421, 22, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna bj_emlrtBCI_DoaMusicSignal = { -1, -1,
  425, 17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna cj_emlrtBCI_DoaMusicSignal = { -1, -1,
  426, 17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna dj_emlrtBCI_DoaMusicSignal = { -1, -1,
  427, 17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ej_emlrtBCI_DoaMusicSignal = { -1, -1,
  428, 17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna fj_emlrtBCI_DoaMusicSignal = { -1, -1,
  429, 17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna gj_emlrtBCI_DoaMusicSignal = { -1, -1,
  430, 17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna hj_emlrtBCI_DoaMusicSignal = { -1, -1,
  431, 17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ij_emlrtBCI_DoaMusicSignal = { -1, -1,
  432, 17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna jj_emlrtBCI_DoaMusicSignal = { -1, -1,
  415, 13, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna kj_emlrtBCI_DoaMusicSignal = { -1, -1,
  416, 32, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna lj_emlrtBCI_DoaMusicSignal = { -1, -1,
  416, 13, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna mj_emlrtBCI_DoaMusicSignal = { -1, -1,
  563, 14, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna nj_emlrtBCI_DoaMusicSignal = { -1, -1,
  563, 23, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna oj_emlrtBCI_DoaMusicSignal = { -1, -1,
  574, 21, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna pj_emlrtBCI_DoaMusicSignal = { -1, -1,
  574, 9, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna qj_emlrtBCI_DoaMusicSignal = { -1, -1,
  575, 19, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna rj_emlrtBCI_DoaMusicSignal = { -1, -1,
  575, 9, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna sj_emlrtBCI_DoaMusicSignal = { -1, -1,
  583, 36, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna tj_emlrtBCI_DoaMusicSignal = { -1, -1,
  583, 17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna uj_emlrtBCI_DoaMusicSignal = { -1, -1,
  584, 34, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna vj_emlrtBCI_DoaMusicSignal = { -1, -1,
  584, 17, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna wj_emlrtBCI_DoaMusicSignal = { -1, -1,
  564, 21, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna xj_emlrtBCI_DoaMusicSignal = { -1, -1,
  564, 9, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna yj_emlrtBCI_DoaMusicSignal = { -1, -1,
  565, 19, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ak_emlrtBCI_DoaMusicSignal = { -1, -1,
  565, 9, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna bk_emlrtBCI_DoaMusicSignal = { -1, -1,
  552, 16, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ck_emlrtBCI_DoaMusicSignal = { -1, -1,
  552, 5, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna dk_emlrtBCI_DoaMusicSignal = { -1, -1,
  553, 16, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna ek_emlrtBCI_DoaMusicSignal = { -1, -1,
  553, 5, "", "sortIdx",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\eml\\eml\\+coder\\+internal\\sortIdx.m",
  0 };

static rtBoundsCheckInfo_DoaMusicSigna fk_emlrtBCI_DoaMusicSignal = { -1, -1,
  776, 9, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtDoubleCheckInfo_DoaMusicSigna b_emlrtDCI_DoaMusicSignal = { 776, 9,
  "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 1 };

static rtBoundsCheckInfo_DoaMusicSigna gk_emlrtBCI_DoaMusicSignal = { -1, -1,
  781, 7, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna hk_emlrtBCI_DoaMusicSignal = { -1, -1,
  782, 8, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna ik_emlrtBCI_DoaMusicSignal = { -1, -1,
  783, 8, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

static rtBoundsCheckInfo_DoaMusicSigna jk_emlrtBCI_DoaMusicSignal = { -1, -1,
  784, 8, "", "findpeaks",
  "D:\\Program Files\\MATLAB\\R2016a\\toolbox\\signal\\signal\\findpeaks.m", 0 };

/* Function Declarations */
static void assignFullOutputs(const double y[123], const double iPk_data[],
  const int iPk_size[1], const double wxPk_data[], const int wxPk_size[2], const
  double bPk_data[], const int bPk_size[1], double YpkOut_data[], int
  YpkOut_size[2], double XpkOut_data[], int XpkOut_size[2], double WpkOut_data[],
  int WpkOut_size[2], double PpkOut_data[], int PpkOut_size[2]);
static void b_abs(const creal_T x[4], double y[4]);
static void b_diff(const double x_data[], const int x_size[2], double y_data[],
                   int y_size[1]);
static boolean_T b_dimagree(const int z_size[1], const int varargin_2_size[1]);
static void b_do_vectors(const double a_data[], const int a_size[1], const
  double b_data[], const int b_size[1], double c_data[], int c_size[1], int
  ia_data[], int ia_size[1], int ib_data[], int ib_size[1]);
static void b_error(void);
static void b_merge(int idx_data[], int idx_size[1], double x_data[], int
                    x_size[1], int offset, int np, int nq, int iwork_data[], int
                    iwork_size[1], double xwork_data[], int xwork_size[1]);
static void b_merge_block(int idx_data[], int idx_size[1], double x_data[], int
  x_size[1], int n, int iwork_data[], int iwork_size[1], double xwork_data[],
  int xwork_size[1]);
static void b_rtErrorWithMessageID(const int b, const char *c, const
  rtRunTimeErrorInfo_DoaMusicSign *aInfo);
static void b_sign(double x_data[], int x_size[1]);
static void b_sort(double x[4], int idx[4]);
static void b_sortIdx(double x_data[], int x_size[1], int idx_data[], int
                      idx_size[1]);
static void b_sqrt(creal_T *x);
static void b_sum(const creal_T x[484], creal_T y[121]);
static void b_xzlartg(const creal_T f, const creal_T g, double *cs, creal_T *sn);
static void c_abs(const creal_T x[121], double y[121]);
static boolean_T c_dimagree(const int z_size[1], const int varargin_1_size[1]);
static void c_error(void);
static void c_findPeaksSeparatedByMoreThanM(const double y[123], const double
  iPk_data[], const int iPk_size[1], double Pd, double idx_data[], int idx_size
  [1]);
static void c_merge(int idx_data[], int idx_size[1], double x_data[], int
                    x_size[1], int offset, int np, int nq, int iwork_data[], int
                    iwork_size[1], double xwork_data[], int xwork_size[1]);
static void c_removePeaksBelowMinPeakPromin(const double y[123], double
  iPk_data[], int iPk_size[1], double pbPk_data[], int pbPk_size[1], double
  iLB_data[], int iLB_size[1], double iRB_data[], int iRB_size[1]);
static void c_rtErrorWithMessageID(const int b, const char *c, const
  rtRunTimeErrorInfo_DoaMusicSign *aInfo);
static void c_sort(double x_data[], int x_size[1], int idx_data[], int idx_size
                   [1]);
static double c_sum(const boolean_T x_data[], const int x_size[2]);
static void check_forloop_overflow_error(void);
static void combineFullPeaks(const double y[123], const double iPk_data[], const
  int iPk_size[1], const double bPk_data[], const int bPk_size[1], const double
  iLBw_data[], const int iLBw_size[1], const double iRBw_data[], const int
  iRBw_size[1], const double wPk_data[], const int wPk_size[2], const double
  iInf_data[], const int iInf_size[1], double iPkOut_data[], int iPkOut_size[1],
  double bPkOut_data[], int bPkOut_size[1], double bxPkOut_data[], int
  bxPkOut_size[2], double byPkOut_data[], int byPkOut_size[2], double
  wxPkOut_data[], int wxPkOut_size[2]);
static void d_error(void);
static void d_rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo);
static void d_sort(double x_data[], int x_size[1], int dim, int idx_data[], int
                   idx_size[1]);
static void diff(const double x_data[], const int x_size[1], double y_data[],
                 int y_size[1]);
static boolean_T dimagree(const int z_size[1], const int varargin_1_size[1],
  const int varargin_2_size[1]);
static void do_vectors(const double a_data[], const int a_size[1], const double
  b_data[], const int b_size[1], double c_data[], int c_size[1], int ia_data[],
  int ia_size[1], int ib_data[], int ib_size[1]);
static void e_rtErrorWithMessageID(const int b, const char *c, const
  rtRunTimeErrorInfo_DoaMusicSign *aInfo);
static void e_sort(double x_data[], int x_size[1]);
static void eig(const creal_T A[16], creal_T V[16], creal_T D[4]);
static void error(void);
static void f_rtErrorWithMessageID(const int b, const char *c, const
  rtRunTimeErrorInfo_DoaMusicSign *aInfo);
static void fetchPeakExtents(const double idx_data[], const int idx_size[1],
  double bPk_data[], int bPk_size[1], double bxPk_data[], int bxPk_size[2],
  double byPk_data[], int byPk_size[2], double wxPk_data[], int wxPk_size[2]);
static void findExtents(const double y[123], double iPk_data[], int iPk_size[1],
  const double iFin_data[], const int iFin_size[1], const double iInf_data[],
  const int iInf_size[1], const double iInflect_data[], const int iInflect_size
  [1], double bPk_data[], int bPk_size[1], double bxPk_data[], int bxPk_size[2],
  double byPk_data[], int byPk_size[2], double wxPk_data[], int wxPk_size[2]);
static void findLocalMaxima(const double yTemp[123], double iPk_data[], int
  iPk_size[1], double iInflect_data[], int iInflect_size[1]);
static void findpeaks(const double Yin[123], double varargin_2, double
                      varargin_8, double Ypk_data[], int Ypk_size[2], double
                      Xpk_data[], int Xpk_size[2]);
static void flipud(double x_data[], int x_size[1]);
static void g_rtErrorWithMessageID(const int b, const char *c, const
  rtRunTimeErrorInfo_DoaMusicSign *aInfo);
static void getAllPeaks(const double y[123], double iPk_data[], int iPk_size[1],
  double iInf_data[], int iInf_size[1], double iInflect_data[], int
  iInflect_size[1]);
static void getLeftBase(const double yTemp[123], const double iPeak_data[],
  const int iPeak_size[1], const double iFinite_data[], const int iFinite_size[1],
  const double iInflect_data[], const int iInflect_size[1], double iBase_data[],
  int iBase_size[1], double iSaddle_data[], int iSaddle_size[1]);
static void getPeakBase(const double yTemp[123], const double iPk_data[], const
  int iPk_size[1], const double iFin_data[], const int iFin_size[1], const
  double iInflect_data[], const int iInflect_size[1], double peakBase_data[],
  int peakBase_size[1], double iLeftSaddle_data[], int iLeftSaddle_size[1],
  double iRightSaddle_data[], int iRightSaddle_size[1]);
static void getPeakWidth(const double y[123], const double iPk_data[], const int
  iPk_size[1], const double pbPk_data[], const int pbPk_size[1], double
  iLB_data[], int iLB_size[1], double iRB_data[], int iRB_size[1], double
  wxPk_data[], int wxPk_size[2]);
static void h_rtErrorWithMessageID(const int b, const char *c, const
  rtRunTimeErrorInfo_DoaMusicSign *aInfo);
static void i_rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo);
static void indexShapeCheck(int matrixSize, const int indexSize[2]);
static boolean_T issorted(const double x_data[], const int x_size[1]);
static void j_rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo);
static void k_rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo);
static void keepAtMostNpPeaks(int idx_size[1], double Np);
static void l_rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo);
static void m_rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo);
static void merge(int idx[4], double x[4], int offset, int np, int nq, int
                  iwork[4], double xwork[4]);
static void merge_block(int idx_data[], int idx_size[1], double x_data[], int
  x_size[1], int n, int iwork_data[], int iwork_size[1], double xwork_data[],
  int xwork_size[1]);
static void n_rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo);
static int nonSingletonDim(const int x_size[1]);
static void o_rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo);
static void parse_inputs(const double Yin[123], double varargin_2, double
  varargin_8, double y[123], double *Pd, double *NpOut);
static void pow2db(const double y[121], double ydB[121]);
static void removePeaksBelowMinPeakHeight(const double Y[123], double iPk_data[],
  int iPk_size[1]);
static void removePeaksBelowThreshold(const double Y[123], double iPk_data[],
  int iPk_size[1]);
static void rtAddSizeString(char * aBuf, const int aDim);
static void rtDynamicBoundsError(int aIndexValue, int aLoBound, int aHiBound,
  const rtBoundsCheckInfo_DoaMusicSigna *aInfo);
static void rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo);
static void rtGenSizeString(const int aNDims, const int *aDims, char *aBuf);
static void rtIntegerError(const double aInteger, const
  rtDoubleCheckInfo_DoaMusicSigna *aInfo);
static boolean_T rtIsNullOrEmptyString(const char *aString);
static void rtReportErrorLocation(const char * aFcnName, const int aLineNo);
static void rtSizeEq1DError(const int aDim1, const int aDim2, const
  rtEqualityCheckInfo_DoaMusicSig *aInfo);
static void rtSubAssignSizeCheck(const int *aDims1, const int aNDims1, const int
  *aDims2, const int aNDims2, const rtEqualityCheckInfo_DoaMusicSig *aInfo);
static double rt_hypotd_snf(double u0, double u1);
static double skip_to_last_equal_value(int *k, const double x_data[], const int
  x_size[1]);
static void sort(double x[4], int idx[4]);
static void sortIdx(double x_data[], int x_size[1], int idx_data[], int
                    idx_size[1]);
static double sum(const double x[4]);
static void xzggbal(creal_T A[16], int *ilo, int *ihi, int rscale[4]);
static void xzggev(creal_T A[16], int *info, creal_T alpha1[4], creal_T beta1[4],
                   creal_T V[16]);
static void xzhgeqz(creal_T A[16], int ilo, int ihi, creal_T Z[16], int *info,
                    creal_T alpha1[4], creal_T beta1[4]);
static void xzlartg(const creal_T f, const creal_T g, double *cs, creal_T *sn,
                    creal_T *r);
static void xztgevc(const creal_T A[16], creal_T V[16]);

/* Function Definitions */

/*
 * Arguments    : const double y[123]
 *                const double iPk_data[]
 *                const int iPk_size[1]
 *                const double wxPk_data[]
 *                const int wxPk_size[2]
 *                const double bPk_data[]
 *                const int bPk_size[1]
 *                double YpkOut_data[]
 *                int YpkOut_size[2]
 *                double XpkOut_data[]
 *                int XpkOut_size[2]
 *                double WpkOut_data[]
 *                int WpkOut_size[2]
 *                double PpkOut_data[]
 *                int PpkOut_size[2]
 * Return Type  : void
 */
static void assignFullOutputs(const double y[123], const double iPk_data[],
  const int iPk_size[1], const double wxPk_data[], const int wxPk_size[2], const
  double bPk_data[], const int bPk_size[1], double YpkOut_data[], int
  YpkOut_size[2], double XpkOut_data[], int XpkOut_size[2], double WpkOut_data[],
  int WpkOut_size[2], double PpkOut_data[], int PpkOut_size[2])
{
  int loop_ub;
  int i13;
  double Wpk_data[246];
  int Wpk_size[1];
  int i14;
  double Ypk_data[246];
  loop_ub = iPk_size[0];
  for (i13 = 0; i13 < loop_ub; i13++) {
    i14 = (int)iPk_data[i13];
    if (!((i14 >= 1) && (i14 <= 123))) {
      rtDynamicBoundsError(i14, 1, 123, &md_emlrtBCI_DoaMusicSignal);
    }

    Ypk_data[i13] = y[i14 - 1];
  }

  b_diff(wxPk_data, wxPk_size, Wpk_data, Wpk_size);
  if (iPk_size[0] != bPk_size[0]) {
    rtSizeEq1DError(iPk_size[0], bPk_size[0], &s_emlrtECI_DoaMusicSignal);
  }

  YpkOut_size[0] = 1;
  YpkOut_size[1] = iPk_size[0];
  loop_ub = iPk_size[0];
  for (i13 = 0; i13 < loop_ub; i13++) {
    YpkOut_data[i13] = Ypk_data[i13];
  }

  PpkOut_size[0] = 1;
  PpkOut_size[1] = iPk_size[0];
  loop_ub = iPk_size[0];
  for (i13 = 0; i13 < loop_ub; i13++) {
    PpkOut_data[i13] = Ypk_data[i13] - bPk_data[i13];
  }

  XpkOut_size[0] = 1;
  XpkOut_size[1] = iPk_size[0];
  loop_ub = iPk_size[0];
  for (i13 = 0; i13 < loop_ub; i13++) {
    XpkOut_data[i13] = 1.0 + (double)((int)iPk_data[i13] - 1);
  }

  WpkOut_size[0] = 1;
  WpkOut_size[1] = Wpk_size[0];
  loop_ub = Wpk_size[0];
  for (i13 = 0; i13 < loop_ub; i13++) {
    WpkOut_data[i13] = Wpk_data[i13];
  }
}

/*
 * Arguments    : const creal_T x[4]
 *                double y[4]
 * Return Type  : void
 */
static void b_abs(const creal_T x[4], double y[4])
{
  int k;
  for (k = 0; k < 4; k++) {
    y[k] = rt_hypotd_snf(x[k].re, x[k].im);
  }
}

/*
 * Arguments    : const double x_data[]
 *                const int x_size[2]
 *                double y_data[]
 *                int y_size[1]
 * Return Type  : void
 */
static void b_diff(const double x_data[], const int x_size[2], double y_data[],
                   int y_size[1])
{
  int stride;
  int ix;
  int iy;
  int s;
  int i15;
  int i16;
  y_size[0] = (unsigned char)x_size[0];
  if (!((unsigned char)x_size[0] == 0)) {
    stride = x_size[0];
    ix = 1;
    iy = 1;
    for (s = 1; s <= stride; s++) {
      i15 = x_size[0] << 1;
      if (!((ix >= 1) && (ix <= i15))) {
        rtDynamicBoundsError(ix, 1, i15, &nd_emlrtBCI_DoaMusicSignal);
      }

      i15 = x_size[0] << 1;
      i16 = ix + stride;
      if (!((i16 >= 1) && (i16 <= i15))) {
        rtDynamicBoundsError(i16, 1, i15, &m_emlrtBCI_DoaMusicSignal);
      }

      if (!((iy >= 1) && (iy <= y_size[0]))) {
        rtDynamicBoundsError(iy, 1, y_size[0], &n_emlrtBCI_DoaMusicSignal);
      }

      y_data[iy - 1] = x_data[(ix + stride) - 1] - x_data[ix - 1];
      ix++;
      iy++;
    }
  }
}

/*
 * Arguments    : const int z_size[1]
 *                const int varargin_2_size[1]
 * Return Type  : boolean_T
 */
static boolean_T b_dimagree(const int z_size[1], const int varargin_2_size[1])
{
  boolean_T p;
  boolean_T b_p;
  int k;
  boolean_T exitg1;
  int b_k;
  int c_k;
  p = true;
  b_p = true;
  k = 1;
  exitg1 = false;
  while ((!exitg1) && (k < 3)) {
    if (k <= 1) {
      b_k = z_size[0];
    } else {
      b_k = 1;
    }

    if (k <= 1) {
      c_k = varargin_2_size[0];
    } else {
      c_k = 1;
    }

    if (b_k != c_k) {
      b_p = false;
      exitg1 = true;
    } else {
      k++;
    }
  }

  if (b_p) {
  } else {
    p = false;
  }

  return p;
}

/*
 * Arguments    : const double a_data[]
 *                const int a_size[1]
 *                const double b_data[]
 *                const int b_size[1]
 *                double c_data[]
 *                int c_size[1]
 *                int ia_data[]
 *                int ia_size[1]
 *                int ib_data[]
 *                int ib_size[1]
 * Return Type  : void
 */
static void b_do_vectors(const double a_data[], const int a_size[1], const
  double b_data[], const int b_size[1], double c_data[], int c_size[1], int
  ia_data[], int ia_size[1], int ib_data[], int ib_size[1])
{
  int ncmax;
  int nc;
  int iafirst;
  int ialast;
  int ibfirst;
  int iblast;
  int b_ialast;
  double ak;
  int b_iblast;
  double bk;
  int b_ia_data[123];
  double absxk;
  int exponent;
  double b_c_data[123];
  boolean_T p;
  if (a_size[0] <= b_size[0]) {
    ncmax = a_size[0];
  } else {
    ncmax = b_size[0];
  }

  c_size[0] = (signed char)ncmax;
  ia_size[0] = ncmax;
  ib_size[0] = ncmax;
  if (!issorted(a_data, a_size)) {
    c_error();
  }

  if (!issorted(b_data, b_size)) {
    d_error();
  }

  nc = 0;
  iafirst = 0;
  ialast = 1;
  ibfirst = 0;
  iblast = 1;
  while ((ialast <= a_size[0]) && (iblast <= b_size[0])) {
    b_ialast = ialast;
    ak = skip_to_last_equal_value(&b_ialast, a_data, a_size);
    ialast = b_ialast;
    b_iblast = iblast;
    bk = skip_to_last_equal_value(&b_iblast, b_data, b_size);
    iblast = b_iblast;
    absxk = fabs(bk / 2.0);
    if ((!rtIsInf(absxk)) && (!rtIsNaN(absxk))) {
      if (absxk <= 2.2250738585072014E-308) {
        absxk = 4.94065645841247E-324;
      } else {
        frexp(absxk, &exponent);
        absxk = ldexp(1.0, exponent - 53);
      }
    } else {
      absxk = rtNaN;
    }

    if ((fabs(bk - ak) < absxk) || (rtIsInf(ak) && rtIsInf(bk) && ((ak > 0.0) ==
          (bk > 0.0)))) {
      p = true;
    } else {
      p = false;
    }

    if (p) {
      nc++;
      iblast = (signed char)ncmax;
      if (!((nc >= 1) && (nc <= iblast))) {
        rtDynamicBoundsError(nc, 1, iblast, &yc_emlrtBCI_DoaMusicSignal);
      }

      c_data[nc - 1] = ak;
      if (!((nc >= 1) && (nc <= ncmax))) {
        rtDynamicBoundsError(nc, 1, ncmax, &ad_emlrtBCI_DoaMusicSignal);
      }

      ia_data[nc - 1] = iafirst + 1;
      if (!((nc >= 1) && (nc <= ncmax))) {
        rtDynamicBoundsError(nc, 1, ncmax, &bd_emlrtBCI_DoaMusicSignal);
      }

      ib_data[nc - 1] = ibfirst + 1;
      ialast = b_ialast + 1;
      iafirst = b_ialast;
      iblast = b_iblast + 1;
      ibfirst = b_iblast;
    } else {
      if ((ak < bk) || rtIsNaN(bk)) {
        p = true;
      } else {
        p = false;
      }

      if (p) {
        ialast = b_ialast + 1;
        iafirst = b_ialast;
      } else {
        iblast = b_iblast + 1;
        ibfirst = b_iblast;
      }
    }
  }

  if (ncmax > 0) {
    if (nc <= ncmax) {
    } else {
      j_rtErrorWithMessageID(&m_emlrtRTEI_DoaMusicSignal);
    }

    if (1 > nc) {
      ialast = 0;
    } else {
      if (!(nc <= ncmax)) {
        rtDynamicBoundsError(nc, 1, ncmax, &jc_emlrtBCI_DoaMusicSignal);
      }

      ialast = nc;
    }

    for (iblast = 0; iblast < ialast; iblast++) {
      b_ia_data[iblast] = ia_data[iblast];
    }

    ia_size[0] = ialast;
    for (iblast = 0; iblast < ialast; iblast++) {
      ia_data[iblast] = b_ia_data[iblast];
    }
  }

  if (ncmax > 0) {
    if (nc <= ncmax) {
    } else {
      j_rtErrorWithMessageID(&n_emlrtRTEI_DoaMusicSignal);
    }

    if (1 > nc) {
      ialast = 0;
    } else {
      if (!(nc <= ncmax)) {
        rtDynamicBoundsError(nc, 1, ncmax, &kc_emlrtBCI_DoaMusicSignal);
      }

      ialast = nc;
    }

    for (iblast = 0; iblast < ialast; iblast++) {
      b_ia_data[iblast] = ib_data[iblast];
    }

    ib_size[0] = ialast;
    for (iblast = 0; iblast < ialast; iblast++) {
      ib_data[iblast] = b_ia_data[iblast];
    }
  }

  if (ncmax > 0) {
    if (nc <= ncmax) {
    } else {
      j_rtErrorWithMessageID(&o_emlrtRTEI_DoaMusicSignal);
    }

    if (1 > nc) {
      nc = 0;
    } else {
      iblast = (signed char)ncmax;
      if (!(1 <= iblast)) {
        rtDynamicBoundsError(1, 1, iblast, &lc_emlrtBCI_DoaMusicSignal);
      }

      iblast = (signed char)ncmax;
      if (!(nc <= iblast)) {
        rtDynamicBoundsError(nc, 1, iblast, &lc_emlrtBCI_DoaMusicSignal);
      }
    }

    for (iblast = 0; iblast < nc; iblast++) {
      b_c_data[iblast] = c_data[iblast];
    }

    c_size[0] = nc;
    for (iblast = 0; iblast < nc; iblast++) {
      c_data[iblast] = b_c_data[iblast];
    }
  }
}

/*
 * Arguments    : void
 * Return Type  : void
 */
static void b_error(void)
{
  b_rtErrorWithMessageID(5, "log10", &b_emlrtRTEI_DoaMusicSignal);
}

/*
 * Arguments    : int idx_data[]
 *                int idx_size[1]
 *                double x_data[]
 *                int x_size[1]
 *                int offset
 *                int np
 *                int nq
 *                int iwork_data[]
 *                int iwork_size[1]
 *                double xwork_data[]
 *                int xwork_size[1]
 * Return Type  : void
 */
static void b_merge(int idx_data[], int idx_size[1], double x_data[], int
                    x_size[1], int offset, int np, int nq, int iwork_data[], int
                    iwork_size[1], double xwork_data[], int xwork_size[1])
{
  int n;
  int qend;
  int p;
  int i32;
  int iout;
  int exitg1;
  if (nq == 0) {
  } else {
    n = np + nq;
    if ((!(1 > n)) && (n > 2147483646)) {
      check_forloop_overflow_error();
    }

    for (qend = 1; qend <= n; qend++) {
      i32 = idx_size[0];
      iout = offset + qend;
      if (!((iout >= 1) && (iout <= i32))) {
        rtDynamicBoundsError(iout, 1, i32, &bk_emlrtBCI_DoaMusicSignal);
      }

      i32 = iwork_size[0];
      if (!((qend >= 1) && (qend <= i32))) {
        rtDynamicBoundsError(qend, 1, i32, &ck_emlrtBCI_DoaMusicSignal);
      }

      iwork_data[qend - 1] = idx_data[iout - 1];
      i32 = x_size[0];
      iout = offset + qend;
      if (!((iout >= 1) && (iout <= i32))) {
        rtDynamicBoundsError(iout, 1, i32, &dk_emlrtBCI_DoaMusicSignal);
      }

      i32 = xwork_size[0];
      if (!((qend >= 1) && (qend <= i32))) {
        rtDynamicBoundsError(qend, 1, i32, &ek_emlrtBCI_DoaMusicSignal);
      }

      xwork_data[qend - 1] = x_data[iout - 1];
    }

    p = 1;
    n = np + 1;
    qend = np + nq;
    iout = offset;
    do {
      exitg1 = 0;
      iout++;
      i32 = xwork_size[0];
      if (!((p >= 1) && (p <= i32))) {
        rtDynamicBoundsError(p, 1, i32, &mj_emlrtBCI_DoaMusicSignal);
      }

      i32 = xwork_size[0];
      if (!((n >= 1) && (n <= i32))) {
        rtDynamicBoundsError(n, 1, i32, &nj_emlrtBCI_DoaMusicSignal);
      }

      if (xwork_data[p - 1] >= xwork_data[n - 1]) {
        i32 = iwork_size[0];
        if (!((p >= 1) && (p <= i32))) {
          rtDynamicBoundsError(p, 1, i32, &wj_emlrtBCI_DoaMusicSignal);
        }

        i32 = idx_size[0];
        if (!((iout >= 1) && (iout <= i32))) {
          rtDynamicBoundsError(iout, 1, i32, &xj_emlrtBCI_DoaMusicSignal);
        }

        idx_data[iout - 1] = iwork_data[p - 1];
        i32 = xwork_size[0];
        if (!((p >= 1) && (p <= i32))) {
          rtDynamicBoundsError(p, 1, i32, &yj_emlrtBCI_DoaMusicSignal);
        }

        i32 = x_size[0];
        if (!((iout >= 1) && (iout <= i32))) {
          rtDynamicBoundsError(iout, 1, i32, &ak_emlrtBCI_DoaMusicSignal);
        }

        x_data[iout - 1] = xwork_data[p - 1];
        if (p < np) {
          p++;
        } else {
          exitg1 = 1;
        }
      } else {
        i32 = iwork_size[0];
        if (!((n >= 1) && (n <= i32))) {
          rtDynamicBoundsError(n, 1, i32, &oj_emlrtBCI_DoaMusicSignal);
        }

        i32 = idx_size[0];
        if (!((iout >= 1) && (iout <= i32))) {
          rtDynamicBoundsError(iout, 1, i32, &pj_emlrtBCI_DoaMusicSignal);
        }

        idx_data[iout - 1] = iwork_data[n - 1];
        i32 = xwork_size[0];
        if (!((n >= 1) && (n <= i32))) {
          rtDynamicBoundsError(n, 1, i32, &qj_emlrtBCI_DoaMusicSignal);
        }

        i32 = x_size[0];
        if (!((iout >= 1) && (iout <= i32))) {
          rtDynamicBoundsError(iout, 1, i32, &rj_emlrtBCI_DoaMusicSignal);
        }

        x_data[iout - 1] = xwork_data[n - 1];
        if (n < qend) {
          n++;
        } else {
          n = (iout - p) + 1;
          if ((!(p > np)) && (np > 2147483646)) {
            check_forloop_overflow_error();
          }

          while (p <= np) {
            i32 = iwork_size[0];
            if (!((p >= 1) && (p <= i32))) {
              rtDynamicBoundsError(p, 1, i32, &sj_emlrtBCI_DoaMusicSignal);
            }

            i32 = idx_size[0];
            iout = n + p;
            if (!((iout >= 1) && (iout <= i32))) {
              rtDynamicBoundsError(iout, 1, i32, &tj_emlrtBCI_DoaMusicSignal);
            }

            idx_data[iout - 1] = iwork_data[p - 1];
            i32 = xwork_size[0];
            if (!((p >= 1) && (p <= i32))) {
              rtDynamicBoundsError(p, 1, i32, &uj_emlrtBCI_DoaMusicSignal);
            }

            i32 = x_size[0];
            iout = n + p;
            if (!((iout >= 1) && (iout <= i32))) {
              rtDynamicBoundsError(iout, 1, i32, &vj_emlrtBCI_DoaMusicSignal);
            }

            x_data[iout - 1] = xwork_data[p - 1];
            p++;
          }

          exitg1 = 1;
        }
      }
    } while (exitg1 == 0);
  }
}

/*
 * Arguments    : int idx_data[]
 *                int idx_size[1]
 *                double x_data[]
 *                int x_size[1]
 *                int n
 *                int iwork_data[]
 *                int iwork_size[1]
 *                double xwork_data[]
 *                int xwork_size[1]
 * Return Type  : void
 */
static void b_merge_block(int idx_data[], int idx_size[1], double x_data[], int
  x_size[1], int n, int iwork_data[], int iwork_size[1], double xwork_data[],
  int xwork_size[1])
{
  int nPairs;
  int bLen;
  int tailOffset;
  int nTail;
  nPairs = n >> 2;
  bLen = 4;
  while (nPairs > 1) {
    if ((nPairs & 1) != 0) {
      nPairs--;
      tailOffset = bLen * nPairs;
      nTail = n - tailOffset;
      if (nTail > bLen) {
        c_merge(idx_data, idx_size, x_data, x_size, tailOffset, bLen, nTail -
                bLen, iwork_data, iwork_size, xwork_data, xwork_size);
      }
    }

    tailOffset = bLen << 1;
    nPairs >>= 1;
    for (nTail = 1; nTail <= nPairs; nTail++) {
      c_merge(idx_data, idx_size, x_data, x_size, (nTail - 1) * tailOffset, bLen,
              bLen, iwork_data, iwork_size, xwork_data, xwork_size);
    }

    bLen = tailOffset;
  }

  if (n > bLen) {
    c_merge(idx_data, idx_size, x_data, x_size, 0, bLen, n - bLen, iwork_data,
            iwork_size, xwork_data, xwork_size);
  }
}

/*
 * Arguments    : const int b
 *                const char *c
 *                const rtRunTimeErrorInfo_DoaMusicSign *aInfo
 * Return Type  : void
 */
static void b_rtErrorWithMessageID(const int b, const char *c, const
  rtRunTimeErrorInfo_DoaMusicSign *aInfo)
{
  fprintf(stderr,
          "Domain error. To compute complex results from real x, use \'%.*s(complex(x))\'.",
          b, c);
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : double x_data[]
 *                int x_size[1]
 * Return Type  : void
 */
static void b_sign(double x_data[], int x_size[1])
{
  int nx;
  int k;
  int i17;
  nx = x_size[0];
  for (k = 0; k + 1 <= nx; k++) {
    i17 = x_size[0];
    if (!((k + 1 >= 1) && (k + 1 <= i17))) {
      rtDynamicBoundsError(k + 1, 1, i17, &bg_emlrtBCI_DoaMusicSignal);
    }

    i17 = x_size[0];
    if (!((k + 1 >= 1) && (k + 1 <= i17))) {
      rtDynamicBoundsError(k + 1, 1, i17, &cg_emlrtBCI_DoaMusicSignal);
    }

    if (x_data[k] < 0.0) {
      x_data[k] = -1.0;
    } else if (x_data[k] > 0.0) {
      x_data[k] = 1.0;
    } else {
      if (x_data[k] == 0.0) {
        x_data[k] = 0.0;
      }
    }
  }
}

/*
 * Arguments    : double x[4]
 *                int idx[4]
 * Return Type  : void
 */
static void b_sort(double x[4], int idx[4])
{
  double x4[4];
  int idx4[4];
  double xwork[4];
  int m;
  int nNaNs;
  int ib;
  int k;
  signed char perm[4];
  int nPairs;
  int quartetOffset;
  int bLen;
  for (m = 0; m < 4; m++) {
    idx[m] = 0;
    x4[m] = 0.0;
    idx4[m] = 0;
    xwork[m] = 0.0;
  }

  nNaNs = 0;
  ib = 0;
  for (k = 0; k < 4; k++) {
    if (rtIsNaN(x[k])) {
      nPairs = 4 - nNaNs;
      if (!((nPairs >= 1) && (nPairs <= 4))) {
        rtDynamicBoundsError(nPairs, 1, 4, &se_emlrtBCI_DoaMusicSignal);
      }

      idx[nPairs - 1] = k + 1;
      nPairs = 4 - nNaNs;
      if (!((nPairs >= 1) && (nPairs <= 4))) {
        rtDynamicBoundsError(nPairs, 1, 4, &pf_emlrtBCI_DoaMusicSignal);
      }

      xwork[nPairs - 1] = x[k];
      nNaNs++;
    } else {
      ib++;
      idx4[ib - 1] = k + 1;
      x4[ib - 1] = x[k];
      if (ib == 4) {
        quartetOffset = k - nNaNs;
        if (x4[0] <= x4[1]) {
          ib = 1;
          m = 2;
        } else {
          ib = 2;
          m = 1;
        }

        if (x4[2] <= x4[3]) {
          bLen = 3;
          nPairs = 4;
        } else {
          bLen = 4;
          nPairs = 3;
        }

        if (x4[ib - 1] <= x4[bLen - 1]) {
          if (x4[m - 1] <= x4[bLen - 1]) {
            perm[0] = (signed char)ib;
            perm[1] = (signed char)m;
            perm[2] = (signed char)bLen;
            perm[3] = (signed char)nPairs;
          } else if (x4[m - 1] <= x4[nPairs - 1]) {
            perm[0] = (signed char)ib;
            perm[1] = (signed char)bLen;
            perm[2] = (signed char)m;
            perm[3] = (signed char)nPairs;
          } else {
            perm[0] = (signed char)ib;
            perm[1] = (signed char)bLen;
            perm[2] = (signed char)nPairs;
            perm[3] = (signed char)m;
          }
        } else if (x4[ib - 1] <= x4[nPairs - 1]) {
          if (x4[m - 1] <= x4[nPairs - 1]) {
            perm[0] = (signed char)bLen;
            perm[1] = (signed char)ib;
            perm[2] = (signed char)m;
            perm[3] = (signed char)nPairs;
          } else {
            perm[0] = (signed char)bLen;
            perm[1] = (signed char)ib;
            perm[2] = (signed char)nPairs;
            perm[3] = (signed char)m;
          }
        } else {
          perm[0] = (signed char)bLen;
          perm[1] = (signed char)nPairs;
          perm[2] = (signed char)ib;
          perm[3] = (signed char)m;
        }

        nPairs = quartetOffset - 2;
        if (!((nPairs >= 1) && (nPairs <= 4))) {
          rtDynamicBoundsError(nPairs, 1, 4, &hf_emlrtBCI_DoaMusicSignal);
        }

        idx[nPairs - 1] = idx4[perm[0] - 1];
        nPairs = quartetOffset - 1;
        if (!((nPairs >= 1) && (nPairs <= 4))) {
          rtDynamicBoundsError(nPairs, 1, 4, &if_emlrtBCI_DoaMusicSignal);
        }

        idx[nPairs - 1] = idx4[perm[1] - 1];
        if (!((quartetOffset >= 1) && (quartetOffset <= 4))) {
          rtDynamicBoundsError(quartetOffset, 1, 4, &jf_emlrtBCI_DoaMusicSignal);
        }

        idx[quartetOffset - 1] = idx4[perm[2] - 1];
        if (!((quartetOffset + 1 >= 1) && (quartetOffset + 1 <= 4))) {
          rtDynamicBoundsError(quartetOffset + 1, 1, 4,
                               &kf_emlrtBCI_DoaMusicSignal);
        }

        idx[quartetOffset] = idx4[perm[3] - 1];
        nPairs = quartetOffset - 2;
        if (!((nPairs >= 1) && (nPairs <= 4))) {
          rtDynamicBoundsError(nPairs, 1, 4, &lf_emlrtBCI_DoaMusicSignal);
        }

        x[nPairs - 1] = x4[perm[0] - 1];
        nPairs = quartetOffset - 1;
        if (!((nPairs >= 1) && (nPairs <= 4))) {
          rtDynamicBoundsError(nPairs, 1, 4, &mf_emlrtBCI_DoaMusicSignal);
        }

        x[nPairs - 1] = x4[perm[1] - 1];
        if (!((quartetOffset >= 1) && (quartetOffset <= 4))) {
          rtDynamicBoundsError(quartetOffset, 1, 4, &nf_emlrtBCI_DoaMusicSignal);
        }

        x[quartetOffset - 1] = x4[perm[2] - 1];
        if (!((quartetOffset + 1 >= 1) && (quartetOffset + 1 <= 4))) {
          rtDynamicBoundsError(quartetOffset + 1, 1, 4,
                               &of_emlrtBCI_DoaMusicSignal);
        }

        x[quartetOffset] = x4[perm[3] - 1];
        ib = 0;
      }
    }
  }

  if (ib > 0) {
    for (m = 0; m < 4; m++) {
      perm[m] = 0;
    }

    switch (ib) {
     case 1:
      perm[0] = 1;
      break;

     case 2:
      if (x4[0] <= x4[1]) {
        perm[0] = 1;
        perm[1] = 2;
      } else {
        perm[0] = 2;
        perm[1] = 1;
      }
      break;

     default:
      if (x4[0] <= x4[1]) {
        if (x4[1] <= x4[2]) {
          perm[0] = 1;
          perm[1] = 2;
          perm[2] = 3;
        } else if (x4[0] <= x4[2]) {
          perm[0] = 1;
          perm[1] = 3;
          perm[2] = 2;
        } else {
          perm[0] = 3;
          perm[1] = 1;
          perm[2] = 2;
        }
      } else if (x4[0] <= x4[2]) {
        perm[0] = 2;
        perm[1] = 1;
        perm[2] = 3;
      } else if (x4[1] <= x4[2]) {
        perm[0] = 2;
        perm[1] = 3;
        perm[2] = 1;
      } else {
        perm[0] = 3;
        perm[1] = 2;
        perm[2] = 1;
      }
      break;
    }

    if (ib > 2147483646) {
      check_forloop_overflow_error();
    }

    for (k = 5; k - 4 <= ib; k++) {
      nPairs = perm[k - 5];
      if (!(nPairs >= 1)) {
        rtDynamicBoundsError(0, 1, 4, &df_emlrtBCI_DoaMusicSignal);
      }

      bLen = (k - nNaNs) - ib;
      if (!((bLen >= 1) && (bLen <= 4))) {
        rtDynamicBoundsError(bLen, 1, 4, &ef_emlrtBCI_DoaMusicSignal);
      }

      idx[bLen - 1] = idx4[nPairs - 1];
      nPairs = perm[k - 5];
      if (!(nPairs >= 1)) {
        rtDynamicBoundsError(0, 1, 4, &ff_emlrtBCI_DoaMusicSignal);
      }

      bLen = (k - nNaNs) - ib;
      if (!((bLen >= 1) && (bLen <= 4))) {
        rtDynamicBoundsError(bLen, 1, 4, &gf_emlrtBCI_DoaMusicSignal);
      }

      x[bLen - 1] = x4[nPairs - 1];
    }
  }

  m = nNaNs >> 1;
  for (k = 1; k <= m; k++) {
    nPairs = (k - nNaNs) + 4;
    if (!((nPairs >= 1) && (nPairs <= 4))) {
      rtDynamicBoundsError(nPairs, 1, 4, &ve_emlrtBCI_DoaMusicSignal);
    }

    ib = idx[nPairs - 1];
    nPairs = 5 - k;
    if (!(nPairs >= 1)) {
      rtDynamicBoundsError(nPairs, 1, 4, &we_emlrtBCI_DoaMusicSignal);
    }

    bLen = (k - nNaNs) + 4;
    if (!((bLen >= 1) && (bLen <= 4))) {
      rtDynamicBoundsError(bLen, 1, 4, &xe_emlrtBCI_DoaMusicSignal);
    }

    idx[bLen - 1] = idx[nPairs - 1];
    nPairs = 5 - k;
    if (!(nPairs >= 1)) {
      rtDynamicBoundsError(nPairs, 1, 4, &re_emlrtBCI_DoaMusicSignal);
    }

    idx[nPairs - 1] = ib;
    nPairs = 5 - k;
    if (!(nPairs >= 1)) {
      rtDynamicBoundsError(nPairs, 1, 4, &ye_emlrtBCI_DoaMusicSignal);
    }

    bLen = (k - nNaNs) + 4;
    if (!((bLen >= 1) && (bLen <= 4))) {
      rtDynamicBoundsError(bLen, 1, 4, &af_emlrtBCI_DoaMusicSignal);
    }

    x[bLen - 1] = xwork[nPairs - 1];
    nPairs = (k - nNaNs) + 4;
    if (!((nPairs >= 1) && (nPairs <= 4))) {
      rtDynamicBoundsError(nPairs, 1, 4, &bf_emlrtBCI_DoaMusicSignal);
    }

    bLen = 5 - k;
    if (!(bLen >= 1)) {
      rtDynamicBoundsError(bLen, 1, 4, &cf_emlrtBCI_DoaMusicSignal);
    }

    x[bLen - 1] = xwork[nPairs - 1];
  }

  if ((nNaNs & 1) != 0) {
    nPairs = (m - nNaNs) + 5;
    if (!((nPairs >= 1) && (nPairs <= 4))) {
      rtDynamicBoundsError(nPairs, 1, 4, &te_emlrtBCI_DoaMusicSignal);
    }

    bLen = (m - nNaNs) + 5;
    if (!((bLen >= 1) && (bLen <= 4))) {
      rtDynamicBoundsError(bLen, 1, 4, &ue_emlrtBCI_DoaMusicSignal);
    }

    x[bLen - 1] = xwork[nPairs - 1];
  }

  if (4 - nNaNs > 1) {
    for (m = 0; m < 4; m++) {
      idx4[m] = 0;
    }

    nPairs = (4 - nNaNs) >> 2;
    bLen = 4;
    while (nPairs > 1) {
      if ((nPairs & 1) != 0) {
        nPairs--;
        m = bLen * nPairs;
        ib = 4 - (nNaNs + m);
        if (ib > bLen) {
          merge(idx, x, m, bLen, ib - bLen, idx4, xwork);
        }
      }

      m = bLen << 1;
      nPairs >>= 1;
      for (k = 1; k <= nPairs; k++) {
        merge(idx, x, (k - 1) * m, bLen, bLen, idx4, xwork);
      }

      bLen = m;
    }

    if (4 - nNaNs > bLen) {
      merge(idx, x, 0, bLen, 4 - (nNaNs + bLen), idx4, xwork);
    }
  }
}

/*
 * Arguments    : double x_data[]
 *                int x_size[1]
 *                int idx_data[]
 *                int idx_size[1]
 * Return Type  : void
 */
static void b_sortIdx(double x_data[], int x_size[1], int idx_data[], int
                      idx_size[1])
{
  unsigned char unnamed_idx_0;
  int b_x_size[1];
  int m;
  int i36;
  double b_x_data[246];
  int n;
  double x4[4];
  unsigned char idx4[4];
  int iwork_size[1];
  int xwork;
  int iwork_data[246];
  int xwork_size[1];
  int nNaNs;
  double xwork_data[246];
  int ib;
  int k;
  int wOffset;
  signed char perm[4];
  int i37;
  int itmp;
  int i4;
  unnamed_idx_0 = (unsigned char)x_size[0];
  b_x_size[0] = x_size[0];
  m = x_size[0];
  for (i36 = 0; i36 < m; i36++) {
    b_x_data[i36] = x_data[i36];
  }

  idx_size[0] = unnamed_idx_0;
  m = unnamed_idx_0;
  for (i36 = 0; i36 < m; i36++) {
    idx_data[i36] = 0;
  }

  n = x_size[0];
  for (m = 0; m < 4; m++) {
    x4[m] = 0.0;
    idx4[m] = 0;
  }

  m = unnamed_idx_0;
  iwork_size[0] = unnamed_idx_0;
  for (i36 = 0; i36 < m; i36++) {
    iwork_data[i36] = 0;
  }

  xwork = (unsigned char)x_size[0];
  xwork_size[0] = (unsigned char)x_size[0];
  for (i36 = 0; i36 < xwork; i36++) {
    xwork_data[i36] = 0.0;
  }

  nNaNs = 0;
  ib = 0;
  for (k = 1; k <= n; k++) {
    if (!((k >= 1) && (k <= b_x_size[0]))) {
      rtDynamicBoundsError(k, 1, b_x_size[0], &ai_emlrtBCI_DoaMusicSignal);
    }

    if (rtIsNaN(b_x_data[k - 1])) {
      i36 = unnamed_idx_0;
      i37 = n - nNaNs;
      if (!((i37 >= 1) && (i37 <= i36))) {
        rtDynamicBoundsError(i37, 1, i36, &jj_emlrtBCI_DoaMusicSignal);
      }

      idx_data[i37 - 1] = k;
      if (!((k >= 1) && (k <= b_x_size[0]))) {
        rtDynamicBoundsError(k, 1, b_x_size[0], &kj_emlrtBCI_DoaMusicSignal);
      }

      i36 = n - nNaNs;
      if (!((i36 >= 1) && (i36 <= xwork))) {
        rtDynamicBoundsError(i36, 1, xwork, &lj_emlrtBCI_DoaMusicSignal);
      }

      xwork_data[i36 - 1] = b_x_data[k - 1];
      nNaNs++;
    } else {
      ib++;
      idx4[ib - 1] = (unsigned char)k;
      if (!((k >= 1) && (k <= b_x_size[0]))) {
        rtDynamicBoundsError(k, 1, b_x_size[0], &aj_emlrtBCI_DoaMusicSignal);
      }

      x4[ib - 1] = b_x_data[k - 1];
      if (ib == 4) {
        wOffset = k - nNaNs;
        if (x4[0] <= x4[1]) {
          m = 1;
          ib = 2;
        } else {
          m = 2;
          ib = 1;
        }

        if (x4[2] <= x4[3]) {
          itmp = 3;
          i4 = 4;
        } else {
          itmp = 4;
          i4 = 3;
        }

        if (x4[m - 1] <= x4[itmp - 1]) {
          if (x4[ib - 1] <= x4[itmp - 1]) {
            perm[0] = (signed char)m;
            perm[1] = (signed char)ib;
            perm[2] = (signed char)itmp;
            perm[3] = (signed char)i4;
          } else if (x4[ib - 1] <= x4[i4 - 1]) {
            perm[0] = (signed char)m;
            perm[1] = (signed char)itmp;
            perm[2] = (signed char)ib;
            perm[3] = (signed char)i4;
          } else {
            perm[0] = (signed char)m;
            perm[1] = (signed char)itmp;
            perm[2] = (signed char)i4;
            perm[3] = (signed char)ib;
          }
        } else if (x4[m - 1] <= x4[i4 - 1]) {
          if (x4[ib - 1] <= x4[i4 - 1]) {
            perm[0] = (signed char)itmp;
            perm[1] = (signed char)m;
            perm[2] = (signed char)ib;
            perm[3] = (signed char)i4;
          } else {
            perm[0] = (signed char)itmp;
            perm[1] = (signed char)m;
            perm[2] = (signed char)i4;
            perm[3] = (signed char)ib;
          }
        } else {
          perm[0] = (signed char)itmp;
          perm[1] = (signed char)i4;
          perm[2] = (signed char)m;
          perm[3] = (signed char)ib;
        }

        i36 = unnamed_idx_0;
        i37 = wOffset - 3;
        if (!((i37 >= 1) && (i37 <= i36))) {
          rtDynamicBoundsError(i37, 1, i36, &bj_emlrtBCI_DoaMusicSignal);
        }

        idx_data[i37 - 1] = idx4[perm[0] - 1];
        i36 = unnamed_idx_0;
        i37 = wOffset - 2;
        if (!((i37 >= 1) && (i37 <= i36))) {
          rtDynamicBoundsError(i37, 1, i36, &cj_emlrtBCI_DoaMusicSignal);
        }

        idx_data[i37 - 1] = idx4[perm[1] - 1];
        i36 = unnamed_idx_0;
        i37 = wOffset - 1;
        if (!((i37 >= 1) && (i37 <= i36))) {
          rtDynamicBoundsError(i37, 1, i36, &dj_emlrtBCI_DoaMusicSignal);
        }

        idx_data[i37 - 1] = idx4[perm[2] - 1];
        i36 = unnamed_idx_0;
        if (!((wOffset >= 1) && (wOffset <= i36))) {
          rtDynamicBoundsError(wOffset, 1, i36, &ej_emlrtBCI_DoaMusicSignal);
        }

        idx_data[wOffset - 1] = idx4[perm[3] - 1];
        i36 = wOffset - 3;
        if (!((i36 >= 1) && (i36 <= b_x_size[0]))) {
          rtDynamicBoundsError(i36, 1, b_x_size[0], &fj_emlrtBCI_DoaMusicSignal);
        }

        b_x_data[i36 - 1] = x4[perm[0] - 1];
        i36 = wOffset - 2;
        if (!((i36 >= 1) && (i36 <= b_x_size[0]))) {
          rtDynamicBoundsError(i36, 1, b_x_size[0], &gj_emlrtBCI_DoaMusicSignal);
        }

        b_x_data[i36 - 1] = x4[perm[1] - 1];
        i36 = wOffset - 1;
        if (!((i36 >= 1) && (i36 <= b_x_size[0]))) {
          rtDynamicBoundsError(i36, 1, b_x_size[0], &hj_emlrtBCI_DoaMusicSignal);
        }

        b_x_data[i36 - 1] = x4[perm[2] - 1];
        if (!((wOffset >= 1) && (wOffset <= b_x_size[0]))) {
          rtDynamicBoundsError(wOffset, 1, b_x_size[0],
                               &ij_emlrtBCI_DoaMusicSignal);
        }

        b_x_data[wOffset - 1] = x4[perm[3] - 1];
        ib = 0;
      }
    }
  }

  wOffset = x_size[0] - nNaNs;
  if (ib > 0) {
    for (m = 0; m < 4; m++) {
      perm[m] = 0;
    }

    switch (ib) {
     case 1:
      perm[0] = 1;
      break;

     case 2:
      if (x4[0] <= x4[1]) {
        perm[0] = 1;
        perm[1] = 2;
      } else {
        perm[0] = 2;
        perm[1] = 1;
      }
      break;

     default:
      if (x4[0] <= x4[1]) {
        if (x4[1] <= x4[2]) {
          perm[0] = 1;
          perm[1] = 2;
          perm[2] = 3;
        } else if (x4[0] <= x4[2]) {
          perm[0] = 1;
          perm[1] = 3;
          perm[2] = 2;
        } else {
          perm[0] = 3;
          perm[1] = 1;
          perm[2] = 2;
        }
      } else if (x4[0] <= x4[2]) {
        perm[0] = 2;
        perm[1] = 1;
        perm[2] = 3;
      } else if (x4[1] <= x4[2]) {
        perm[0] = 2;
        perm[1] = 3;
        perm[2] = 1;
      } else {
        perm[0] = 3;
        perm[1] = 2;
        perm[2] = 1;
      }
      break;
    }

    if (ib > 2147483646) {
      check_forloop_overflow_error();
    }

    for (k = 1; k <= ib; k++) {
      i36 = perm[k - 1];
      if (!(i36 >= 1)) {
        rtDynamicBoundsError(0, 1, 4, &df_emlrtBCI_DoaMusicSignal);
      }

      i37 = unnamed_idx_0;
      i4 = (wOffset - ib) + k;
      if (!((i4 >= 1) && (i4 <= i37))) {
        rtDynamicBoundsError(i4, 1, i37, &xi_emlrtBCI_DoaMusicSignal);
      }

      idx_data[i4 - 1] = idx4[i36 - 1];
      i36 = perm[k - 1];
      if (!(i36 >= 1)) {
        rtDynamicBoundsError(0, 1, 4, &ff_emlrtBCI_DoaMusicSignal);
      }

      i37 = (wOffset - ib) + k;
      if (!((i37 >= 1) && (i37 <= b_x_size[0]))) {
        rtDynamicBoundsError(i37, 1, b_x_size[0], &yi_emlrtBCI_DoaMusicSignal);
      }

      b_x_data[i37 - 1] = x4[i36 - 1];
    }
  }

  m = nNaNs >> 1;
  for (k = 1; k <= m; k++) {
    i36 = unnamed_idx_0;
    i37 = wOffset + k;
    if (!((i37 >= 1) && (i37 <= i36))) {
      rtDynamicBoundsError(i37, 1, i36, &pi_emlrtBCI_DoaMusicSignal);
    }

    itmp = idx_data[i37 - 1];
    i36 = unnamed_idx_0;
    i37 = (n - k) + 1;
    if (!((i37 >= 1) && (i37 <= i36))) {
      rtDynamicBoundsError(i37, 1, i36, &qi_emlrtBCI_DoaMusicSignal);
    }

    i36 = unnamed_idx_0;
    i4 = wOffset + k;
    if (!((i4 >= 1) && (i4 <= i36))) {
      rtDynamicBoundsError(i4, 1, i36, &ri_emlrtBCI_DoaMusicSignal);
    }

    idx_data[i4 - 1] = idx_data[i37 - 1];
    i36 = unnamed_idx_0;
    i37 = (n - k) + 1;
    if (!((i37 >= 1) && (i37 <= i36))) {
      rtDynamicBoundsError(i37, 1, i36, &si_emlrtBCI_DoaMusicSignal);
    }

    idx_data[i37 - 1] = itmp;
    i36 = (n - k) + 1;
    if (!((i36 >= 1) && (i36 <= xwork))) {
      rtDynamicBoundsError(i36, 1, xwork, &ti_emlrtBCI_DoaMusicSignal);
    }

    i37 = wOffset + k;
    if (!((i37 >= 1) && (i37 <= b_x_size[0]))) {
      rtDynamicBoundsError(i37, 1, b_x_size[0], &ui_emlrtBCI_DoaMusicSignal);
    }

    b_x_data[i37 - 1] = xwork_data[i36 - 1];
    i36 = wOffset + k;
    if (!((i36 >= 1) && (i36 <= xwork))) {
      rtDynamicBoundsError(i36, 1, xwork, &vi_emlrtBCI_DoaMusicSignal);
    }

    i37 = (n - k) + 1;
    if (!((i37 >= 1) && (i37 <= b_x_size[0]))) {
      rtDynamicBoundsError(i37, 1, b_x_size[0], &wi_emlrtBCI_DoaMusicSignal);
    }

    b_x_data[i37 - 1] = xwork_data[i36 - 1];
  }

  if ((nNaNs & 1) != 0) {
    i36 = (unsigned char)x_size[0];
    i37 = (wOffset + m) + 1;
    if (!((i37 >= 1) && (i37 <= i36))) {
      rtDynamicBoundsError(i37, 1, i36, &bi_emlrtBCI_DoaMusicSignal);
    }

    i36 = (wOffset + m) + 1;
    if (!((i36 >= 1) && (i36 <= b_x_size[0]))) {
      rtDynamicBoundsError(i36, 1, b_x_size[0], &ci_emlrtBCI_DoaMusicSignal);
    }

    b_x_data[i36 - 1] = xwork_data[i37 - 1];
  }

  m = x_size[0] - nNaNs;
  if (m > 1) {
    b_merge_block(idx_data, idx_size, b_x_data, b_x_size, m, iwork_data,
                  iwork_size, xwork_data, xwork_size);
  }

  x_size[0] = b_x_size[0];
  m = b_x_size[0];
  for (i36 = 0; i36 < m; i36++) {
    x_data[i36] = b_x_data[i36];
  }
}

/*
 * Arguments    : creal_T *x
 * Return Type  : void
 */
static void b_sqrt(creal_T *x)
{
  double absxi;
  double absxr;
  if (x->im == 0.0) {
    if (x->re < 0.0) {
      absxi = 0.0;
      absxr = sqrt(fabs(x->re));
    } else {
      absxi = sqrt(x->re);
      absxr = 0.0;
    }
  } else if (x->re == 0.0) {
    if (x->im < 0.0) {
      absxi = sqrt(-x->im / 2.0);
      absxr = -absxi;
    } else {
      absxi = sqrt(x->im / 2.0);
      absxr = absxi;
    }
  } else if (rtIsNaN(x->re) || rtIsNaN(x->im)) {
    absxi = rtNaN;
    absxr = rtNaN;
  } else if (rtIsInf(x->im)) {
    absxi = rtInf;
    absxr = x->im;
  } else if (rtIsInf(x->re)) {
    if (x->re < 0.0) {
      absxi = 0.0;
      absxr = rtInf;
    } else {
      absxi = rtInf;
      absxr = 0.0;
    }
  } else {
    absxr = fabs(x->re);
    absxi = fabs(x->im);
    if ((absxr > 4.4942328371557893E+307) || (absxi > 4.4942328371557893E+307))
    {
      absxr *= 0.5;
      absxi *= 0.5;
      absxi = rt_hypotd_snf(absxr, absxi);
      if (absxi > absxr) {
        absxi = sqrt(absxi) * sqrt(1.0 + absxr / absxi);
      } else {
        absxi = sqrt(absxi) * 1.4142135623730951;
      }
    } else {
      absxi = sqrt((rt_hypotd_snf(absxr, absxi) + absxr) * 0.5);
    }

    if (x->re > 0.0) {
      absxr = 0.5 * (x->im / absxi);
    } else {
      if (x->im < 0.0) {
        absxr = -absxi;
      } else {
        absxr = absxi;
      }

      absxi = 0.5 * (x->im / absxr);
    }
  }

  x->re = absxi;
  x->im = absxr;
}

/*
 * Arguments    : const creal_T x[484]
 *                creal_T y[121]
 * Return Type  : void
 */
static void b_sum(const creal_T x[484], creal_T y[121])
{
  int i;
  int xoffset;
  double s_re;
  double s_im;
  int k;
  for (i = 0; i < 121; i++) {
    xoffset = i << 2;
    s_re = x[xoffset].re;
    s_im = x[xoffset].im;
    for (k = 0; k < 3; k++) {
      s_re += x[(xoffset + k) + 1].re;
      s_im += x[(xoffset + k) + 1].im;
    }

    y[i].re = s_re;
    y[i].im = s_im;
  }
}

/*
 * Arguments    : const creal_T f
 *                const creal_T g
 *                double *cs
 *                creal_T *sn
 * Return Type  : void
 */
static void b_xzlartg(const creal_T f, const creal_T g, double *cs, creal_T *sn)
{
  double scale;
  double g2;
  double f2s;
  double fs_re;
  double fs_im;
  double gs_re;
  double gs_im;
  int count;
  int rescaledir;
  boolean_T guard1 = false;
  double d;
  double g2s;
  scale = fabs(f.re);
  g2 = fabs(f.im);
  if (g2 > scale) {
    scale = g2;
  }

  f2s = fabs(g.re);
  g2 = fabs(g.im);
  if (g2 > f2s) {
    f2s = g2;
  }

  if (f2s > scale) {
    scale = f2s;
  }

  fs_re = f.re;
  fs_im = f.im;
  gs_re = g.re;
  gs_im = g.im;
  count = 0;
  rescaledir = 0;
  guard1 = false;
  if (scale >= 7.4428285367870146E+137) {
    do {
      count++;
      fs_re *= 1.3435752215134178E-138;
      fs_im *= 1.3435752215134178E-138;
      gs_re *= 1.3435752215134178E-138;
      gs_im *= 1.3435752215134178E-138;
      scale *= 1.3435752215134178E-138;
    } while (!(scale < 7.4428285367870146E+137));

    rescaledir = 1;
    guard1 = true;
  } else if (scale <= 1.3435752215134178E-138) {
    if ((g.re == 0.0) && (g.im == 0.0)) {
      *cs = 1.0;
      sn->re = 0.0;
      sn->im = 0.0;
    } else {
      do {
        count++;
        fs_re *= 7.4428285367870146E+137;
        fs_im *= 7.4428285367870146E+137;
        gs_re *= 7.4428285367870146E+137;
        gs_im *= 7.4428285367870146E+137;
        scale *= 7.4428285367870146E+137;
      } while (!(scale > 1.3435752215134178E-138));

      rescaledir = -1;
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1) {
    scale = fs_re * fs_re + fs_im * fs_im;
    g2 = gs_re * gs_re + gs_im * gs_im;
    f2s = g2;
    if (1.0 > g2) {
      f2s = 1.0;
    }

    if (scale <= f2s * 2.0041683600089728E-292) {
      if ((f.re == 0.0) && (f.im == 0.0)) {
        *cs = 0.0;
        d = rt_hypotd_snf(gs_re, gs_im);
        sn->re = gs_re / d;
        sn->im = -gs_im / d;
      } else {
        if (g2 < 0.0) {
          error();
        }

        g2s = sqrt(g2);
        *cs = rt_hypotd_snf(fs_re, fs_im) / g2s;
        f2s = fabs(f.re);
        g2 = fabs(f.im);
        if (g2 > f2s) {
          f2s = g2;
        }

        if (f2s > 1.0) {
          d = rt_hypotd_snf(f.re, f.im);
          fs_re = f.re / d;
          fs_im = f.im / d;
        } else {
          g2 = 7.4428285367870146E+137 * f.re;
          scale = 7.4428285367870146E+137 * f.im;
          d = rt_hypotd_snf(g2, scale);
          fs_re = g2 / d;
          fs_im = scale / d;
        }

        gs_re /= g2s;
        gs_im = -gs_im / g2s;
        sn->re = fs_re * gs_re - fs_im * gs_im;
        sn->im = fs_re * gs_im + fs_im * gs_re;
      }
    } else {
      f2s = 1.0 + g2 / scale;
      if (f2s < 0.0) {
        error();
      }

      f2s = sqrt(f2s);
      *cs = 1.0 / f2s;
      d = scale + g2;
      fs_re = f2s * fs_re / d;
      fs_im = f2s * fs_im / d;
      sn->re = fs_re * gs_re - fs_im * -gs_im;
      sn->im = fs_re * -gs_im + fs_im * gs_re;
      if (rescaledir > 0) {
        if ((!(1 > count)) && (count > 2147483646)) {
          check_forloop_overflow_error();
        }
      } else {
        if ((rescaledir < 0) && ((!(1 > count)) && (count > 2147483646))) {
          check_forloop_overflow_error();
        }
      }
    }
  }
}

/*
 * Arguments    : const creal_T x[121]
 *                double y[121]
 * Return Type  : void
 */
static void c_abs(const creal_T x[121], double y[121])
{
  int k;
  for (k = 0; k < 121; k++) {
    y[k] = rt_hypotd_snf(x[k].re, x[k].im);
  }
}

/*
 * Arguments    : const int z_size[1]
 *                const int varargin_1_size[1]
 * Return Type  : boolean_T
 */
static boolean_T c_dimagree(const int z_size[1], const int varargin_1_size[1])
{
  boolean_T p;
  boolean_T b_p;
  int k;
  boolean_T exitg1;
  int b_k;
  int c_k;
  p = true;
  b_p = true;
  k = 1;
  exitg1 = false;
  while ((!exitg1) && (k < 3)) {
    if (k <= 1) {
      b_k = z_size[0];
    } else {
      b_k = 1;
    }

    if (k <= 1) {
      c_k = varargin_1_size[0];
    } else {
      c_k = 1;
    }

    if (b_k != c_k) {
      b_p = false;
      exitg1 = true;
    } else {
      k++;
    }
  }

  if (b_p) {
  } else {
    p = false;
  }

  return p;
}

/*
 * Arguments    : void
 * Return Type  : void
 */
static void c_error(void)
{
  m_rtErrorWithMessageID(&b_emlrtRTEI_DoaMusicSignal);
}

/*
 * Arguments    : const double y[123]
 *                const double iPk_data[]
 *                const int iPk_size[1]
 *                double Pd
 *                double idx_data[]
 *                int idx_size[1]
 * Return Type  : void
 */
static void c_findPeaksSeparatedByMoreThanM(const double y[123], const double
  iPk_data[], const int iPk_size[1], double Pd, double idx_data[], int idx_size
  [1])
{
  int k;
  int i12;
  int ndbl;
  int apnd;
  int cdiff;
  double locs_temp_data[246];
  int locs_temp_size[1];
  double locs_data[246];
  int iidx_data[246];
  int iidx_size[1];
  int sortIdx_size_idx_0;
  int sortIdx_data[246];
  boolean_T idelete_data[246];
  double locs;
  boolean_T tmp_data[246];
  boolean_T b_idelete_data[246];
  if ((iPk_size[0] == 0) || (Pd == 0.0)) {
    if (iPk_size[0] < 1) {
      ndbl = 0;
      apnd = 0;
    } else {
      ndbl = (int)floor(((double)iPk_size[0] - 1.0) + 0.5);
      apnd = ndbl + 1;
      cdiff = (ndbl - iPk_size[0]) + 1;
      if (fabs(cdiff) < 4.4408920985006262E-16 * (double)iPk_size[0]) {
        ndbl++;
        apnd = iPk_size[0];
      } else if (cdiff > 0) {
        apnd = ndbl;
      } else {
        ndbl++;
      }
    }

    if (ndbl > 0) {
      locs_temp_data[0] = 1.0;
      if (ndbl > 1) {
        locs_temp_data[ndbl - 1] = apnd;
        cdiff = (ndbl - 1) / 2;
        for (k = 1; k < cdiff; k++) {
          if (!(k + 1 <= ndbl)) {
            rtDynamicBoundsError(k + 1, 1, ndbl, &kd_emlrtBCI_DoaMusicSignal);
          }

          locs_temp_data[k] = 1.0 + (double)k;
          i12 = ndbl - k;
          if (!((i12 >= 1) && (i12 <= ndbl))) {
            rtDynamicBoundsError(i12, 1, ndbl, &ld_emlrtBCI_DoaMusicSignal);
          }

          locs_temp_data[i12 - 1] = apnd - k;
        }

        if (cdiff << 1 == ndbl - 1) {
          if (!(cdiff + 1 <= ndbl)) {
            rtDynamicBoundsError(cdiff + 1, 1, ndbl, &jd_emlrtBCI_DoaMusicSignal);
          }

          locs_temp_data[cdiff] = (1.0 + (double)apnd) / 2.0;
        } else {
          if (!(cdiff + 1 <= ndbl)) {
            rtDynamicBoundsError(cdiff + 1, 1, ndbl, &hd_emlrtBCI_DoaMusicSignal);
          }

          locs_temp_data[cdiff] = 1.0 + (double)cdiff;
          if (!(cdiff + 2 <= ndbl)) {
            rtDynamicBoundsError(cdiff + 2, 1, ndbl, &id_emlrtBCI_DoaMusicSignal);
          }

          locs_temp_data[cdiff + 1] = apnd - cdiff;
        }
      }
    }

    idx_size[0] = ndbl;
    for (i12 = 0; i12 < ndbl; i12++) {
      idx_data[i12] = locs_temp_data[i12];
    }
  } else {
    k = iPk_size[0];
    for (i12 = 0; i12 < k; i12++) {
      cdiff = (int)iPk_data[i12];
      if (!((cdiff >= 1) && (cdiff <= 123))) {
        rtDynamicBoundsError(cdiff, 1, 123, &cd_emlrtBCI_DoaMusicSignal);
      }
    }

    k = iPk_size[0];
    for (i12 = 0; i12 < k; i12++) {
      locs_data[i12] = 1.0 + (double)((int)iPk_data[i12] - 1);
    }

    locs_temp_size[0] = iPk_size[0];
    k = iPk_size[0];
    for (i12 = 0; i12 < k; i12++) {
      locs_temp_data[i12] = y[(int)iPk_data[i12] - 1];
    }

    c_sort(locs_temp_data, locs_temp_size, iidx_data, iidx_size);
    sortIdx_size_idx_0 = iidx_size[0];
    k = iidx_size[0];
    for (i12 = 0; i12 < k; i12++) {
      sortIdx_data[i12] = iidx_data[i12];
    }

    locs_temp_size[0] = iidx_size[0];
    k = iidx_size[0];
    for (i12 = 0; i12 < k; i12++) {
      cdiff = sortIdx_data[i12];
      if (!((cdiff >= 1) && (cdiff <= iPk_size[0]))) {
        rtDynamicBoundsError(cdiff, 1, iPk_size[0], &dd_emlrtBCI_DoaMusicSignal);
      }

      locs_temp_data[i12] = locs_data[cdiff - 1];
    }

    cdiff = (unsigned char)iidx_size[0];
    k = (unsigned char)iidx_size[0];
    for (i12 = 0; i12 < k; i12++) {
      idelete_data[i12] = false;
    }

    for (apnd = 1; apnd - 1 < sortIdx_size_idx_0; apnd++) {
      if (!((apnd >= 1) && (apnd <= cdiff))) {
        rtDynamicBoundsError(apnd, 1, cdiff, &fd_emlrtBCI_DoaMusicSignal);
      }

      if (!idelete_data[apnd - 1]) {
        if (!((apnd >= 1) && (apnd <= sortIdx_size_idx_0))) {
          rtDynamicBoundsError(apnd, 1, sortIdx_size_idx_0,
                               &dd_emlrtBCI_DoaMusicSignal);
        }

        locs = locs_data[sortIdx_data[apnd - 1] - 1] - Pd;
        k = locs_temp_size[0];
        for (i12 = 0; i12 < k; i12++) {
          tmp_data[i12] = (locs_temp_data[i12] >= locs);
        }

        if (!((apnd >= 1) && (apnd <= sortIdx_size_idx_0))) {
          rtDynamicBoundsError(apnd, 1, sortIdx_size_idx_0,
                               &dd_emlrtBCI_DoaMusicSignal);
        }

        locs = locs_data[sortIdx_data[apnd - 1] - 1] + Pd;
        k = locs_temp_size[0];
        for (i12 = 0; i12 < k; i12++) {
          b_idelete_data[i12] = (locs_temp_data[i12] <= locs);
        }

        k = locs_temp_size[0];
        for (i12 = 0; i12 < k; i12++) {
          tmp_data[i12] = (tmp_data[i12] && b_idelete_data[i12]);
        }

        if (cdiff != locs_temp_size[0]) {
          rtSizeEq1DError(cdiff, locs_temp_size[0], &r_emlrtECI_DoaMusicSignal);
        }

        for (i12 = 0; i12 < cdiff; i12++) {
          b_idelete_data[i12] = idelete_data[i12];
        }

        for (i12 = 0; i12 < cdiff; i12++) {
          idelete_data[i12] = (idelete_data[i12] || tmp_data[i12]);
        }

        if (!((apnd >= 1) && (apnd <= cdiff))) {
          rtDynamicBoundsError(apnd, 1, cdiff, &gd_emlrtBCI_DoaMusicSignal);
        }

        idelete_data[apnd - 1] = false;
      }
    }

    cdiff = (unsigned char)iidx_size[0] - 1;
    ndbl = 0;
    for (apnd = 0; apnd <= cdiff; apnd++) {
      if (!idelete_data[apnd]) {
        ndbl++;
      }
    }

    k = 0;
    for (apnd = 0; apnd <= cdiff; apnd++) {
      if (!idelete_data[apnd]) {
        iidx_data[k] = apnd + 1;
        k++;
      }
    }

    for (i12 = 0; i12 < ndbl; i12++) {
      if (!((iidx_data[i12] >= 1) && (iidx_data[i12] <= sortIdx_size_idx_0))) {
        rtDynamicBoundsError(iidx_data[i12], 1, sortIdx_size_idx_0,
                             &ed_emlrtBCI_DoaMusicSignal);
      }
    }

    idx_size[0] = ndbl;
    for (i12 = 0; i12 < ndbl; i12++) {
      idx_data[i12] = sortIdx_data[iidx_data[i12] - 1];
    }

    e_sort(idx_data, idx_size);
  }
}

/*
 * Arguments    : int idx_data[]
 *                int idx_size[1]
 *                double x_data[]
 *                int x_size[1]
 *                int offset
 *                int np
 *                int nq
 *                int iwork_data[]
 *                int iwork_size[1]
 *                double xwork_data[]
 *                int xwork_size[1]
 * Return Type  : void
 */
static void c_merge(int idx_data[], int idx_size[1], double x_data[], int
                    x_size[1], int offset, int np, int nq, int iwork_data[], int
                    iwork_size[1], double xwork_data[], int xwork_size[1])
{
  int n;
  int qend;
  int p;
  int i38;
  int iout;
  int exitg1;
  if (nq == 0) {
  } else {
    n = np + nq;
    if ((!(1 > n)) && (n > 2147483646)) {
      check_forloop_overflow_error();
    }

    for (qend = 1; qend <= n; qend++) {
      i38 = idx_size[0];
      iout = offset + qend;
      if (!((iout >= 1) && (iout <= i38))) {
        rtDynamicBoundsError(iout, 1, i38, &bk_emlrtBCI_DoaMusicSignal);
      }

      i38 = iwork_size[0];
      if (!((qend >= 1) && (qend <= i38))) {
        rtDynamicBoundsError(qend, 1, i38, &ck_emlrtBCI_DoaMusicSignal);
      }

      iwork_data[qend - 1] = idx_data[iout - 1];
      i38 = x_size[0];
      iout = offset + qend;
      if (!((iout >= 1) && (iout <= i38))) {
        rtDynamicBoundsError(iout, 1, i38, &dk_emlrtBCI_DoaMusicSignal);
      }

      i38 = xwork_size[0];
      if (!((qend >= 1) && (qend <= i38))) {
        rtDynamicBoundsError(qend, 1, i38, &ek_emlrtBCI_DoaMusicSignal);
      }

      xwork_data[qend - 1] = x_data[iout - 1];
    }

    p = 1;
    n = np + 1;
    qend = np + nq;
    iout = offset;
    do {
      exitg1 = 0;
      iout++;
      i38 = xwork_size[0];
      if (!((p >= 1) && (p <= i38))) {
        rtDynamicBoundsError(p, 1, i38, &mj_emlrtBCI_DoaMusicSignal);
      }

      i38 = xwork_size[0];
      if (!((n >= 1) && (n <= i38))) {
        rtDynamicBoundsError(n, 1, i38, &nj_emlrtBCI_DoaMusicSignal);
      }

      if (xwork_data[p - 1] <= xwork_data[n - 1]) {
        i38 = iwork_size[0];
        if (!((p >= 1) && (p <= i38))) {
          rtDynamicBoundsError(p, 1, i38, &wj_emlrtBCI_DoaMusicSignal);
        }

        i38 = idx_size[0];
        if (!((iout >= 1) && (iout <= i38))) {
          rtDynamicBoundsError(iout, 1, i38, &xj_emlrtBCI_DoaMusicSignal);
        }

        idx_data[iout - 1] = iwork_data[p - 1];
        i38 = xwork_size[0];
        if (!((p >= 1) && (p <= i38))) {
          rtDynamicBoundsError(p, 1, i38, &yj_emlrtBCI_DoaMusicSignal);
        }

        i38 = x_size[0];
        if (!((iout >= 1) && (iout <= i38))) {
          rtDynamicBoundsError(iout, 1, i38, &ak_emlrtBCI_DoaMusicSignal);
        }

        x_data[iout - 1] = xwork_data[p - 1];
        if (p < np) {
          p++;
        } else {
          exitg1 = 1;
        }
      } else {
        i38 = iwork_size[0];
        if (!((n >= 1) && (n <= i38))) {
          rtDynamicBoundsError(n, 1, i38, &oj_emlrtBCI_DoaMusicSignal);
        }

        i38 = idx_size[0];
        if (!((iout >= 1) && (iout <= i38))) {
          rtDynamicBoundsError(iout, 1, i38, &pj_emlrtBCI_DoaMusicSignal);
        }

        idx_data[iout - 1] = iwork_data[n - 1];
        i38 = xwork_size[0];
        if (!((n >= 1) && (n <= i38))) {
          rtDynamicBoundsError(n, 1, i38, &qj_emlrtBCI_DoaMusicSignal);
        }

        i38 = x_size[0];
        if (!((iout >= 1) && (iout <= i38))) {
          rtDynamicBoundsError(iout, 1, i38, &rj_emlrtBCI_DoaMusicSignal);
        }

        x_data[iout - 1] = xwork_data[n - 1];
        if (n < qend) {
          n++;
        } else {
          n = (iout - p) + 1;
          if ((!(p > np)) && (np > 2147483646)) {
            check_forloop_overflow_error();
          }

          while (p <= np) {
            i38 = iwork_size[0];
            if (!((p >= 1) && (p <= i38))) {
              rtDynamicBoundsError(p, 1, i38, &sj_emlrtBCI_DoaMusicSignal);
            }

            i38 = idx_size[0];
            iout = n + p;
            if (!((iout >= 1) && (iout <= i38))) {
              rtDynamicBoundsError(iout, 1, i38, &tj_emlrtBCI_DoaMusicSignal);
            }

            idx_data[iout - 1] = iwork_data[p - 1];
            i38 = xwork_size[0];
            if (!((p >= 1) && (p <= i38))) {
              rtDynamicBoundsError(p, 1, i38, &uj_emlrtBCI_DoaMusicSignal);
            }

            i38 = x_size[0];
            iout = n + p;
            if (!((iout >= 1) && (iout <= i38))) {
              rtDynamicBoundsError(iout, 1, i38, &vj_emlrtBCI_DoaMusicSignal);
            }

            x_data[iout - 1] = xwork_data[p - 1];
            p++;
          }

          exitg1 = 1;
        }
      }
    } while (exitg1 == 0);
  }
}

/*
 * Arguments    : const double y[123]
 *                double iPk_data[]
 *                int iPk_size[1]
 *                double pbPk_data[]
 *                int pbPk_size[1]
 *                double iLB_data[]
 *                int iLB_size[1]
 *                double iRB_data[]
 *                int iRB_size[1]
 * Return Type  : void
 */
static void c_removePeaksBelowMinPeakPromin(const double y[123], double
  iPk_data[], int iPk_size[1], double pbPk_data[], int pbPk_size[1], double
  iLB_data[], int iLB_size[1], double iRB_data[], int iRB_size[1])
{
  int i23;
  int ii;
  int x_size_idx_0;
  int idx;
  boolean_T x_data[123];
  int ii_data[123];
  boolean_T exitg1;
  boolean_T guard1 = false;
  boolean_T b_guard1 = false;
  boolean_T nonSingletonDimFound;
  int idx_data[123];
  double b_iPk_data[123];
  i23 = iPk_size[0];
  ii = pbPk_size[0];
  if (i23 != ii) {
    rtSizeEq1DError(i23, ii, &u_emlrtECI_DoaMusicSignal);
  }

  x_size_idx_0 = iPk_size[0];
  idx = iPk_size[0];
  for (i23 = 0; i23 < idx; i23++) {
    x_data[i23] = (y[(int)iPk_data[i23] - 1] - pbPk_data[i23] >= 0.5);
  }

  idx = 0;
  ii = 1;
  exitg1 = false;
  while ((!exitg1) && (ii <= x_size_idx_0)) {
    if (!((ii >= 1) && (ii <= x_size_idx_0))) {
      rtDynamicBoundsError(ii, 1, x_size_idx_0, &i_emlrtBCI_DoaMusicSignal);
    }

    guard1 = false;
    if (x_data[ii - 1]) {
      idx++;
      if (!((idx >= 1) && (idx <= x_size_idx_0))) {
        rtDynamicBoundsError(idx, 1, x_size_idx_0, &j_emlrtBCI_DoaMusicSignal);
      }

      ii_data[idx - 1] = ii;
      if (idx >= x_size_idx_0) {
        exitg1 = true;
      } else {
        guard1 = true;
      }
    } else {
      guard1 = true;
    }

    if (guard1) {
      ii++;
    }
  }

  if (idx <= x_size_idx_0) {
  } else {
    j_rtErrorWithMessageID(&j_emlrtRTEI_DoaMusicSignal);
  }

  if (x_size_idx_0 == 1) {
    if (idx == 0) {
      x_size_idx_0 = 0;
    }
  } else {
    if (1 > idx) {
      idx = 0;
    } else {
      if (!(1 <= x_size_idx_0)) {
        rtDynamicBoundsError(1, 1, x_size_idx_0, &g_emlrtBCI_DoaMusicSignal);
      }

      if (!(idx <= x_size_idx_0)) {
        rtDynamicBoundsError(idx, 1, x_size_idx_0, &g_emlrtBCI_DoaMusicSignal);
      }
    }

    b_guard1 = false;
    if (!(x_size_idx_0 != 1)) {
      nonSingletonDimFound = false;
      if (idx != 1) {
        nonSingletonDimFound = true;
      }

      if (nonSingletonDimFound) {
        nonSingletonDimFound = true;
      } else {
        b_guard1 = true;
      }
    } else {
      b_guard1 = true;
    }

    if (b_guard1) {
      nonSingletonDimFound = false;
    }

    if (!nonSingletonDimFound) {
    } else {
      i_rtErrorWithMessageID(&i_emlrtRTEI_DoaMusicSignal);
    }

    x_size_idx_0 = idx;
  }

  for (i23 = 0; i23 < x_size_idx_0; i23++) {
    idx_data[i23] = ii_data[i23];
  }

  idx = iPk_size[0];
  for (i23 = 0; i23 < x_size_idx_0; i23++) {
    ii = idx_data[i23];
    if (!((ii >= 1) && (ii <= idx))) {
      rtDynamicBoundsError(ii, 1, idx, &ng_emlrtBCI_DoaMusicSignal);
    }

    b_iPk_data[i23] = iPk_data[ii - 1];
  }

  iPk_size[0] = x_size_idx_0;
  for (i23 = 0; i23 < x_size_idx_0; i23++) {
    iPk_data[i23] = b_iPk_data[i23];
  }

  idx = pbPk_size[0];
  for (i23 = 0; i23 < x_size_idx_0; i23++) {
    ii = idx_data[i23];
    if (!((ii >= 1) && (ii <= idx))) {
      rtDynamicBoundsError(ii, 1, idx, &og_emlrtBCI_DoaMusicSignal);
    }

    b_iPk_data[i23] = pbPk_data[ii - 1];
  }

  pbPk_size[0] = x_size_idx_0;
  for (i23 = 0; i23 < x_size_idx_0; i23++) {
    pbPk_data[i23] = b_iPk_data[i23];
  }

  idx = iLB_size[0];
  for (i23 = 0; i23 < x_size_idx_0; i23++) {
    ii = idx_data[i23];
    if (!((ii >= 1) && (ii <= idx))) {
      rtDynamicBoundsError(ii, 1, idx, &pg_emlrtBCI_DoaMusicSignal);
    }

    b_iPk_data[i23] = iLB_data[ii - 1];
  }

  iLB_size[0] = x_size_idx_0;
  for (i23 = 0; i23 < x_size_idx_0; i23++) {
    iLB_data[i23] = b_iPk_data[i23];
  }

  idx = iRB_size[0];
  for (i23 = 0; i23 < x_size_idx_0; i23++) {
    ii = idx_data[i23];
    if (!((ii >= 1) && (ii <= idx))) {
      rtDynamicBoundsError(ii, 1, idx, &qg_emlrtBCI_DoaMusicSignal);
    }

    b_iPk_data[i23] = iRB_data[ii - 1];
  }

  iRB_size[0] = x_size_idx_0;
  for (i23 = 0; i23 < x_size_idx_0; i23++) {
    iRB_data[i23] = b_iPk_data[i23];
  }
}

/*
 * Arguments    : const int b
 *                const char *c
 *                const rtRunTimeErrorInfo_DoaMusicSign *aInfo
 * Return Type  : void
 */
static void c_rtErrorWithMessageID(const int b, const char *c, const
  rtRunTimeErrorInfo_DoaMusicSign *aInfo)
{
  fprintf(stderr,
          "The loop variable of class %.*s might overflow on the last iteration of the for loop. This could lead to an infinite loop.",
          b, c);
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : double x_data[]
 *                int x_size[1]
 *                int idx_data[]
 *                int idx_size[1]
 * Return Type  : void
 */
static void c_sort(double x_data[], int x_size[1], int idx_data[], int idx_size
                   [1])
{
  int dim;
  dim = 2;
  if (x_size[0] != 1) {
    dim = 1;
  }

  d_sort(x_data, x_size, dim, idx_data, idx_size);
}

/*
 * Arguments    : const boolean_T x_data[]
 *                const int x_size[2]
 * Return Type  : double
 */
static double c_sum(const boolean_T x_data[], const int x_size[2])
{
  double y;
  boolean_T p;
  boolean_T b_p;
  int k;
  int exitg1;
  if ((x_size[1] == 1) || (x_size[1] != 1)) {
    p = true;
  } else {
    p = false;
  }

  if (p) {
  } else {
    k_rtErrorWithMessageID(&p_emlrtRTEI_DoaMusicSignal);
  }

  p = false;
  b_p = false;
  k = 0;
  do {
    exitg1 = 0;
    if (k < 2) {
      if (x_size[k] != 0) {
        exitg1 = 1;
      } else {
        k++;
      }
    } else {
      b_p = true;
      exitg1 = 1;
    }
  } while (exitg1 == 0);

  if (!b_p) {
  } else {
    p = true;
  }

  if (!p) {
  } else {
    o_rtErrorWithMessageID(&q_emlrtRTEI_DoaMusicSignal);
  }

  if (x_size[1] == 0) {
    y = 0.0;
  } else {
    y = x_data[0];
    for (k = 2; k <= x_size[1]; k++) {
      if (!((k >= 1) && (k <= x_size[1]))) {
        rtDynamicBoundsError(k, 1, x_size[1], &od_emlrtBCI_DoaMusicSignal);
      }

      y += (double)x_data[k - 1];
    }
  }

  return y;
}

/*
 * Arguments    : void
 * Return Type  : void
 */
static void check_forloop_overflow_error(void)
{
  c_rtErrorWithMessageID(5, "int32", &c_emlrtRTEI_DoaMusicSignal);
}

/*
 * Arguments    : const double y[123]
 *                const double iPk_data[]
 *                const int iPk_size[1]
 *                const double bPk_data[]
 *                const int bPk_size[1]
 *                const double iLBw_data[]
 *                const int iLBw_size[1]
 *                const double iRBw_data[]
 *                const int iRBw_size[1]
 *                const double wPk_data[]
 *                const int wPk_size[2]
 *                const double iInf_data[]
 *                const int iInf_size[1]
 *                double iPkOut_data[]
 *                int iPkOut_size[1]
 *                double bPkOut_data[]
 *                int bPkOut_size[1]
 *                double bxPkOut_data[]
 *                int bxPkOut_size[2]
 *                double byPkOut_data[]
 *                int byPkOut_size[2]
 *                double wxPkOut_data[]
 *                int wxPkOut_size[2]
 * Return Type  : void
 */
static void combineFullPeaks(const double y[123], const double iPk_data[], const
  int iPk_size[1], const double bPk_data[], const int bPk_size[1], const double
  iLBw_data[], const int iLBw_size[1], const double iRBw_data[], const int
  iRBw_size[1], const double wPk_data[], const int wPk_size[2], const double
  iInf_data[], const int iInf_size[1], double iPkOut_data[], int iPkOut_size[1],
  double bPkOut_data[], int bPkOut_size[1], double bxPkOut_data[], int
  bxPkOut_size[2], double byPkOut_data[], int byPkOut_size[2], double
  wxPkOut_data[], int wxPkOut_size[2])
{
  int ia_data[123];
  int ia_size[1];
  int ib_data[123];
  int ib_size[1];
  double c_data[123];
  int c_size[1];
  int iFinite_size_idx_0;
  int k;
  int i9;
  int iFinite_data[123];
  int iPkOut;
  int iInfinite_data[123];
  int i10;
  double iInfL_data[123];
  int iInfL_size[1];
  double iInfR_data[123];
  int iInfR_size[1];
  int ia[1];
  int b_ia[1];
  int c_ia[1];
  int d_ia[1];
  int e_ia[1];
  int f_ia[1];
  int g_ia[1];
  int h_ia[1];
  int i_ia[2];
  int j_ia[1];
  int k_ia[1];
  do_vectors(iPk_data, iPk_size, iInf_data, iInf_size, iPkOut_data, iPkOut_size,
             ia_data, ia_size, ib_data, ib_size);
  b_do_vectors(iPkOut_data, iPkOut_size, iPk_data, iPk_size, c_data, c_size,
               ia_data, ia_size, ib_data, ib_size);
  iFinite_size_idx_0 = ia_size[0];
  k = ia_size[0];
  for (i9 = 0; i9 < k; i9++) {
    iFinite_data[i9] = ia_data[i9];
  }

  b_do_vectors(iPkOut_data, iPkOut_size, iInf_data, iInf_size, c_data, c_size,
               ia_data, ia_size, ib_data, ib_size);
  k = ia_size[0];
  for (i9 = 0; i9 < k; i9++) {
    iInfinite_data[i9] = ia_data[i9];
  }

  iPkOut = iPkOut_size[0];
  bPkOut_size[0] = (unsigned char)iPkOut_size[0];
  k = (unsigned char)iPkOut_size[0];
  for (i9 = 0; i9 < k; i9++) {
    bPkOut_data[i9] = 0.0;
  }

  for (i9 = 0; i9 < iFinite_size_idx_0; i9++) {
    i10 = (unsigned char)iPkOut_size[0];
    k = iFinite_data[i9];
    if (!((k >= 1) && (k <= i10))) {
      rtDynamicBoundsError(k, 1, i10, &rb_emlrtBCI_DoaMusicSignal);
    }

    ia_data[i9] = k;
  }

  if (iFinite_size_idx_0 != bPk_size[0]) {
    rtSizeEq1DError(iFinite_size_idx_0, bPk_size[0], &f_emlrtECI_DoaMusicSignal);
  }

  k = bPk_size[0];
  for (i9 = 0; i9 < k; i9++) {
    bPkOut_data[ia_data[i9] - 1] = bPk_data[i9];
  }

  k = ia_size[0];
  for (i9 = 0; i9 < k; i9++) {
    i10 = iInfinite_data[i9];
    if (!((i10 >= 1) && (i10 <= bPkOut_size[0]))) {
      rtDynamicBoundsError(i10, 1, bPkOut_size[0], &sb_emlrtBCI_DoaMusicSignal);
    }

    ia_data[i9] = i10;
  }

  k = ia_size[0];
  for (i9 = 0; i9 < k; i9++) {
    bPkOut_data[ia_data[i9] - 1] = 0.0;
  }

  c_size[0] = iInf_size[0];
  k = iInf_size[0];
  for (i9 = 0; i9 < k; i9++) {
    c_data[i9] = iInf_data[i9] - 1.0;
  }

  iInfL_size[0] = (signed char)iInf_size[0];
  if (b_dimagree(iInfL_size, c_size)) {
  } else {
    l_rtErrorWithMessageID(&l_emlrtRTEI_DoaMusicSignal);
  }

  for (k = 1; k <= (signed char)iInf_size[0]; k++) {
    if (!(k <= c_size[0])) {
      rtDynamicBoundsError(k, 1, c_size[0], &o_emlrtBCI_DoaMusicSignal);
    }

    if (!(k <= iInfL_size[0])) {
      rtDynamicBoundsError(k, 1, iInfL_size[0], &s_emlrtBCI_DoaMusicSignal);
    }

    if ((1.0 >= c_data[k - 1]) || rtIsNaN(c_data[k - 1])) {
      iInfL_data[k - 1] = 1.0;
    } else {
      iInfL_data[k - 1] = c_data[k - 1];
    }
  }

  c_size[0] = iInf_size[0];
  k = iInf_size[0];
  for (i9 = 0; i9 < k; i9++) {
    c_data[i9] = iInf_data[i9] + 1.0;
  }

  iInfR_size[0] = (signed char)iInf_size[0];
  if (c_dimagree(iInfR_size, c_size)) {
  } else {
    l_rtErrorWithMessageID(&l_emlrtRTEI_DoaMusicSignal);
  }

  for (k = 1; k <= (signed char)iInf_size[0]; k++) {
    if (!(k <= c_size[0])) {
      rtDynamicBoundsError(k, 1, c_size[0], &p_emlrtBCI_DoaMusicSignal);
    }

    if (!(k <= iInfR_size[0])) {
      rtDynamicBoundsError(k, 1, iInfR_size[0], &s_emlrtBCI_DoaMusicSignal);
    }

    if (c_data[k - 1] <= 123.0) {
      iInfR_data[k - 1] = c_data[k - 1];
    } else {
      iInfR_data[k - 1] = 123.0;
    }
  }

  bxPkOut_size[0] = iPkOut;
  bxPkOut_size[1] = 2;
  k = iPkOut << 1;
  for (i9 = 0; i9 < k; i9++) {
    bxPkOut_data[i9] = 0.0;
  }

  for (i9 = 0; i9 < iFinite_size_idx_0; i9++) {
    i10 = iFinite_data[i9];
    if (!((i10 >= 1) && (i10 <= iPkOut))) {
      rtDynamicBoundsError(i10, 1, iPkOut, &tb_emlrtBCI_DoaMusicSignal);
    }

    ia_data[i9] = i10 - 1;
  }

  k = iLBw_size[0];
  for (i9 = 0; i9 < k; i9++) {
    i10 = (int)iLBw_data[i9];
    if (!((i10 >= 1) && (i10 <= 123))) {
      rtDynamicBoundsError(i10, 1, 123, &ub_emlrtBCI_DoaMusicSignal);
    }
  }

  ia[0] = iFinite_size_idx_0;
  rtSubAssignSizeCheck(ia, 1, iLBw_size, 1, &e_emlrtECI_DoaMusicSignal);
  k = iLBw_size[0];
  for (i9 = 0; i9 < k; i9++) {
    bxPkOut_data[ia_data[i9]] = 1.0 + (double)((int)iLBw_data[i9] - 1);
  }

  for (i9 = 0; i9 < iFinite_size_idx_0; i9++) {
    i10 = iFinite_data[i9];
    if (!((i10 >= 1) && (i10 <= iPkOut))) {
      rtDynamicBoundsError(i10, 1, iPkOut, &vb_emlrtBCI_DoaMusicSignal);
    }

    ia_data[i9] = i10 - 1;
  }

  k = iRBw_size[0];
  for (i9 = 0; i9 < k; i9++) {
    i10 = (int)iRBw_data[i9];
    if (!((i10 >= 1) && (i10 <= 123))) {
      rtDynamicBoundsError(i10, 1, 123, &wb_emlrtBCI_DoaMusicSignal);
    }
  }

  b_ia[0] = iFinite_size_idx_0;
  rtSubAssignSizeCheck(b_ia, 1, iRBw_size, 1, &d_emlrtECI_DoaMusicSignal);
  k = iRBw_size[0];
  for (i9 = 0; i9 < k; i9++) {
    bxPkOut_data[ia_data[i9] + iPkOut] = 1.0 + (double)((int)iRBw_data[i9] - 1);
  }

  k = (signed char)iInf_size[0];
  for (i9 = 0; i9 < k; i9++) {
    i10 = (int)iInfL_data[i9];
    if (!((i10 >= 1) && (i10 <= 123))) {
      rtDynamicBoundsError(i10, 1, 123, &xb_emlrtBCI_DoaMusicSignal);
    }
  }

  i9 = (signed char)iInf_size[0];
  if (iInf_size[0] != i9) {
    rtSizeEq1DError(iInf_size[0], i9, &q_emlrtECI_DoaMusicSignal);
  }

  k = ia_size[0];
  for (i9 = 0; i9 < k; i9++) {
    i10 = iInfinite_data[i9];
    if (!((i10 >= 1) && (i10 <= iPkOut))) {
      rtDynamicBoundsError(i10, 1, iPkOut, &yb_emlrtBCI_DoaMusicSignal);
    }

    ia_data[i9] = i10 - 1;
  }

  c_size[0] = iInf_size[0];
  k = iInf_size[0];
  for (i9 = 0; i9 < k; i9++) {
    c_data[i9] = 0.5 * ((1.0 + (double)((int)iInf_data[i9] - 1)) + (1.0 +
      (double)((int)iInfL_data[i9] - 1)));
  }

  c_ia[0] = ia_size[0];
  rtSubAssignSizeCheck(c_ia, 1, c_size, 1, &c_emlrtECI_DoaMusicSignal);
  k = iInf_size[0];
  for (i9 = 0; i9 < k; i9++) {
    bxPkOut_data[ia_data[i9]] = c_data[i9];
  }

  k = (signed char)iInf_size[0];
  for (i9 = 0; i9 < k; i9++) {
    i10 = (int)iInfR_data[i9];
    if (!((i10 >= 1) && (i10 <= 123))) {
      rtDynamicBoundsError(i10, 1, 123, &ac_emlrtBCI_DoaMusicSignal);
    }
  }

  i9 = (signed char)iInf_size[0];
  if (iInf_size[0] != i9) {
    rtSizeEq1DError(iInf_size[0], i9, &p_emlrtECI_DoaMusicSignal);
  }

  k = ia_size[0];
  for (i9 = 0; i9 < k; i9++) {
    i10 = iInfinite_data[i9];
    if (!((i10 >= 1) && (i10 <= iPkOut))) {
      rtDynamicBoundsError(i10, 1, iPkOut, &bc_emlrtBCI_DoaMusicSignal);
    }

    ia_data[i9] = i10 - 1;
  }

  c_size[0] = iInf_size[0];
  k = iInf_size[0];
  for (i9 = 0; i9 < k; i9++) {
    c_data[i9] = 0.5 * ((1.0 + (double)((int)iInf_data[i9] - 1)) + (1.0 +
      (double)((int)iInfR_data[i9] - 1)));
  }

  d_ia[0] = ia_size[0];
  rtSubAssignSizeCheck(d_ia, 1, c_size, 1, &b_emlrtECI_DoaMusicSignal);
  k = iInf_size[0];
  for (i9 = 0; i9 < k; i9++) {
    bxPkOut_data[ia_data[i9] + iPkOut] = c_data[i9];
  }

  byPkOut_size[0] = iPkOut;
  byPkOut_size[1] = 2;
  k = iPkOut << 1;
  for (i9 = 0; i9 < k; i9++) {
    byPkOut_data[i9] = 0.0;
  }

  for (i9 = 0; i9 < iFinite_size_idx_0; i9++) {
    i10 = iFinite_data[i9];
    if (!((i10 >= 1) && (i10 <= iPkOut))) {
      rtDynamicBoundsError(i10, 1, iPkOut, &cc_emlrtBCI_DoaMusicSignal);
    }

    ia_data[i9] = i10 - 1;
  }

  e_ia[0] = iFinite_size_idx_0;
  rtSubAssignSizeCheck(e_ia, 1, iLBw_size, 1, &m_emlrtECI_DoaMusicSignal);
  k = iLBw_size[0];
  for (i9 = 0; i9 < k; i9++) {
    byPkOut_data[ia_data[i9]] = y[(int)iLBw_data[i9] - 1];
  }

  for (i9 = 0; i9 < iFinite_size_idx_0; i9++) {
    i10 = iFinite_data[i9];
    if (!((i10 >= 1) && (i10 <= iPkOut))) {
      rtDynamicBoundsError(i10, 1, iPkOut, &dc_emlrtBCI_DoaMusicSignal);
    }

    ia_data[i9] = i10 - 1;
  }

  f_ia[0] = iFinite_size_idx_0;
  rtSubAssignSizeCheck(f_ia, 1, iRBw_size, 1, &l_emlrtECI_DoaMusicSignal);
  k = iRBw_size[0];
  for (i9 = 0; i9 < k; i9++) {
    byPkOut_data[ia_data[i9] + iPkOut] = y[(int)iRBw_data[i9] - 1];
  }

  k = ia_size[0];
  for (i9 = 0; i9 < k; i9++) {
    i10 = iInfinite_data[i9];
    if (!((i10 >= 1) && (i10 <= iPkOut))) {
      rtDynamicBoundsError(i10, 1, iPkOut, &ec_emlrtBCI_DoaMusicSignal);
    }

    ia_data[i9] = i10 - 1;
  }

  g_ia[0] = ia_size[0];
  rtSubAssignSizeCheck(g_ia, 1, iInfL_size, 1, &k_emlrtECI_DoaMusicSignal);
  k = (signed char)iInf_size[0];
  for (i9 = 0; i9 < k; i9++) {
    byPkOut_data[ia_data[i9]] = y[(int)iInfL_data[i9] - 1];
  }

  k = ia_size[0];
  for (i9 = 0; i9 < k; i9++) {
    i10 = iInfinite_data[i9];
    if (!((i10 >= 1) && (i10 <= iPkOut))) {
      rtDynamicBoundsError(i10, 1, iPkOut, &fc_emlrtBCI_DoaMusicSignal);
    }

    ia_data[i9] = i10 - 1;
  }

  h_ia[0] = ia_size[0];
  rtSubAssignSizeCheck(h_ia, 1, iInfR_size, 1, &j_emlrtECI_DoaMusicSignal);
  k = (signed char)iInf_size[0];
  for (i9 = 0; i9 < k; i9++) {
    byPkOut_data[ia_data[i9] + iPkOut] = y[(int)iInfR_data[i9] - 1];
  }

  wxPkOut_size[0] = iPkOut;
  wxPkOut_size[1] = 2;
  k = iPkOut << 1;
  for (i9 = 0; i9 < k; i9++) {
    wxPkOut_data[i9] = 0.0;
  }

  for (i9 = 0; i9 < iFinite_size_idx_0; i9++) {
    i10 = iFinite_data[i9];
    if (!((i10 >= 1) && (i10 <= iPkOut))) {
      rtDynamicBoundsError(i10, 1, iPkOut, &gc_emlrtBCI_DoaMusicSignal);
    }

    ia_data[i9] = i10 - 1;
  }

  i_ia[0] = iFinite_size_idx_0;
  i_ia[1] = 2;
  rtSubAssignSizeCheck(i_ia, 2, wPk_size, 2, &i_emlrtECI_DoaMusicSignal);
  for (i9 = 0; i9 < 2; i9++) {
    k = wPk_size[0];
    for (i10 = 0; i10 < k; i10++) {
      wxPkOut_data[ia_data[i10] + iPkOut * i9] = wPk_data[i10 + wPk_size[0] * i9];
    }
  }

  i9 = (signed char)iInf_size[0];
  if (iInf_size[0] != i9) {
    rtSizeEq1DError(iInf_size[0], i9, &o_emlrtECI_DoaMusicSignal);
  }

  k = ia_size[0];
  for (i9 = 0; i9 < k; i9++) {
    i10 = iInfinite_data[i9];
    if (!((i10 >= 1) && (i10 <= iPkOut))) {
      rtDynamicBoundsError(i10, 1, iPkOut, &hc_emlrtBCI_DoaMusicSignal);
    }

    ia_data[i9] = i10 - 1;
  }

  c_size[0] = iInf_size[0];
  k = iInf_size[0];
  for (i9 = 0; i9 < k; i9++) {
    c_data[i9] = 0.5 * ((1.0 + (double)((int)iInf_data[i9] - 1)) + (1.0 +
      (double)((int)iInfL_data[i9] - 1)));
  }

  j_ia[0] = ia_size[0];
  rtSubAssignSizeCheck(j_ia, 1, c_size, 1, &h_emlrtECI_DoaMusicSignal);
  k = iInf_size[0];
  for (i9 = 0; i9 < k; i9++) {
    wxPkOut_data[ia_data[i9]] = c_data[i9];
  }

  i9 = (signed char)iInf_size[0];
  if (iInf_size[0] != i9) {
    rtSizeEq1DError(iInf_size[0], i9, &n_emlrtECI_DoaMusicSignal);
  }

  k = ia_size[0];
  for (i9 = 0; i9 < k; i9++) {
    i10 = iInfinite_data[i9];
    if (!((i10 >= 1) && (i10 <= iPkOut))) {
      rtDynamicBoundsError(i10, 1, iPkOut, &ic_emlrtBCI_DoaMusicSignal);
    }

    ia_data[i9] = i10 - 1;
  }

  c_size[0] = iInf_size[0];
  k = iInf_size[0];
  for (i9 = 0; i9 < k; i9++) {
    c_data[i9] = 0.5 * ((1.0 + (double)((int)iInf_data[i9] - 1)) + (1.0 +
      (double)((int)iInfR_data[i9] - 1)));
  }

  k_ia[0] = ia_size[0];
  rtSubAssignSizeCheck(k_ia, 1, c_size, 1, &g_emlrtECI_DoaMusicSignal);
  k = iInf_size[0];
  for (i9 = 0; i9 < k; i9++) {
    wxPkOut_data[ia_data[i9] + iPkOut] = c_data[i9];
  }
}

/*
 * Arguments    : void
 * Return Type  : void
 */
static void d_error(void)
{
  n_rtErrorWithMessageID(&b_emlrtRTEI_DoaMusicSignal);
}

/*
 * Arguments    : const rtRunTimeErrorInfo_DoaMusicSign *aInfo
 * Return Type  : void
 */
static void d_rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo)
{
  fprintf(stderr, "The power value must be non-negative");
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : double x_data[]
 *                int x_size[1]
 *                int dim
 *                int idx_data[]
 *                int idx_size[1]
 * Return Type  : void
 */
static void d_sort(double x_data[], int x_size[1], int dim, int idx_data[], int
                   idx_size[1])
{
  int i27;
  double vwork_data[246];
  int vwork_size[1];
  int vstride;
  int k;
  int j;
  int iidx_data[246];
  int iidx_size[1];
  int i28;
  int i29;
  if (dim <= 1) {
    i27 = x_size[0];
  } else {
    i27 = 1;
  }

  vwork_size[0] = (unsigned char)i27;
  idx_size[0] = (unsigned char)x_size[0];
  vstride = 1;
  if ((!(1 > dim - 1)) && (dim - 1 > 2147483646)) {
    check_forloop_overflow_error();
  }

  k = 1;
  while (k <= dim - 1) {
    vstride *= x_size[0];
    k = 2;
  }

  if ((!(1 > vstride)) && (vstride > 2147483646)) {
    check_forloop_overflow_error();
  }

  for (j = 1; j <= vstride; j++) {
    for (k = 1; k <= i27; k++) {
      i28 = x_size[0];
      i29 = j + (k - 1) * vstride;
      if (!((i29 >= 1) && (i29 <= i28))) {
        rtDynamicBoundsError(i29, 1, i28, &xh_emlrtBCI_DoaMusicSignal);
      }

      if (!((k >= 1) && (k <= vwork_size[0]))) {
        rtDynamicBoundsError(k, 1, vwork_size[0], &yh_emlrtBCI_DoaMusicSignal);
      }

      vwork_data[k - 1] = x_data[i29 - 1];
    }

    sortIdx(vwork_data, vwork_size, iidx_data, iidx_size);
    for (k = 1; k <= i27; k++) {
      if (!(k <= vwork_size[0])) {
        rtDynamicBoundsError(k, 1, vwork_size[0], &th_emlrtBCI_DoaMusicSignal);
      }

      i28 = x_size[0];
      i29 = j + (k - 1) * vstride;
      if (!((i29 >= 1) && (i29 <= i28))) {
        rtDynamicBoundsError(i29, 1, i28, &uh_emlrtBCI_DoaMusicSignal);
      }

      x_data[i29 - 1] = vwork_data[k - 1];
      if (!(k <= iidx_size[0])) {
        rtDynamicBoundsError(k, 1, iidx_size[0], &vh_emlrtBCI_DoaMusicSignal);
      }

      i28 = j + (k - 1) * vstride;
      if (!((i28 >= 1) && (i28 <= idx_size[0]))) {
        rtDynamicBoundsError(i28, 1, idx_size[0], &wh_emlrtBCI_DoaMusicSignal);
      }

      idx_data[i28 - 1] = iidx_data[k - 1];
    }
  }
}

/*
 * Arguments    : const double x_data[]
 *                const int x_size[1]
 *                double y_data[]
 *                int y_size[1]
 * Return Type  : void
 */
static void diff(const double x_data[], const int x_size[1], double y_data[],
                 int y_size[1])
{
  int b_x_size;
  int ixLead;
  int iyLead;
  double work_data_idx_0;
  int m;
  double tmp2;
  if (x_size[0] == 0) {
    y_size[0] = 0;
  } else {
    if (x_size[0] - 1 <= 1) {
      b_x_size = x_size[0] - 1;
    } else {
      b_x_size = 1;
    }

    if (b_x_size < 1) {
      y_size[0] = 0;
    } else {
      if (x_size[0] != 1) {
      } else {
        k_rtErrorWithMessageID(&k_emlrtRTEI_DoaMusicSignal);
      }

      y_size[0] = (signed char)(x_size[0] - 1);
      if (!((signed char)(x_size[0] - 1) == 0)) {
        ixLead = 2;
        iyLead = 1;
        work_data_idx_0 = x_data[0];
        for (m = 2; m <= x_size[0]; m++) {
          if (!((ixLead >= 1) && (ixLead <= x_size[0]))) {
            rtDynamicBoundsError(ixLead, 1, x_size[0],
                                 &m_emlrtBCI_DoaMusicSignal);
          }

          tmp2 = work_data_idx_0;
          work_data_idx_0 = x_data[ixLead - 1];
          tmp2 = x_data[ixLead - 1] - tmp2;
          ixLead++;
          if (!((iyLead >= 1) && (iyLead <= y_size[0]))) {
            rtDynamicBoundsError(iyLead, 1, y_size[0],
                                 &n_emlrtBCI_DoaMusicSignal);
          }

          y_data[iyLead - 1] = tmp2;
          iyLead++;
        }
      }
    }
  }
}

/*
 * Arguments    : const int z_size[1]
 *                const int varargin_1_size[1]
 *                const int varargin_2_size[1]
 * Return Type  : boolean_T
 */
static boolean_T dimagree(const int z_size[1], const int varargin_1_size[1],
  const int varargin_2_size[1])
{
  boolean_T p;
  boolean_T b_p;
  int k;
  boolean_T exitg2;
  int b_k;
  boolean_T exitg1;
  int c_k;
  int d_k;
  int e_k;
  p = true;
  b_p = true;
  k = 1;
  exitg2 = false;
  while ((!exitg2) && (k < 3)) {
    if (k <= 1) {
      b_k = z_size[0];
    } else {
      b_k = 1;
    }

    if (k <= 1) {
      c_k = varargin_1_size[0];
    } else {
      c_k = 1;
    }

    if (b_k != c_k) {
      b_p = false;
      exitg2 = true;
    } else {
      k++;
    }
  }

  if (b_p) {
    b_p = true;
    k = 1;
    exitg1 = false;
    while ((!exitg1) && (k < 3)) {
      if (k <= 1) {
        d_k = z_size[0];
      } else {
        d_k = 1;
      }

      if (k <= 1) {
        e_k = varargin_2_size[0];
      } else {
        e_k = 1;
      }

      if (d_k != e_k) {
        b_p = false;
        exitg1 = true;
      } else {
        k++;
      }
    }

    if (b_p) {
    } else {
      p = false;
    }
  } else {
    p = false;
  }

  return p;
}

/*
 * Arguments    : const double a_data[]
 *                const int a_size[1]
 *                const double b_data[]
 *                const int b_size[1]
 *                double c_data[]
 *                int c_size[1]
 *                int ia_data[]
 *                int ia_size[1]
 *                int ib_data[]
 *                int ib_size[1]
 * Return Type  : void
 */
static void do_vectors(const double a_data[], const int a_size[1], const double
  b_data[], const int b_size[1], double c_data[], int c_size[1], int ia_data[],
  int ia_size[1], int ib_data[], int ib_size[1])
{
  int na;
  int nb;
  int ncmax;
  int nc;
  int nia;
  int nib;
  int iafirst;
  int ialast;
  int ibfirst;
  int iblast;
  int b_ialast;
  double ak;
  int b_iblast;
  double bk;
  int i11;
  double absxk;
  int exponent;
  int b_ia_data[123];
  boolean_T p;
  double b_c_data[246];
  na = a_size[0];
  nb = b_size[0];
  ncmax = a_size[0] + b_size[0];
  c_size[0] = (unsigned char)ncmax;
  ia_size[0] = a_size[0];
  ib_size[0] = b_size[0];
  if (!issorted(a_data, a_size)) {
    c_error();
  }

  if (!issorted(b_data, b_size)) {
    d_error();
  }

  nc = 0;
  nia = 0;
  nib = 0;
  iafirst = 1;
  ialast = 1;
  ibfirst = 0;
  iblast = 1;
  while ((ialast <= na) && (iblast <= nb)) {
    b_ialast = ialast;
    ak = skip_to_last_equal_value(&b_ialast, a_data, a_size);
    ialast = b_ialast;
    b_iblast = iblast;
    bk = skip_to_last_equal_value(&b_iblast, b_data, b_size);
    iblast = b_iblast;
    absxk = fabs(bk / 2.0);
    if ((!rtIsInf(absxk)) && (!rtIsNaN(absxk))) {
      if (absxk <= 2.2250738585072014E-308) {
        absxk = 4.94065645841247E-324;
      } else {
        frexp(absxk, &exponent);
        absxk = ldexp(1.0, exponent - 53);
      }
    } else {
      absxk = rtNaN;
    }

    if ((fabs(bk - ak) < absxk) || (rtIsInf(ak) && rtIsInf(bk) && ((ak > 0.0) ==
          (bk > 0.0)))) {
      p = true;
    } else {
      p = false;
    }

    if (p) {
      nc++;
      i11 = (unsigned char)ncmax;
      if (!((nc >= 1) && (nc <= i11))) {
        rtDynamicBoundsError(nc, 1, i11, &uc_emlrtBCI_DoaMusicSignal);
      }

      c_data[nc - 1] = ak;
      nia++;
      if (!((nia >= 1) && (nia <= ia_size[0]))) {
        rtDynamicBoundsError(nia, 1, ia_size[0], &vc_emlrtBCI_DoaMusicSignal);
      }

      ia_data[nia - 1] = iafirst;
      ialast = b_ialast + 1;
      iafirst = b_ialast + 1;
      iblast = b_iblast + 1;
      ibfirst = b_iblast;
    } else {
      if ((ak < bk) || rtIsNaN(bk)) {
        p = true;
      } else {
        p = false;
      }

      if (p) {
        nc++;
        nia++;
        i11 = (unsigned char)ncmax;
        if (!((nc >= 1) && (nc <= i11))) {
          rtDynamicBoundsError(nc, 1, i11, &sc_emlrtBCI_DoaMusicSignal);
        }

        c_data[nc - 1] = ak;
        if (!((nia >= 1) && (nia <= ia_size[0]))) {
          rtDynamicBoundsError(nia, 1, ia_size[0], &tc_emlrtBCI_DoaMusicSignal);
        }

        ia_data[nia - 1] = iafirst;
        ialast = b_ialast + 1;
        iafirst = b_ialast + 1;
      } else {
        nc++;
        nib++;
        i11 = (unsigned char)ncmax;
        if (!((nc >= 1) && (nc <= i11))) {
          rtDynamicBoundsError(nc, 1, i11, &qc_emlrtBCI_DoaMusicSignal);
        }

        c_data[nc - 1] = bk;
        if (!((nib >= 1) && (nib <= ib_size[0]))) {
          rtDynamicBoundsError(nib, 1, ib_size[0], &rc_emlrtBCI_DoaMusicSignal);
        }

        ib_data[nib - 1] = ibfirst + 1;
        iblast = b_iblast + 1;
        ibfirst = b_iblast;
      }
    }
  }

  while (ialast <= na) {
    iafirst = ialast;
    ak = skip_to_last_equal_value(&iafirst, a_data, a_size);
    nc++;
    nia++;
    i11 = (unsigned char)ncmax;
    if (!((nc >= 1) && (nc <= i11))) {
      rtDynamicBoundsError(nc, 1, i11, &oc_emlrtBCI_DoaMusicSignal);
    }

    c_data[nc - 1] = ak;
    if (!((nia >= 1) && (nia <= ia_size[0]))) {
      rtDynamicBoundsError(nia, 1, ia_size[0], &pc_emlrtBCI_DoaMusicSignal);
    }

    ia_data[nia - 1] = ialast;
    ialast = iafirst + 1;
  }

  while (iblast <= nb) {
    iafirst = iblast;
    bk = skip_to_last_equal_value(&iafirst, b_data, b_size);
    nc++;
    nib++;
    i11 = (unsigned char)ncmax;
    if (!((nc >= 1) && (nc <= i11))) {
      rtDynamicBoundsError(nc, 1, i11, &mc_emlrtBCI_DoaMusicSignal);
    }

    c_data[nc - 1] = bk;
    if (!((nib >= 1) && (nib <= ib_size[0]))) {
      rtDynamicBoundsError(nib, 1, ib_size[0], &nc_emlrtBCI_DoaMusicSignal);
    }

    ib_data[nib - 1] = iblast;
    iblast = iafirst + 1;
  }

  if (a_size[0] > 0) {
    if (nia <= a_size[0]) {
    } else {
      j_rtErrorWithMessageID(&m_emlrtRTEI_DoaMusicSignal);
    }

    if (1 > nia) {
      nia = 0;
    } else {
      if (!(nia <= a_size[0])) {
        rtDynamicBoundsError(nia, 1, a_size[0], &jc_emlrtBCI_DoaMusicSignal);
      }
    }

    for (i11 = 0; i11 < nia; i11++) {
      b_ia_data[i11] = ia_data[i11];
    }

    ia_size[0] = nia;
    for (i11 = 0; i11 < nia; i11++) {
      ia_data[i11] = b_ia_data[i11];
    }
  }

  if (b_size[0] > 0) {
    if (nib <= b_size[0]) {
    } else {
      j_rtErrorWithMessageID(&n_emlrtRTEI_DoaMusicSignal);
    }

    if (1 > nib) {
      nib = 0;
    } else {
      if (!(nib <= b_size[0])) {
        rtDynamicBoundsError(nib, 1, b_size[0], &kc_emlrtBCI_DoaMusicSignal);
      }
    }

    for (i11 = 0; i11 < nib; i11++) {
      b_ia_data[i11] = ib_data[i11];
    }

    ib_size[0] = nib;
    for (i11 = 0; i11 < nib; i11++) {
      ib_data[i11] = b_ia_data[i11];
    }
  }

  if (ncmax > 0) {
    if (nc <= ncmax) {
    } else {
      j_rtErrorWithMessageID(&o_emlrtRTEI_DoaMusicSignal);
    }

    if (1 > nc) {
      nc = 0;
    } else {
      i11 = (unsigned char)ncmax;
      if (!(1 <= i11)) {
        rtDynamicBoundsError(1, 1, i11, &lc_emlrtBCI_DoaMusicSignal);
      }

      i11 = (unsigned char)ncmax;
      if (!(nc <= i11)) {
        rtDynamicBoundsError(nc, 1, i11, &lc_emlrtBCI_DoaMusicSignal);
      }
    }

    for (i11 = 0; i11 < nc; i11++) {
      b_c_data[i11] = c_data[i11];
    }

    c_size[0] = nc;
    for (i11 = 0; i11 < nc; i11++) {
      c_data[i11] = b_c_data[i11];
    }
  }
}

/*
 * Arguments    : const int b
 *                const char *c
 *                const rtRunTimeErrorInfo_DoaMusicSign *aInfo
 * Return Type  : void
 */
static void e_rtErrorWithMessageID(const int b, const char *c, const
  rtRunTimeErrorInfo_DoaMusicSign *aInfo)
{
  fprintf(stderr, "%.*s", b, c);
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : double x_data[]
 *                int x_size[1]
 * Return Type  : void
 */
static void e_sort(double x_data[], int x_size[1])
{
  int dim;
  int i33;
  double vwork_data[246];
  int vwork_size[1];
  unsigned char x_idx_0;
  int vstride;
  int k;
  int iidx_data[246];
  int iidx_size[1];
  int i34;
  int i35;
  dim = nonSingletonDim(x_size) - 1;
  if (dim + 1 <= 1) {
    i33 = x_size[0];
  } else {
    i33 = 1;
  }

  vwork_size[0] = (unsigned char)i33;
  x_idx_0 = (unsigned char)x_size[0];
  vstride = 1;
  if ((!(1 > dim)) && (dim > 2147483646)) {
    check_forloop_overflow_error();
  }

  k = 1;
  while (k <= dim) {
    vstride *= x_size[0];
    k = 2;
  }

  if ((!(1 > vstride)) && (vstride > 2147483646)) {
    check_forloop_overflow_error();
  }

  for (dim = 1; dim <= vstride; dim++) {
    for (k = 1; k <= i33; k++) {
      i34 = x_size[0];
      i35 = dim + (k - 1) * vstride;
      if (!((i35 >= 1) && (i35 <= i34))) {
        rtDynamicBoundsError(i35, 1, i34, &xh_emlrtBCI_DoaMusicSignal);
      }

      if (!((k >= 1) && (k <= vwork_size[0]))) {
        rtDynamicBoundsError(k, 1, vwork_size[0], &yh_emlrtBCI_DoaMusicSignal);
      }

      vwork_data[k - 1] = x_data[i35 - 1];
    }

    b_sortIdx(vwork_data, vwork_size, iidx_data, iidx_size);
    for (k = 1; k <= i33; k++) {
      if (!(k <= vwork_size[0])) {
        rtDynamicBoundsError(k, 1, vwork_size[0], &th_emlrtBCI_DoaMusicSignal);
      }

      i34 = x_size[0];
      i35 = dim + (k - 1) * vstride;
      if (!((i35 >= 1) && (i35 <= i34))) {
        rtDynamicBoundsError(i35, 1, i34, &uh_emlrtBCI_DoaMusicSignal);
      }

      x_data[i35 - 1] = vwork_data[k - 1];
      i34 = x_idx_0;
      i35 = dim + (k - 1) * vstride;
      if (!((i35 >= 1) && (i35 <= i34))) {
        rtDynamicBoundsError(i35, 1, i34, &wh_emlrtBCI_DoaMusicSignal);
      }

      if (!(k <= iidx_size[0])) {
        rtDynamicBoundsError(k, 1, iidx_size[0], &vh_emlrtBCI_DoaMusicSignal);
      }
    }
  }
}

/*
 * Arguments    : const creal_T A[16]
 *                creal_T V[16]
 *                creal_T D[4]
 * Return Type  : void
 */
static void eig(const creal_T A[16], creal_T V[16], creal_T D[4])
{
  creal_T At[16];
  int info;
  creal_T beta1[4];
  int coltop;
  double colnorm;
  double scale;
  double t;
  double absxk;
  memcpy(&At[0], &A[0], sizeof(creal_T) << 4);
  xzggev(At, &info, D, beta1, V);
  for (coltop = 0; coltop <= 13; coltop += 4) {
    colnorm = 0.0;
    scale = 2.2250738585072014E-308;
    for (info = coltop; info + 1 <= coltop + 4; info++) {
      absxk = fabs(V[info].re);
      if (absxk > scale) {
        t = scale / absxk;
        colnorm = 1.0 + colnorm * t * t;
        scale = absxk;
      } else {
        t = absxk / scale;
        colnorm += t * t;
      }

      absxk = fabs(V[info].im);
      if (absxk > scale) {
        t = scale / absxk;
        colnorm = 1.0 + colnorm * t * t;
        scale = absxk;
      } else {
        t = absxk / scale;
        colnorm += t * t;
      }
    }

    colnorm = scale * sqrt(colnorm);
    for (info = coltop; info + 1 <= coltop + 4; info++) {
      if (V[info].im == 0.0) {
        V[info].re /= colnorm;
        V[info].im = 0.0;
      } else if (V[info].re == 0.0) {
        V[info].re = 0.0;
        V[info].im /= colnorm;
      } else {
        V[info].re /= colnorm;
        V[info].im /= colnorm;
      }
    }
  }

  for (info = 0; info < 4; info++) {
    t = D[info].re;
    if (beta1[info].im == 0.0) {
      if (D[info].im == 0.0) {
        D[info].re /= beta1[info].re;
        D[info].im = 0.0;
      } else if (D[info].re == 0.0) {
        D[info].re = 0.0;
        D[info].im /= beta1[info].re;
      } else {
        D[info].re /= beta1[info].re;
        D[info].im /= beta1[info].re;
      }
    } else if (beta1[info].re == 0.0) {
      if (D[info].re == 0.0) {
        D[info].re = D[info].im / beta1[info].im;
        D[info].im = 0.0;
      } else if (D[info].im == 0.0) {
        D[info].re = 0.0;
        D[info].im = -(t / beta1[info].im);
      } else {
        D[info].re = D[info].im / beta1[info].im;
        D[info].im = -(t / beta1[info].im);
      }
    } else {
      absxk = fabs(beta1[info].re);
      colnorm = fabs(beta1[info].im);
      if (absxk > colnorm) {
        colnorm = beta1[info].im / beta1[info].re;
        scale = beta1[info].re + colnorm * beta1[info].im;
        D[info].re = (D[info].re + colnorm * D[info].im) / scale;
        D[info].im = (D[info].im - colnorm * t) / scale;
      } else if (colnorm == absxk) {
        if (beta1[info].re > 0.0) {
          colnorm = 0.5;
        } else {
          colnorm = -0.5;
        }

        if (beta1[info].im > 0.0) {
          scale = 0.5;
        } else {
          scale = -0.5;
        }

        D[info].re = (D[info].re * colnorm + D[info].im * scale) / absxk;
        D[info].im = (D[info].im * colnorm - t * scale) / absxk;
      } else {
        colnorm = beta1[info].re / beta1[info].im;
        scale = beta1[info].im + colnorm * beta1[info].re;
        D[info].re = (colnorm * D[info].re + D[info].im) / scale;
        D[info].im = (colnorm * D[info].im - t) / scale;
      }
    }
  }
}

/*
 * Arguments    : void
 * Return Type  : void
 */
static void error(void)
{
  b_rtErrorWithMessageID(4, "sqrt", &b_emlrtRTEI_DoaMusicSignal);
}

/*
 * Arguments    : const int b
 *                const char *c
 *                const rtRunTimeErrorInfo_DoaMusicSign *aInfo
 * Return Type  : void
 */
static void f_rtErrorWithMessageID(const int b, const char *c, const
  rtRunTimeErrorInfo_DoaMusicSign *aInfo)
{
  fprintf(stderr, "%.*s", b, c);
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const double idx_data[]
 *                const int idx_size[1]
 *                double bPk_data[]
 *                int bPk_size[1]
 *                double bxPk_data[]
 *                int bxPk_size[2]
 *                double byPk_data[]
 *                int byPk_size[2]
 *                double wxPk_data[]
 *                int wxPk_size[2]
 * Return Type  : void
 */
static void fetchPeakExtents(const double idx_data[], const int idx_size[1],
  double bPk_data[], int bPk_size[1], double bxPk_data[], int bxPk_size[2],
  double byPk_data[], int byPk_size[2], double wxPk_data[], int wxPk_size[2])
{
  int bPk;
  double b_bPk_data[246];
  int loop_ub;
  int i41;
  int i42;
  double b_bxPk_data[492];
  int bxPk_size_idx_0;
  int i43;
  bPk = bPk_size[0];
  loop_ub = idx_size[0];
  for (i41 = 0; i41 < loop_ub; i41++) {
    i42 = (int)idx_data[i41];
    if (!((i42 >= 1) && (i42 <= bPk))) {
      rtDynamicBoundsError(i42, 1, bPk, &gk_emlrtBCI_DoaMusicSignal);
    }

    b_bPk_data[i41] = bPk_data[i42 - 1];
  }

  bPk_size[0] = idx_size[0];
  loop_ub = idx_size[0];
  for (i41 = 0; i41 < loop_ub; i41++) {
    bPk_data[i41] = b_bPk_data[i41];
  }

  bPk = bxPk_size[0];
  bxPk_size_idx_0 = idx_size[0];
  for (i41 = 0; i41 < 2; i41++) {
    loop_ub = idx_size[0];
    for (i42 = 0; i42 < loop_ub; i42++) {
      i43 = (int)idx_data[i42];
      if (!((i43 >= 1) && (i43 <= bPk))) {
        rtDynamicBoundsError(i43, 1, bPk, &hk_emlrtBCI_DoaMusicSignal);
      }

      b_bxPk_data[i42 + bxPk_size_idx_0 * i41] = bxPk_data[(i43 + bxPk_size[0] *
        i41) - 1];
    }
  }

  bxPk_size[0] = idx_size[0];
  bxPk_size[1] = 2;
  for (i41 = 0; i41 < 2; i41++) {
    for (i42 = 0; i42 < bxPk_size_idx_0; i42++) {
      bxPk_data[i42 + bxPk_size[0] * i41] = b_bxPk_data[i42 + bxPk_size_idx_0 *
        i41];
    }
  }

  bPk = byPk_size[0];
  bxPk_size_idx_0 = idx_size[0];
  for (i41 = 0; i41 < 2; i41++) {
    loop_ub = idx_size[0];
    for (i42 = 0; i42 < loop_ub; i42++) {
      i43 = (int)idx_data[i42];
      if (!((i43 >= 1) && (i43 <= bPk))) {
        rtDynamicBoundsError(i43, 1, bPk, &ik_emlrtBCI_DoaMusicSignal);
      }

      b_bxPk_data[i42 + bxPk_size_idx_0 * i41] = byPk_data[(i43 + byPk_size[0] *
        i41) - 1];
    }
  }

  byPk_size[0] = idx_size[0];
  byPk_size[1] = 2;
  for (i41 = 0; i41 < 2; i41++) {
    for (i42 = 0; i42 < bxPk_size_idx_0; i42++) {
      byPk_data[i42 + byPk_size[0] * i41] = b_bxPk_data[i42 + bxPk_size_idx_0 *
        i41];
    }
  }

  bPk = wxPk_size[0];
  bxPk_size_idx_0 = idx_size[0];
  for (i41 = 0; i41 < 2; i41++) {
    loop_ub = idx_size[0];
    for (i42 = 0; i42 < loop_ub; i42++) {
      i43 = (int)idx_data[i42];
      if (!((i43 >= 1) && (i43 <= bPk))) {
        rtDynamicBoundsError(i43, 1, bPk, &jk_emlrtBCI_DoaMusicSignal);
      }

      b_bxPk_data[i42 + bxPk_size_idx_0 * i41] = wxPk_data[(i43 + wxPk_size[0] *
        i41) - 1];
    }
  }

  wxPk_size[0] = idx_size[0];
  wxPk_size[1] = 2;
  for (i41 = 0; i41 < 2; i41++) {
    for (i42 = 0; i42 < bxPk_size_idx_0; i42++) {
      wxPk_data[i42 + wxPk_size[0] * i41] = b_bxPk_data[i42 + bxPk_size_idx_0 *
        i41];
    }
  }
}

/*
 * Arguments    : const double y[123]
 *                double iPk_data[]
 *                int iPk_size[1]
 *                const double iFin_data[]
 *                const int iFin_size[1]
 *                const double iInf_data[]
 *                const int iInf_size[1]
 *                const double iInflect_data[]
 *                const int iInflect_size[1]
 *                double bPk_data[]
 *                int bPk_size[1]
 *                double bxPk_data[]
 *                int bxPk_size[2]
 *                double byPk_data[]
 *                int byPk_size[2]
 *                double wxPk_data[]
 *                int wxPk_size[2]
 * Return Type  : void
 */
static void findExtents(const double y[123], double iPk_data[], int iPk_size[1],
  const double iFin_data[], const int iFin_size[1], const double iInf_data[],
  const int iInf_size[1], const double iInflect_data[], const int iInflect_size
  [1], double bPk_data[], int bPk_size[1], double bxPk_data[], int bxPk_size[2],
  double byPk_data[], int byPk_size[2], double wxPk_data[], int wxPk_size[2])
{
  double yFinite[123];
  int loop_ub;
  int i20;
  int tmp_data[123];
  double b_bPk_data[123];
  int b_bPk_size[1];
  double iLB_data[123];
  int iLB_size[1];
  double iRB_data[123];
  int iRB_size[1];
  int b_iPk_size[1];
  double b_iPk_data[123];
  double b_wxPk_data[246];
  int b_wxPk_size[2];
  memcpy(&yFinite[0], &y[0], 123U * sizeof(double));
  loop_ub = iInf_size[0];
  for (i20 = 0; i20 < loop_ub; i20++) {
    tmp_data[i20] = (int)iInf_data[i20];
  }

  loop_ub = iInf_size[0];
  for (i20 = 0; i20 < loop_ub; i20++) {
    yFinite[tmp_data[i20] - 1] = rtNaN;
  }

  getPeakBase(yFinite, iPk_data, iPk_size, iFin_data, iFin_size, iInflect_data,
              iInflect_size, b_bPk_data, b_bPk_size, iLB_data, iLB_size,
              iRB_data, iRB_size);
  b_iPk_size[0] = iPk_size[0];
  loop_ub = iPk_size[0];
  for (i20 = 0; i20 < loop_ub; i20++) {
    b_iPk_data[i20] = iPk_data[i20];
  }

  c_removePeaksBelowMinPeakPromin(yFinite, b_iPk_data, b_iPk_size, b_bPk_data,
    b_bPk_size, iLB_data, iLB_size, iRB_data, iRB_size);
  getPeakWidth(yFinite, b_iPk_data, b_iPk_size, b_bPk_data, b_bPk_size, iLB_data,
               iLB_size, iRB_data, iRB_size, b_wxPk_data, b_wxPk_size);
  combineFullPeaks(y, b_iPk_data, b_iPk_size, b_bPk_data, b_bPk_size, iLB_data,
                   iLB_size, iRB_data, iRB_size, b_wxPk_data, b_wxPk_size,
                   iInf_data, iInf_size, iPk_data, iPk_size, bPk_data, bPk_size,
                   bxPk_data, bxPk_size, byPk_data, byPk_size, wxPk_data,
                   wxPk_size);
}

/*
 * Arguments    : const double yTemp[123]
 *                double iPk_data[]
 *                int iPk_size[1]
 *                double iInflect_data[]
 *                int iInflect_size[1]
 * Return Type  : void
 */
static void findLocalMaxima(const double yTemp[123], double iPk_data[], int
  iPk_size[1], double iInflect_data[], int iInflect_size[1])
{
  double b_yTemp[125];
  boolean_T yFinite[125];
  int nx;
  boolean_T x[124];
  int idx;
  signed char ii_data[124];
  int ii;
  boolean_T exitg3;
  boolean_T guard3 = false;
  int loop_ub;
  signed char tmp_data[125];
  int i5;
  int i6;
  int b_loop_ub;
  double yTemp_data[125];
  signed char iTemp_data[125];
  int yTemp_size[1];
  double s_data[124];
  int s_size[1];
  double b_tmp_data[124];
  boolean_T x_data[123];
  int b_ii_data[123];
  int ii_size_idx_0;
  boolean_T exitg2;
  boolean_T guard2 = false;
  boolean_T b_guard2 = false;
  boolean_T nonSingletonDimFound;
  int iv0[2];
  int iv1[2];
  int c_ii_data[123];
  boolean_T exitg1;
  boolean_T guard1 = false;
  boolean_T b_guard1 = false;
  b_yTemp[0] = rtNaN;
  memcpy(&b_yTemp[1], &yTemp[0], 123U * sizeof(double));
  b_yTemp[124] = rtNaN;
  for (nx = 0; nx < 125; nx++) {
    yFinite[nx] = !rtIsNaN(b_yTemp[nx]);
  }

  for (nx = 0; nx < 124; nx++) {
    x[nx] = ((b_yTemp[nx] != b_yTemp[nx + 1]) && (yFinite[nx] || yFinite[nx + 1]));
  }

  idx = 0;
  ii = 1;
  exitg3 = false;
  while ((!exitg3) && (ii < 125)) {
    guard3 = false;
    if (x[ii - 1]) {
      idx++;
      ii_data[idx - 1] = (signed char)ii;
      if (idx >= 124) {
        exitg3 = true;
      } else {
        guard3 = true;
      }
    } else {
      guard3 = true;
    }

    if (guard3) {
      ii++;
    }
  }

  if (1 > idx) {
    loop_ub = 0;
  } else {
    loop_ub = idx;
  }

  tmp_data[0] = 1;
  for (i5 = 0; i5 < loop_ub; i5++) {
    tmp_data[i5 + 1] = (signed char)(ii_data[i5] + 1);
  }

  if (1 > idx) {
    i6 = 0;
  } else {
    i6 = idx;
  }

  b_loop_ub = 1 + i6;
  for (i5 = 0; i5 < b_loop_ub; i5++) {
    iTemp_data[i5] = tmp_data[i5];
  }

  yTemp_size[0] = 1 + loop_ub;
  b_loop_ub = 1 + loop_ub;
  for (i5 = 0; i5 < b_loop_ub; i5++) {
    yTemp_data[i5] = b_yTemp[iTemp_data[i5] - 1];
  }

  diff(yTemp_data, yTemp_size, s_data, s_size);
  b_sign(s_data, s_size);
  diff(s_data, s_size, b_tmp_data, yTemp_size);
  b_loop_ub = yTemp_size[0];
  for (i5 = 0; i5 < b_loop_ub; i5++) {
    x_data[i5] = (b_tmp_data[i5] < 0.0);
  }

  nx = yTemp_size[0];
  idx = 0;
  ii_size_idx_0 = yTemp_size[0];
  ii = 1;
  exitg2 = false;
  while ((!exitg2) && (ii <= nx)) {
    if (!((ii >= 1) && (ii <= yTemp_size[0]))) {
      rtDynamicBoundsError(ii, 1, yTemp_size[0], &i_emlrtBCI_DoaMusicSignal);
    }

    guard2 = false;
    if (x_data[ii - 1]) {
      idx++;
      if (!((idx >= 1) && (idx <= ii_size_idx_0))) {
        rtDynamicBoundsError(idx, 1, ii_size_idx_0, &j_emlrtBCI_DoaMusicSignal);
      }

      b_ii_data[idx - 1] = ii;
      if (idx >= nx) {
        exitg2 = true;
      } else {
        guard2 = true;
      }
    } else {
      guard2 = true;
    }

    if (guard2) {
      ii++;
    }
  }

  if (idx <= yTemp_size[0]) {
  } else {
    j_rtErrorWithMessageID(&j_emlrtRTEI_DoaMusicSignal);
  }

  if (yTemp_size[0] == 1) {
    if (idx == 0) {
      ii_size_idx_0 = 0;
    }
  } else {
    if (1 > idx) {
      idx = 0;
    } else {
      if (!(1 <= yTemp_size[0])) {
        rtDynamicBoundsError(1, 1, yTemp_size[0], &g_emlrtBCI_DoaMusicSignal);
      }

      if (!(idx <= yTemp_size[0])) {
        rtDynamicBoundsError(idx, 1, yTemp_size[0], &g_emlrtBCI_DoaMusicSignal);
      }
    }

    b_guard2 = false;
    if (!(yTemp_size[0] != 1)) {
      nonSingletonDimFound = false;
      if (idx != 1) {
        nonSingletonDimFound = true;
      }

      if (nonSingletonDimFound) {
        nonSingletonDimFound = true;
      } else {
        b_guard2 = true;
      }
    } else {
      b_guard2 = true;
    }

    if (b_guard2) {
      nonSingletonDimFound = false;
    }

    if (!nonSingletonDimFound) {
    } else {
      i_rtErrorWithMessageID(&i_emlrtRTEI_DoaMusicSignal);
    }

    ii_size_idx_0 = idx;
  }

  if (1 > s_size[0] - 1) {
    b_loop_ub = 0;
  } else {
    if (!(1 <= s_size[0])) {
      rtDynamicBoundsError(1, 1, s_size[0], &h_emlrtBCI_DoaMusicSignal);
    }

    b_loop_ub = s_size[0] - 1;
    if (!((b_loop_ub >= 1) && (b_loop_ub <= s_size[0]))) {
      rtDynamicBoundsError(b_loop_ub, 1, s_size[0], &h_emlrtBCI_DoaMusicSignal);
    }
  }

  iv0[0] = 1;
  iv0[1] = b_loop_ub;
  indexShapeCheck(s_size[0], iv0);
  if (2 > s_size[0]) {
    i5 = 0;
    nx = 0;
  } else {
    i5 = 1;
    nx = s_size[0];
  }

  iv1[0] = 1;
  iv1[1] = nx - i5;
  indexShapeCheck(s_size[0], iv1);
  nx -= i5;
  if (b_loop_ub != nx) {
    rtSizeEq1DError(b_loop_ub, nx, &emlrtECI_DoaMusicSignal);
  }

  for (nx = 0; nx < b_loop_ub; nx++) {
    x_data[nx] = (s_data[nx] != s_data[i5 + nx]);
  }

  idx = 0;
  ii = 1;
  exitg1 = false;
  while ((!exitg1) && (ii <= b_loop_ub)) {
    if (!((ii >= 1) && (ii <= b_loop_ub))) {
      rtDynamicBoundsError(ii, 1, b_loop_ub, &i_emlrtBCI_DoaMusicSignal);
    }

    guard1 = false;
    if (x_data[ii - 1]) {
      idx++;
      if (!((idx >= 1) && (idx <= b_loop_ub))) {
        rtDynamicBoundsError(idx, 1, b_loop_ub, &j_emlrtBCI_DoaMusicSignal);
      }

      c_ii_data[idx - 1] = ii;
      if (idx >= b_loop_ub) {
        exitg1 = true;
      } else {
        guard1 = true;
      }
    } else {
      guard1 = true;
    }

    if (guard1) {
      ii++;
    }
  }

  if (idx <= b_loop_ub) {
  } else {
    j_rtErrorWithMessageID(&j_emlrtRTEI_DoaMusicSignal);
  }

  if (b_loop_ub == 1) {
    if (idx == 0) {
      b_loop_ub = 0;
    }
  } else {
    if (1 > idx) {
      idx = 0;
    } else {
      if (!(1 <= b_loop_ub)) {
        rtDynamicBoundsError(1, 1, b_loop_ub, &g_emlrtBCI_DoaMusicSignal);
      }

      if (!(idx <= b_loop_ub)) {
        rtDynamicBoundsError(idx, 1, b_loop_ub, &g_emlrtBCI_DoaMusicSignal);
      }
    }

    b_guard1 = false;
    if (!(b_loop_ub != 1)) {
      nonSingletonDimFound = false;
      if (idx != 1) {
        nonSingletonDimFound = true;
      }

      if (nonSingletonDimFound) {
        nonSingletonDimFound = true;
      } else {
        b_guard1 = true;
      }
    } else {
      b_guard1 = true;
    }

    if (b_guard1) {
      nonSingletonDimFound = false;
    }

    if (!nonSingletonDimFound) {
    } else {
      i_rtErrorWithMessageID(&i_emlrtRTEI_DoaMusicSignal);
    }

    b_loop_ub = idx;
  }

  iInflect_size[0] = b_loop_ub;
  for (i5 = 0; i5 < b_loop_ub; i5++) {
    nx = 1 + loop_ub;
    ii = c_ii_data[i5] + 1;
    if (!((ii >= 1) && (ii <= nx))) {
      rtDynamicBoundsError(ii, 1, nx, &k_emlrtBCI_DoaMusicSignal);
    }

    iInflect_data[i5] = (double)iTemp_data[ii - 1] - 1.0;
  }

  iPk_size[0] = ii_size_idx_0;
  for (i5 = 0; i5 < ii_size_idx_0; i5++) {
    nx = 1 + loop_ub;
    ii = b_ii_data[i5] + 1;
    if (!((ii >= 1) && (ii <= nx))) {
      rtDynamicBoundsError(ii, 1, nx, &l_emlrtBCI_DoaMusicSignal);
    }

    iPk_data[i5] = (double)iTemp_data[ii - 1] - 1.0;
  }
}

/*
 * Arguments    : const double Yin[123]
 *                double varargin_2
 *                double varargin_8
 *                double Ypk_data[]
 *                int Ypk_size[2]
 *                double Xpk_data[]
 *                int Xpk_size[2]
 * Return Type  : void
 */
static void findpeaks(const double Yin[123], double varargin_2, double
                      varargin_8, double Ypk_data[], int Ypk_size[2], double
                      Xpk_data[], int Xpk_size[2])
{
  double y[123];
  double minD;
  double maxN;
  double iFinite_data[123];
  int iFinite_size[1];
  double iInfite_data[123];
  int iInfite_size[1];
  double iInflect_data[123];
  int iInflect_size[1];
  int tmp_size[1];
  int loop_ub;
  int i2;
  double tmp_data[123];
  int iPk_size[1];
  double iPk_data[246];
  double bPk_data[246];
  int bPk_size[1];
  double bxPk_data[492];
  int bxPk_size[2];
  double byPk_data[492];
  int byPk_size[2];
  double wxPk_data[492];
  int wxPk_size[2];
  double idx_data[246];
  double b_iPk_data[246];
  int b_iPk_size[1];
  int i3;
  parse_inputs(Yin, varargin_2, varargin_8, y, &minD, &maxN);
  getAllPeaks(y, iFinite_data, iFinite_size, iInfite_data, iInfite_size,
              iInflect_data, iInflect_size);
  tmp_size[0] = iFinite_size[0];
  loop_ub = iFinite_size[0];
  for (i2 = 0; i2 < loop_ub; i2++) {
    tmp_data[i2] = iFinite_data[i2];
  }

  removePeaksBelowMinPeakHeight(y, tmp_data, tmp_size);
  iPk_size[0] = tmp_size[0];
  loop_ub = tmp_size[0];
  for (i2 = 0; i2 < loop_ub; i2++) {
    iPk_data[i2] = tmp_data[i2];
  }

  loop_ub = iPk_size[0];
  for (i2 = 0; i2 < loop_ub; i2++) {
    tmp_data[i2] = iPk_data[i2];
  }

  removePeaksBelowThreshold(y, tmp_data, tmp_size);
  iPk_size[0] = tmp_size[0];
  loop_ub = tmp_size[0];
  for (i2 = 0; i2 < loop_ub; i2++) {
    iPk_data[i2] = tmp_data[i2];
  }

  findExtents(y, iPk_data, iPk_size, iFinite_data, iFinite_size, iInfite_data,
              iInfite_size, iInflect_data, iInflect_size, bPk_data, bPk_size,
              bxPk_data, bxPk_size, byPk_data, byPk_size, wxPk_data, wxPk_size);
  c_findPeaksSeparatedByMoreThanM(y, iPk_data, iPk_size, minD, idx_data,
    tmp_size);
  keepAtMostNpPeaks(tmp_size, maxN);
  loop_ub = tmp_size[0];
  for (i2 = 0; i2 < loop_ub; i2++) {
    if (idx_data[i2] != (int)floor(idx_data[i2])) {
      rtIntegerError(idx_data[i2], &emlrtDCI_DoaMusicSignal);
    }

    i3 = (int)idx_data[i2];
    if (!((i3 >= 1) && (i3 <= iPk_size[0]))) {
      rtDynamicBoundsError(i3, 1, iPk_size[0], &f_emlrtBCI_DoaMusicSignal);
    }
  }

  fetchPeakExtents(idx_data, tmp_size, bPk_data, bPk_size, bxPk_data, bxPk_size,
                   byPk_data, byPk_size, wxPk_data, wxPk_size);
  b_iPk_size[0] = tmp_size[0];
  loop_ub = tmp_size[0];
  for (i2 = 0; i2 < loop_ub; i2++) {
    b_iPk_data[i2] = iPk_data[(int)idx_data[i2] - 1];
  }

  assignFullOutputs(y, b_iPk_data, b_iPk_size, wxPk_data, wxPk_size, bPk_data,
                    bPk_size, Ypk_data, Ypk_size, Xpk_data, Xpk_size, iPk_data,
                    bxPk_size, idx_data, byPk_size);
}

/*
 * Arguments    : double x_data[]
 *                int x_size[1]
 * Return Type  : void
 */
static void flipud(double x_data[], int x_size[1])
{
  int m;
  int md2;
  int i;
  int i21;
  double xtmp;
  int i22;
  m = x_size[0] + 1;
  md2 = x_size[0] >> 1;
  for (i = 1; i <= md2; i++) {
    i21 = x_size[0];
    if (!(i <= i21)) {
      rtDynamicBoundsError(i, 1, i21, &jg_emlrtBCI_DoaMusicSignal);
    }

    xtmp = x_data[i - 1];
    i21 = x_size[0];
    i22 = m - i;
    if (!((i22 >= 1) && (i22 <= i21))) {
      rtDynamicBoundsError(i22, 1, i21, &kg_emlrtBCI_DoaMusicSignal);
    }

    i21 = x_size[0];
    if (!(i <= i21)) {
      rtDynamicBoundsError(i, 1, i21, &lg_emlrtBCI_DoaMusicSignal);
    }

    x_data[i - 1] = x_data[i22 - 1];
    i21 = x_size[0];
    i22 = m - i;
    if (!((i22 >= 1) && (i22 <= i21))) {
      rtDynamicBoundsError(i22, 1, i21, &mg_emlrtBCI_DoaMusicSignal);
    }

    x_data[i22 - 1] = xtmp;
  }
}

/*
 * Arguments    : const int b
 *                const char *c
 *                const rtRunTimeErrorInfo_DoaMusicSign *aInfo
 * Return Type  : void
 */
static void g_rtErrorWithMessageID(const int b, const char *c, const
  rtRunTimeErrorInfo_DoaMusicSign *aInfo)
{
  fprintf(stderr, "%.*s", b, c);
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const double y[123]
 *                double iPk_data[]
 *                int iPk_size[1]
 *                double iInf_data[]
 *                int iInf_size[1]
 *                double iInflect_data[]
 *                int iInflect_size[1]
 * Return Type  : void
 */
static void getAllPeaks(const double y[123], double iPk_data[], int iPk_size[1],
  double iInf_data[], int iInf_size[1], double iInflect_data[], int
  iInflect_size[1])
{
  boolean_T x[123];
  int idx;
  signed char ii_data[123];
  int ii;
  boolean_T exitg1;
  boolean_T guard1 = false;
  double yTemp[123];
  int i4;
  for (idx = 0; idx < 123; idx++) {
    x[idx] = (rtIsInf(y[idx]) && (y[idx] > 0.0));
  }

  idx = 0;
  ii = 1;
  exitg1 = false;
  while ((!exitg1) && (ii < 124)) {
    guard1 = false;
    if (x[ii - 1]) {
      idx++;
      ii_data[idx - 1] = (signed char)ii;
      if (idx >= 123) {
        exitg1 = true;
      } else {
        guard1 = true;
      }
    } else {
      guard1 = true;
    }

    if (guard1) {
      ii++;
    }
  }

  if (1 > idx) {
    idx = 0;
  }

  iInf_size[0] = idx;
  for (ii = 0; ii < idx; ii++) {
    iInf_data[ii] = ii_data[ii];
  }

  memcpy(&yTemp[0], &y[0], 123U * sizeof(double));
  for (ii = 0; ii < idx; ii++) {
    i4 = (int)iInf_data[ii];
    ii_data[ii] = (signed char)i4;
  }

  for (ii = 0; ii < idx; ii++) {
    yTemp[ii_data[ii] - 1] = rtNaN;
  }

  findLocalMaxima(yTemp, iPk_data, iPk_size, iInflect_data, iInflect_size);
}

/*
 * Arguments    : const double yTemp[123]
 *                const double iPeak_data[]
 *                const int iPeak_size[1]
 *                const double iFinite_data[]
 *                const int iFinite_size[1]
 *                const double iInflect_data[]
 *                const int iInflect_size[1]
 *                double iBase_data[]
 *                int iBase_size[1]
 *                double iSaddle_data[]
 *                int iSaddle_size[1]
 * Return Type  : void
 */
static void getLeftBase(const double yTemp[123], const double iPeak_data[],
  const int iPeak_size[1], const double iFinite_data[], const int iFinite_size[1],
  const double iInflect_data[], const int iInflect_size[1], double iBase_data[],
  int iBase_size[1], double iSaddle_data[], int iSaddle_size[1])
{
  int n;
  int i8;
  int peak_size_idx_0;
  int valley_size_idx_0;
  double peak_data[123];
  int iValley_size_idx_0;
  double valley_data[123];
  double iValley_data[123];
  int i;
  int j;
  int k;
  double v;
  double iv;
  int exitg3;
  double p;
  boolean_T exitg2;
  boolean_T exitg4;
  double isv;
  boolean_T exitg1;
  iBase_size[0] = (signed char)iPeak_size[0];
  n = (signed char)iPeak_size[0];
  for (i8 = 0; i8 < n; i8++) {
    iBase_data[i8] = 0.0;
  }

  iSaddle_size[0] = (signed char)iPeak_size[0];
  n = (signed char)iPeak_size[0];
  for (i8 = 0; i8 < n; i8++) {
    iSaddle_data[i8] = 0.0;
  }

  peak_size_idx_0 = (signed char)iFinite_size[0];
  n = (signed char)iFinite_size[0];
  for (i8 = 0; i8 < n; i8++) {
    peak_data[i8] = 0.0;
  }

  valley_size_idx_0 = (signed char)iFinite_size[0];
  n = (signed char)iFinite_size[0];
  for (i8 = 0; i8 < n; i8++) {
    valley_data[i8] = 0.0;
  }

  iValley_size_idx_0 = (signed char)iFinite_size[0];
  n = (signed char)iFinite_size[0];
  for (i8 = 0; i8 < n; i8++) {
    iValley_data[i8] = 0.0;
  }

  n = 0;
  i = 1;
  j = 1;
  k = 1;
  v = rtNaN;
  iv = 1.0;
  while (k <= iPeak_size[0]) {
    do {
      exitg3 = 0;
      if (!((i >= 1) && (i <= iInflect_size[0]))) {
        rtDynamicBoundsError(i, 1, iInflect_size[0], &t_emlrtBCI_DoaMusicSignal);
      }

      if (!((j >= 1) && (j <= iFinite_size[0]))) {
        rtDynamicBoundsError(j, 1, iFinite_size[0], &u_emlrtBCI_DoaMusicSignal);
      }

      if (iInflect_data[i - 1] != iFinite_data[j - 1]) {
        if (!((i >= 1) && (i <= iInflect_size[0]))) {
          rtDynamicBoundsError(i, 1, iInflect_size[0],
                               &ob_emlrtBCI_DoaMusicSignal);
        }

        i8 = (int)iInflect_data[i - 1];
        if (!((i8 >= 1) && (i8 <= 123))) {
          rtDynamicBoundsError(i8, 1, 123, &nb_emlrtBCI_DoaMusicSignal);
        }

        v = yTemp[i8 - 1];
        if (!((i >= 1) && (i <= iInflect_size[0]))) {
          rtDynamicBoundsError(i, 1, iInflect_size[0],
                               &pb_emlrtBCI_DoaMusicSignal);
        }

        iv = iInflect_data[i - 1];
        if (rtIsNaN(yTemp[(int)iInflect_data[i - 1] - 1])) {
          n = 0;
        } else {
          exitg4 = false;
          while ((!exitg4) && (n > 0)) {
            if (!(n <= valley_size_idx_0)) {
              rtDynamicBoundsError(n, 1, valley_size_idx_0,
                                   &qb_emlrtBCI_DoaMusicSignal);
            }

            if (valley_data[n - 1] > v) {
              n--;
            } else {
              exitg4 = true;
            }
          }
        }

        i++;
      } else {
        exitg3 = 1;
      }
    } while (exitg3 == 0);

    if (!((i >= 1) && (i <= iInflect_size[0]))) {
      rtDynamicBoundsError(i, 1, iInflect_size[0], &w_emlrtBCI_DoaMusicSignal);
    }

    i8 = (int)iInflect_data[i - 1];
    if (!((i8 >= 1) && (i8 <= 123))) {
      rtDynamicBoundsError(i8, 1, 123, &v_emlrtBCI_DoaMusicSignal);
    }

    p = yTemp[i8 - 1];
    exitg2 = false;
    while ((!exitg2) && (n > 0)) {
      if (!(n <= peak_size_idx_0)) {
        rtDynamicBoundsError(n, 1, peak_size_idx_0, &x_emlrtBCI_DoaMusicSignal);
      }

      if (peak_data[n - 1] < p) {
        if (!(n <= valley_size_idx_0)) {
          rtDynamicBoundsError(n, 1, valley_size_idx_0,
                               &kb_emlrtBCI_DoaMusicSignal);
        }

        if (valley_data[n - 1] < v) {
          if (!(n <= valley_size_idx_0)) {
            rtDynamicBoundsError(n, 1, valley_size_idx_0,
                                 &lb_emlrtBCI_DoaMusicSignal);
          }

          v = valley_data[n - 1];
          if (!(n <= iValley_size_idx_0)) {
            rtDynamicBoundsError(n, 1, iValley_size_idx_0,
                                 &mb_emlrtBCI_DoaMusicSignal);
          }

          iv = iValley_data[n - 1];
        }

        n--;
      } else {
        exitg2 = true;
      }
    }

    isv = iv;
    exitg1 = false;
    while ((!exitg1) && (n > 0)) {
      if (!(n <= peak_size_idx_0)) {
        rtDynamicBoundsError(n, 1, peak_size_idx_0, &y_emlrtBCI_DoaMusicSignal);
      }

      if (peak_data[n - 1] <= p) {
        if (!(n <= valley_size_idx_0)) {
          rtDynamicBoundsError(n, 1, valley_size_idx_0,
                               &hb_emlrtBCI_DoaMusicSignal);
        }

        if (valley_data[n - 1] < v) {
          if (!(n <= valley_size_idx_0)) {
            rtDynamicBoundsError(n, 1, valley_size_idx_0,
                                 &ib_emlrtBCI_DoaMusicSignal);
          }

          v = valley_data[n - 1];
          if (!(n <= iValley_size_idx_0)) {
            rtDynamicBoundsError(n, 1, iValley_size_idx_0,
                                 &jb_emlrtBCI_DoaMusicSignal);
          }

          iv = iValley_data[n - 1];
        }

        n--;
      } else {
        exitg1 = true;
      }
    }

    n++;
    if (!((n >= 1) && (n <= peak_size_idx_0))) {
      rtDynamicBoundsError(n, 1, peak_size_idx_0, &ab_emlrtBCI_DoaMusicSignal);
    }

    peak_data[n - 1] = yTemp[(int)iInflect_data[i - 1] - 1];
    if (!((n >= 1) && (n <= valley_size_idx_0))) {
      rtDynamicBoundsError(n, 1, valley_size_idx_0, &bb_emlrtBCI_DoaMusicSignal);
    }

    valley_data[n - 1] = v;
    if (!((n >= 1) && (n <= iValley_size_idx_0))) {
      rtDynamicBoundsError(n, 1, iValley_size_idx_0, &cb_emlrtBCI_DoaMusicSignal);
    }

    iValley_data[n - 1] = iv;
    if (!((i >= 1) && (i <= iInflect_size[0]))) {
      rtDynamicBoundsError(i, 1, iInflect_size[0], &db_emlrtBCI_DoaMusicSignal);
    }

    if (!((k >= 1) && (k <= iPeak_size[0]))) {
      rtDynamicBoundsError(k, 1, iPeak_size[0], &eb_emlrtBCI_DoaMusicSignal);
    }

    if (iInflect_data[i - 1] == iPeak_data[k - 1]) {
      if (!((k >= 1) && (k <= iBase_size[0]))) {
        rtDynamicBoundsError(k, 1, iBase_size[0], &fb_emlrtBCI_DoaMusicSignal);
      }

      iBase_data[k - 1] = iv;
      if (!((k >= 1) && (k <= iSaddle_size[0]))) {
        rtDynamicBoundsError(k, 1, iSaddle_size[0], &gb_emlrtBCI_DoaMusicSignal);
      }

      iSaddle_data[k - 1] = isv;
      k++;
    }

    i++;
    j++;
  }
}

/*
 * Arguments    : const double yTemp[123]
 *                const double iPk_data[]
 *                const int iPk_size[1]
 *                const double iFin_data[]
 *                const int iFin_size[1]
 *                const double iInflect_data[]
 *                const int iInflect_size[1]
 *                double peakBase_data[]
 *                int peakBase_size[1]
 *                double iLeftSaddle_data[]
 *                int iLeftSaddle_size[1]
 *                double iRightSaddle_data[]
 *                int iRightSaddle_size[1]
 * Return Type  : void
 */
static void getPeakBase(const double yTemp[123], const double iPk_data[], const
  int iPk_size[1], const double iFin_data[], const int iFin_size[1], const
  double iInflect_data[], const int iInflect_size[1], double peakBase_data[],
  int peakBase_size[1], double iLeftSaddle_data[], int iLeftSaddle_size[1],
  double iRightSaddle_data[], int iRightSaddle_size[1])
{
  double iLeftBase_data[123];
  int iLeftBase_size[1];
  int tmp_size[1];
  int loop_ub;
  int i7;
  double tmp_data[123];
  int b_tmp_size[1];
  double b_tmp_data[123];
  int c_tmp_size[1];
  double c_tmp_data[123];
  double iRightBase_data[123];
  int iRightBase_size[1];
  int k;
  signed char csz_idx_0;
  int yTemp_size[1];
  int b_yTemp_size[1];
  getLeftBase(yTemp, iPk_data, iPk_size, iFin_data, iFin_size, iInflect_data,
              iInflect_size, iLeftBase_data, iLeftBase_size, iLeftSaddle_data,
              iLeftSaddle_size);
  tmp_size[0] = iPk_size[0];
  loop_ub = iPk_size[0];
  for (i7 = 0; i7 < loop_ub; i7++) {
    tmp_data[i7] = iPk_data[i7];
  }

  flipud(tmp_data, tmp_size);
  b_tmp_size[0] = iFin_size[0];
  loop_ub = iFin_size[0];
  for (i7 = 0; i7 < loop_ub; i7++) {
    b_tmp_data[i7] = iFin_data[i7];
  }

  flipud(b_tmp_data, b_tmp_size);
  c_tmp_size[0] = iInflect_size[0];
  loop_ub = iInflect_size[0];
  for (i7 = 0; i7 < loop_ub; i7++) {
    c_tmp_data[i7] = iInflect_data[i7];
  }

  flipud(c_tmp_data, c_tmp_size);
  getLeftBase(yTemp, tmp_data, tmp_size, b_tmp_data, b_tmp_size, c_tmp_data,
              c_tmp_size, iRightBase_data, iRightBase_size, iRightSaddle_data,
              iRightSaddle_size);
  flipud(iRightBase_data, iRightBase_size);
  flipud(iRightSaddle_data, iRightSaddle_size);
  loop_ub = iLeftBase_size[0];
  for (i7 = 0; i7 < loop_ub; i7++) {
    k = (int)iLeftBase_data[i7];
    if (!((k >= 1) && (k <= 123))) {
      rtDynamicBoundsError(k, 1, 123, &q_emlrtBCI_DoaMusicSignal);
    }
  }

  loop_ub = iRightBase_size[0];
  for (i7 = 0; i7 < loop_ub; i7++) {
    k = (int)iRightBase_data[i7];
    if (!((k >= 1) && (k <= 123))) {
      rtDynamicBoundsError(k, 1, 123, &r_emlrtBCI_DoaMusicSignal);
    }
  }

  if (iLeftBase_size[0] <= iRightBase_size[0]) {
    loop_ub = iLeftBase_size[0];
  } else {
    loop_ub = iRightBase_size[0];
  }

  if (iLeftBase_size[0] <= iRightBase_size[0]) {
    csz_idx_0 = (signed char)iLeftBase_size[0];
  } else {
    csz_idx_0 = (signed char)iRightBase_size[0];
  }

  if (iLeftBase_size[0] <= iRightBase_size[0]) {
    peakBase_size[0] = (signed char)iLeftBase_size[0];
  } else {
    peakBase_size[0] = (signed char)iRightBase_size[0];
  }

  yTemp_size[0] = iLeftBase_size[0];
  b_yTemp_size[0] = iRightBase_size[0];
  if (dimagree(peakBase_size, yTemp_size, b_yTemp_size)) {
  } else {
    l_rtErrorWithMessageID(&l_emlrtRTEI_DoaMusicSignal);
  }

  for (k = 0; k + 1 <= csz_idx_0; k++) {
    if (!((k + 1 >= 1) && (k + 1 <= iLeftBase_size[0]))) {
      rtDynamicBoundsError(k + 1, 1, iLeftBase_size[0],
                           &p_emlrtBCI_DoaMusicSignal);
    }

    if (!((k + 1 >= 1) && (k + 1 <= iRightBase_size[0]))) {
      rtDynamicBoundsError(k + 1, 1, iRightBase_size[0],
                           &o_emlrtBCI_DoaMusicSignal);
    }

    i7 = (signed char)loop_ub;
    if (!((k + 1 >= 1) && (k + 1 <= i7))) {
      rtDynamicBoundsError(k + 1, 1, i7, &s_emlrtBCI_DoaMusicSignal);
    }

    if ((yTemp[(int)iLeftBase_data[k] - 1] >= yTemp[(int)iRightBase_data[k] - 1])
        || rtIsNaN(yTemp[(int)iRightBase_data[k] - 1])) {
      peakBase_data[k] = yTemp[(int)iLeftBase_data[k] - 1];
    } else {
      peakBase_data[k] = yTemp[(int)iRightBase_data[k] - 1];
    }
  }
}

/*
 * Arguments    : const double y[123]
 *                const double iPk_data[]
 *                const int iPk_size[1]
 *                const double pbPk_data[]
 *                const int pbPk_size[1]
 *                double iLB_data[]
 *                int iLB_size[1]
 *                double iRB_data[]
 *                int iRB_size[1]
 *                double wxPk_data[]
 *                int wxPk_size[2]
 * Return Type  : void
 */
static void getPeakWidth(const double y[123], const double iPk_data[], const int
  iPk_size[1], const double pbPk_data[], const int pbPk_size[1], double
  iLB_data[], int iLB_size[1], double iRB_data[], int iRB_size[1], double
  wxPk_data[], int wxPk_size[2])
{
  int base_size_idx_0;
  int i;
  int i24;
  double base_data[123];
  double refHeight;
  int i25;
  double iLeft;
  boolean_T exitg2;
  double xLeft;
  double iRight;
  boolean_T exitg1;
  if (iPk_size[0] == 0) {
    base_size_idx_0 = 0;
    iLB_size[0] = 0;
    iRB_size[0] = 0;
  } else {
    base_size_idx_0 = pbPk_size[0];
    i = pbPk_size[0];
    for (i24 = 0; i24 < i; i24++) {
      base_data[i24] = pbPk_data[i24];
    }
  }

  wxPk_size[0] = iPk_size[0];
  wxPk_size[1] = 2;
  i = iPk_size[0] << 1;
  for (i24 = 0; i24 < i; i24++) {
    wxPk_data[i24] = 0.0;
  }

  for (i = 0; i < iPk_size[0]; i++) {
    i24 = i + 1;
    if (!((i24 >= 1) && (i24 <= iPk_size[0]))) {
      rtDynamicBoundsError(i24, 1, iPk_size[0], &rg_emlrtBCI_DoaMusicSignal);
    }

    i24 = i + 1;
    if (!((i24 >= 1) && (i24 <= base_size_idx_0))) {
      rtDynamicBoundsError(i24, 1, base_size_idx_0, &sg_emlrtBCI_DoaMusicSignal);
    }

    refHeight = (y[(int)iPk_data[i] - 1] + base_data[i]) / 2.0;
    i24 = i + 1;
    if (!((i24 >= 1) && (i24 <= iPk_size[0]))) {
      rtDynamicBoundsError(i24, 1, iPk_size[0], &tg_emlrtBCI_DoaMusicSignal);
    }

    i24 = iLB_size[0];
    i25 = i + 1;
    if (!((i25 >= 1) && (i25 <= i24))) {
      rtDynamicBoundsError(i25, 1, i24, &ug_emlrtBCI_DoaMusicSignal);
    }

    iLeft = iPk_data[i];
    exitg2 = false;
    while ((!exitg2) && (iLeft >= iLB_data[i])) {
      i24 = (int)iLeft;
      if (!((i24 >= 1) && (i24 <= 123))) {
        rtDynamicBoundsError(i24, 1, 123, &lh_emlrtBCI_DoaMusicSignal);
      }

      if (y[i24 - 1] > refHeight) {
        iLeft--;
      } else {
        exitg2 = true;
      }
    }

    i24 = iLB_size[0];
    i25 = 1 + i;
    if (!((i25 >= 1) && (i25 <= i24))) {
      rtDynamicBoundsError(i25, 1, i24, &mh_emlrtBCI_DoaMusicSignal);
    }

    if (iLeft < iLB_data[i25 - 1]) {
      i24 = iLB_size[0];
      i25 = 1 + i;
      if (!((i25 >= 1) && (i25 <= i24))) {
        rtDynamicBoundsError(i25, 1, i24, &nh_emlrtBCI_DoaMusicSignal);
      }

      i24 = (int)iLB_data[i25 - 1];
      if (!((i24 >= 1) && (i24 <= 123))) {
        rtDynamicBoundsError(i24, 1, 123, &vg_emlrtBCI_DoaMusicSignal);
      }

      xLeft = 1.0 + (double)(i24 - 1);
    } else {
      i24 = (int)iLeft;
      if (!((i24 >= 1) && (i24 <= 123))) {
        rtDynamicBoundsError(i24, 1, 123, &wg_emlrtBCI_DoaMusicSignal);
      }

      i24 = (int)(iLeft + 1.0);
      if (!((i24 >= 1) && (i24 <= 123))) {
        rtDynamicBoundsError(i24, 1, 123, &xg_emlrtBCI_DoaMusicSignal);
      }

      i24 = (int)(iLeft + 1.0);
      if (!((i24 >= 1) && (i24 <= 123))) {
        rtDynamicBoundsError(i24, 1, 123, &yg_emlrtBCI_DoaMusicSignal);
      }

      i24 = i + 1;
      if (!((i24 >= 1) && (i24 <= iPk_size[0]))) {
        rtDynamicBoundsError(i24, 1, iPk_size[0], &ah_emlrtBCI_DoaMusicSignal);
      }

      i24 = i + 1;
      if (!((i24 >= 1) && (i24 <= base_size_idx_0))) {
        rtDynamicBoundsError(i24, 1, base_size_idx_0,
                             &bh_emlrtBCI_DoaMusicSignal);
      }

      xLeft = (1.0 + (double)((int)iLeft - 1)) + ((1.0 + (double)((int)(iLeft +
        1.0) - 1)) - (1.0 + (double)((int)iLeft - 1))) * (0.5 * (y[(int)
        iPk_data[i] - 1] + base_data[i]) - y[(int)iLeft - 1]) / (y[(int)(iLeft +
        1.0) - 1] - y[(int)iLeft - 1]);
      if (rtIsNaN(xLeft)) {
        if (rtIsInf(base_data[i])) {
          xLeft = 0.5 * ((1.0 + (double)((int)iLeft - 1)) + (1.0 + (double)((int)
            (iLeft + 1.0) - 1)));
        } else {
          xLeft = 1.0 + (double)((int)(iLeft + 1.0) - 1);
        }
      }
    }

    i24 = i + 1;
    if (!((i24 >= 1) && (i24 <= iPk_size[0]))) {
      rtDynamicBoundsError(i24, 1, iPk_size[0], &ch_emlrtBCI_DoaMusicSignal);
    }

    i24 = iRB_size[0];
    i25 = i + 1;
    if (!((i25 >= 1) && (i25 <= i24))) {
      rtDynamicBoundsError(i25, 1, i24, &dh_emlrtBCI_DoaMusicSignal);
    }

    iRight = iPk_data[i];
    exitg1 = false;
    while ((!exitg1) && (iRight <= iRB_data[i])) {
      i24 = (int)iRight;
      if (!((i24 >= 1) && (i24 <= 123))) {
        rtDynamicBoundsError(i24, 1, 123, &oh_emlrtBCI_DoaMusicSignal);
      }

      if (y[i24 - 1] > refHeight) {
        iRight++;
      } else {
        exitg1 = true;
      }
    }

    i24 = iRB_size[0];
    i25 = 1 + i;
    if (!((i25 >= 1) && (i25 <= i24))) {
      rtDynamicBoundsError(i25, 1, i24, &ph_emlrtBCI_DoaMusicSignal);
    }

    if (iRight > iRB_data[i25 - 1]) {
      i24 = iRB_size[0];
      i25 = 1 + i;
      if (!((i25 >= 1) && (i25 <= i24))) {
        rtDynamicBoundsError(i25, 1, i24, &qh_emlrtBCI_DoaMusicSignal);
      }

      i24 = (int)iRB_data[i25 - 1];
      if (!((i24 >= 1) && (i24 <= 123))) {
        rtDynamicBoundsError(i24, 1, 123, &eh_emlrtBCI_DoaMusicSignal);
      }

      iLeft = 1.0 + (double)(i24 - 1);
    } else {
      i24 = (int)iRight;
      if (!((i24 >= 1) && (i24 <= 123))) {
        rtDynamicBoundsError(i24, 1, 123, &fh_emlrtBCI_DoaMusicSignal);
      }

      i24 = (int)(iRight - 1.0);
      if (!((i24 >= 1) && (i24 <= 123))) {
        rtDynamicBoundsError(i24, 1, 123, &gh_emlrtBCI_DoaMusicSignal);
      }

      i24 = (int)(iRight - 1.0);
      if (!((i24 >= 1) && (i24 <= 123))) {
        rtDynamicBoundsError(i24, 1, 123, &hh_emlrtBCI_DoaMusicSignal);
      }

      i24 = i + 1;
      if (!((i24 >= 1) && (i24 <= iPk_size[0]))) {
        rtDynamicBoundsError(i24, 1, iPk_size[0], &ih_emlrtBCI_DoaMusicSignal);
      }

      i24 = i + 1;
      if (!((i24 >= 1) && (i24 <= base_size_idx_0))) {
        rtDynamicBoundsError(i24, 1, base_size_idx_0,
                             &jh_emlrtBCI_DoaMusicSignal);
      }

      iLeft = (1.0 + (double)((int)iRight - 1)) + ((1.0 + (double)((int)(iRight
        - 1.0) - 1)) - (1.0 + (double)((int)iRight - 1))) * (0.5 * (y[(int)
        iPk_data[i] - 1] + base_data[i]) - y[(int)iRight - 1]) / (y[(int)(iRight
        - 1.0) - 1] - y[(int)iRight - 1]);
      if (rtIsNaN(iLeft)) {
        if (rtIsInf(base_data[i])) {
          iLeft = 0.5 * ((1.0 + (double)((int)iRight - 1)) + (1.0 + (double)
            ((int)(iRight - 1.0) - 1)));
        } else {
          iLeft = 1.0 + (double)((int)(iRight - 1.0) - 1);
        }
      }
    }

    i24 = 1 + i;
    if (!((i24 >= 1) && (i24 <= wxPk_size[0]))) {
      rtDynamicBoundsError(i24, 1, wxPk_size[0], &kh_emlrtBCI_DoaMusicSignal);
    }

    wxPk_data[i] = xLeft;
    wxPk_data[i + wxPk_size[0]] = iLeft;
  }
}

/*
 * Arguments    : const int b
 *                const char *c
 *                const rtRunTimeErrorInfo_DoaMusicSign *aInfo
 * Return Type  : void
 */
static void h_rtErrorWithMessageID(const int b, const char *c, const
  rtRunTimeErrorInfo_DoaMusicSign *aInfo)
{
  fprintf(stderr, "%.*s", b, c);
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const rtRunTimeErrorInfo_DoaMusicSign *aInfo
 * Return Type  : void
 */
static void i_rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo)
{
  fprintf(stderr,
          "Vector(vector) subscript turned out to be a scalar(vector) subscript with shape different from the compiled assumption.");
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : int matrixSize
 *                const int indexSize[2]
 * Return Type  : void
 */
static void indexShapeCheck(int matrixSize, const int indexSize[2])
{
  boolean_T guard1 = false;
  boolean_T nonSingletonDimFound;
  guard1 = false;
  if (!(matrixSize != 1)) {
    nonSingletonDimFound = false;
    if (indexSize[1] != 1) {
      nonSingletonDimFound = true;
    }

    if (nonSingletonDimFound) {
      nonSingletonDimFound = true;
    } else {
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1) {
    nonSingletonDimFound = false;
  }

  if (!nonSingletonDimFound) {
  } else {
    i_rtErrorWithMessageID(&i_emlrtRTEI_DoaMusicSignal);
  }
}

/*
 * Arguments    : const double x_data[]
 *                const int x_size[1]
 * Return Type  : boolean_T
 */
static boolean_T issorted(const double x_data[], const int x_size[1])
{
  boolean_T y;
  int k;
  boolean_T exitg1;
  boolean_T p;
  y = true;
  if (x_size[0] == 0) {
  } else {
    k = 1;
    exitg1 = false;
    while ((!exitg1) && (k <= x_size[0] - 1)) {
      if (!((k >= 1) && (k <= x_size[0]))) {
        rtDynamicBoundsError(k, 1, x_size[0], &xc_emlrtBCI_DoaMusicSignal);
      }

      if (!((k + 1 >= 1) && (k + 1 <= x_size[0]))) {
        rtDynamicBoundsError(k + 1, 1, x_size[0], &wc_emlrtBCI_DoaMusicSignal);
      }

      if ((x_data[k - 1] <= x_data[k]) || rtIsNaN(x_data[k])) {
        p = true;
      } else {
        p = false;
      }

      if (!p) {
        y = false;
        exitg1 = true;
      } else {
        k++;
      }
    }
  }

  return y;
}

/*
 * Arguments    : const rtRunTimeErrorInfo_DoaMusicSign *aInfo
 * Return Type  : void
 */
static void j_rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo)
{
  fprintf(stderr, "Assertion failed.");
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const rtRunTimeErrorInfo_DoaMusicSign *aInfo
 * Return Type  : void
 */
static void k_rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo)
{
  fprintf(stderr,
          "The working dimension was selected automatically, is variable-length, and has length 1 at run time. This is not supported. Manua"
          "lly select the working dimension by supplying the DIM argument.");
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : int idx_size[1]
 *                double Np
 * Return Type  : void
 */
static void keepAtMostNpPeaks(int idx_size[1], double Np)
{
  int i39;
  int i40;
  boolean_T guard1 = false;
  boolean_T nonSingletonDimFound;
  if (idx_size[0] > Np) {
    if (1.0 > Np) {
      i40 = 0;
    } else {
      i39 = idx_size[0];
      if (!(1 <= i39)) {
        rtDynamicBoundsError(1, 1, i39, &fk_emlrtBCI_DoaMusicSignal);
      }

      if (Np != floor(Np)) {
        rtIntegerError(Np, &b_emlrtDCI_DoaMusicSignal);
      }

      i39 = idx_size[0];
      i40 = (int)Np;
      if (!(i40 <= i39)) {
        rtDynamicBoundsError(i40, 1, i39, &fk_emlrtBCI_DoaMusicSignal);
      }
    }

    guard1 = false;
    if (!(idx_size[0] != 1)) {
      nonSingletonDimFound = false;
      if (i40 != 1) {
        nonSingletonDimFound = true;
      }

      if (nonSingletonDimFound) {
        nonSingletonDimFound = true;
      } else {
        guard1 = true;
      }
    } else {
      guard1 = true;
    }

    if (guard1) {
      nonSingletonDimFound = false;
    }

    if (!nonSingletonDimFound) {
    } else {
      i_rtErrorWithMessageID(&i_emlrtRTEI_DoaMusicSignal);
    }

    idx_size[0] = i40;
  }
}

/*
 * Arguments    : const rtRunTimeErrorInfo_DoaMusicSign *aInfo
 * Return Type  : void
 */
static void l_rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo)
{
  fprintf(stderr, "Matrix dimensions must agree.");
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const rtRunTimeErrorInfo_DoaMusicSign *aInfo
 * Return Type  : void
 */
static void m_rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo)
{
  fprintf(stderr,
          "The first operand is not sorted in ascending order. Use SORT first.");
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : int idx[4]
 *                double x[4]
 *                int offset
 *                int np
 *                int nq
 *                int iwork[4]
 *                double xwork[4]
 * Return Type  : void
 */
static void merge(int idx[4], double x[4], int offset, int np, int nq, int
                  iwork[4], double xwork[4])
{
  int n;
  int qend;
  int p;
  int iout;
  int exitg1;
  if (nq == 0) {
  } else {
    n = np + nq;
    if ((!(1 > n)) && (n > 2147483646)) {
      check_forloop_overflow_error();
    }

    for (qend = 1; qend <= n; qend++) {
      iout = offset + qend;
      if (!((iout >= 1) && (iout <= 4))) {
        rtDynamicBoundsError(iout, 1, 4, &xf_emlrtBCI_DoaMusicSignal);
      }

      if (!((qend >= 1) && (qend <= 4))) {
        rtDynamicBoundsError(qend, 1, 4, &yf_emlrtBCI_DoaMusicSignal);
      }

      iwork[qend - 1] = idx[iout - 1];
      iout = offset + qend;
      if (!((iout >= 1) && (iout <= 4))) {
        rtDynamicBoundsError(iout, 1, 4, &ag_emlrtBCI_DoaMusicSignal);
      }

      xwork[qend - 1] = x[iout - 1];
    }

    p = 1;
    n = np;
    qend = np + nq;
    iout = offset;
    do {
      exitg1 = 0;
      iout++;
      if (!(p <= 4)) {
        rtDynamicBoundsError(p, 1, 4, &qf_emlrtBCI_DoaMusicSignal);
      }

      if (!((n + 1 >= 1) && (n + 1 <= 4))) {
        rtDynamicBoundsError(n + 1, 1, 4, &rf_emlrtBCI_DoaMusicSignal);
      }

      if (xwork[p - 1] <= xwork[n]) {
        if (!((iout >= 1) && (iout <= 4))) {
          rtDynamicBoundsError(iout, 1, 4, &wf_emlrtBCI_DoaMusicSignal);
        }

        idx[iout - 1] = iwork[p - 1];
        x[iout - 1] = xwork[p - 1];
        if (p < np) {
          p++;
        } else {
          exitg1 = 1;
        }
      } else {
        if (!((iout >= 1) && (iout <= 4))) {
          rtDynamicBoundsError(iout, 1, 4, &sf_emlrtBCI_DoaMusicSignal);
        }

        idx[iout - 1] = iwork[n];
        x[iout - 1] = xwork[n];
        if (n + 1 < qend) {
          n++;
        } else {
          n = (iout - p) + 1;
          if ((!(p > np)) && (np > 2147483646)) {
            check_forloop_overflow_error();
          }

          while (p <= np) {
            if (!((p >= 1) && (p <= 4))) {
              rtDynamicBoundsError(p, 1, 4, &tf_emlrtBCI_DoaMusicSignal);
            }

            iout = n + p;
            if (!((iout >= 1) && (iout <= 4))) {
              rtDynamicBoundsError(iout, 1, 4, &uf_emlrtBCI_DoaMusicSignal);
            }

            idx[iout - 1] = iwork[p - 1];
            iout = n + p;
            if (!((iout >= 1) && (iout <= 4))) {
              rtDynamicBoundsError(iout, 1, 4, &vf_emlrtBCI_DoaMusicSignal);
            }

            x[iout - 1] = xwork[p - 1];
            p++;
          }

          exitg1 = 1;
        }
      }
    } while (exitg1 == 0);
  }
}

/*
 * Arguments    : int idx_data[]
 *                int idx_size[1]
 *                double x_data[]
 *                int x_size[1]
 *                int n
 *                int iwork_data[]
 *                int iwork_size[1]
 *                double xwork_data[]
 *                int xwork_size[1]
 * Return Type  : void
 */
static void merge_block(int idx_data[], int idx_size[1], double x_data[], int
  x_size[1], int n, int iwork_data[], int iwork_size[1], double xwork_data[],
  int xwork_size[1])
{
  int nPairs;
  int bLen;
  int tailOffset;
  int nTail;
  nPairs = n >> 2;
  bLen = 4;
  while (nPairs > 1) {
    if ((nPairs & 1) != 0) {
      nPairs--;
      tailOffset = bLen * nPairs;
      nTail = n - tailOffset;
      if (nTail > bLen) {
        b_merge(idx_data, idx_size, x_data, x_size, tailOffset, bLen, nTail -
                bLen, iwork_data, iwork_size, xwork_data, xwork_size);
      }
    }

    tailOffset = bLen << 1;
    nPairs >>= 1;
    for (nTail = 1; nTail <= nPairs; nTail++) {
      b_merge(idx_data, idx_size, x_data, x_size, (nTail - 1) * tailOffset, bLen,
              bLen, iwork_data, iwork_size, xwork_data, xwork_size);
    }

    bLen = tailOffset;
  }

  if (n > bLen) {
    b_merge(idx_data, idx_size, x_data, x_size, 0, bLen, n - bLen, iwork_data,
            iwork_size, xwork_data, xwork_size);
  }
}

/*
 * Arguments    : const rtRunTimeErrorInfo_DoaMusicSign *aInfo
 * Return Type  : void
 */
static void n_rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo)
{
  fprintf(stderr,
          "The second operand is not sorted in ascending order. Use SORT first.");
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const int x_size[1]
 * Return Type  : int
 */
static int nonSingletonDim(const int x_size[1])
{
  int dim;
  dim = 2;
  if (x_size[0] != 1) {
    dim = 1;
  }

  return dim;
}

/*
 * Arguments    : const rtRunTimeErrorInfo_DoaMusicSign *aInfo
 * Return Type  : void
 */
static void o_rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo)
{
  fprintf(stderr,
          "If the input is a variable-size array, it cannot be 0-by-0 at run time.");
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const double Yin[123]
 *                double varargin_2
 *                double varargin_8
 *                double y[123]
 *                double *Pd
 *                double *NpOut
 * Return Type  : void
 */
static void parse_inputs(const double Yin[123], double varargin_2, double
  varargin_8, double y[123], double *Pd, double *NpOut)
{
  boolean_T p;
  boolean_T b_p;
  memcpy(&y[0], &Yin[0], 123U * sizeof(double));
  *Pd = varargin_8;
  *NpOut = varargin_2;
  p = true;
  if (!(varargin_8 < 0.0)) {
  } else {
    p = false;
  }

  if (p) {
  } else {
    e_rtErrorWithMessageID(43, "Expected MinPeakDistance to be nonnegative.",
      &e_emlrtRTEI_DoaMusicSignal);
  }

  p = true;
  if (varargin_8 < 122.0) {
  } else {
    p = false;
  }

  if (p) {
  } else {
    f_rtErrorWithMessageID(69,
      "Expected MinPeakDistance to be an array with all of the values < 122.",
      &f_emlrtRTEI_DoaMusicSignal);
  }

  p = true;
  if (!(varargin_8 < 0.0)) {
  } else {
    p = false;
  }

  if (p) {
  } else {
    e_rtErrorWithMessageID(43, "Expected MinPeakDistance to be nonnegative.",
      &e_emlrtRTEI_DoaMusicSignal);
  }

  p = true;
  if ((!rtIsInf(varargin_2)) && (!rtIsNaN(varargin_2)) && (floor(varargin_2) ==
       varargin_2)) {
    b_p = true;
  } else {
    b_p = false;
  }

  if (b_p) {
  } else {
    p = false;
  }

  if (p) {
  } else {
    g_rtErrorWithMessageID(37, "Expected NPeaks to be integer-valued.",
      &g_emlrtRTEI_DoaMusicSignal);
  }

  p = true;
  if (!(varargin_2 <= 0.0)) {
  } else {
    p = false;
  }

  if (p) {
  } else {
    h_rtErrorWithMessageID(31, "Expected NPeaks to be positive.",
      &h_emlrtRTEI_DoaMusicSignal);
  }
}

/*
 * Arguments    : const double y[121]
 *                double ydB[121]
 * Return Type  : void
 */
static void pow2db(const double y[121], double ydB[121])
{
  boolean_T x[121];
  int k;
  boolean_T cond;
  boolean_T exitg1;
  for (k = 0; k < 121; k++) {
    x[k] = (y[k] >= 0.0);
  }

  cond = true;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 121)) {
    if (!x[k]) {
      cond = false;
      exitg1 = true;
    } else {
      k++;
    }
  }

  if (!cond) {
    d_rtErrorWithMessageID(&d_emlrtRTEI_DoaMusicSignal);
  }

  cond = false;
  for (k = 0; k < 121; k++) {
    if (cond || (y[k] < 0.0)) {
      cond = true;
    } else {
      cond = false;
    }
  }

  if (cond) {
    b_error();
  }

  for (k = 0; k < 121; k++) {
    ydB[k] = (10.0 * log10(y[k]) + 300.0) - 300.0;
  }
}

/*
 * Arguments    : const double Y[123]
 *                double iPk_data[]
 *                int iPk_size[1]
 * Return Type  : void
 */
static void removePeaksBelowMinPeakHeight(const double Y[123], double iPk_data[],
  int iPk_size[1])
{
  int loop_ub;
  int i18;
  int trueCount;
  int i;
  int partialTrueCount;
  if (!(iPk_size[0] == 0)) {
    loop_ub = iPk_size[0];
    for (i18 = 0; i18 < loop_ub; i18++) {
      trueCount = (int)iPk_data[i18];
      if (!((trueCount >= 1) && (trueCount <= 123))) {
        rtDynamicBoundsError(trueCount, 1, 123, &dg_emlrtBCI_DoaMusicSignal);
      }
    }

    loop_ub = iPk_size[0] - 1;
    trueCount = 0;
    for (i = 0; i <= loop_ub; i++) {
      i18 = (int)iPk_data[i];
      if (!((i18 >= 1) && (i18 <= 123))) {
        rtDynamicBoundsError(i18, 1, 123, &dg_emlrtBCI_DoaMusicSignal);
      }

      if (Y[i18 - 1] > -15.0) {
        trueCount++;
      }
    }

    partialTrueCount = 0;
    for (i = 0; i <= loop_ub; i++) {
      i18 = (int)iPk_data[i];
      if (!((i18 >= 1) && (i18 <= 123))) {
        rtDynamicBoundsError(i18, 1, 123, &dg_emlrtBCI_DoaMusicSignal);
      }

      if (Y[i18 - 1] > -15.0) {
        i18 = iPk_size[0];
        if (!((i + 1 >= 1) && (i + 1 <= i18))) {
          rtDynamicBoundsError(i + 1, 1, i18, &eg_emlrtBCI_DoaMusicSignal);
        }

        iPk_data[partialTrueCount] = iPk_data[i];
        partialTrueCount++;
      }
    }

    iPk_size[0] = trueCount;
  }
}

/*
 * Arguments    : const double Y[123]
 *                double iPk_data[]
 *                int iPk_size[1]
 * Return Type  : void
 */
static void removePeaksBelowThreshold(const double Y[123], double iPk_data[],
  int iPk_size[1])
{
  int varargin_1_size[1];
  int loop_ub;
  int i19;
  int varargin_2_size[1];
  int k;
  signed char csz_idx_0;
  double base_data[123];
  int base_size[1];
  int i;
  int partialTrueCount;
  varargin_1_size[0] = iPk_size[0];
  loop_ub = iPk_size[0];
  for (i19 = 0; i19 < loop_ub; i19++) {
    k = (int)(iPk_data[i19] - 1.0);
    if (!((k >= 1) && (k <= 123))) {
      rtDynamicBoundsError(k, 1, 123, &fg_emlrtBCI_DoaMusicSignal);
    }
  }

  varargin_2_size[0] = iPk_size[0];
  loop_ub = iPk_size[0];
  for (i19 = 0; i19 < loop_ub; i19++) {
    k = (int)(iPk_data[i19] + 1.0);
    if (!((k >= 1) && (k <= 123))) {
      rtDynamicBoundsError(k, 1, 123, &gg_emlrtBCI_DoaMusicSignal);
    }
  }

  loop_ub = iPk_size[0];
  csz_idx_0 = (signed char)iPk_size[0];
  base_size[0] = (signed char)iPk_size[0];
  if (dimagree(base_size, varargin_1_size, varargin_2_size)) {
  } else {
    l_rtErrorWithMessageID(&l_emlrtRTEI_DoaMusicSignal);
  }

  for (k = 0; k + 1 <= csz_idx_0; k++) {
    i19 = iPk_size[0];
    if (!((k + 1 >= 1) && (k + 1 <= i19))) {
      rtDynamicBoundsError(k + 1, 1, i19, &p_emlrtBCI_DoaMusicSignal);
    }

    i19 = iPk_size[0];
    if (!((k + 1 >= 1) && (k + 1 <= i19))) {
      rtDynamicBoundsError(k + 1, 1, i19, &o_emlrtBCI_DoaMusicSignal);
    }

    i19 = (signed char)loop_ub;
    if (!((k + 1 >= 1) && (k + 1 <= i19))) {
      rtDynamicBoundsError(k + 1, 1, i19, &s_emlrtBCI_DoaMusicSignal);
    }

    if ((Y[(int)(iPk_data[k] - 1.0) - 1] >= Y[(int)(iPk_data[k] + 1.0) - 1]) ||
        rtIsNaN(Y[(int)(iPk_data[k] + 1.0) - 1])) {
      base_data[k] = Y[(int)(iPk_data[k] - 1.0) - 1];
    } else {
      base_data[k] = Y[(int)(iPk_data[k] + 1.0) - 1];
    }
  }

  loop_ub = iPk_size[0];
  for (i19 = 0; i19 < loop_ub; i19++) {
    k = (int)iPk_data[i19];
    if (!((k >= 1) && (k <= 123))) {
      rtDynamicBoundsError(k, 1, 123, &hg_emlrtBCI_DoaMusicSignal);
    }
  }

  i19 = iPk_size[0];
  k = csz_idx_0;
  if (i19 != k) {
    rtSizeEq1DError(i19, k, &t_emlrtECI_DoaMusicSignal);
  }

  loop_ub = iPk_size[0] - 1;
  k = 0;
  for (i = 0; i <= loop_ub; i++) {
    if (Y[(int)iPk_data[i] - 1] - base_data[i] >= 0.0) {
      k++;
    }
  }

  partialTrueCount = 0;
  for (i = 0; i <= loop_ub; i++) {
    if (Y[(int)iPk_data[i] - 1] - base_data[i] >= 0.0) {
      i19 = iPk_size[0];
      if (!((i + 1 >= 1) && (i + 1 <= i19))) {
        rtDynamicBoundsError(i + 1, 1, i19, &ig_emlrtBCI_DoaMusicSignal);
      }

      iPk_data[partialTrueCount] = iPk_data[i];
      partialTrueCount++;
    }
  }

  iPk_size[0] = k;
}

/*
 * Arguments    : char * aBuf
 *                const int aDim
 * Return Type  : void
 */
static void rtAddSizeString(char * aBuf, const int aDim)
{
  char dimStr[1024];
  sprintf(dimStr, "[%d]", aDim);
  if (strlen(aBuf) + strlen(dimStr) < 1024) {
    strcat(aBuf, dimStr);
  }
}

/*
 * Arguments    : int aIndexValue
 *                int aLoBound
 *                int aHiBound
 *                const rtBoundsCheckInfo_DoaMusicSigna *aInfo
 * Return Type  : void
 */
static void rtDynamicBoundsError(int aIndexValue, int aLoBound, int aHiBound,
  const rtBoundsCheckInfo_DoaMusicSigna *aInfo)
{
  if (aLoBound == 0) {
    aIndexValue++;
    aLoBound = 1;
    aHiBound++;
  }

  if (rtIsNullOrEmptyString(aInfo->aName_DoaMusicSignal)) {
    fprintf(stderr,
            "Index exceeds array dimensions.  Index value %d exceeds valid range [%d-%d].",
            aIndexValue, aLoBound, aHiBound);
    fprintf(stderr, "\n");
  } else {
    fprintf(stderr,
            "Index exceeds array dimensions.  Index value %d exceeds valid range [%d-%d] of array %s.",
            aIndexValue, aLoBound, aHiBound, aInfo->aName_DoaMusicSignal);
    fprintf(stderr, "\n");
  }

  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const rtRunTimeErrorInfo_DoaMusicSign *aInfo
 * Return Type  : void
 */
static void rtErrorWithMessageID(const rtRunTimeErrorInfo_DoaMusicSign *aInfo)
{
  fprintf(stderr, "Inner matrix dimensions must agree.");
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const int aNDims
 *                const int *aDims
 *                char *aBuf
 * Return Type  : void
 */
static void rtGenSizeString(const int aNDims, const int *aDims, char *aBuf)
{
  int i;
  aBuf[0] = '\x00';
  for (i = 0; i < aNDims; i++) {
    rtAddSizeString(aBuf, aDims[i]);
  }
}

/*
 * Arguments    : const double aInteger
 *                const rtDoubleCheckInfo_DoaMusicSigna *aInfo
 * Return Type  : void
 */
static void rtIntegerError(const double aInteger, const
  rtDoubleCheckInfo_DoaMusicSigna *aInfo)
{
  fprintf(stderr,
          "Expected a value representable in the C type \'int\'.  Found %g instead.",
          aInteger);
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const char *aString
 * Return Type  : boolean_T
 */
static boolean_T rtIsNullOrEmptyString(const char *aString)
{
  return (aString == NULL) || (*aString == '\x00');
}

/*
 * Arguments    : const char * aFcnName
 *                const int aLineNo
 * Return Type  : void
 */
static void rtReportErrorLocation(const char * aFcnName, const int aLineNo)
{
  fprintf(stderr, "Error in %s (line %d)", aFcnName, aLineNo);
  fprintf(stderr, "\n");
}

/*
 * Arguments    : const int aDim1
 *                const int aDim2
 *                const rtEqualityCheckInfo_DoaMusicSig *aInfo
 * Return Type  : void
 */
static void rtSizeEq1DError(const int aDim1, const int aDim2, const
  rtEqualityCheckInfo_DoaMusicSig *aInfo)
{
  fprintf(stderr, "Sizes mismatch: %d ~= %d.", aDim1, aDim2);
  fprintf(stderr, "\n");
  if (aInfo != NULL) {
    rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                          aInfo->lineNo_DoaMusicSignal);
  }

  fflush(stderr);
  abort();
}

/*
 * Arguments    : const int *aDims1
 *                const int aNDims1
 *                const int *aDims2
 *                const int aNDims2
 *                const rtEqualityCheckInfo_DoaMusicSig *aInfo
 * Return Type  : void
 */
static void rtSubAssignSizeCheck(const int *aDims1, const int aNDims1, const int
  *aDims2, const int aNDims2, const rtEqualityCheckInfo_DoaMusicSig *aInfo)
{
  int i;
  int j;
  char dims1Str[1024];
  char dims2Str[1024];
  i = 0;
  j = 0;
  while ((i < aNDims1) && (j < aNDims2)) {
    while ((i < aNDims1) && (aDims1[i] == 1)) {
      i++;
    }

    while ((j < aNDims2) && (aDims2[j] == 1)) {
      j++;
    }

    if (((i < aNDims1) || (j < aNDims2)) && ((i == aNDims1) || ((j == aNDims2) ||
          ((aDims1[i] != -1) && ((aDims2[j] != -1) && (aDims1[i] != aDims2[j]))))))
    {
      rtGenSizeString(aNDims1, aDims1, dims1Str);
      rtGenSizeString(aNDims2, aDims2, dims2Str);
      fprintf(stderr, "Subscripted assignment dimension mismatch: %s ~= %s.",
              dims1Str, dims2Str);
      fprintf(stderr, "\n");
      if (aInfo != NULL) {
        rtReportErrorLocation(aInfo->fName_DoaMusicSignal,
                              aInfo->lineNo_DoaMusicSignal);
      }

      fflush(stderr);
      abort();
    }

    i++;
    j++;
  }
}

/*
 * Arguments    : double u0
 *                double u1
 * Return Type  : double
 */
static double rt_hypotd_snf(double u0, double u1)
{
  double y;
  double a;
  double b;
  a = fabs(u0);
  b = fabs(u1);
  if (a < b) {
    a /= b;
    y = b * sqrt(a * a + 1.0);
  } else if (a > b) {
    b /= a;
    y = a * sqrt(b * b + 1.0);
  } else if (rtIsNaN(b)) {
    y = b;
  } else {
    y = a * 1.4142135623730951;
  }

  return y;
}

/*
 * Arguments    : int *k
 *                const double x_data[]
 *                const int x_size[1]
 * Return Type  : double
 */
static double skip_to_last_equal_value(int *k, const double x_data[], const int
  x_size[1])
{
  double xk;
  int i26;
  boolean_T exitg1;
  double absxk;
  int exponent;
  boolean_T p;
  i26 = *k;
  if (!((i26 >= 1) && (i26 <= x_size[0]))) {
    rtDynamicBoundsError(i26, 1, x_size[0], &sh_emlrtBCI_DoaMusicSignal);
  }

  xk = x_data[i26 - 1];
  exitg1 = false;
  while ((!exitg1) && (*k < x_size[0])) {
    i26 = *k + 1;
    if (!((i26 >= 1) && (i26 <= x_size[0]))) {
      rtDynamicBoundsError(i26, 1, x_size[0], &rh_emlrtBCI_DoaMusicSignal);
    }

    absxk = fabs(xk / 2.0);
    if ((!rtIsInf(absxk)) && (!rtIsNaN(absxk))) {
      if (absxk <= 2.2250738585072014E-308) {
        absxk = 4.94065645841247E-324;
      } else {
        frexp(absxk, &exponent);
        absxk = ldexp(1.0, exponent - 53);
      }
    } else {
      absxk = rtNaN;
    }

    if ((fabs(xk - x_data[*k]) < absxk) || (rtIsInf(x_data[*k]) && rtIsInf(xk) &&
         ((x_data[*k] > 0.0) == (xk > 0.0)))) {
      p = true;
    } else {
      p = false;
    }

    if (p) {
      (*k)++;
    } else {
      exitg1 = true;
    }
  }

  return xk;
}

/*
 * Arguments    : double x[4]
 *                int idx[4]
 * Return Type  : void
 */
static void sort(double x[4], int idx[4])
{
  b_sort(x, idx);
}

/*
 * Arguments    : double x_data[]
 *                int x_size[1]
 *                int idx_data[]
 *                int idx_size[1]
 * Return Type  : void
 */
static void sortIdx(double x_data[], int x_size[1], int idx_data[], int
                    idx_size[1])
{
  unsigned char unnamed_idx_0;
  int b_x_size[1];
  int m;
  int i30;
  double b_x_data[246];
  int n;
  double x4[4];
  unsigned char idx4[4];
  int iwork_size[1];
  int xwork;
  int iwork_data[246];
  int xwork_size[1];
  int nNaNs;
  double xwork_data[246];
  int ib;
  int k;
  int wOffset;
  signed char perm[4];
  int i31;
  int itmp;
  int i4;
  unnamed_idx_0 = (unsigned char)x_size[0];
  b_x_size[0] = x_size[0];
  m = x_size[0];
  for (i30 = 0; i30 < m; i30++) {
    b_x_data[i30] = x_data[i30];
  }

  idx_size[0] = unnamed_idx_0;
  m = unnamed_idx_0;
  for (i30 = 0; i30 < m; i30++) {
    idx_data[i30] = 0;
  }

  n = x_size[0];
  for (m = 0; m < 4; m++) {
    x4[m] = 0.0;
    idx4[m] = 0;
  }

  m = unnamed_idx_0;
  iwork_size[0] = unnamed_idx_0;
  for (i30 = 0; i30 < m; i30++) {
    iwork_data[i30] = 0;
  }

  xwork = (unsigned char)x_size[0];
  xwork_size[0] = (unsigned char)x_size[0];
  for (i30 = 0; i30 < xwork; i30++) {
    xwork_data[i30] = 0.0;
  }

  nNaNs = 0;
  ib = 0;
  for (k = 1; k <= n; k++) {
    if (!((k >= 1) && (k <= b_x_size[0]))) {
      rtDynamicBoundsError(k, 1, b_x_size[0], &ai_emlrtBCI_DoaMusicSignal);
    }

    if (rtIsNaN(b_x_data[k - 1])) {
      i30 = unnamed_idx_0;
      i31 = n - nNaNs;
      if (!((i31 >= 1) && (i31 <= i30))) {
        rtDynamicBoundsError(i31, 1, i30, &jj_emlrtBCI_DoaMusicSignal);
      }

      idx_data[i31 - 1] = k;
      if (!((k >= 1) && (k <= b_x_size[0]))) {
        rtDynamicBoundsError(k, 1, b_x_size[0], &kj_emlrtBCI_DoaMusicSignal);
      }

      i30 = n - nNaNs;
      if (!((i30 >= 1) && (i30 <= xwork))) {
        rtDynamicBoundsError(i30, 1, xwork, &lj_emlrtBCI_DoaMusicSignal);
      }

      xwork_data[i30 - 1] = b_x_data[k - 1];
      nNaNs++;
    } else {
      ib++;
      idx4[ib - 1] = (unsigned char)k;
      if (!((k >= 1) && (k <= b_x_size[0]))) {
        rtDynamicBoundsError(k, 1, b_x_size[0], &aj_emlrtBCI_DoaMusicSignal);
      }

      x4[ib - 1] = b_x_data[k - 1];
      if (ib == 4) {
        wOffset = k - nNaNs;
        if (x4[0] >= x4[1]) {
          m = 1;
          ib = 2;
        } else {
          m = 2;
          ib = 1;
        }

        if (x4[2] >= x4[3]) {
          itmp = 3;
          i4 = 4;
        } else {
          itmp = 4;
          i4 = 3;
        }

        if (x4[m - 1] >= x4[itmp - 1]) {
          if (x4[ib - 1] >= x4[itmp - 1]) {
            perm[0] = (signed char)m;
            perm[1] = (signed char)ib;
            perm[2] = (signed char)itmp;
            perm[3] = (signed char)i4;
          } else if (x4[ib - 1] >= x4[i4 - 1]) {
            perm[0] = (signed char)m;
            perm[1] = (signed char)itmp;
            perm[2] = (signed char)ib;
            perm[3] = (signed char)i4;
          } else {
            perm[0] = (signed char)m;
            perm[1] = (signed char)itmp;
            perm[2] = (signed char)i4;
            perm[3] = (signed char)ib;
          }
        } else if (x4[m - 1] >= x4[i4 - 1]) {
          if (x4[ib - 1] >= x4[i4 - 1]) {
            perm[0] = (signed char)itmp;
            perm[1] = (signed char)m;
            perm[2] = (signed char)ib;
            perm[3] = (signed char)i4;
          } else {
            perm[0] = (signed char)itmp;
            perm[1] = (signed char)m;
            perm[2] = (signed char)i4;
            perm[3] = (signed char)ib;
          }
        } else {
          perm[0] = (signed char)itmp;
          perm[1] = (signed char)i4;
          perm[2] = (signed char)m;
          perm[3] = (signed char)ib;
        }

        i30 = unnamed_idx_0;
        i31 = wOffset - 3;
        if (!((i31 >= 1) && (i31 <= i30))) {
          rtDynamicBoundsError(i31, 1, i30, &bj_emlrtBCI_DoaMusicSignal);
        }

        idx_data[i31 - 1] = idx4[perm[0] - 1];
        i30 = unnamed_idx_0;
        i31 = wOffset - 2;
        if (!((i31 >= 1) && (i31 <= i30))) {
          rtDynamicBoundsError(i31, 1, i30, &cj_emlrtBCI_DoaMusicSignal);
        }

        idx_data[i31 - 1] = idx4[perm[1] - 1];
        i30 = unnamed_idx_0;
        i31 = wOffset - 1;
        if (!((i31 >= 1) && (i31 <= i30))) {
          rtDynamicBoundsError(i31, 1, i30, &dj_emlrtBCI_DoaMusicSignal);
        }

        idx_data[i31 - 1] = idx4[perm[2] - 1];
        i30 = unnamed_idx_0;
        if (!((wOffset >= 1) && (wOffset <= i30))) {
          rtDynamicBoundsError(wOffset, 1, i30, &ej_emlrtBCI_DoaMusicSignal);
        }

        idx_data[wOffset - 1] = idx4[perm[3] - 1];
        i30 = wOffset - 3;
        if (!((i30 >= 1) && (i30 <= b_x_size[0]))) {
          rtDynamicBoundsError(i30, 1, b_x_size[0], &fj_emlrtBCI_DoaMusicSignal);
        }

        b_x_data[i30 - 1] = x4[perm[0] - 1];
        i30 = wOffset - 2;
        if (!((i30 >= 1) && (i30 <= b_x_size[0]))) {
          rtDynamicBoundsError(i30, 1, b_x_size[0], &gj_emlrtBCI_DoaMusicSignal);
        }

        b_x_data[i30 - 1] = x4[perm[1] - 1];
        i30 = wOffset - 1;
        if (!((i30 >= 1) && (i30 <= b_x_size[0]))) {
          rtDynamicBoundsError(i30, 1, b_x_size[0], &hj_emlrtBCI_DoaMusicSignal);
        }

        b_x_data[i30 - 1] = x4[perm[2] - 1];
        if (!((wOffset >= 1) && (wOffset <= b_x_size[0]))) {
          rtDynamicBoundsError(wOffset, 1, b_x_size[0],
                               &ij_emlrtBCI_DoaMusicSignal);
        }

        b_x_data[wOffset - 1] = x4[perm[3] - 1];
        ib = 0;
      }
    }
  }

  wOffset = x_size[0] - nNaNs;
  if (ib > 0) {
    for (m = 0; m < 4; m++) {
      perm[m] = 0;
    }

    switch (ib) {
     case 1:
      perm[0] = 1;
      break;

     case 2:
      if (x4[0] >= x4[1]) {
        perm[0] = 1;
        perm[1] = 2;
      } else {
        perm[0] = 2;
        perm[1] = 1;
      }
      break;

     default:
      if (x4[0] >= x4[1]) {
        if (x4[1] >= x4[2]) {
          perm[0] = 1;
          perm[1] = 2;
          perm[2] = 3;
        } else if (x4[0] >= x4[2]) {
          perm[0] = 1;
          perm[1] = 3;
          perm[2] = 2;
        } else {
          perm[0] = 3;
          perm[1] = 1;
          perm[2] = 2;
        }
      } else if (x4[0] >= x4[2]) {
        perm[0] = 2;
        perm[1] = 1;
        perm[2] = 3;
      } else if (x4[1] >= x4[2]) {
        perm[0] = 2;
        perm[1] = 3;
        perm[2] = 1;
      } else {
        perm[0] = 3;
        perm[1] = 2;
        perm[2] = 1;
      }
      break;
    }

    if (ib > 2147483646) {
      check_forloop_overflow_error();
    }

    for (k = 1; k <= ib; k++) {
      i30 = perm[k - 1];
      if (!(i30 >= 1)) {
        rtDynamicBoundsError(0, 1, 4, &df_emlrtBCI_DoaMusicSignal);
      }

      i31 = unnamed_idx_0;
      i4 = (wOffset - ib) + k;
      if (!((i4 >= 1) && (i4 <= i31))) {
        rtDynamicBoundsError(i4, 1, i31, &xi_emlrtBCI_DoaMusicSignal);
      }

      idx_data[i4 - 1] = idx4[i30 - 1];
      i30 = perm[k - 1];
      if (!(i30 >= 1)) {
        rtDynamicBoundsError(0, 1, 4, &ff_emlrtBCI_DoaMusicSignal);
      }

      i31 = (wOffset - ib) + k;
      if (!((i31 >= 1) && (i31 <= b_x_size[0]))) {
        rtDynamicBoundsError(i31, 1, b_x_size[0], &yi_emlrtBCI_DoaMusicSignal);
      }

      b_x_data[i31 - 1] = x4[i30 - 1];
    }
  }

  m = nNaNs >> 1;
  for (k = 1; k <= m; k++) {
    i30 = unnamed_idx_0;
    i31 = wOffset + k;
    if (!((i31 >= 1) && (i31 <= i30))) {
      rtDynamicBoundsError(i31, 1, i30, &pi_emlrtBCI_DoaMusicSignal);
    }

    itmp = idx_data[i31 - 1];
    i30 = unnamed_idx_0;
    i31 = (n - k) + 1;
    if (!((i31 >= 1) && (i31 <= i30))) {
      rtDynamicBoundsError(i31, 1, i30, &qi_emlrtBCI_DoaMusicSignal);
    }

    i30 = unnamed_idx_0;
    i4 = wOffset + k;
    if (!((i4 >= 1) && (i4 <= i30))) {
      rtDynamicBoundsError(i4, 1, i30, &ri_emlrtBCI_DoaMusicSignal);
    }

    idx_data[i4 - 1] = idx_data[i31 - 1];
    i30 = unnamed_idx_0;
    i31 = (n - k) + 1;
    if (!((i31 >= 1) && (i31 <= i30))) {
      rtDynamicBoundsError(i31, 1, i30, &si_emlrtBCI_DoaMusicSignal);
    }

    idx_data[i31 - 1] = itmp;
    i30 = (n - k) + 1;
    if (!((i30 >= 1) && (i30 <= xwork))) {
      rtDynamicBoundsError(i30, 1, xwork, &ti_emlrtBCI_DoaMusicSignal);
    }

    i31 = wOffset + k;
    if (!((i31 >= 1) && (i31 <= b_x_size[0]))) {
      rtDynamicBoundsError(i31, 1, b_x_size[0], &ui_emlrtBCI_DoaMusicSignal);
    }

    b_x_data[i31 - 1] = xwork_data[i30 - 1];
    i30 = wOffset + k;
    if (!((i30 >= 1) && (i30 <= xwork))) {
      rtDynamicBoundsError(i30, 1, xwork, &vi_emlrtBCI_DoaMusicSignal);
    }

    i31 = (n - k) + 1;
    if (!((i31 >= 1) && (i31 <= b_x_size[0]))) {
      rtDynamicBoundsError(i31, 1, b_x_size[0], &wi_emlrtBCI_DoaMusicSignal);
    }

    b_x_data[i31 - 1] = xwork_data[i30 - 1];
  }

  if ((nNaNs & 1) != 0) {
    i30 = (unsigned char)x_size[0];
    i31 = (wOffset + m) + 1;
    if (!((i31 >= 1) && (i31 <= i30))) {
      rtDynamicBoundsError(i31, 1, i30, &bi_emlrtBCI_DoaMusicSignal);
    }

    i30 = (wOffset + m) + 1;
    if (!((i30 >= 1) && (i30 <= b_x_size[0]))) {
      rtDynamicBoundsError(i30, 1, b_x_size[0], &ci_emlrtBCI_DoaMusicSignal);
    }

    b_x_data[i30 - 1] = xwork_data[i31 - 1];
  }

  m = x_size[0] - nNaNs;
  if (m > 1) {
    merge_block(idx_data, idx_size, b_x_data, b_x_size, m, iwork_data,
                iwork_size, xwork_data, xwork_size);
  }

  if ((nNaNs > 0) && (m > 0)) {
    if (nNaNs > 2147483646) {
      check_forloop_overflow_error();
    }

    for (k = 1; k <= nNaNs; k++) {
      i30 = m + k;
      if (!((i30 >= 1) && (i30 <= b_x_size[0]))) {
        rtDynamicBoundsError(i30, 1, b_x_size[0], &li_emlrtBCI_DoaMusicSignal);
      }

      if (!((k >= 1) && (k <= xwork_size[0]))) {
        rtDynamicBoundsError(k, 1, xwork_size[0], &mi_emlrtBCI_DoaMusicSignal);
      }

      xwork_data[k - 1] = b_x_data[i30 - 1];
      i30 = m + k;
      if (!((i30 >= 1) && (i30 <= idx_size[0]))) {
        rtDynamicBoundsError(i30, 1, idx_size[0], &ni_emlrtBCI_DoaMusicSignal);
      }

      if (!((k >= 1) && (k <= iwork_size[0]))) {
        rtDynamicBoundsError(k, 1, iwork_size[0], &oi_emlrtBCI_DoaMusicSignal);
      }

      iwork_data[k - 1] = idx_data[i30 - 1];
    }

    while (m > 0) {
      if (!(m <= b_x_size[0])) {
        rtDynamicBoundsError(m, 1, b_x_size[0], &hi_emlrtBCI_DoaMusicSignal);
      }

      i30 = nNaNs + m;
      if (!((i30 >= 1) && (i30 <= b_x_size[0]))) {
        rtDynamicBoundsError(i30, 1, b_x_size[0], &ii_emlrtBCI_DoaMusicSignal);
      }

      b_x_data[i30 - 1] = b_x_data[m - 1];
      if (!(m <= idx_size[0])) {
        rtDynamicBoundsError(m, 1, idx_size[0], &ji_emlrtBCI_DoaMusicSignal);
      }

      i30 = nNaNs + m;
      if (!((i30 >= 1) && (i30 <= idx_size[0]))) {
        rtDynamicBoundsError(i30, 1, idx_size[0], &ki_emlrtBCI_DoaMusicSignal);
      }

      idx_data[i30 - 1] = idx_data[m - 1];
      m--;
    }

    for (k = 1; k <= nNaNs; k++) {
      if (!(k <= xwork_size[0])) {
        rtDynamicBoundsError(k, 1, xwork_size[0], &di_emlrtBCI_DoaMusicSignal);
      }

      if (!(k <= b_x_size[0])) {
        rtDynamicBoundsError(k, 1, b_x_size[0], &ei_emlrtBCI_DoaMusicSignal);
      }

      b_x_data[k - 1] = xwork_data[k - 1];
      if (!(k <= iwork_size[0])) {
        rtDynamicBoundsError(k, 1, iwork_size[0], &fi_emlrtBCI_DoaMusicSignal);
      }

      if (!(k <= idx_size[0])) {
        rtDynamicBoundsError(k, 1, idx_size[0], &gi_emlrtBCI_DoaMusicSignal);
      }

      idx_data[k - 1] = iwork_data[k - 1];
    }
  }

  x_size[0] = b_x_size[0];
  m = b_x_size[0];
  for (i30 = 0; i30 < m; i30++) {
    x_data[i30] = b_x_data[i30];
  }
}

/*
 * Arguments    : const double x[4]
 * Return Type  : double
 */
static double sum(const double x[4])
{
  double y;
  int k;
  y = x[0];
  for (k = 0; k < 3; k++) {
    y += x[k + 1];
  }

  return y;
}

/*
 * Arguments    : creal_T A[16]
 *                int *ilo
 *                int *ihi
 *                int rscale[4]
 * Return Type  : void
 */
static void xzggbal(creal_T A[16], int *ilo, int *ihi, int rscale[4])
{
  int i;
  int exitg2;
  int j;
  boolean_T found;
  int ii;
  boolean_T exitg5;
  int nzcount;
  int jj;
  boolean_T exitg6;
  double atmp_re;
  int exitg1;
  boolean_T guard2 = false;
  double atmp_im;
  boolean_T exitg3;
  boolean_T exitg4;
  boolean_T guard1 = false;
  for (i = 0; i < 4; i++) {
    rscale[i] = 1;
  }

  *ilo = 1;
  *ihi = 4;
  do {
    exitg2 = 0;
    i = 0;
    j = 0;
    found = false;
    ii = *ihi;
    exitg5 = false;
    while ((!exitg5) && (ii > 0)) {
      nzcount = 0;
      i = ii;
      j = *ihi;
      jj = 1;
      exitg6 = false;
      while ((!exitg6) && (jj <= *ihi)) {
        guard2 = false;
        if ((A[(ii + ((jj - 1) << 2)) - 1].re != 0.0) || (A[(ii + ((jj - 1) << 2))
             - 1].im != 0.0) || (ii == jj)) {
          if (nzcount == 0) {
            j = jj;
            nzcount = 1;
            guard2 = true;
          } else {
            nzcount = 2;
            exitg6 = true;
          }
        } else {
          guard2 = true;
        }

        if (guard2) {
          jj++;
        }
      }

      if (nzcount < 2) {
        found = true;
        exitg5 = true;
      } else {
        ii--;
      }
    }

    if (!found) {
      exitg2 = 2;
    } else {
      if (i != *ihi) {
        for (ii = 0; ii < 4; ii++) {
          if (!((i >= 1) && (i <= 4))) {
            rtDynamicBoundsError(i, 1, 4, &ae_emlrtBCI_DoaMusicSignal);
          }

          atmp_re = A[(i + (ii << 2)) - 1].re;
          if (!((i >= 1) && (i <= 4))) {
            rtDynamicBoundsError(i, 1, 4, &wd_emlrtBCI_DoaMusicSignal);
          }

          atmp_im = A[(i + (ii << 2)) - 1].im;
          if (!((*ihi >= 1) && (*ihi <= 4))) {
            rtDynamicBoundsError(*ihi, 1, 4, &be_emlrtBCI_DoaMusicSignal);
          }

          A[(i + (ii << 2)) - 1].re = A[(*ihi + (ii << 2)) - 1].re;
          if (!((*ihi >= 1) && (*ihi <= 4))) {
            rtDynamicBoundsError(*ihi, 1, 4, &xd_emlrtBCI_DoaMusicSignal);
          }

          A[(i + (ii << 2)) - 1].im = A[(*ihi + (ii << 2)) - 1].im;
          A[(*ihi + (ii << 2)) - 1].re = atmp_re;
          A[(*ihi + (ii << 2)) - 1].im = atmp_im;
        }
      }

      if (j != *ihi) {
        for (ii = 0; ii + 1 <= *ihi; ii++) {
          if (!((j >= 1) && (j <= 4))) {
            rtDynamicBoundsError(j, 1, 4, &ce_emlrtBCI_DoaMusicSignal);
          }

          atmp_re = A[ii + ((j - 1) << 2)].re;
          if (!((j >= 1) && (j <= 4))) {
            rtDynamicBoundsError(j, 1, 4, &vd_emlrtBCI_DoaMusicSignal);
          }

          atmp_im = A[ii + ((j - 1) << 2)].im;
          A[ii + ((j - 1) << 2)] = A[ii + ((*ihi - 1) << 2)];
          A[ii + ((*ihi - 1) << 2)].re = atmp_re;
          A[ii + ((*ihi - 1) << 2)].im = atmp_im;
        }
      }

      if (!((*ihi >= 1) && (*ihi <= 4))) {
        rtDynamicBoundsError(*ihi, 1, 4, &ud_emlrtBCI_DoaMusicSignal);
      }

      rscale[*ihi - 1] = j;
      (*ihi)--;
      if (*ihi == 1) {
        rscale[0] = 1;
        exitg2 = 1;
      }
    }
  } while (exitg2 == 0);

  if (exitg2 == 1) {
  } else {
    do {
      exitg1 = 0;
      i = 0;
      j = 0;
      found = false;
      jj = *ilo;
      exitg3 = false;
      while ((!exitg3) && (jj <= *ihi)) {
        nzcount = 0;
        i = *ihi;
        j = jj;
        ii = *ilo;
        exitg4 = false;
        while ((!exitg4) && (ii <= *ihi)) {
          guard1 = false;
          if ((A[(ii + ((jj - 1) << 2)) - 1].re != 0.0) || (A[(ii + ((jj - 1) <<
                 2)) - 1].im != 0.0) || (ii == jj)) {
            if (nzcount == 0) {
              i = ii;
              nzcount = 1;
              guard1 = true;
            } else {
              nzcount = 2;
              exitg4 = true;
            }
          } else {
            guard1 = true;
          }

          if (guard1) {
            ii++;
          }
        }

        if (nzcount < 2) {
          found = true;
          exitg3 = true;
        } else {
          jj++;
        }
      }

      if (!found) {
        exitg1 = 1;
      } else {
        if (i != *ilo) {
          for (ii = *ilo - 1; ii + 1 < 5; ii++) {
            if (!((i >= 1) && (i <= 4))) {
              rtDynamicBoundsError(i, 1, 4, &ae_emlrtBCI_DoaMusicSignal);
            }

            atmp_re = A[(i + (ii << 2)) - 1].re;
            if (!((i >= 1) && (i <= 4))) {
              rtDynamicBoundsError(i, 1, 4, &wd_emlrtBCI_DoaMusicSignal);
            }

            atmp_im = A[(i + (ii << 2)) - 1].im;
            if (!((*ilo >= 1) && (*ilo <= 4))) {
              rtDynamicBoundsError(*ilo, 1, 4, &be_emlrtBCI_DoaMusicSignal);
            }

            A[(i + (ii << 2)) - 1].re = A[(*ilo + (ii << 2)) - 1].re;
            if (!((*ilo >= 1) && (*ilo <= 4))) {
              rtDynamicBoundsError(*ilo, 1, 4, &xd_emlrtBCI_DoaMusicSignal);
            }

            A[(i + (ii << 2)) - 1].im = A[(*ilo + (ii << 2)) - 1].im;
            A[(*ilo + (ii << 2)) - 1].re = atmp_re;
            A[(*ilo + (ii << 2)) - 1].im = atmp_im;
          }
        }

        if (j != *ilo) {
          for (ii = 0; ii + 1 <= *ihi; ii++) {
            if (!((j >= 1) && (j <= 4))) {
              rtDynamicBoundsError(j, 1, 4, &ce_emlrtBCI_DoaMusicSignal);
            }

            atmp_re = A[ii + ((j - 1) << 2)].re;
            if (!((j >= 1) && (j <= 4))) {
              rtDynamicBoundsError(j, 1, 4, &vd_emlrtBCI_DoaMusicSignal);
            }

            atmp_im = A[ii + ((j - 1) << 2)].im;
            if (!((*ilo >= 1) && (*ilo <= 4))) {
              rtDynamicBoundsError(*ilo, 1, 4, &de_emlrtBCI_DoaMusicSignal);
            }

            A[ii + ((j - 1) << 2)].re = A[ii + ((*ilo - 1) << 2)].re;
            if (!((*ilo >= 1) && (*ilo <= 4))) {
              rtDynamicBoundsError(*ilo, 1, 4, &yd_emlrtBCI_DoaMusicSignal);
            }

            A[ii + ((j - 1) << 2)].im = A[ii + ((*ilo - 1) << 2)].im;
            A[ii + ((*ilo - 1) << 2)].re = atmp_re;
            A[ii + ((*ilo - 1) << 2)].im = atmp_im;
          }
        }

        if (!((*ilo >= 1) && (*ilo <= 4))) {
          rtDynamicBoundsError(*ilo, 1, 4, &td_emlrtBCI_DoaMusicSignal);
        }

        rscale[*ilo - 1] = j;
        (*ilo)++;
        if (*ilo == *ihi) {
          rscale[*ilo - 1] = *ilo;
          exitg1 = 1;
        }
      }
    } while (exitg1 == 0);
  }
}

/*
 * Arguments    : creal_T A[16]
 *                int *info
 *                creal_T alpha1[4]
 *                creal_T beta1[4]
 *                creal_T V[16]
 * Return Type  : void
 */
static void xzggev(creal_T A[16], int *info, creal_T alpha1[4], creal_T beta1[4],
                   creal_T V[16])
{
  double anrm;
  int jrow;
  boolean_T exitg1;
  double absxk;
  boolean_T ilascl;
  double anrmto;
  int i;
  int ilo;
  int ihi;
  int rscale[4];
  double ctoc;
  signed char I[16];
  boolean_T notdone;
  double cfrom1;
  double stemp_re;
  double stemp_im;
  int jcol;
  creal_T tmp;
  int j;
  *info = 0;
  anrm = 0.0;
  jrow = 0;
  exitg1 = false;
  while ((!exitg1) && (jrow < 16)) {
    absxk = rt_hypotd_snf(A[jrow].re, A[jrow].im);
    if (rtIsNaN(absxk)) {
      anrm = rtNaN;
      exitg1 = true;
    } else {
      if (absxk > anrm) {
        anrm = absxk;
      }

      jrow++;
    }
  }

  if (!((!rtIsInf(anrm)) && (!rtIsNaN(anrm)))) {
    for (i = 0; i < 4; i++) {
      alpha1[i].re = rtNaN;
      alpha1[i].im = 0.0;
      beta1[i].re = rtNaN;
      beta1[i].im = 0.0;
    }

    for (jrow = 0; jrow < 16; jrow++) {
      V[jrow].re = rtNaN;
      V[jrow].im = 0.0;
    }
  } else {
    ilascl = false;
    anrmto = anrm;
    if ((anrm > 0.0) && (anrm < 6.7178761075670888E-139)) {
      anrmto = 6.7178761075670888E-139;
      ilascl = true;
    } else {
      if (anrm > 1.4885657073574029E+138) {
        anrmto = 1.4885657073574029E+138;
        ilascl = true;
      }
    }

    if (ilascl) {
      absxk = anrm;
      ctoc = anrmto;
      notdone = true;
      while (notdone) {
        cfrom1 = absxk * 2.0041683600089728E-292;
        stemp_re = ctoc / 4.9896007738368E+291;
        if ((cfrom1 > ctoc) && (ctoc != 0.0)) {
          stemp_im = 2.0041683600089728E-292;
          absxk = cfrom1;
        } else if (stemp_re > absxk) {
          stemp_im = 4.9896007738368E+291;
          ctoc = stemp_re;
        } else {
          stemp_im = ctoc / absxk;
          notdone = false;
        }

        for (jrow = 0; jrow < 16; jrow++) {
          A[jrow].re *= stemp_im;
          A[jrow].im *= stemp_im;
        }
      }
    }

    xzggbal(A, &ilo, &ihi, rscale);
    for (jrow = 0; jrow < 16; jrow++) {
      I[jrow] = 0;
    }

    for (jrow = 0; jrow < 4; jrow++) {
      I[jrow + (jrow << 2)] = 1;
    }

    for (jrow = 0; jrow < 16; jrow++) {
      V[jrow].re = I[jrow];
      V[jrow].im = 0.0;
    }

    if (ihi < ilo + 2) {
    } else {
      for (jcol = ilo - 1; jcol + 1 < ihi - 1; jcol++) {
        for (jrow = ihi - 1; jrow + 1 > jcol + 2; jrow--) {
          xzlartg(A[(jrow + (jcol << 2)) - 1], A[jrow + (jcol << 2)], &cfrom1,
                  &tmp, &A[(jrow + (jcol << 2)) - 1]);
          A[jrow + (jcol << 2)].re = 0.0;
          A[jrow + (jcol << 2)].im = 0.0;
          for (j = jcol + 1; j + 1 < 5; j++) {
            stemp_re = cfrom1 * A[(jrow + (j << 2)) - 1].re + (tmp.re * A[jrow +
              (j << 2)].re - tmp.im * A[jrow + (j << 2)].im);
            stemp_im = cfrom1 * A[(jrow + (j << 2)) - 1].im + (tmp.re * A[jrow +
              (j << 2)].im + tmp.im * A[jrow + (j << 2)].re);
            absxk = A[(jrow + (j << 2)) - 1].im;
            ctoc = A[(jrow + (j << 2)) - 1].re;
            A[jrow + (j << 2)].re = cfrom1 * A[jrow + (j << 2)].re - (tmp.re *
              A[(jrow + (j << 2)) - 1].re + tmp.im * A[(jrow + (j << 2)) - 1].im);
            A[jrow + (j << 2)].im = cfrom1 * A[jrow + (j << 2)].im - (tmp.re *
              absxk - tmp.im * ctoc);
            A[(jrow + (j << 2)) - 1].re = stemp_re;
            A[(jrow + (j << 2)) - 1].im = stemp_im;
          }

          tmp.re = -tmp.re;
          tmp.im = -tmp.im;
          if ((!(1 > ihi)) && (ihi > 2147483646)) {
            check_forloop_overflow_error();
          }

          for (i = 0; i + 1 <= ihi; i++) {
            stemp_re = cfrom1 * A[i + (jrow << 2)].re + (tmp.re * A[i + ((jrow -
              1) << 2)].re - tmp.im * A[i + ((jrow - 1) << 2)].im);
            stemp_im = cfrom1 * A[i + (jrow << 2)].im + (tmp.re * A[i + ((jrow -
              1) << 2)].im + tmp.im * A[i + ((jrow - 1) << 2)].re);
            absxk = A[i + (jrow << 2)].im;
            ctoc = A[i + (jrow << 2)].re;
            A[i + ((jrow - 1) << 2)].re = cfrom1 * A[i + ((jrow - 1) << 2)].re -
              (tmp.re * A[i + (jrow << 2)].re + tmp.im * A[i + (jrow << 2)].im);
            A[i + ((jrow - 1) << 2)].im = cfrom1 * A[i + ((jrow - 1) << 2)].im -
              (tmp.re * absxk - tmp.im * ctoc);
            A[i + (jrow << 2)].re = stemp_re;
            A[i + (jrow << 2)].im = stemp_im;
          }

          for (i = 0; i < 4; i++) {
            stemp_re = cfrom1 * V[i + (jrow << 2)].re + (tmp.re * V[i + ((jrow -
              1) << 2)].re - tmp.im * V[i + ((jrow - 1) << 2)].im);
            stemp_im = cfrom1 * V[i + (jrow << 2)].im + (tmp.re * V[i + ((jrow -
              1) << 2)].im + tmp.im * V[i + ((jrow - 1) << 2)].re);
            absxk = V[i + (jrow << 2)].re;
            V[i + ((jrow - 1) << 2)].re = cfrom1 * V[i + ((jrow - 1) << 2)].re -
              (tmp.re * V[i + (jrow << 2)].re + tmp.im * V[i + (jrow << 2)].im);
            V[i + ((jrow - 1) << 2)].im = cfrom1 * V[i + ((jrow - 1) << 2)].im -
              (tmp.re * V[i + (jrow << 2)].im - tmp.im * absxk);
            V[i + (jrow << 2)].re = stemp_re;
            V[i + (jrow << 2)].im = stemp_im;
          }
        }
      }
    }

    xzhgeqz(A, ilo, ihi, V, info, alpha1, beta1);
    if (*info != 0) {
    } else {
      xztgevc(A, V);
      if (ilo > 1) {
        for (i = ilo - 2; i + 1 >= 1; i--) {
          jrow = rscale[i];
          if (rscale[i] != i + 1) {
            for (j = 0; j < 4; j++) {
              tmp = V[i + (j << 2)];
              if (!((jrow >= 1) && (jrow <= 4))) {
                rtDynamicBoundsError(jrow, 1, 4, &sd_emlrtBCI_DoaMusicSignal);
              }

              V[i + (j << 2)].re = V[(jrow + (j << 2)) - 1].re;
              if (!((jrow >= 1) && (jrow <= 4))) {
                rtDynamicBoundsError(jrow, 1, 4, &rd_emlrtBCI_DoaMusicSignal);
              }

              V[i + (j << 2)].im = V[(jrow + (j << 2)) - 1].im;
              V[(jrow + (j << 2)) - 1] = tmp;
            }
          }
        }
      }

      if (ihi < 4) {
        while (ihi + 1 < 5) {
          if (!((ihi + 1 >= 1) && (ihi + 1 <= 4))) {
            rtDynamicBoundsError(ihi + 1, 1, 4, &pd_emlrtBCI_DoaMusicSignal);
          }

          jrow = rscale[ihi];
          if (rscale[ihi] != ihi + 1) {
            for (j = 0; j < 4; j++) {
              tmp = V[ihi + (j << 2)];
              if (!((jrow >= 1) && (jrow <= 4))) {
                rtDynamicBoundsError(jrow, 1, 4, &sd_emlrtBCI_DoaMusicSignal);
              }

              V[ihi + (j << 2)].re = V[(jrow + (j << 2)) - 1].re;
              if (!((jrow >= 1) && (jrow <= 4))) {
                rtDynamicBoundsError(jrow, 1, 4, &qd_emlrtBCI_DoaMusicSignal);
              }

              V[ihi + (j << 2)].im = V[(jrow + (j << 2)) - 1].im;
              V[(jrow + (j << 2)) - 1] = tmp;
            }
          }

          ihi++;
        }
      }

      for (jrow = 0; jrow < 4; jrow++) {
        absxk = fabs(V[jrow << 2].re) + fabs(V[jrow << 2].im);
        for (jcol = 0; jcol < 3; jcol++) {
          ctoc = fabs(V[(jcol + (jrow << 2)) + 1].re) + fabs(V[(jcol + (jrow <<
            2)) + 1].im);
          if (ctoc > absxk) {
            absxk = ctoc;
          }
        }

        if (absxk >= 6.7178761075670888E-139) {
          absxk = 1.0 / absxk;
          for (jcol = 0; jcol < 4; jcol++) {
            V[jcol + (jrow << 2)].re *= absxk;
            V[jcol + (jrow << 2)].im *= absxk;
          }
        }
      }

      if (ilascl) {
        notdone = true;
        while (notdone) {
          cfrom1 = anrmto * 2.0041683600089728E-292;
          stemp_re = anrm / 4.9896007738368E+291;
          if ((cfrom1 > anrm) && (anrm != 0.0)) {
            stemp_im = 2.0041683600089728E-292;
            anrmto = cfrom1;
          } else if (stemp_re > anrmto) {
            stemp_im = 4.9896007738368E+291;
            anrm = stemp_re;
          } else {
            stemp_im = anrm / anrmto;
            notdone = false;
          }

          for (jrow = 0; jrow < 4; jrow++) {
            alpha1[jrow].re *= stemp_im;
            alpha1[jrow].im *= stemp_im;
          }
        }
      }
    }
  }
}

/*
 * Arguments    : creal_T A[16]
 *                int ilo
 *                int ihi
 *                creal_T Z[16]
 *                int *info
 *                creal_T alpha1[4]
 *                creal_T beta1[4]
 * Return Type  : void
 */
static void xzhgeqz(creal_T A[16], int ilo, int ihi, creal_T Z[16], int *info,
                    creal_T alpha1[4], creal_T beta1[4])
{
  int i;
  double eshift_re;
  double eshift_im;
  creal_T ctemp;
  double anorm;
  double scale;
  double sumsq;
  double reAij;
  boolean_T firstNonZero;
  double b_atol;
  int j;
  int jp1;
  double ascale;
  boolean_T failed;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  int ifirst;
  double imAij;
  int istart;
  int ilast;
  int ilastm1;
  int iiter;
  int maxit;
  double temp2;
  boolean_T goto60;
  boolean_T goto70;
  boolean_T goto90;
  int jiter;
  int exitg1;
  boolean_T exitg3;
  boolean_T b_guard1 = false;
  creal_T b_ascale;
  creal_T shift;
  double ad22_re;
  creal_T b_A;
  double ad22_im;
  boolean_T exitg2;
  double t1_im;
  creal_T c_A;
  *info = 0;
  for (i = 0; i < 4; i++) {
    alpha1[i].re = 0.0;
    alpha1[i].im = 0.0;
    beta1[i].re = 1.0;
    beta1[i].im = 0.0;
  }

  eshift_re = 0.0;
  eshift_im = 0.0;
  ctemp.re = 0.0;
  ctemp.im = 0.0;
  anorm = 0.0;
  if (ilo > ihi) {
  } else {
    scale = 0.0;
    sumsq = 0.0;
    firstNonZero = true;
    if ((!(ilo > ihi)) && (ihi > 2147483646)) {
      check_forloop_overflow_error();
    }

    for (j = ilo; j <= ihi; j++) {
      jp1 = j + 1;
      if (ihi < j + 1) {
        jp1 = ihi;
      }

      if ((!(ilo > jp1)) && (jp1 > 2147483646)) {
        check_forloop_overflow_error();
      }

      for (i = ilo; i <= jp1; i++) {
        reAij = A[(i + ((j - 1) << 2)) - 1].re;
        imAij = A[(i + ((j - 1) << 2)) - 1].im;
        if (reAij != 0.0) {
          anorm = fabs(reAij);
          if (firstNonZero) {
            sumsq = 1.0;
            scale = anorm;
            firstNonZero = false;
          } else if (scale < anorm) {
            temp2 = scale / anorm;
            sumsq = 1.0 + sumsq * temp2 * temp2;
            scale = anorm;
          } else {
            temp2 = anorm / scale;
            sumsq += temp2 * temp2;
          }
        }

        if (imAij != 0.0) {
          anorm = fabs(imAij);
          if (firstNonZero) {
            sumsq = 1.0;
            scale = anorm;
            firstNonZero = false;
          } else if (scale < anorm) {
            temp2 = scale / anorm;
            sumsq = 1.0 + sumsq * temp2 * temp2;
            scale = anorm;
          } else {
            temp2 = anorm / scale;
            sumsq += temp2 * temp2;
          }
        }
      }
    }

    if (sumsq < 0.0) {
      error();
    }

    anorm = scale * sqrt(sumsq);
  }

  reAij = 2.2204460492503131E-16 * anorm;
  b_atol = 2.2250738585072014E-308;
  if (reAij > 2.2250738585072014E-308) {
    b_atol = reAij;
  }

  reAij = 2.2250738585072014E-308;
  if (anorm > 2.2250738585072014E-308) {
    reAij = anorm;
  }

  ascale = 1.0 / reAij;
  failed = true;
  for (j = ihi + 1; j < 5; j++) {
    if (!(j >= 1)) {
      rtDynamicBoundsError(j, 1, 4, &pe_emlrtBCI_DoaMusicSignal);
    }

    if (!(j >= 1)) {
      rtDynamicBoundsError(j, 1, 4, &pe_emlrtBCI_DoaMusicSignal);
    }

    if (!(j >= 1)) {
      rtDynamicBoundsError(j, 1, 4, &pe_emlrtBCI_DoaMusicSignal);
    }

    alpha1[j - 1].re = A[(j + ((j - 1) << 2)) - 1].re;
    if (!(j >= 1)) {
      rtDynamicBoundsError(j, 1, 4, &oe_emlrtBCI_DoaMusicSignal);
    }

    if (!(j >= 1)) {
      rtDynamicBoundsError(j, 1, 4, &oe_emlrtBCI_DoaMusicSignal);
    }

    if (!(j >= 1)) {
      rtDynamicBoundsError(j, 1, 4, &pe_emlrtBCI_DoaMusicSignal);
    }

    alpha1[j - 1].im = A[(j + ((j - 1) << 2)) - 1].im;
  }

  guard1 = false;
  guard2 = false;
  if (ihi >= ilo) {
    ifirst = ilo - 1;
    istart = ilo;
    ilast = ihi - 1;
    ilastm1 = ihi - 2;
    iiter = 0;
    maxit = 30 * ((ihi - ilo) + 1);
    goto60 = false;
    goto70 = false;
    goto90 = false;
    if ((!(1 > maxit)) && (maxit > 2147483646)) {
      check_forloop_overflow_error();
    }

    jiter = 1;
    do {
      exitg1 = 0;
      if (jiter <= maxit) {
        if (ilast + 1 == ilo) {
          goto60 = true;
        } else {
          if (!((ilast + 1 >= 1) && (ilast + 1 <= 4))) {
            rtDynamicBoundsError(ilast + 1, 1, 4, &ee_emlrtBCI_DoaMusicSignal);
          }

          if (!((ilastm1 + 1 >= 1) && (ilastm1 + 1 <= 4))) {
            rtDynamicBoundsError(ilastm1 + 1, 1, 4, &fe_emlrtBCI_DoaMusicSignal);
          }

          if (fabs(A[ilast + (ilastm1 << 2)].re) + fabs(A[ilast + (ilastm1 << 2)]
               .im) <= b_atol) {
            A[ilast + (ilastm1 << 2)].re = 0.0;
            A[ilast + (ilastm1 << 2)].im = 0.0;
            goto60 = true;
          } else {
            j = ilastm1;
            exitg3 = false;
            while ((!exitg3) && (j + 1 >= ilo)) {
              if (j + 1 == ilo) {
                firstNonZero = true;
              } else {
                if (!((j >= 1) && (j <= 4))) {
                  rtDynamicBoundsError(j, 1, 4, &ge_emlrtBCI_DoaMusicSignal);
                }

                if (fabs(A[j + ((j - 1) << 2)].re) + fabs(A[j + ((j - 1) << 2)].
                     im) <= b_atol) {
                  A[j + ((j - 1) << 2)].re = 0.0;
                  A[j + ((j - 1) << 2)].im = 0.0;
                  firstNonZero = true;
                } else {
                  firstNonZero = false;
                }
              }

              if (firstNonZero) {
                ifirst = j;
                goto70 = true;
                exitg3 = true;
              } else {
                j--;
              }
            }
          }
        }

        if (goto60 || goto70) {
          firstNonZero = true;
        } else {
          firstNonZero = false;
        }

        if (!firstNonZero) {
          for (i = 0; i < 4; i++) {
            alpha1[i].re = rtNaN;
            alpha1[i].im = 0.0;
            beta1[i].re = rtNaN;
            beta1[i].im = 0.0;
          }

          for (jp1 = 0; jp1 < 16; jp1++) {
            Z[jp1].re = rtNaN;
            Z[jp1].im = 0.0;
          }

          *info = 1;
          exitg1 = 1;
        } else {
          b_guard1 = false;
          if (goto60) {
            goto60 = false;
            alpha1[ilast] = A[ilast + (ilast << 2)];
            ilast = ilastm1;
            ilastm1--;
            if (ilast + 1 < ilo) {
              failed = false;
              guard2 = true;
              exitg1 = 1;
            } else {
              iiter = 0;
              eshift_re = 0.0;
              eshift_im = 0.0;
              b_guard1 = true;
            }
          } else {
            if (goto70) {
              goto70 = false;
              iiter++;
              if (iiter - iiter / 10 * 10 != 0) {
                if (!((ilastm1 + 1 >= 1) && (ilastm1 + 1 <= 4))) {
                  rtDynamicBoundsError(ilastm1 + 1, 1, 4,
                                       &he_emlrtBCI_DoaMusicSignal);
                }

                anorm = ascale * A[ilastm1 + (ilastm1 << 2)].re;
                reAij = ascale * A[ilastm1 + (ilastm1 << 2)].im;
                if (reAij == 0.0) {
                  shift.re = anorm / 0.5;
                  shift.im = 0.0;
                } else if (anorm == 0.0) {
                  shift.re = 0.0;
                  shift.im = reAij / 0.5;
                } else {
                  shift.re = anorm / 0.5;
                  shift.im = reAij / 0.5;
                }

                anorm = ascale * A[ilast + (ilast << 2)].re;
                reAij = ascale * A[ilast + (ilast << 2)].im;
                if (reAij == 0.0) {
                  ad22_re = anorm / 0.5;
                  ad22_im = 0.0;
                } else if (anorm == 0.0) {
                  ad22_re = 0.0;
                  ad22_im = reAij / 0.5;
                } else {
                  ad22_re = anorm / 0.5;
                  ad22_im = reAij / 0.5;
                }

                temp2 = 0.5 * (shift.re + ad22_re);
                t1_im = 0.5 * (shift.im + ad22_im);
                anorm = ascale * A[ilastm1 + (ilast << 2)].re;
                reAij = ascale * A[ilastm1 + (ilast << 2)].im;
                if (reAij == 0.0) {
                  sumsq = anorm / 0.5;
                  imAij = 0.0;
                } else if (anorm == 0.0) {
                  sumsq = 0.0;
                  imAij = reAij / 0.5;
                } else {
                  sumsq = anorm / 0.5;
                  imAij = reAij / 0.5;
                }

                anorm = ascale * A[ilast + (ilastm1 << 2)].re;
                reAij = ascale * A[ilast + (ilastm1 << 2)].im;
                if (reAij == 0.0) {
                  scale = anorm / 0.5;
                  anorm = 0.0;
                } else if (anorm == 0.0) {
                  scale = 0.0;
                  anorm = reAij / 0.5;
                } else {
                  scale = anorm / 0.5;
                  anorm = reAij / 0.5;
                }

                reAij = shift.re * ad22_im + shift.im * ad22_re;
                shift.re = ((temp2 * temp2 - t1_im * t1_im) + (sumsq * scale -
                  imAij * anorm)) - (shift.re * ad22_re - shift.im * ad22_im);
                shift.im = ((temp2 * t1_im + t1_im * temp2) + (sumsq * anorm +
                  imAij * scale)) - reAij;
                b_sqrt(&shift);
                if ((temp2 - ad22_re) * shift.re + (t1_im - ad22_im) * shift.im <=
                    0.0) {
                  shift.re += temp2;
                  shift.im += t1_im;
                } else {
                  shift.re = temp2 - shift.re;
                  shift.im = t1_im - shift.im;
                }
              } else {
                if (!((ilastm1 + 1 >= 1) && (ilastm1 + 1 <= 4))) {
                  rtDynamicBoundsError(ilastm1 + 1, 1, 4,
                                       &ie_emlrtBCI_DoaMusicSignal);
                }

                anorm = ascale * A[ilast + (ilastm1 << 2)].re;
                reAij = ascale * A[ilast + (ilastm1 << 2)].im;
                if (reAij == 0.0) {
                  sumsq = anorm / 0.5;
                  imAij = 0.0;
                } else if (anorm == 0.0) {
                  sumsq = 0.0;
                  imAij = reAij / 0.5;
                } else {
                  sumsq = anorm / 0.5;
                  imAij = reAij / 0.5;
                }

                eshift_re += sumsq;
                eshift_im += imAij;
                shift.re = eshift_re;
                shift.im = eshift_im;
              }

              j = ilastm1;
              jp1 = ilastm1 + 1;
              exitg2 = false;
              while ((!exitg2) && (j + 1 > ifirst + 1)) {
                istart = j + 1;
                ctemp.re = ascale * A[j + (j << 2)].re - shift.re * 0.5;
                ctemp.im = ascale * A[j + (j << 2)].im - shift.im * 0.5;
                anorm = fabs(ctemp.re) + fabs(ctemp.im);
                if (!((jp1 + 1 >= 1) && (jp1 + 1 <= 4))) {
                  rtDynamicBoundsError(jp1 + 1, 1, 4,
                                       &je_emlrtBCI_DoaMusicSignal);
                }

                temp2 = ascale * (fabs(A[jp1 + (j << 2)].re) + fabs(A[jp1 + (j <<
                  2)].im));
                reAij = anorm;
                if (temp2 > anorm) {
                  reAij = temp2;
                }

                if ((reAij < 1.0) && (reAij != 0.0)) {
                  anorm /= reAij;
                  temp2 /= reAij;
                }

                if ((fabs(A[j + ((j - 1) << 2)].re) + fabs(A[j + ((j - 1) << 2)]
                      .im)) * temp2 <= anorm * b_atol) {
                  goto90 = true;
                  exitg2 = true;
                } else {
                  jp1 = j;
                  j--;
                }
              }

              if (!goto90) {
                istart = ifirst + 1;
                ctemp.re = ascale * A[ifirst + (ifirst << 2)].re - shift.re *
                  0.5;
                ctemp.im = ascale * A[ifirst + (ifirst << 2)].im - shift.im *
                  0.5;
                goto90 = true;
              }
            }

            if (goto90) {
              goto90 = false;
              if (!((istart + 1 >= 1) && (istart + 1 <= 4))) {
                rtDynamicBoundsError(istart + 1, 1, 4,
                                     &ke_emlrtBCI_DoaMusicSignal);
              }

              b_ascale.re = ascale * A[istart + ((istart - 1) << 2)].re;
              b_ascale.im = ascale * A[istart + ((istart - 1) << 2)].im;
              b_xzlartg(ctemp, b_ascale, &scale, &shift);
              j = istart;
              jp1 = istart - 1;
              while (j < ilast + 1) {
                if (j > istart) {
                  if (!((jp1 >= 1) && (jp1 <= 4))) {
                    rtDynamicBoundsError(jp1, 1, 4, &me_emlrtBCI_DoaMusicSignal);
                  }

                  b_A.re = A[(j + ((jp1 - 1) << 2)) - 1].re;
                  if (!((jp1 >= 1) && (jp1 <= 4))) {
                    rtDynamicBoundsError(jp1, 1, 4, &me_emlrtBCI_DoaMusicSignal);
                  }

                  b_A.im = A[(j + ((jp1 - 1) << 2)) - 1].im;
                  if (!((jp1 >= 1) && (jp1 <= 4))) {
                    rtDynamicBoundsError(jp1, 1, 4, &ne_emlrtBCI_DoaMusicSignal);
                  }

                  c_A.re = A[j + ((jp1 - 1) << 2)].re;
                  if (!((jp1 >= 1) && (jp1 <= 4))) {
                    rtDynamicBoundsError(jp1, 1, 4, &ne_emlrtBCI_DoaMusicSignal);
                  }

                  c_A.im = A[j + ((jp1 - 1) << 2)].im;
                  xzlartg(b_A, c_A, &scale, &shift, &A[(j + ((jp1 - 1) << 2)) -
                          1]);
                  A[j + ((jp1 - 1) << 2)].re = 0.0;
                  A[j + ((jp1 - 1) << 2)].im = 0.0;
                }

                for (jp1 = j - 1; jp1 + 1 < 5; jp1++) {
                  ad22_re = scale * A[(j + (jp1 << 2)) - 1].re + (shift.re * A[j
                    + (jp1 << 2)].re - shift.im * A[j + (jp1 << 2)].im);
                  ad22_im = scale * A[(j + (jp1 << 2)) - 1].im + (shift.re * A[j
                    + (jp1 << 2)].im + shift.im * A[j + (jp1 << 2)].re);
                  anorm = A[(j + (jp1 << 2)) - 1].im;
                  reAij = A[(j + (jp1 << 2)) - 1].re;
                  A[j + (jp1 << 2)].re = scale * A[j + (jp1 << 2)].re -
                    (shift.re * A[(j + (jp1 << 2)) - 1].re + shift.im * A[(j +
                      (jp1 << 2)) - 1].im);
                  A[j + (jp1 << 2)].im = scale * A[j + (jp1 << 2)].im -
                    (shift.re * anorm - shift.im * reAij);
                  A[(j + (jp1 << 2)) - 1].re = ad22_re;
                  A[(j + (jp1 << 2)) - 1].im = ad22_im;
                }

                shift.re = -shift.re;
                shift.im = -shift.im;
                jp1 = j + 2;
                if (ilast + 1 < j + 2) {
                  jp1 = ilast + 1;
                }

                if ((!(1 > jp1)) && (jp1 > 2147483646)) {
                  check_forloop_overflow_error();
                }

                for (i = 0; i + 1 <= jp1; i++) {
                  ad22_re = scale * A[i + (j << 2)].re + (shift.re * A[i + ((j -
                    1) << 2)].re - shift.im * A[i + ((j - 1) << 2)].im);
                  ad22_im = scale * A[i + (j << 2)].im + (shift.re * A[i + ((j -
                    1) << 2)].im + shift.im * A[i + ((j - 1) << 2)].re);
                  anorm = A[i + (j << 2)].im;
                  reAij = A[i + (j << 2)].re;
                  A[i + ((j - 1) << 2)].re = scale * A[i + ((j - 1) << 2)].re -
                    (shift.re * A[i + (j << 2)].re + shift.im * A[i + (j << 2)].
                     im);
                  A[i + ((j - 1) << 2)].im = scale * A[i + ((j - 1) << 2)].im -
                    (shift.re * anorm - shift.im * reAij);
                  A[i + (j << 2)].re = ad22_re;
                  A[i + (j << 2)].im = ad22_im;
                }

                for (i = 0; i < 4; i++) {
                  ad22_re = scale * Z[i + (j << 2)].re + (shift.re * Z[i + ((j -
                    1) << 2)].re - shift.im * Z[i + ((j - 1) << 2)].im);
                  ad22_im = scale * Z[i + (j << 2)].im + (shift.re * Z[i + ((j -
                    1) << 2)].im + shift.im * Z[i + ((j - 1) << 2)].re);
                  anorm = Z[i + (j << 2)].im;
                  reAij = Z[i + (j << 2)].re;
                  Z[i + ((j - 1) << 2)].re = scale * Z[i + ((j - 1) << 2)].re -
                    (shift.re * Z[i + (j << 2)].re + shift.im * Z[i + (j << 2)].
                     im);
                  Z[i + ((j - 1) << 2)].im = scale * Z[i + ((j - 1) << 2)].im -
                    (shift.re * anorm - shift.im * reAij);
                  Z[i + (j << 2)].re = ad22_re;
                  Z[i + (j << 2)].im = ad22_im;
                }

                jp1 = j;
                j++;
              }
            }

            b_guard1 = true;
          }

          if (b_guard1) {
            jiter++;
          }
        }
      } else {
        guard2 = true;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  } else {
    guard1 = true;
  }

  if (guard2) {
    if (failed) {
      *info = ilast + 1;
      if ((!(1 > ilast + 1)) && (ilast + 1 > 2147483646)) {
        check_forloop_overflow_error();
      }

      for (jp1 = 1; jp1 <= ilast + 1; jp1++) {
        if (!((jp1 >= 1) && (jp1 <= 4))) {
          rtDynamicBoundsError(jp1, 1, 4, &le_emlrtBCI_DoaMusicSignal);
        }

        alpha1[jp1 - 1].re = rtNaN;
        if (!((jp1 >= 1) && (jp1 <= 4))) {
          rtDynamicBoundsError(jp1, 1, 4, &le_emlrtBCI_DoaMusicSignal);
        }

        alpha1[jp1 - 1].im = 0.0;
        beta1[jp1 - 1].re = rtNaN;
        beta1[jp1 - 1].im = 0.0;
      }

      for (jp1 = 0; jp1 < 16; jp1++) {
        Z[jp1].re = rtNaN;
        Z[jp1].im = 0.0;
      }
    } else {
      guard1 = true;
    }
  }

  if (guard1) {
    if ((!(1 > ilo - 1)) && (ilo - 1 > 2147483646)) {
      check_forloop_overflow_error();
    }

    for (j = 0; j + 1 < ilo; j++) {
      alpha1[j] = A[j + (j << 2)];
    }
  }
}

/*
 * Arguments    : const creal_T f
 *                const creal_T g
 *                double *cs
 *                creal_T *sn
 *                creal_T *r
 * Return Type  : void
 */
static void xzlartg(const creal_T f, const creal_T g, double *cs, creal_T *sn,
                    creal_T *r)
{
  double scale;
  double f2s;
  double x;
  double fs_re;
  double fs_im;
  double gs_re;
  double gs_im;
  int count;
  int rescaledir;
  boolean_T guard1 = false;
  double g2;
  double g2s;
  scale = fabs(f.re);
  f2s = fabs(f.im);
  if (f2s > scale) {
    scale = f2s;
  }

  x = fabs(g.re);
  f2s = fabs(g.im);
  if (f2s > x) {
    x = f2s;
  }

  if (x > scale) {
    scale = x;
  }

  fs_re = f.re;
  fs_im = f.im;
  gs_re = g.re;
  gs_im = g.im;
  count = 0;
  rescaledir = 0;
  guard1 = false;
  if (scale >= 7.4428285367870146E+137) {
    do {
      count++;
      fs_re *= 1.3435752215134178E-138;
      fs_im *= 1.3435752215134178E-138;
      gs_re *= 1.3435752215134178E-138;
      gs_im *= 1.3435752215134178E-138;
      scale *= 1.3435752215134178E-138;
    } while (!(scale < 7.4428285367870146E+137));

    rescaledir = 1;
    guard1 = true;
  } else if (scale <= 1.3435752215134178E-138) {
    if ((g.re == 0.0) && (g.im == 0.0)) {
      *cs = 1.0;
      sn->re = 0.0;
      sn->im = 0.0;
      *r = f;
    } else {
      do {
        count++;
        fs_re *= 7.4428285367870146E+137;
        fs_im *= 7.4428285367870146E+137;
        gs_re *= 7.4428285367870146E+137;
        gs_im *= 7.4428285367870146E+137;
        scale *= 7.4428285367870146E+137;
      } while (!(scale > 1.3435752215134178E-138));

      rescaledir = -1;
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1) {
    scale = fs_re * fs_re + fs_im * fs_im;
    g2 = gs_re * gs_re + gs_im * gs_im;
    x = g2;
    if (1.0 > g2) {
      x = 1.0;
    }

    if (scale <= x * 2.0041683600089728E-292) {
      if ((f.re == 0.0) && (f.im == 0.0)) {
        *cs = 0.0;
        r->re = rt_hypotd_snf(g.re, g.im);
        r->im = 0.0;
        g2 = rt_hypotd_snf(gs_re, gs_im);
        sn->re = gs_re / g2;
        sn->im = -gs_im / g2;
      } else {
        if (g2 < 0.0) {
          error();
        }

        g2s = sqrt(g2);
        *cs = rt_hypotd_snf(fs_re, fs_im) / g2s;
        x = fabs(f.re);
        f2s = fabs(f.im);
        if (f2s > x) {
          x = f2s;
        }

        if (x > 1.0) {
          g2 = rt_hypotd_snf(f.re, f.im);
          fs_re = f.re / g2;
          fs_im = f.im / g2;
        } else {
          scale = 7.4428285367870146E+137 * f.re;
          f2s = 7.4428285367870146E+137 * f.im;
          g2 = rt_hypotd_snf(scale, f2s);
          fs_re = scale / g2;
          fs_im = f2s / g2;
        }

        gs_re /= g2s;
        gs_im = -gs_im / g2s;
        sn->re = fs_re * gs_re - fs_im * gs_im;
        sn->im = fs_re * gs_im + fs_im * gs_re;
        r->re = *cs * f.re + (sn->re * g.re - sn->im * g.im);
        r->im = *cs * f.im + (sn->re * g.im + sn->im * g.re);
      }
    } else {
      x = 1.0 + g2 / scale;
      if (x < 0.0) {
        error();
      }

      f2s = sqrt(x);
      r->re = f2s * fs_re;
      r->im = f2s * fs_im;
      *cs = 1.0 / f2s;
      g2 += scale;
      scale = r->re / g2;
      f2s = r->im / g2;
      sn->re = scale * gs_re - f2s * -gs_im;
      sn->im = scale * -gs_im + f2s * gs_re;
      if (rescaledir > 0) {
        if ((!(1 > count)) && (count > 2147483646)) {
          check_forloop_overflow_error();
        }

        for (rescaledir = 1; rescaledir <= count; rescaledir++) {
          r->re *= 7.4428285367870146E+137;
          r->im *= 7.4428285367870146E+137;
        }
      } else {
        if (rescaledir < 0) {
          if ((!(1 > count)) && (count > 2147483646)) {
            check_forloop_overflow_error();
          }

          for (rescaledir = 1; rescaledir <= count; rescaledir++) {
            r->re *= 1.3435752215134178E-138;
            r->im *= 1.3435752215134178E-138;
          }
        }
      }
    }
  }
}

/*
 * Arguments    : const creal_T A[16]
 *                creal_T V[16]
 * Return Type  : void
 */
static void xztgevc(const creal_T A[16], creal_T V[16])
{
  double rworka[4];
  int jc;
  double anorm;
  int j;
  double xmx;
  double ascale;
  double d_re;
  int je;
  double temp;
  double salpha_re;
  double salpha_im;
  double acoeff;
  boolean_T b0;
  boolean_T b1;
  double scale;
  double acoefa;
  creal_T work1[4];
  int jr;
  double dmin;
  creal_T work2[4];
  int b_j;
  double d_im;
  double work1_re;
  for (jc = 0; jc < 4; jc++) {
    rworka[jc] = 0.0;
  }

  anorm = fabs(A[0].re) + fabs(A[0].im);
  for (j = 0; j < 3; j++) {
    for (jc = 0; jc <= j; jc++) {
      rworka[j + 1] += fabs(A[jc + ((j + 1) << 2)].re) + fabs(A[jc + ((j + 1) <<
        2)].im);
    }

    d_re = rworka[j + 1] + (fabs(A[(j + ((j + 1) << 2)) + 1].re) + fabs(A[(j +
      ((j + 1) << 2)) + 1].im));
    if (d_re > anorm) {
      anorm = d_re;
    }
  }

  xmx = anorm;
  if (2.2250738585072014E-308 > anorm) {
    xmx = 2.2250738585072014E-308;
  }

  ascale = 1.0 / xmx;
  for (je = 0; je < 4; je++) {
    xmx = (fabs(A[(((3 - je) << 2) - je) + 3].re) + fabs(A[(((3 - je) << 2) - je)
            + 3].im)) * ascale;
    if (1.0 > xmx) {
      xmx = 1.0;
    }

    temp = 1.0 / xmx;
    salpha_re = ascale * (temp * A[(((3 - je) << 2) - je) + 3].re);
    salpha_im = ascale * (temp * A[(((3 - je) << 2) - je) + 3].im);
    acoeff = temp * ascale;
    if ((fabs(temp) >= 2.2250738585072014E-308) && (fabs(acoeff) <
         4.0083367200179456E-292)) {
      b0 = true;
    } else {
      b0 = false;
    }

    if ((fabs(salpha_re) + fabs(salpha_im) >= 2.2250738585072014E-308) && (fabs
         (salpha_re) + fabs(salpha_im) < 4.0083367200179456E-292)) {
      b1 = true;
    } else {
      b1 = false;
    }

    scale = 1.0;
    if (b0) {
      xmx = anorm;
      if (2.4948003869184E+291 < anorm) {
        xmx = 2.4948003869184E+291;
      }

      scale = 4.0083367200179456E-292 / fabs(temp) * xmx;
    }

    if (b1) {
      d_re = 4.0083367200179456E-292 / (fabs(salpha_re) + fabs(salpha_im));
      if (d_re > scale) {
        scale = d_re;
      }
    }

    if (b0 || b1) {
      xmx = fabs(acoeff);
      d_re = fabs(salpha_re) + fabs(salpha_im);
      if (1.0 > xmx) {
        xmx = 1.0;
      }

      if (d_re > xmx) {
        xmx = d_re;
      }

      d_re = 1.0 / (2.2250738585072014E-308 * xmx);
      if (d_re < scale) {
        scale = d_re;
      }

      if (b0) {
        acoeff = ascale * (scale * temp);
      } else {
        acoeff *= scale;
      }

      if (b1) {
        salpha_re *= scale;
        salpha_im *= scale;
      } else {
        salpha_re *= scale;
        salpha_im *= scale;
      }
    }

    acoefa = fabs(acoeff);
    for (jr = 0; jr < 4; jr++) {
      work1[jr].re = 0.0;
      work1[jr].im = 0.0;
    }

    work1[3 - je].re = 1.0;
    work1[3 - je].im = 0.0;
    dmin = 2.2204460492503131E-16 * acoefa * anorm;
    d_re = 2.2204460492503131E-16 * (fabs(salpha_re) + fabs(salpha_im));
    if (d_re > dmin) {
      dmin = d_re;
    }

    if (2.2250738585072014E-308 > dmin) {
      dmin = 2.2250738585072014E-308;
    }

    for (jr = 0; jr <= 2 - je; jr++) {
      work1[jr].re = acoeff * A[jr + ((3 - je) << 2)].re;
      work1[jr].im = acoeff * A[jr + ((3 - je) << 2)].im;
    }

    work1[3 - je].re = 1.0;
    work1[3 - je].im = 0.0;
    for (j = 0; j <= 2 - je; j++) {
      b_j = (-je - j) + 2;
      jc = b_j + 1;
      if (!(jc >= 1)) {
        rtDynamicBoundsError(jc, 1, 4, &qe_emlrtBCI_DoaMusicSignal);
      }

      d_re = acoeff * A[b_j + (b_j << 2)].re - salpha_re;
      d_im = acoeff * A[b_j + (b_j << 2)].im - salpha_im;
      if (fabs(d_re) + fabs(d_im) <= dmin) {
        d_re = dmin;
        d_im = 0.0;
      }

      if ((fabs(d_re) + fabs(d_im) < 1.0) && (fabs(work1[b_j].re) + fabs
           (work1[b_j].im) >= 1.1235582092889474E+307 * (fabs(d_re) + fabs(d_im))))
      {
        temp = 1.0 / (fabs(work1[b_j].re) + fabs(work1[b_j].im));
        for (jr = 0; jr <= 3 - je; jr++) {
          work1[jr].re *= temp;
          work1[jr].im *= temp;
        }
      }

      work1_re = -work1[b_j].re;
      if (d_im == 0.0) {
        if (-work1[b_j].im == 0.0) {
          work1[b_j].re = -work1[b_j].re / d_re;
          work1[b_j].im = 0.0;
        } else if (-work1[b_j].re == 0.0) {
          work1[b_j].re = 0.0;
          work1[b_j].im = -work1[b_j].im / d_re;
        } else {
          work1[b_j].re = -work1[b_j].re / d_re;
          work1[b_j].im = -work1[b_j].im / d_re;
        }
      } else if (d_re == 0.0) {
        if (-work1[b_j].re == 0.0) {
          work1[b_j].re = -work1[b_j].im / d_im;
          work1[b_j].im = 0.0;
        } else if (-work1[b_j].im == 0.0) {
          work1[b_j].re = 0.0;
          work1[b_j].im = -(work1_re / d_im);
        } else {
          work1[b_j].re = -work1[b_j].im / d_im;
          work1[b_j].im = -(work1_re / d_im);
        }
      } else {
        temp = fabs(d_re);
        xmx = fabs(d_im);
        if (temp > xmx) {
          scale = d_im / d_re;
          xmx = d_re + scale * d_im;
          work1[b_j].re = (-work1[b_j].re + scale * -work1[b_j].im) / xmx;
          work1[b_j].im = (-work1[b_j].im - scale * work1_re) / xmx;
        } else if (xmx == temp) {
          if (d_re > 0.0) {
            scale = 0.5;
          } else {
            scale = -0.5;
          }

          if (d_im > 0.0) {
            xmx = 0.5;
          } else {
            xmx = -0.5;
          }

          work1[b_j].re = (-work1[b_j].re * scale + -work1[b_j].im * xmx) / temp;
          work1[b_j].im = (-work1[b_j].im * scale - work1_re * xmx) / temp;
        } else {
          scale = d_re / d_im;
          xmx = d_im + scale * d_re;
          work1[b_j].re = (scale * -work1[b_j].re + -work1[b_j].im) / xmx;
          work1[b_j].im = (scale * -work1[b_j].im - work1_re) / xmx;
        }
      }

      if (b_j + 1 > 1) {
        if (fabs(work1[b_j].re) + fabs(work1[b_j].im) > 1.0) {
          temp = 1.0 / (fabs(work1[b_j].re) + fabs(work1[b_j].im));
          if (acoefa * rworka[b_j] >= 1.1235582092889474E+307 * temp) {
            for (jr = 0; jr <= 3 - je; jr++) {
              work1[jr].re *= temp;
              work1[jr].im *= temp;
            }
          }
        }

        d_re = acoeff * work1[b_j].re;
        d_im = acoeff * work1[b_j].im;
        for (jr = 0; jr < b_j; jr++) {
          work1[jr].re += d_re * A[jr + (b_j << 2)].re - d_im * A[jr + (b_j << 2)]
            .im;
          work1[jr].im += d_re * A[jr + (b_j << 2)].im + d_im * A[jr + (b_j << 2)]
            .re;
        }
      }
    }

    for (jr = 0; jr < 4; jr++) {
      work2[jr].re = 0.0;
      work2[jr].im = 0.0;
    }

    for (jc = 0; jc <= 3 - je; jc++) {
      for (jr = 0; jr < 4; jr++) {
        work2[jr].re += V[jr + (jc << 2)].re * work1[jc].re - V[jr + (jc << 2)].
          im * work1[jc].im;
        work2[jr].im += V[jr + (jc << 2)].re * work1[jc].im + V[jr + (jc << 2)].
          im * work1[jc].re;
      }
    }

    xmx = fabs(work2[0].re) + fabs(work2[0].im);
    for (jr = 0; jr < 3; jr++) {
      d_re = fabs(work2[jr + 1].re) + fabs(work2[jr + 1].im);
      if (d_re > xmx) {
        xmx = d_re;
      }
    }

    if (xmx > 2.2250738585072014E-308) {
      temp = 1.0 / xmx;
      for (jr = 0; jr < 4; jr++) {
        V[jr + ((3 - je) << 2)].re = temp * work2[jr].re;
        V[jr + ((3 - je) << 2)].im = temp * work2[jr].im;
      }
    } else {
      for (jr = 0; jr < 4; jr++) {
        V[jr + ((3 - je) << 2)].re = 0.0;
        V[jr + ((3 - je) << 2)].im = 0.0;
      }
    }
  }
}

/*
 * DOA estimation using MUSIC method. but filter only the signal.
 *  input:
 *     % recStvPartition, MxK complex, matrix of steering vectors, each column is one steering vector for a specific Azimuth angle. M is the number of channel. K is the number of azimuth scan angle.
 *     % rxSigNoise: NxM complex, N is the number of snapshots, M is the number of channel. each colum is one snapshot
 *     % PilotSequence: Nx1 complex, N is the length of pilot.
 *     % AzimuthScanAngles: 1xK double, azimuth scan angle in degree, should be in assending order.
 *     % MaxNumSig: 1x1 double, the number of maximum signals in DOA search.
 *     % FilterFlag: 1x1 double, the switch of PN filter function.
 *  output:
 *     % spatialSpectrum, 1xK double, it is a matrix representing the magnitude of the estimated spatial spectrum.
 *     % doas, 1xP double, the signal's direction of arrival (DOA) .
 *  2017-10-18 V1.0 Collus Wang and Wayne Zhang. inherited from old repo.
 *  2017-10-20 V1.1 Collus Wang. eigD convert to double.
 * Arguments    : const creal_T recStvPartition[484]
 *                const creal_T rxSigNoise[2048]
 *                const creal_T PilotSequence[512]
 *                const double AzimuthScanAngles[121]
 *                double MaxNumSig
 *                double FilterFlag
 *                double spatialSpectrum[121]
 *                double doas_data[]
 *                int doas_size[1]
 * Return Type  : void
 */
void DoaEstimatorMUSICSignalImplement(const creal_T recStvPartition[484], const
  creal_T rxSigNoise[2048], const creal_T PilotSequence[512], const double
  AzimuthScanAngles[121], double MaxNumSig, double FilterFlag, double
  spatialSpectrum[121], double doas_data[], int doas_size[1])
{
  int i0;
  creal_T Pxs[4];
  int i1;
  creal_T Rxx[16];
  creal_T eigV[16];
  double eigD[4];
  int ixstart;
  double unusedU0[4];
  double temp_re;
  double temp_im;
  int iidx[4];
  double b_eigD[4];
  double SigThd;
  double pwrSum;
  int NumSig;
  int idx;
  boolean_T exitg4;
  int loop_ub;
  creal_T b_eigV[16];
  creal_T Vnoise_data[12];
  creal_T b_data[12];
  creal_T b_recStvPartition[484];
  int br;
  int ic;
  creal_T c_recStvPartition[484];
  int ar;
  int b;
  creal_T dcv0[121];
  creal_T dcv1[121];
  int ib;
  double brm;
  boolean_T exitg2;
  boolean_T exitg3;
  double b_spatialSpectrum[121];
  double idxDoa_data[247];
  double processSpectrum[121];
  int ia;
  double b_processSpectrum[123];
  double unusedU2_data[246];
  int unusedU2_size[2];
  double b_idxDoa_data[246];
  int idxDoa_size[2];
  boolean_T exitg1;
  boolean_T c_idxDoa_data[246];
  int b_idxDoa_size[2];
  double itmp_data[247];

  /* 'DoaEstimatorMUSICSignalImplement:16' if FilterFlag == 1 */
  if (FilterFlag == 1.0) {
    /* 'DoaEstimatorMUSICSignalImplement:17' Pxs = rxSigNoise.'*conj(PilotSequence); */
    for (i0 = 0; i0 < 4; i0++) {
      Pxs[i0].re = 0.0;
      Pxs[i0].im = 0.0;
      for (i1 = 0; i1 < 512; i1++) {
        Pxs[i0].re += rxSigNoise[i1 + (i0 << 9)].re * PilotSequence[i1].re -
          rxSigNoise[i1 + (i0 << 9)].im * -PilotSequence[i1].im;
        Pxs[i0].im += rxSigNoise[i1 + (i0 << 9)].re * -PilotSequence[i1].im +
          rxSigNoise[i1 + (i0 << 9)].im * PilotSequence[i1].re;
      }
    }

    /*  PN code filtering in time. */
    /* 'DoaEstimatorMUSICSignalImplement:18' Rxx = Pxs*Pxs'; */
    for (i0 = 0; i0 < 4; i0++) {
      for (i1 = 0; i1 < 4; i1++) {
        Rxx[i0 + (i1 << 2)].re = Pxs[i0].re * Pxs[i1].re - Pxs[i0].im * -Pxs[i1]
          .im;
        Rxx[i0 + (i1 << 2)].im = Pxs[i0].re * -Pxs[i1].im + Pxs[i0].im * Pxs[i1]
          .re;
      }
    }
  } else {
    /* 'DoaEstimatorMUSICSignalImplement:19' else */
    /* 'DoaEstimatorMUSICSignalImplement:20' Rxx = rxSigNoise.'*conj(rxSigNoise); */
    for (i0 = 0; i0 < 4; i0++) {
      for (i1 = 0; i1 < 4; i1++) {
        Rxx[i0 + (i1 << 2)].re = 0.0;
        Rxx[i0 + (i1 << 2)].im = 0.0;
        for (ixstart = 0; ixstart < 512; ixstart++) {
          temp_re = rxSigNoise[ixstart + (i1 << 9)].re;
          temp_im = -rxSigNoise[ixstart + (i1 << 9)].im;
          Rxx[i0 + (i1 << 2)].re += rxSigNoise[ixstart + (i0 << 9)].re * temp_re
            - rxSigNoise[ixstart + (i0 << 9)].im * temp_im;
          Rxx[i0 + (i1 << 2)].im += rxSigNoise[ixstart + (i0 << 9)].re * temp_im
            + rxSigNoise[ixstart + (i0 << 9)].im * temp_re;
        }
      }
    }
  }

  /* 'DoaEstimatorMUSICSignalImplement:23' [eigV, eigD] = eig(Rxx, 'vector'); */
  eig(Rxx, eigV, Pxs);

  /* 'DoaEstimatorMUSICSignalImplement:24' eigD = abs(eigD); */
  b_abs(Pxs, eigD);

  /* 'DoaEstimatorMUSICSignalImplement:25' [~,idx] = sort(eigD, 'ascend'); */
  for (ixstart = 0; ixstart < 4; ixstart++) {
    unusedU0[ixstart] = eigD[ixstart];
  }

  sort(unusedU0, iidx);
  for (ixstart = 0; ixstart < 4; ixstart++) {
    unusedU0[ixstart] = iidx[ixstart];
  }

  /* 'DoaEstimatorMUSICSignalImplement:25' ~ */
  /* 'DoaEstimatorMUSICSignalImplement:26' eigD = eigD(idx); */
  for (i0 = 0; i0 < 4; i0++) {
    i1 = (int)unusedU0[i0];
    if (!((i1 >= 1) && (i1 <= 4))) {
      rtDynamicBoundsError(i1, 1, 4, &emlrtBCI_DoaMusicSignal);
    }

    b_eigD[i0] = eigD[i1 - 1];
  }

  for (i0 = 0; i0 < 4; i0++) {
    eigD[i0] = b_eigD[i0];
  }

  /* 'DoaEstimatorMUSICSignalImplement:27' eigV = eigV(:,idx); */
  /*  find out the Number of signal. */
  /* 'DoaEstimatorMUSICSignalImplement:30' SigThd = 0.8*sum(eigD); */
  SigThd = 0.8 * sum(eigD);

  /*  assume the signals power should exceed certurn percentage of the total power. */
  /* 'DoaEstimatorMUSICSignalImplement:31' NumCh = length(eigD); */
  /* 'DoaEstimatorMUSICSignalImplement:32' pwrSum = 0; */
  pwrSum = 0.0;

  /* 'DoaEstimatorMUSICSignalImplement:33' NumSig = NumCh-1; */
  NumSig = 3;

  /*  at least one column for noise space */
  /* 'DoaEstimatorMUSICSignalImplement:34' for idx = 1:NumCh-1 */
  idx = 0;
  exitg4 = false;
  while ((!exitg4) && (idx < 3)) {
    /* 'DoaEstimatorMUSICSignalImplement:35' pwrSum = pwrSum + eigD(NumCh-idx+1); */
    pwrSum += eigD[3 - idx];

    /* 'DoaEstimatorMUSICSignalImplement:36' if pwrSum>SigThd */
    if (pwrSum > SigThd) {
      /* 'DoaEstimatorMUSICSignalImplement:37' NumSig = idx; */
      NumSig = 1 + idx;
      exitg4 = true;
    } else {
      idx++;
    }
  }

  /*  noise space construction */
  /* 'DoaEstimatorMUSICSignalImplement:43' Vnoise = eigV(:, 1:NumCh-NumSig ); */
  loop_ub = 4 - NumSig;
  for (i0 = 0; i0 < 4; i0++) {
    for (i1 = 0; i1 < 4; i1++) {
      b_eigV[i1 + (i0 << 2)] = eigV[i1 + (((int)unusedU0[i0] - 1) << 2)];
    }
  }

  for (i0 = 0; i0 < loop_ub; i0++) {
    memcpy(&Vnoise_data[i0 << 2], &b_eigV[i0 << 2], sizeof(creal_T) << 2);
  }

  /* 'DoaEstimatorMUSICSignalImplement:44' Rnn = Vnoise*Vnoise'; */
  for (i0 = 0; i0 < 4; i0++) {
    for (i1 = 0; i1 < loop_ub; i1++) {
      b_data[i1 + loop_ub * i0].re = Vnoise_data[i0 + (i1 << 2)].re;
      b_data[i1 + loop_ub * i0].im = -Vnoise_data[i0 + (i1 << 2)].im;
    }
  }

  if (!(4 - NumSig == loop_ub)) {
    rtErrorWithMessageID(&emlrtRTEI_DoaMusicSignal);
  }

  if ((4 - NumSig == 1) || (loop_ub == 1)) {
    for (i0 = 0; i0 < 4; i0++) {
      for (i1 = 0; i1 < 4; i1++) {
        Rxx[i0 + (i1 << 2)].re = 0.0;
        Rxx[i0 + (i1 << 2)].im = 0.0;
        for (ixstart = 0; ixstart < loop_ub; ixstart++) {
          Rxx[i0 + (i1 << 2)].re += Vnoise_data[i0 + (ixstart << 2)].re *
            b_data[ixstart + loop_ub * i1].re - Vnoise_data[i0 + (ixstart << 2)]
            .im * b_data[ixstart + loop_ub * i1].im;
          Rxx[i0 + (i1 << 2)].im += Vnoise_data[i0 + (ixstart << 2)].re *
            b_data[ixstart + loop_ub * i1].im + Vnoise_data[i0 + (ixstart << 2)]
            .im * b_data[ixstart + loop_ub * i1].re;
        }
      }
    }
  } else {
    i0 = 4 - NumSig;
    memset(&Rxx[0], 0, sizeof(creal_T) << 4);
    for (ixstart = 0; ixstart <= 13; ixstart += 4) {
      for (ic = ixstart; ic + 1 <= ixstart + 4; ic++) {
        Rxx[ic].re = 0.0;
        Rxx[ic].im = 0.0;
      }
    }

    br = 1;
    for (ixstart = 0; ixstart <= 13; ixstart += 4) {
      ar = 0;
      b = (br + i0) - 1;
      if ((!(br > b)) && (b > 2147483646)) {
        check_forloop_overflow_error();
      }

      for (ib = br; ib <= b; ib++) {
        i1 = loop_ub << 2;
        if (!((ib >= 1) && (ib <= i1))) {
          rtDynamicBoundsError(ib, 1, i1, &d_emlrtBCI_DoaMusicSignal);
        }

        i1 = loop_ub << 2;
        if (!((ib >= 1) && (ib <= i1))) {
          rtDynamicBoundsError(ib, 1, i1, &d_emlrtBCI_DoaMusicSignal);
        }

        if ((b_data[ib - 1].re != 0.0) || (b_data[ib - 1].im != 0.0)) {
          i1 = loop_ub << 2;
          if (!((ib >= 1) && (ib <= i1))) {
            rtDynamicBoundsError(ib, 1, i1, &c_emlrtBCI_DoaMusicSignal);
          }

          i1 = loop_ub << 2;
          if (!((ib >= 1) && (ib <= i1))) {
            rtDynamicBoundsError(ib, 1, i1, &c_emlrtBCI_DoaMusicSignal);
          }

          temp_re = b_data[ib - 1].re - 0.0 * b_data[ib - 1].im;
          i1 = loop_ub << 2;
          if (!((ib >= 1) && (ib <= i1))) {
            rtDynamicBoundsError(ib, 1, i1, &c_emlrtBCI_DoaMusicSignal);
          }

          i1 = loop_ub << 2;
          if (!((ib >= 1) && (ib <= i1))) {
            rtDynamicBoundsError(ib, 1, i1, &c_emlrtBCI_DoaMusicSignal);
          }

          temp_im = b_data[ib - 1].im + 0.0 * b_data[ib - 1].re;
          ia = ar;
          for (ic = ixstart; ic + 1 <= ixstart + 4; ic++) {
            ia++;
            i1 = (4 - NumSig) << 2;
            if (!((ia >= 1) && (ia <= i1))) {
              rtDynamicBoundsError(ia, 1, i1, &e_emlrtBCI_DoaMusicSignal);
            }

            i1 = (4 - NumSig) << 2;
            if (!((ia >= 1) && (ia <= i1))) {
              rtDynamicBoundsError(ia, 1, i1, &e_emlrtBCI_DoaMusicSignal);
            }

            i1 = (4 - NumSig) << 2;
            if (!((ia >= 1) && (ia <= i1))) {
              rtDynamicBoundsError(ia, 1, i1, &e_emlrtBCI_DoaMusicSignal);
            }

            i1 = (4 - NumSig) << 2;
            if (!((ia >= 1) && (ia <= i1))) {
              rtDynamicBoundsError(ia, 1, i1, &e_emlrtBCI_DoaMusicSignal);
            }

            Rxx[ic].re += temp_re * Vnoise_data[ia - 1].re - temp_im *
              Vnoise_data[ia - 1].im;
            Rxx[ic].im += temp_re * Vnoise_data[ia - 1].im + temp_im *
              Vnoise_data[ia - 1].re;
          }
        }

        ar += 4;
      }

      br += i0;
    }
  }

  /* 'DoaEstimatorMUSICSignalImplement:46' spatialSpectrum = abs(1./sum((recStvPartition'*Rnn).'.*recStvPartition)); */
  for (i0 = 0; i0 < 4; i0++) {
    for (i1 = 0; i1 < 121; i1++) {
      b_recStvPartition[i0 + (i1 << 2)].re = 0.0;
      b_recStvPartition[i0 + (i1 << 2)].im = 0.0;
      for (ixstart = 0; ixstart < 4; ixstart++) {
        temp_re = recStvPartition[ixstart + (i1 << 2)].re;
        temp_im = -recStvPartition[ixstart + (i1 << 2)].im;
        b_recStvPartition[i0 + (i1 << 2)].re += temp_re * Rxx[ixstart + (i0 << 2)]
          .re - temp_im * Rxx[ixstart + (i0 << 2)].im;
        b_recStvPartition[i0 + (i1 << 2)].im += temp_re * Rxx[ixstart + (i0 << 2)]
          .im + temp_im * Rxx[ixstart + (i0 << 2)].re;
      }
    }
  }

  for (i0 = 0; i0 < 121; i0++) {
    for (i1 = 0; i1 < 4; i1++) {
      c_recStvPartition[i1 + (i0 << 2)].re = b_recStvPartition[i1 + (i0 << 2)].
        re * recStvPartition[i1 + (i0 << 2)].re - b_recStvPartition[i1 + (i0 <<
        2)].im * recStvPartition[i1 + (i0 << 2)].im;
      c_recStvPartition[i1 + (i0 << 2)].im = b_recStvPartition[i1 + (i0 << 2)].
        re * recStvPartition[i1 + (i0 << 2)].im + b_recStvPartition[i1 + (i0 <<
        2)].im * recStvPartition[i1 + (i0 << 2)].re;
    }
  }

  b_sum(c_recStvPartition, dcv0);
  for (i0 = 0; i0 < 121; i0++) {
    if (dcv0[i0].im == 0.0) {
      dcv1[i0].re = 1.0 / dcv0[i0].re;
      dcv1[i0].im = 0.0;
    } else if (dcv0[i0].re == 0.0) {
      dcv1[i0].re = 0.0;
      dcv1[i0].im = -(1.0 / dcv0[i0].im);
    } else {
      brm = fabs(dcv0[i0].re);
      temp_re = fabs(dcv0[i0].im);
      if (brm > temp_re) {
        temp_re = dcv0[i0].im / dcv0[i0].re;
        temp_im = dcv0[i0].re + temp_re * dcv0[i0].im;
        dcv1[i0].re = (1.0 + temp_re * 0.0) / temp_im;
        dcv1[i0].im = (0.0 - temp_re) / temp_im;
      } else if (temp_re == brm) {
        if (dcv0[i0].re > 0.0) {
          temp_re = 0.5;
        } else {
          temp_re = -0.5;
        }

        if (dcv0[i0].im > 0.0) {
          temp_im = 0.5;
        } else {
          temp_im = -0.5;
        }

        dcv1[i0].re = (temp_re + 0.0 * temp_im) / brm;
        dcv1[i0].im = (0.0 * temp_re - temp_im) / brm;
      } else {
        temp_re = dcv0[i0].re / dcv0[i0].im;
        temp_im = dcv0[i0].im + temp_re * dcv0[i0].re;
        dcv1[i0].re = temp_re / temp_im;
        dcv1[i0].im = (temp_re * 0.0 - 1.0) / temp_im;
      }
    }
  }

  c_abs(dcv1, spatialSpectrum);

  /* 'DoaEstimatorMUSICSignalImplement:48' if MaxNumSig ==1 */
  if (MaxNumSig == 1.0) {
    /* 'DoaEstimatorMUSICSignalImplement:49' [~,idxDoa] = max(spatialSpectrum); */
    ixstart = 1;
    temp_re = spatialSpectrum[0];
    ar = 1;
    if (rtIsNaN(spatialSpectrum[0])) {
      br = 2;
      exitg3 = false;
      while ((!exitg3) && (br < 122)) {
        ixstart = br;
        if (!rtIsNaN(spatialSpectrum[br - 1])) {
          temp_re = spatialSpectrum[br - 1];
          ar = br;
          exitg3 = true;
        } else {
          br++;
        }
      }
    }

    if (ixstart < 121) {
      while (ixstart + 1 < 122) {
        if (spatialSpectrum[ixstart] > temp_re) {
          temp_re = spatialSpectrum[ixstart];
          ar = ixstart + 1;
        }

        ixstart++;
      }
    }

    b = 1;
    idxDoa_data[0] = ar;

    /* 'DoaEstimatorMUSICSignalImplement:49' ~ */
  } else {
    /* 'DoaEstimatorMUSICSignalImplement:50' else */
    /* 'DoaEstimatorMUSICSignalImplement:51' processSpectrum = spatialSpectrum/max(spatialSpectrum); */
    ixstart = 1;
    temp_re = spatialSpectrum[0];
    if (rtIsNaN(spatialSpectrum[0])) {
      br = 2;
      exitg2 = false;
      while ((!exitg2) && (br < 122)) {
        ixstart = br;
        if (!rtIsNaN(spatialSpectrum[br - 1])) {
          temp_re = spatialSpectrum[br - 1];
          exitg2 = true;
        } else {
          br++;
        }
      }
    }

    if (ixstart < 121) {
      while (ixstart + 1 < 122) {
        if (spatialSpectrum[ixstart] > temp_re) {
          temp_re = spatialSpectrum[ixstart];
        }

        ixstart++;
      }
    }

    /* 'DoaEstimatorMUSICSignalImplement:52' processSpectrum = pow2db(processSpectrum); */
    for (i0 = 0; i0 < 121; i0++) {
      b_spatialSpectrum[i0] = spatialSpectrum[i0] / temp_re;
    }

    pow2db(b_spatialSpectrum, processSpectrum);

    /* 'DoaEstimatorMUSICSignalImplement:53' processSpectrumExpand = [processSpectrum(2), processSpectrum, processSpectrum(end-1) ]; */
    /*  expand the spectrum so that findpeaks can return peaks at the boundary. */
    /*  peak para. */
    /* 'DoaEstimatorMUSICSignalImplement:55' minPeakHeight = -15; */
    /* 'DoaEstimatorMUSICSignalImplement:56' minPeakProminence = .5; */
    /* 'DoaEstimatorMUSICSignalImplement:57' minPeakDistance = 1/(AzimuthScanAngles(2)-AzimuthScanAngles(1)); */
    /*  degrees / reselution */
    /*  find peaks */
    /* 'DoaEstimatorMUSICSignalImplement:59' [~, idxDoa] = findpeaks(processSpectrumExpand, 'NPeaks', min([MaxNumSig,NumSig]), 'MinPeakProminence', minPeakProminence, 'MinPeakHeight', minPeakHeight, 'MinPeakDistance', minPeakDistance); */
    ixstart = 1;
    temp_re = MaxNumSig;
    if (rtIsNaN(MaxNumSig)) {
      ixstart = 2;
      temp_re = NumSig;
    }

    if ((ixstart < 2) && (NumSig < temp_re)) {
      temp_re = NumSig;
    }

    b_processSpectrum[0] = processSpectrum[1];
    memcpy(&b_processSpectrum[1], &processSpectrum[0], 121U * sizeof(double));
    b_processSpectrum[122] = processSpectrum[119];
    findpeaks(b_processSpectrum, temp_re, 1.0 / (AzimuthScanAngles[1] -
               AzimuthScanAngles[0]), unusedU2_data, unusedU2_size,
              b_idxDoa_data, idxDoa_size);

    /* 'DoaEstimatorMUSICSignalImplement:59' ~ */
    /* 'DoaEstimatorMUSICSignalImplement:60' idxDoa = idxDoa - 1; */
    b = idxDoa_size[1];
    loop_ub = idxDoa_size[0] * idxDoa_size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      idxDoa_data[i0] = b_idxDoa_data[i0] - 1.0;
    }

    /*  index of processSpectrum and processSpectrumExpand differs 1 point */
    /*  if max is not in the peak list, add max */
    /* 'DoaEstimatorMUSICSignalImplement:62' [~,idxMax] = max(processSpectrum); */
    ixstart = 1;
    temp_re = processSpectrum[0];
    ar = 1;
    if (rtIsNaN(processSpectrum[0])) {
      br = 2;
      exitg1 = false;
      while ((!exitg1) && (br < 122)) {
        ixstart = br;
        if (!rtIsNaN(processSpectrum[br - 1])) {
          temp_re = processSpectrum[br - 1];
          ar = br;
          exitg1 = true;
        } else {
          br++;
        }
      }
    }

    if (ixstart < 121) {
      while (ixstart + 1 < 122) {
        if (processSpectrum[ixstart] > temp_re) {
          temp_re = processSpectrum[ixstart];
          ar = ixstart + 1;
        }

        ixstart++;
      }
    }

    /* 'DoaEstimatorMUSICSignalImplement:62' ~ */
    /* 'DoaEstimatorMUSICSignalImplement:63' if ~sum(idxDoa == idxMax) */
    b_idxDoa_size[0] = 1;
    b_idxDoa_size[1] = idxDoa_size[1];
    loop_ub = idxDoa_size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      c_idxDoa_data[i0] = (idxDoa_data[i0] == ar);
    }

    if (!(c_sum(c_idxDoa_data, b_idxDoa_size) != 0.0)) {
      /* 'DoaEstimatorMUSICSignalImplement:64' idxDoa = [idxMax, idxDoa]; */
      itmp_data[0] = ar;
      loop_ub = idxDoa_size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        itmp_data[i0 + 1] = idxDoa_data[i0];
      }

      b = 1 + idxDoa_size[1];
      loop_ub = 1 + idxDoa_size[1];
      for (i0 = 0; i0 < loop_ub; i0++) {
        idxDoa_data[i0] = itmp_data[i0];
      }
    }
  }

  /* 'DoaEstimatorMUSICSignalImplement:67' doas = AzimuthScanAngles(idxDoa); */
  doas_size[0] = b;
  for (i0 = 0; i0 < b; i0++) {
    i1 = (int)idxDoa_data[i0];
    if (!((i1 >= 1) && (i1 <= 121))) {
      rtDynamicBoundsError(i1, 1, 121, &b_emlrtBCI_DoaMusicSignal);
    }

    doas_data[i0] = AzimuthScanAngles[i1 - 1];
  }
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void DoaEstimatorMUSICSignalImplement_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void DoaEstimatorMUSICSignalImplement_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for DoaEstimatorMUSICSignalImplement.c
 *
 * [EOF]
 */
