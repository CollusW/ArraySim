/*
 * File: DoaEstimatorMUSICSignalImplement.c
 *
 * MATLAB Coder version            : 3.3
 * C/C++ source code generated on  : 20-Oct-2017 09:57:53
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "DoaEstimatorMUSICSignalImplement.h"

/* Type Definitions */
#ifndef struct_emxArray_int32_T_246_DoaMusicSi
#define struct_emxArray_int32_T_246_DoaMusicSi

struct emxArray_int32_T_246_DoaMusicSi
{
  int data_DoaMusicSignal[246];
  int size_DoaMusicSignal[1];
};

#endif                                 /*struct_emxArray_int32_T_246_DoaMusicSi*/

#ifndef typedef_emxArray_int32_T_246_DoaMusicSi
#define typedef_emxArray_int32_T_246_DoaMusicSi

typedef struct emxArray_int32_T_246_DoaMusicSi emxArray_int32_T_246_DoaMusicSi;

#endif                                 /*typedef_emxArray_int32_T_246_DoaMusicSi*/

/* Function Declarations */
static void abs_DoaMusicSignal(const creal_T x[4], double y[4]);
static boolean_T anyNonFinite_DoaMusicSignal(const creal_T x[16]);
static void assignFullOutputs_DoaMusicSigna(const double y[123], const int
  iPk_data[], const int iPk_size[1], const double wxPk_data[], const int
  wxPk_size[2], const double bPk_data[], double YpkOut_data[], int YpkOut_size[2],
  double XpkOut_data[], int XpkOut_size[2], double WpkOut_data[], int
  WpkOut_size[2], double PpkOut_data[], int PpkOut_size[2]);
static void b_abs_DoaMusicSignal(const creal_T x[121], double y[121]);
static void b_do_vectors_DoaMusicSignal(const int a_data[], const int a_size[1],
  const int b_data[], const int b_size[1], int c_data[], int c_size[1], int
  ia_data[], int ia_size[1], int ib_data[], int ib_size[1]);
static void b_merge_DoaMusicSignal(int idx_data[], int x_data[], int offset, int
  np, int nq, int iwork_data[], int xwork_data[]);
static void b_sortIdx_DoaMusicSignal(int x_data[], int x_size[1], int idx_data[],
  int idx_size[1]);
static void b_sort_DoaMusicSignal(double x[4], int idx[4]);
static void b_sum_DoaMusicSignal(const creal_T x[484], creal_T y[121]);
static void b_xscal_DoaMusicSignal(int n, const creal_T a, creal_T x[16], int
  ix0);
static void b_xzlartg_DoaMusicSignal(const creal_T f, const creal_T g, double
  *cs, creal_T *sn);
static void c_findPeaksSeparatedByMoreThanM(const double y[123], const int
  iPk_data[], const int iPk_size[1], double Pd, int idx_data[], int idx_size[1]);
static void c_removePeaksBelowMinPeakPromin(const double y[123], int iPk_data[],
  int iPk_size[1], double pbPk_data[], int pbPk_size[1], int iLB_data[], int
  iLB_size[1], int iRB_data[], int iRB_size[1]);
static void c_sort_DoaMusicSignal(int x_data[], int x_size[1]);
static double c_sum_DoaMusicSignal(const boolean_T x_data[], const int x_size[2]);
static void c_xscal_DoaMusicSignal(const creal_T a, creal_T x[16], int ix0);
static void combineFullPeaks_DoaMusicSignal(const double y[123], const int
  iPk_data[], const int iPk_size[1], const double bPk_data[], const int
  bPk_size[1], const int iLBw_data[], const int iLBw_size[1], const int
  iRBw_data[], const int iRBw_size[1], const double wPk_data[], const int
  wPk_size[2], const int iInf_data[], const int iInf_size[1], int iPkOut_data[],
  int iPkOut_size[1], double bPkOut_data[], int bPkOut_size[1], double
  bxPkOut_data[], int bxPkOut_size[2], double byPkOut_data[], int byPkOut_size[2],
  double wxPkOut_data[], int wxPkOut_size[2]);
static void diff_DoaMusicSignal(const double x_data[], const int x_size[2],
  double y_data[], int y_size[1]);
static void do_vectors_DoaMusicSignal(const int a_data[], const int a_size[1],
  const int b_data[], const int b_size[1], int c_data[], int c_size[1], int
  ia_data[], int ia_size[1], int ib_data[], int ib_size[1]);
static void eig_DoaMusicSignal(const creal_T A[16], creal_T V[16], creal_T D[4]);
static int eml_zlahqr_DoaMusicSignal(creal_T h[16], creal_T z[16]);
static void fetchPeakExtents_DoaMusicSignal(const int idx_data[], const int
  idx_size[1], double bPk_data[], int bPk_size[1], double bxPk_data[], int
  bxPk_size[2], double byPk_data[], int byPk_size[2], double wxPk_data[], int
  wxPk_size[2]);
static void findExtents_DoaMusicSignal(const double y[123], int iPk_data[], int
  iPk_size[1], const int iFin_data[], const int iFin_size[1], const int
  iInf_data[], const int iInf_size[1], const int iInflect_data[], const int
  iInflect_size[1], double bPk_data[], int bPk_size[1], double bxPk_data[], int
  bxPk_size[2], double byPk_data[], int byPk_size[2], double wxPk_data[], int
  wxPk_size[2]);
static void findpeaks_DoaMusicSignal(const double Yin[123], double varargin_2,
  double varargin_8, double Ypk_data[], int Ypk_size[2], double Xpk_data[], int
  Xpk_size[2]);
static void getAllPeaksCodegen_DoaMusicSign(const double y[123], int iPk_data[],
  int iPk_size[1], int iInf_data[], int iInf_size[1], int iInflect_data[], int
  iInflect_size[1]);
static void getLeftBase_DoaMusicSignal(const double yTemp[123], const int
  iPeak_data[], const int iPeak_size[1], const int iFinite_data[], const int
  iFinite_size[1], const int iInflect_data[], int iBase_data[], int iBase_size[1],
  int iSaddle_data[], int iSaddle_size[1]);
static void getPeakBase_DoaMusicSignal(const double yTemp[123], const int
  iPk_data[], const int iPk_size[1], const int iFin_data[], const int iFin_size
  [1], const int iInflect_data[], const int iInflect_size[1], double
  peakBase_data[], int peakBase_size[1], int iLeftSaddle_data[], int
  iLeftSaddle_size[1], int iRightSaddle_data[], int iRightSaddle_size[1]);
static void getPeakWidth_DoaMusicSignal(const double y[123], const int iPk_data[],
  const int iPk_size[1], const double pbPk_data[], const int pbPk_size[1], int
  iLB_data[], int iLB_size[1], int iRB_data[], int iRB_size[1], double
  wxPk_data[], int wxPk_size[2]);
static void keepAtMostNpPeaks_DoaMusicSigna(int idx_size[1], double Np);
static void merge_DoaMusicSignal(int idx[4], double x[4], int offset, int np,
  int nq, int iwork[4], double xwork[4]);
static void merge_block_DoaMusicSignal(int idx_data[], int x_data[], int n, int
  iwork_data[], int xwork_data[]);
static int nonSingletonDim_DoaMusicSignal(const int x_size[1]);
static void parse_inputs_DoaMusicSignal(const double Yin[123], double varargin_2,
  double varargin_8, double y[123], double *Pd, double *NpOut);
static void pow2db_DoaMusicSignal(const double y[121], double ydB[121]);
static creal_T recip_DoaMusicSignal(const creal_T y);
static void removeSmallPeaks_DoaMusicSignal(const double y[123], const int
  iFinite_data[], const int iFinite_size[1], int iPk_data[], int iPk_size[1]);
static double rt_hypotd_snf_DoaMusicSignal(double u0, double u1);
static void schur_DoaMusicSignal(const creal_T A[16], creal_T V[16], creal_T T
  [16]);
static void sortIdx_DoaMusicSignal(const double x_data[], const int x_size[1],
  int idx_data[], int idx_size[1]);
static void sort_DoaMusicSignal(double x[4], int idx[4]);
static void sqrt_DoaMusicSignal(creal_T *x);
static double sum_DoaMusicSignal(const double x[4]);
static double xdlapy3_DoaMusicSignal(double x1, double x2, double x3);
static void xgehrd_DoaMusicSignal(creal_T a[16], creal_T tau[3]);
static void xgerc_DoaMusicSignal(int m, int n, const creal_T alpha1, int ix0,
  const creal_T y[4], creal_T A[16], int ia0);
static double xnrm2_DoaMusicSignal(int n, const creal_T x[16], int ix0);
static void xscal_DoaMusicSignal(int n, const creal_T a, creal_T x[16], int ix0);
static void xzggev_DoaMusicSignal(creal_T A[16], int *info, creal_T alpha1[4],
  creal_T beta1[4], creal_T V[16]);
static void xzhgeqz_DoaMusicSignal(creal_T A[16], int ilo, int ihi, creal_T Z[16],
  int *info, creal_T alpha1[4], creal_T beta1[4]);
static creal_T xzlarfg_DoaMusicSignal(creal_T *alpha1, creal_T *x);
static void xzlartg_DoaMusicSignal(const creal_T f, const creal_T g, double *cs,
  creal_T *sn, creal_T *r);
static void xzlascl_DoaMusicSignal(double cfrom, double cto, creal_T A[16]);
static void xztgevc_DoaMusicSignal(const creal_T A[16], creal_T V[16]);

/* Function Definitions */

/*
 * Arguments    : const creal_T x[4]
 *                double y[4]
 * Return Type  : void
 */
static void abs_DoaMusicSignal(const creal_T x[4], double y[4])
{
  int k;
  for (k = 0; k < 4; k++) {
    y[k] = rt_hypotd_snf_DoaMusicSignal(x[k].re, x[k].im);
  }
}

/*
 * Arguments    : const creal_T x[16]
 * Return Type  : boolean_T
 */
static boolean_T anyNonFinite_DoaMusicSignal(const creal_T x[16])
{
  boolean_T p;
  int k;
  p = false;
  for (k = 0; k < 16; k++) {
    if (p || (rtIsInf(x[k].re) || rtIsInf(x[k].im)) || (rtIsNaN(x[k].re) ||
         rtIsNaN(x[k].im))) {
      p = true;
    } else {
      p = false;
    }
  }

  return p;
}

/*
 * Arguments    : const double y[123]
 *                const int iPk_data[]
 *                const int iPk_size[1]
 *                const double wxPk_data[]
 *                const int wxPk_size[2]
 *                const double bPk_data[]
 *                double YpkOut_data[]
 *                int YpkOut_size[2]
 *                double XpkOut_data[]
 *                int XpkOut_size[2]
 *                double WpkOut_data[]
 *                int WpkOut_size[2]
 *                double PpkOut_data[]
 *                int PpkOut_size[2]
 * Return Type  : void
 */
static void assignFullOutputs_DoaMusicSigna(const double y[123], const int
  iPk_data[], const int iPk_size[1], const double wxPk_data[], const int
  wxPk_size[2], const double bPk_data[], double YpkOut_data[], int YpkOut_size[2],
  double XpkOut_data[], int XpkOut_size[2], double WpkOut_data[], int
  WpkOut_size[2], double PpkOut_data[], int PpkOut_size[2])
{
  int loop_ub;
  int i6;
  double Wpk_data[246];
  int Wpk_size[1];
  double Ypk_data[246];
  signed char tmp_data[246];
  loop_ub = iPk_size[0];
  for (i6 = 0; i6 < loop_ub; i6++) {
    Ypk_data[i6] = y[iPk_data[i6] - 1];
  }

  diff_DoaMusicSignal(wxPk_data, wxPk_size, Wpk_data, Wpk_size);
  YpkOut_size[0] = 1;
  YpkOut_size[1] = iPk_size[0];
  loop_ub = iPk_size[0];
  for (i6 = 0; i6 < loop_ub; i6++) {
    YpkOut_data[i6] = Ypk_data[i6];
  }

  PpkOut_size[0] = 1;
  PpkOut_size[1] = iPk_size[0];
  loop_ub = iPk_size[0];
  for (i6 = 0; i6 < loop_ub; i6++) {
    PpkOut_data[i6] = Ypk_data[i6] - bPk_data[i6];
  }

  loop_ub = iPk_size[0];
  for (i6 = 0; i6 < loop_ub; i6++) {
    tmp_data[i6] = (signed char)(1 + (signed char)(iPk_data[i6] - 1));
  }

  XpkOut_size[0] = 1;
  XpkOut_size[1] = iPk_size[0];
  loop_ub = iPk_size[0];
  for (i6 = 0; i6 < loop_ub; i6++) {
    XpkOut_data[i6] = tmp_data[i6];
  }

  WpkOut_size[0] = 1;
  WpkOut_size[1] = Wpk_size[0];
  loop_ub = Wpk_size[0];
  for (i6 = 0; i6 < loop_ub; i6++) {
    WpkOut_data[i6] = Wpk_data[i6];
  }
}

/*
 * Arguments    : const creal_T x[121]
 *                double y[121]
 * Return Type  : void
 */
static void b_abs_DoaMusicSignal(const creal_T x[121], double y[121])
{
  int k;
  for (k = 0; k < 121; k++) {
    y[k] = rt_hypotd_snf_DoaMusicSignal(x[k].re, x[k].im);
  }
}

/*
 * Arguments    : const int a_data[]
 *                const int a_size[1]
 *                const int b_data[]
 *                const int b_size[1]
 *                int c_data[]
 *                int c_size[1]
 *                int ia_data[]
 *                int ia_size[1]
 *                int ib_data[]
 *                int ib_size[1]
 * Return Type  : void
 */
static void b_do_vectors_DoaMusicSignal(const int a_data[], const int a_size[1],
  const int b_data[], const int b_size[1], int c_data[], int c_size[1], int
  ia_data[], int ia_size[1], int ib_data[], int ib_size[1])
{
  int iafirst;
  int ncmax;
  int nc;
  int ialast;
  int ibfirst;
  int iblast;
  int b_ialast;
  int ak;
  int b_iblast;
  int b_ia_data[123];
  int bk;
  iafirst = a_size[0];
  ncmax = b_size[0];
  if (iafirst < ncmax) {
    ncmax = iafirst;
  }

  c_size[0] = (signed char)ncmax;
  ia_size[0] = ncmax;
  ib_size[0] = ncmax;
  nc = 0;
  iafirst = 0;
  ialast = 1;
  ibfirst = 0;
  iblast = 1;
  while ((ialast <= a_size[0]) && (iblast <= b_size[0])) {
    b_ialast = ialast;
    ak = a_data[ialast - 1];
    while ((b_ialast < a_size[0]) && (a_data[b_ialast] == ak)) {
      b_ialast++;
    }

    ialast = b_ialast;
    b_iblast = iblast;
    bk = b_data[iblast - 1];
    while ((b_iblast < b_size[0]) && (b_data[b_iblast] == bk)) {
      b_iblast++;
    }

    iblast = b_iblast;
    if (ak == bk) {
      nc++;
      c_data[nc - 1] = ak;
      ia_data[nc - 1] = iafirst + 1;
      ib_data[nc - 1] = ibfirst + 1;
      ialast = b_ialast + 1;
      iafirst = b_ialast;
      iblast = b_iblast + 1;
      ibfirst = b_iblast;
    } else if (ak < bk) {
      ialast = b_ialast + 1;
      iafirst = b_ialast;
    } else {
      iblast = b_iblast + 1;
      ibfirst = b_iblast;
    }
  }

  if (ncmax > 0) {
    if (1 > nc) {
      iafirst = 0;
    } else {
      iafirst = nc;
    }

    for (ialast = 0; ialast < iafirst; ialast++) {
      b_ia_data[ialast] = ia_data[ialast];
    }

    ia_size[0] = iafirst;
    for (ialast = 0; ialast < iafirst; ialast++) {
      ia_data[ialast] = b_ia_data[ialast];
    }

    if (1 > nc) {
      iafirst = 0;
    } else {
      iafirst = nc;
    }

    for (ialast = 0; ialast < iafirst; ialast++) {
      b_ia_data[ialast] = ib_data[ialast];
    }

    ib_size[0] = iafirst;
    for (ialast = 0; ialast < iafirst; ialast++) {
      ib_data[ialast] = b_ia_data[ialast];
    }

    if (1 > nc) {
      iafirst = 0;
    } else {
      iafirst = nc;
    }

    for (ialast = 0; ialast < iafirst; ialast++) {
      b_ia_data[ialast] = c_data[ialast];
    }

    c_size[0] = iafirst;
    for (ialast = 0; ialast < iafirst; ialast++) {
      c_data[ialast] = b_ia_data[ialast];
    }
  }
}

/*
 * Arguments    : int idx_data[]
 *                int x_data[]
 *                int offset
 *                int np
 *                int nq
 *                int iwork_data[]
 *                int xwork_data[]
 * Return Type  : void
 */
static void b_merge_DoaMusicSignal(int idx_data[], int x_data[], int offset, int
  np, int nq, int iwork_data[], int xwork_data[])
{
  int n;
  int qend;
  int p;
  int iout;
  int exitg1;
  if (nq != 0) {
    n = np + nq;
    for (qend = 0; qend + 1 <= n; qend++) {
      iwork_data[qend] = idx_data[offset + qend];
      xwork_data[qend] = x_data[offset + qend];
    }

    p = 0;
    n = np;
    qend = np + nq;
    iout = offset - 1;
    do {
      exitg1 = 0;
      iout++;
      if (xwork_data[p] <= xwork_data[n]) {
        idx_data[iout] = iwork_data[p];
        x_data[iout] = xwork_data[p];
        if (p + 1 < np) {
          p++;
        } else {
          exitg1 = 1;
        }
      } else {
        idx_data[iout] = iwork_data[n];
        x_data[iout] = xwork_data[n];
        if (n + 1 < qend) {
          n++;
        } else {
          n = (iout - p) + 1;
          while (p + 1 <= np) {
            idx_data[n + p] = iwork_data[p];
            x_data[n + p] = xwork_data[p];
            p++;
          }

          exitg1 = 1;
        }
      }
    } while (exitg1 == 0);
  }
}

/*
 * Arguments    : int x_data[]
 *                int x_size[1]
 *                int idx_data[]
 *                int idx_size[1]
 * Return Type  : void
 */
static void b_sortIdx_DoaMusicSignal(int x_data[], int x_size[1], int idx_data[],
  int idx_size[1])
{
  unsigned char unnamed_idx_0;
  int nQuartets;
  int nDone;
  int n;
  int i;
  int x4[4];
  short idx4[4];
  int iwork_data[246];
  int xwork_data[246];
  int nLeft;
  signed char perm[4];
  int i2;
  int i3;
  int i4;
  unnamed_idx_0 = (unsigned char)x_size[0];
  idx_size[0] = unnamed_idx_0;
  nQuartets = unnamed_idx_0;
  for (nDone = 0; nDone < nQuartets; nDone++) {
    idx_data[nDone] = 0;
  }

  n = x_size[0];
  for (i = 0; i < 4; i++) {
    x4[i] = 0;
    idx4[i] = 0;
  }

  nQuartets = unnamed_idx_0;
  for (nDone = 0; nDone < nQuartets; nDone++) {
    iwork_data[nDone] = 0;
  }

  nQuartets = (unsigned char)x_size[0];
  for (nDone = 0; nDone < nQuartets; nDone++) {
    xwork_data[nDone] = 0;
  }

  nQuartets = x_size[0] >> 2;
  for (nDone = 1; nDone <= nQuartets; nDone++) {
    i = (nDone - 1) << 2;
    idx4[0] = (short)(i + 1);
    idx4[1] = (short)(i + 2);
    idx4[2] = (short)(i + 3);
    idx4[3] = (short)(i + 4);
    x4[0] = x_data[i];
    x4[1] = x_data[i + 1];
    x4[2] = x_data[i + 2];
    x4[3] = x_data[i + 3];
    if (x_data[i] <= x_data[i + 1]) {
      nLeft = 1;
      i2 = 2;
    } else {
      nLeft = 2;
      i2 = 1;
    }

    if (x_data[i + 2] <= x_data[i + 3]) {
      i3 = 3;
      i4 = 4;
    } else {
      i3 = 4;
      i4 = 3;
    }

    if (x4[nLeft - 1] <= x4[i3 - 1]) {
      if (x4[i2 - 1] <= x4[i3 - 1]) {
        perm[0] = (signed char)nLeft;
        perm[1] = (signed char)i2;
        perm[2] = (signed char)i3;
        perm[3] = (signed char)i4;
      } else if (x4[i2 - 1] <= x4[i4 - 1]) {
        perm[0] = (signed char)nLeft;
        perm[1] = (signed char)i3;
        perm[2] = (signed char)i2;
        perm[3] = (signed char)i4;
      } else {
        perm[0] = (signed char)nLeft;
        perm[1] = (signed char)i3;
        perm[2] = (signed char)i4;
        perm[3] = (signed char)i2;
      }
    } else if (x4[nLeft - 1] <= x4[i4 - 1]) {
      if (x4[i2 - 1] <= x4[i4 - 1]) {
        perm[0] = (signed char)i3;
        perm[1] = (signed char)nLeft;
        perm[2] = (signed char)i2;
        perm[3] = (signed char)i4;
      } else {
        perm[0] = (signed char)i3;
        perm[1] = (signed char)nLeft;
        perm[2] = (signed char)i4;
        perm[3] = (signed char)i2;
      }
    } else {
      perm[0] = (signed char)i3;
      perm[1] = (signed char)i4;
      perm[2] = (signed char)nLeft;
      perm[3] = (signed char)i2;
    }

    idx_data[i] = idx4[perm[0] - 1];
    idx_data[i + 1] = idx4[perm[1] - 1];
    idx_data[i + 2] = idx4[perm[2] - 1];
    idx_data[i + 3] = idx4[perm[3] - 1];
    x_data[i] = x4[perm[0] - 1];
    x_data[i + 1] = x4[perm[1] - 1];
    x_data[i + 2] = x4[perm[2] - 1];
    x_data[i + 3] = x4[perm[3] - 1];
  }

  nDone = (nQuartets << 2) - 1;
  nLeft = (x_size[0] - nDone) - 1;
  if (nLeft > 0) {
    for (nQuartets = 0; nQuartets + 1 <= nLeft; nQuartets++) {
      idx4[nQuartets] = (short)((nDone + nQuartets) + 2);
      x4[nQuartets] = x_data[(nDone + nQuartets) + 1];
    }

    for (i = 0; i < 4; i++) {
      perm[i] = 0;
    }

    switch (nLeft) {
     case 1:
      perm[0] = 1;
      break;

     case 2:
      if (x4[0] <= x4[1]) {
        perm[0] = 1;
        perm[1] = 2;
      } else {
        perm[0] = 2;
        perm[1] = 1;
      }
      break;

     default:
      if (x4[0] <= x4[1]) {
        if (x4[1] <= x4[2]) {
          perm[0] = 1;
          perm[1] = 2;
          perm[2] = 3;
        } else if (x4[0] <= x4[2]) {
          perm[0] = 1;
          perm[1] = 3;
          perm[2] = 2;
        } else {
          perm[0] = 3;
          perm[1] = 1;
          perm[2] = 2;
        }
      } else if (x4[0] <= x4[2]) {
        perm[0] = 2;
        perm[1] = 1;
        perm[2] = 3;
      } else if (x4[1] <= x4[2]) {
        perm[0] = 2;
        perm[1] = 3;
        perm[2] = 1;
      } else {
        perm[0] = 3;
        perm[1] = 2;
        perm[2] = 1;
      }
      break;
    }

    for (nQuartets = 1; nQuartets <= nLeft; nQuartets++) {
      idx_data[nDone + nQuartets] = idx4[perm[nQuartets - 1] - 1];
      x_data[nDone + nQuartets] = x4[perm[nQuartets - 1] - 1];
    }
  }

  if (n > 1) {
    merge_block_DoaMusicSignal(idx_data, x_data, n, iwork_data, xwork_data);
  }
}

/*
 * Arguments    : double x[4]
 *                int idx[4]
 * Return Type  : void
 */
static void b_sort_DoaMusicSignal(double x[4], int idx[4])
{
  int i;
  int nNaNs;
  int ib;
  double x4[4];
  int k;
  int idx4[4];
  double xwork[4];
  signed char perm[4];
  int bLen;
  int nPairs;
  int i4;
  for (i = 0; i < 4; i++) {
    idx[i] = 0;
    x4[i] = 0.0;
    idx4[i] = 0;
    xwork[i] = 0.0;
  }

  nNaNs = -3;
  ib = 0;
  for (k = 0; k < 4; k++) {
    if (rtIsNaN(x[k])) {
      idx[-nNaNs] = k + 1;
      xwork[-nNaNs] = x[k];
      nNaNs++;
    } else {
      ib++;
      idx4[ib - 1] = k + 1;
      x4[ib - 1] = x[k];
      if (ib == 4) {
        i = (k - nNaNs) - 6;
        if (x4[0] <= x4[1]) {
          ib = 1;
          bLen = 2;
        } else {
          ib = 2;
          bLen = 1;
        }

        if (x4[2] <= x4[3]) {
          nPairs = 3;
          i4 = 4;
        } else {
          nPairs = 4;
          i4 = 3;
        }

        if (x4[ib - 1] <= x4[nPairs - 1]) {
          if (x4[bLen - 1] <= x4[nPairs - 1]) {
            perm[0] = (signed char)ib;
            perm[1] = (signed char)bLen;
            perm[2] = (signed char)nPairs;
            perm[3] = (signed char)i4;
          } else if (x4[bLen - 1] <= x4[i4 - 1]) {
            perm[0] = (signed char)ib;
            perm[1] = (signed char)nPairs;
            perm[2] = (signed char)bLen;
            perm[3] = (signed char)i4;
          } else {
            perm[0] = (signed char)ib;
            perm[1] = (signed char)nPairs;
            perm[2] = (signed char)i4;
            perm[3] = (signed char)bLen;
          }
        } else if (x4[ib - 1] <= x4[i4 - 1]) {
          if (x4[bLen - 1] <= x4[i4 - 1]) {
            perm[0] = (signed char)nPairs;
            perm[1] = (signed char)ib;
            perm[2] = (signed char)bLen;
            perm[3] = (signed char)i4;
          } else {
            perm[0] = (signed char)nPairs;
            perm[1] = (signed char)ib;
            perm[2] = (signed char)i4;
            perm[3] = (signed char)bLen;
          }
        } else {
          perm[0] = (signed char)nPairs;
          perm[1] = (signed char)i4;
          perm[2] = (signed char)ib;
          perm[3] = (signed char)bLen;
        }

        idx[i] = idx4[perm[0] - 1];
        idx[i + 1] = idx4[perm[1] - 1];
        idx[i + 2] = idx4[perm[2] - 1];
        idx[i + 3] = idx4[perm[3] - 1];
        x[i] = x4[perm[0] - 1];
        x[i + 1] = x4[perm[1] - 1];
        x[i + 2] = x4[perm[2] - 1];
        x[i + 3] = x4[perm[3] - 1];
        ib = 0;
      }
    }
  }

  if (ib > 0) {
    for (i = 0; i < 4; i++) {
      perm[i] = 0;
    }

    switch (ib) {
     case 1:
      perm[0] = 1;
      break;

     case 2:
      if (x4[0] <= x4[1]) {
        perm[0] = 1;
        perm[1] = 2;
      } else {
        perm[0] = 2;
        perm[1] = 1;
      }
      break;

     default:
      if (x4[0] <= x4[1]) {
        if (x4[1] <= x4[2]) {
          perm[0] = 1;
          perm[1] = 2;
          perm[2] = 3;
        } else if (x4[0] <= x4[2]) {
          perm[0] = 1;
          perm[1] = 3;
          perm[2] = 2;
        } else {
          perm[0] = 3;
          perm[1] = 1;
          perm[2] = 2;
        }
      } else if (x4[0] <= x4[2]) {
        perm[0] = 2;
        perm[1] = 1;
        perm[2] = 3;
      } else if (x4[1] <= x4[2]) {
        perm[0] = 2;
        perm[1] = 3;
        perm[2] = 1;
      } else {
        perm[0] = 3;
        perm[1] = 2;
        perm[2] = 1;
      }
      break;
    }

    for (k = 1; k <= ib; k++) {
      idx[(k - nNaNs) - ib] = idx4[perm[k - 1] - 1];
      x[(k - nNaNs) - ib] = x4[perm[k - 1] - 1];
    }
  }

  i = (nNaNs + 3) >> 1;
  for (k = 1; k <= i; k++) {
    ib = idx[k - nNaNs];
    idx[k - nNaNs] = idx[4 - k];
    idx[4 - k] = ib;
    x[k - nNaNs] = xwork[4 - k];
    x[4 - k] = xwork[k - nNaNs];
  }

  if (((nNaNs + 3) & 1) != 0) {
    x[(i - nNaNs) + 1] = xwork[(i - nNaNs) + 1];
  }

  if (1 - nNaNs > 1) {
    for (i = 0; i < 4; i++) {
      idx4[i] = 0;
    }

    nPairs = (1 - nNaNs) >> 2;
    bLen = 4;
    while (nPairs > 1) {
      if ((nPairs & 1) != 0) {
        nPairs--;
        i = bLen * nPairs;
        ib = 1 - (nNaNs + i);
        if (ib > bLen) {
          merge_DoaMusicSignal(idx, x, i, bLen, ib - bLen, idx4, xwork);
        }
      }

      i = bLen << 1;
      nPairs >>= 1;
      for (k = 1; k <= nPairs; k++) {
        merge_DoaMusicSignal(idx, x, (k - 1) * i, bLen, bLen, idx4, xwork);
      }

      bLen = i;
    }

    if (1 - nNaNs > bLen) {
      merge_DoaMusicSignal(idx, x, 0, bLen, 1 - (nNaNs + bLen), idx4, xwork);
    }
  }
}

/*
 * Arguments    : const creal_T x[484]
 *                creal_T y[121]
 * Return Type  : void
 */
static void b_sum_DoaMusicSignal(const creal_T x[484], creal_T y[121])
{
  int i;
  int xoffset;
  double s_re;
  double s_im;
  int k;
  for (i = 0; i < 121; i++) {
    xoffset = i << 2;
    s_re = x[xoffset].re;
    s_im = x[xoffset].im;
    for (k = 0; k < 3; k++) {
      s_re += x[(xoffset + k) + 1].re;
      s_im += x[(xoffset + k) + 1].im;
    }

    y[i].re = s_re;
    y[i].im = s_im;
  }
}

/*
 * Arguments    : int n
 *                const creal_T a
 *                creal_T x[16]
 *                int ix0
 * Return Type  : void
 */
static void b_xscal_DoaMusicSignal(int n, const creal_T a, creal_T x[16], int
  ix0)
{
  int i11;
  int k;
  double x_re;
  double x_im;
  i11 = ix0 + ((n - 1) << 2);
  for (k = ix0; k <= i11; k += 4) {
    x_re = x[k - 1].re;
    x_im = x[k - 1].im;
    x[k - 1].re = a.re * x_re - a.im * x_im;
    x[k - 1].im = a.re * x_im + a.im * x_re;
  }
}

/*
 * Arguments    : const creal_T f
 *                const creal_T g
 *                double *cs
 *                creal_T *sn
 * Return Type  : void
 */
static void b_xzlartg_DoaMusicSignal(const creal_T f, const creal_T g, double
  *cs, creal_T *sn)
{
  double scale;
  double f2s;
  double x;
  double fs_re;
  double fs_im;
  double gs_re;
  double gs_im;
  boolean_T guard1 = false;
  double g2;
  double g2s;
  scale = fabs(f.re);
  f2s = fabs(f.im);
  if (f2s > scale) {
    scale = f2s;
  }

  x = fabs(g.re);
  f2s = fabs(g.im);
  if (f2s > x) {
    x = f2s;
  }

  if (x > scale) {
    scale = x;
  }

  fs_re = f.re;
  fs_im = f.im;
  gs_re = g.re;
  gs_im = g.im;
  guard1 = false;
  if (scale >= 7.4428285367870146E+137) {
    do {
      fs_re *= 1.3435752215134178E-138;
      fs_im *= 1.3435752215134178E-138;
      gs_re *= 1.3435752215134178E-138;
      gs_im *= 1.3435752215134178E-138;
      scale *= 1.3435752215134178E-138;
    } while (!(scale < 7.4428285367870146E+137));

    guard1 = true;
  } else if (scale <= 1.3435752215134178E-138) {
    if ((g.re == 0.0) && (g.im == 0.0)) {
      *cs = 1.0;
      sn->re = 0.0;
      sn->im = 0.0;
    } else {
      do {
        fs_re *= 7.4428285367870146E+137;
        fs_im *= 7.4428285367870146E+137;
        gs_re *= 7.4428285367870146E+137;
        gs_im *= 7.4428285367870146E+137;
        scale *= 7.4428285367870146E+137;
      } while (!(scale > 1.3435752215134178E-138));

      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1) {
    scale = fs_re * fs_re + fs_im * fs_im;
    g2 = gs_re * gs_re + gs_im * gs_im;
    x = g2;
    if (1.0 > g2) {
      x = 1.0;
    }

    if (scale <= x * 2.0041683600089728E-292) {
      if ((f.re == 0.0) && (f.im == 0.0)) {
        *cs = 0.0;
        g2 = rt_hypotd_snf_DoaMusicSignal(gs_re, gs_im);
        sn->re = gs_re / g2;
        sn->im = -gs_im / g2;
      } else {
        g2s = sqrt(g2);
        *cs = rt_hypotd_snf_DoaMusicSignal(fs_re, fs_im) / g2s;
        x = fabs(f.re);
        f2s = fabs(f.im);
        if (f2s > x) {
          x = f2s;
        }

        if (x > 1.0) {
          g2 = rt_hypotd_snf_DoaMusicSignal(f.re, f.im);
          fs_re = f.re / g2;
          fs_im = f.im / g2;
        } else {
          scale = 7.4428285367870146E+137 * f.re;
          f2s = 7.4428285367870146E+137 * f.im;
          g2 = rt_hypotd_snf_DoaMusicSignal(scale, f2s);
          fs_re = scale / g2;
          fs_im = f2s / g2;
        }

        gs_re /= g2s;
        gs_im = -gs_im / g2s;
        sn->re = fs_re * gs_re - fs_im * gs_im;
        sn->im = fs_re * gs_im + fs_im * gs_re;
      }
    } else {
      f2s = sqrt(1.0 + g2 / scale);
      fs_re *= f2s;
      fs_im *= f2s;
      *cs = 1.0 / f2s;
      g2 += scale;
      fs_re /= g2;
      fs_im /= g2;
      sn->re = fs_re * gs_re - fs_im * -gs_im;
      sn->im = fs_re * -gs_im + fs_im * gs_re;
    }
  }
}

/*
 * Arguments    : const double y[123]
 *                const int iPk_data[]
 *                const int iPk_size[1]
 *                double Pd
 *                int idx_data[]
 *                int idx_size[1]
 * Return Type  : void
 */
static void c_findPeaksSeparatedByMoreThanM(const double y[123], const int
  iPk_data[], const int iPk_size[1], double Pd, int idx_data[], int idx_size[1])
{
  int yk;
  int partialTrueCount;
  int n;
  int y_size[1];
  signed char locs_data[246];
  int sortIdx_data[246];
  double y_data[246];
  int sortIdx_size[1];
  signed char locs_temp_data[246];
  int i;
  boolean_T idelete_data[246];
  double locs;
  double b_locs;
  boolean_T tmp_data[246];
  unsigned char b_tmp_data[246];
  if ((iPk_size[0] == 0) || (Pd == 0.0)) {
    if (iPk_size[0] < 1) {
      n = 0;
    } else {
      n = iPk_size[0];
    }

    if (n > 0) {
      sortIdx_data[0] = 1;
      yk = 1;
      for (partialTrueCount = 2; partialTrueCount <= n; partialTrueCount++) {
        yk++;
        sortIdx_data[partialTrueCount - 1] = yk;
      }
    }

    idx_size[0] = n;
    for (partialTrueCount = 0; partialTrueCount < n; partialTrueCount++) {
      idx_data[partialTrueCount] = sortIdx_data[partialTrueCount];
    }
  } else {
    yk = iPk_size[0];
    for (partialTrueCount = 0; partialTrueCount < yk; partialTrueCount++) {
      locs_data[partialTrueCount] = (signed char)(1 + (signed char)
        (iPk_data[partialTrueCount] - 1));
    }

    y_size[0] = iPk_size[0];
    yk = iPk_size[0];
    for (partialTrueCount = 0; partialTrueCount < yk; partialTrueCount++) {
      y_data[partialTrueCount] = y[iPk_data[partialTrueCount] - 1];
    }

    sortIdx_DoaMusicSignal(y_data, y_size, sortIdx_data, sortIdx_size);
    yk = sortIdx_size[0];
    for (partialTrueCount = 0; partialTrueCount < yk; partialTrueCount++) {
      locs_temp_data[partialTrueCount] = locs_data[sortIdx_data[partialTrueCount]
        - 1];
    }

    yk = (unsigned char)sortIdx_size[0];
    for (partialTrueCount = 0; partialTrueCount < yk; partialTrueCount++) {
      idelete_data[partialTrueCount] = false;
    }

    for (i = 0; i < sortIdx_size[0]; i++) {
      if (!idelete_data[i]) {
        locs = (double)locs_data[sortIdx_data[i] - 1] - Pd;
        b_locs = (double)locs_data[sortIdx_data[i] - 1] + Pd;
        yk = sortIdx_size[0];
        for (partialTrueCount = 0; partialTrueCount < yk; partialTrueCount++) {
          tmp_data[partialTrueCount] = ((locs_temp_data[partialTrueCount] >=
            locs) && (locs_temp_data[partialTrueCount] <= b_locs));
        }

        yk = (unsigned char)sortIdx_size[0];
        for (partialTrueCount = 0; partialTrueCount < yk; partialTrueCount++) {
          idelete_data[partialTrueCount] = (idelete_data[partialTrueCount] ||
            tmp_data[partialTrueCount]);
        }

        idelete_data[i] = false;
      }
    }

    yk = (unsigned char)sortIdx_size[0] - 1;
    n = 0;
    for (i = 0; i <= yk; i++) {
      if (!idelete_data[i]) {
        n++;
      }
    }

    partialTrueCount = 0;
    for (i = 0; i <= yk; i++) {
      if (!idelete_data[i]) {
        b_tmp_data[partialTrueCount] = (unsigned char)(i + 1);
        partialTrueCount++;
      }
    }

    idx_size[0] = n;
    for (partialTrueCount = 0; partialTrueCount < n; partialTrueCount++) {
      idx_data[partialTrueCount] = sortIdx_data[b_tmp_data[partialTrueCount] - 1];
    }

    c_sort_DoaMusicSignal(idx_data, idx_size);
  }
}

/*
 * Arguments    : const double y[123]
 *                int iPk_data[]
 *                int iPk_size[1]
 *                double pbPk_data[]
 *                int pbPk_size[1]
 *                int iLB_data[]
 *                int iLB_size[1]
 *                int iRB_data[]
 *                int iRB_size[1]
 * Return Type  : void
 */
static void c_removePeaksBelowMinPeakPromin(const double y[123], int iPk_data[],
  int iPk_size[1], double pbPk_data[], int pbPk_size[1], int iLB_data[], int
  iLB_size[1], int iRB_data[], int iRB_size[1])
{
  int x_size_idx_0;
  int idx;
  int ii;
  boolean_T x_data[123];
  boolean_T exitg1;
  int ii_data[123];
  int idx_data[123];
  double b_pbPk_data[123];
  x_size_idx_0 = iPk_size[0];
  idx = iPk_size[0];
  for (ii = 0; ii < idx; ii++) {
    x_data[ii] = (y[iPk_data[ii] - 1] - pbPk_data[ii] >= 0.5);
  }

  idx = 0;
  ii = 1;
  exitg1 = false;
  while ((!exitg1) && (ii <= x_size_idx_0)) {
    if (x_data[ii - 1]) {
      idx++;
      ii_data[idx - 1] = ii;
      if (idx >= x_size_idx_0) {
        exitg1 = true;
      } else {
        ii++;
      }
    } else {
      ii++;
    }
  }

  if (x_size_idx_0 == 1) {
    if (idx == 0) {
      x_size_idx_0 = 0;
    }
  } else if (1 > idx) {
    x_size_idx_0 = 0;
  } else {
    x_size_idx_0 = idx;
  }

  for (ii = 0; ii < x_size_idx_0; ii++) {
    idx_data[ii] = ii_data[ii];
  }

  for (ii = 0; ii < x_size_idx_0; ii++) {
    ii_data[ii] = iPk_data[idx_data[ii] - 1];
  }

  iPk_size[0] = x_size_idx_0;
  for (ii = 0; ii < x_size_idx_0; ii++) {
    iPk_data[ii] = ii_data[ii];
  }

  for (ii = 0; ii < x_size_idx_0; ii++) {
    b_pbPk_data[ii] = pbPk_data[idx_data[ii] - 1];
  }

  pbPk_size[0] = x_size_idx_0;
  for (ii = 0; ii < x_size_idx_0; ii++) {
    pbPk_data[ii] = b_pbPk_data[ii];
  }

  for (ii = 0; ii < x_size_idx_0; ii++) {
    ii_data[ii] = iLB_data[idx_data[ii] - 1];
  }

  iLB_size[0] = x_size_idx_0;
  for (ii = 0; ii < x_size_idx_0; ii++) {
    iLB_data[ii] = ii_data[ii];
  }

  for (ii = 0; ii < x_size_idx_0; ii++) {
    ii_data[ii] = iRB_data[idx_data[ii] - 1];
  }

  iRB_size[0] = x_size_idx_0;
  for (ii = 0; ii < x_size_idx_0; ii++) {
    iRB_data[ii] = ii_data[ii];
  }
}

/*
 * Arguments    : int x_data[]
 *                int x_size[1]
 * Return Type  : void
 */
static void c_sort_DoaMusicSignal(int x_data[], int x_size[1])
{
  int dim;
  int i14;
  int vwork_size[1];
  int vstride;
  int k;
  int vwork_data[246];
  emxArray_int32_T_246_DoaMusicSi b_vwork_data;
  dim = nonSingletonDim_DoaMusicSignal(x_size);
  if (dim <= 1) {
    i14 = x_size[0];
  } else {
    i14 = 1;
  }

  vwork_size[0] = (unsigned char)i14;
  vstride = 1;
  k = 1;
  while (k <= dim - 1) {
    vstride *= x_size[0];
    k = 2;
  }

  for (dim = 0; dim + 1 <= vstride; dim++) {
    for (k = 0; k + 1 <= i14; k++) {
      vwork_data[k] = x_data[dim + k * vstride];
    }

    b_sortIdx_DoaMusicSignal(vwork_data, vwork_size,
      b_vwork_data.data_DoaMusicSignal, b_vwork_data.size_DoaMusicSignal);
    for (k = 0; k + 1 <= i14; k++) {
      x_data[dim + k * vstride] = vwork_data[k];
    }
  }
}

/*
 * Arguments    : const boolean_T x_data[]
 *                const int x_size[2]
 * Return Type  : double
 */
static double c_sum_DoaMusicSignal(const boolean_T x_data[], const int x_size[2])
{
  double y;
  int k;
  if (x_size[1] == 0) {
    y = 0.0;
  } else {
    y = x_data[0];
    for (k = 2; k <= x_size[1]; k++) {
      y += (double)x_data[k - 1];
    }
  }

  return y;
}

/*
 * Arguments    : const creal_T a
 *                creal_T x[16]
 *                int ix0
 * Return Type  : void
 */
static void c_xscal_DoaMusicSignal(const creal_T a, creal_T x[16], int ix0)
{
  int k;
  double x_re;
  double x_im;
  for (k = ix0; k <= ix0 + 3; k++) {
    x_re = x[k - 1].re;
    x_im = x[k - 1].im;
    x[k - 1].re = a.re * x_re - a.im * x_im;
    x[k - 1].im = a.re * x_im + a.im * x_re;
  }
}

/*
 * Arguments    : const double y[123]
 *                const int iPk_data[]
 *                const int iPk_size[1]
 *                const double bPk_data[]
 *                const int bPk_size[1]
 *                const int iLBw_data[]
 *                const int iLBw_size[1]
 *                const int iRBw_data[]
 *                const int iRBw_size[1]
 *                const double wPk_data[]
 *                const int wPk_size[2]
 *                const int iInf_data[]
 *                const int iInf_size[1]
 *                int iPkOut_data[]
 *                int iPkOut_size[1]
 *                double bPkOut_data[]
 *                int bPkOut_size[1]
 *                double bxPkOut_data[]
 *                int bxPkOut_size[2]
 *                double byPkOut_data[]
 *                int byPkOut_size[2]
 *                double wxPkOut_data[]
 *                int wxPkOut_size[2]
 * Return Type  : void
 */
static void combineFullPeaks_DoaMusicSignal(const double y[123], const int
  iPk_data[], const int iPk_size[1], const double bPk_data[], const int
  bPk_size[1], const int iLBw_data[], const int iLBw_size[1], const int
  iRBw_data[], const int iRBw_size[1], const double wPk_data[], const int
  wPk_size[2], const int iInf_data[], const int iInf_size[1], int iPkOut_data[],
  int iPkOut_size[1], double bPkOut_data[], int bPkOut_size[1], double
  bxPkOut_data[], int bxPkOut_size[2], double byPkOut_data[], int byPkOut_size[2],
  double wxPkOut_data[], int wxPkOut_size[2])
{
  int ia_data[123];
  int ia_size[1];
  int iInfR_data[123];
  int iInfR_size[1];
  int iInfL_data[123];
  int iInfL_size[1];
  int loop_ub;
  int u0;
  int iFinite_data[123];
  int iPkOut;
  int iInfinite_data[123];
  signed char tmp_data[123];
  double b_tmp_data[123];
  int i5;
  do_vectors_DoaMusicSignal(iPk_data, iPk_size, iInf_data, iInf_size,
    iPkOut_data, iPkOut_size, ia_data, ia_size, iInfR_data, iInfR_size);
  b_do_vectors_DoaMusicSignal(iPkOut_data, iPkOut_size, iPk_data, iPk_size,
    iInfL_data, iInfL_size, ia_data, ia_size, iInfR_data, iInfR_size);
  loop_ub = ia_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    iFinite_data[u0] = ia_data[u0];
  }

  b_do_vectors_DoaMusicSignal(iPkOut_data, iPkOut_size, iInf_data, iInf_size,
    iInfL_data, iInfL_size, ia_data, ia_size, iInfR_data, iInfR_size);
  loop_ub = ia_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    iInfinite_data[u0] = ia_data[u0];
  }

  iPkOut = iPkOut_size[0];
  bPkOut_size[0] = (unsigned char)iPkOut_size[0];
  loop_ub = (unsigned char)iPkOut_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    bPkOut_data[u0] = 0.0;
  }

  loop_ub = bPk_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    bPkOut_data[iFinite_data[u0] - 1] = bPk_data[u0];
  }

  loop_ub = ia_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    ia_data[u0] = iInfinite_data[u0];
  }

  loop_ub = ia_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    bPkOut_data[ia_data[u0] - 1] = 0.0;
  }

  loop_ub = iInf_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    ia_data[u0] = iInf_data[u0] - 1;
  }

  for (loop_ub = 0; loop_ub + 1 <= (signed char)iInf_size[0]; loop_ub++) {
    if (ia_data[loop_ub] < 1) {
      iInfL_data[loop_ub] = 1;
    } else {
      iInfL_data[loop_ub] = ia_data[loop_ub];
    }
  }

  loop_ub = iInf_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    ia_data[u0] = iInf_data[u0] + 1;
  }

  for (loop_ub = 0; loop_ub + 1 <= (signed char)iInf_size[0]; loop_ub++) {
    u0 = ia_data[loop_ub];
    if (!(u0 < 123)) {
      u0 = 123;
    }

    iInfR_data[loop_ub] = u0;
  }

  bxPkOut_size[0] = iPkOut;
  bxPkOut_size[1] = 2;
  loop_ub = iPkOut << 1;
  for (u0 = 0; u0 < loop_ub; u0++) {
    bxPkOut_data[u0] = 0.0;
  }

  loop_ub = iLBw_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    tmp_data[u0] = (signed char)(1 + (signed char)(iLBw_data[u0] - 1));
  }

  loop_ub = iLBw_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    bxPkOut_data[iFinite_data[u0] - 1] = tmp_data[u0];
  }

  loop_ub = iRBw_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    tmp_data[u0] = (signed char)(1 + (signed char)(iRBw_data[u0] - 1));
  }

  loop_ub = iRBw_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    bxPkOut_data[(iFinite_data[u0] + iPkOut) - 1] = tmp_data[u0];
  }

  loop_ub = iInf_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    b_tmp_data[u0] = 0.5 * (double)(unsigned char)((unsigned char)((unsigned int)
      (unsigned char)(iInf_data[u0] - 1) + (unsigned char)(iInfL_data[u0] - 1))
      + 2U);
  }

  loop_ub = iInf_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    bxPkOut_data[iInfinite_data[u0] - 1] = b_tmp_data[u0];
  }

  loop_ub = iInf_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    b_tmp_data[u0] = 0.5 * (double)(unsigned char)((unsigned char)((unsigned int)
      (unsigned char)(iInf_data[u0] - 1) + (unsigned char)(iInfR_data[u0] - 1))
      + 2U);
  }

  loop_ub = iInf_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    bxPkOut_data[(iInfinite_data[u0] + iPkOut) - 1] = b_tmp_data[u0];
  }

  byPkOut_size[0] = iPkOut;
  byPkOut_size[1] = 2;
  loop_ub = iPkOut << 1;
  for (u0 = 0; u0 < loop_ub; u0++) {
    byPkOut_data[u0] = 0.0;
  }

  loop_ub = iLBw_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    byPkOut_data[iFinite_data[u0] - 1] = y[iLBw_data[u0] - 1];
  }

  loop_ub = iRBw_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    byPkOut_data[(iFinite_data[u0] + iPkOut) - 1] = y[iRBw_data[u0] - 1];
  }

  loop_ub = (signed char)iInf_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    byPkOut_data[iInfinite_data[u0] - 1] = y[iInfL_data[u0] - 1];
  }

  loop_ub = (signed char)iInf_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    byPkOut_data[(iInfinite_data[u0] + iPkOut) - 1] = y[iInfR_data[u0] - 1];
  }

  wxPkOut_size[0] = iPkOut;
  wxPkOut_size[1] = 2;
  loop_ub = iPkOut << 1;
  for (u0 = 0; u0 < loop_ub; u0++) {
    wxPkOut_data[u0] = 0.0;
  }

  loop_ub = wPk_size[0];
  for (u0 = 0; u0 < 2; u0++) {
    for (i5 = 0; i5 < loop_ub; i5++) {
      wxPkOut_data[(iFinite_data[i5] + iPkOut * u0) - 1] = wPk_data[i5 +
        wPk_size[0] * u0];
    }
  }

  loop_ub = iInf_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    b_tmp_data[u0] = 0.5 * (double)(unsigned char)((unsigned char)((unsigned int)
      (unsigned char)(iInf_data[u0] - 1) + (unsigned char)(iInfL_data[u0] - 1))
      + 2U);
  }

  loop_ub = iInf_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    wxPkOut_data[iInfinite_data[u0] - 1] = b_tmp_data[u0];
  }

  loop_ub = iInf_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    b_tmp_data[u0] = 0.5 * (double)(unsigned char)((unsigned char)((unsigned int)
      (unsigned char)(iInf_data[u0] - 1) + (unsigned char)(iInfR_data[u0] - 1))
      + 2U);
  }

  loop_ub = iInf_size[0];
  for (u0 = 0; u0 < loop_ub; u0++) {
    wxPkOut_data[(iInfinite_data[u0] + iPkOut) - 1] = b_tmp_data[u0];
  }
}

/*
 * Arguments    : const double x_data[]
 *                const int x_size[2]
 *                double y_data[]
 *                int y_size[1]
 * Return Type  : void
 */
static void diff_DoaMusicSignal(const double x_data[], const int x_size[2],
  double y_data[], int y_size[1])
{
  int stride;
  int ix;
  int iy;
  int s;
  y_size[0] = (unsigned char)x_size[0];
  if (!((unsigned char)x_size[0] == 0)) {
    stride = x_size[0];
    ix = 0;
    iy = 0;
    for (s = 1; s <= stride; s++) {
      y_data[iy] = x_data[ix + stride] - x_data[ix];
      ix++;
      iy++;
    }
  }
}

/*
 * Arguments    : const int a_data[]
 *                const int a_size[1]
 *                const int b_data[]
 *                const int b_size[1]
 *                int c_data[]
 *                int c_size[1]
 *                int ia_data[]
 *                int ia_size[1]
 *                int ib_data[]
 *                int ib_size[1]
 * Return Type  : void
 */
static void do_vectors_DoaMusicSignal(const int a_data[], const int a_size[1],
  const int b_data[], const int b_size[1], int c_data[], int c_size[1], int
  ia_data[], int ia_size[1], int ib_data[], int ib_size[1])
{
  int na;
  int nb;
  int ncmax;
  int nc;
  int nia;
  int nib;
  int iafirst;
  int ialast;
  int ibfirst;
  int iblast;
  int b_ialast;
  int ak;
  int b_iblast;
  int bk;
  int b_ia_data[123];
  signed char b_ib_data[123];
  int b_c_data[246];
  na = a_size[0];
  nb = b_size[0];
  ncmax = a_size[0] + b_size[0];
  c_size[0] = (unsigned char)ncmax;
  ia_size[0] = a_size[0];
  ib_size[0] = b_size[0];
  nc = -1;
  nia = -1;
  nib = 0;
  iafirst = 1;
  ialast = 1;
  ibfirst = 0;
  iblast = 1;
  while ((ialast <= na) && (iblast <= nb)) {
    b_ialast = ialast;
    ak = a_data[ialast - 1];
    while ((b_ialast < a_size[0]) && (a_data[b_ialast] == ak)) {
      b_ialast++;
    }

    ialast = b_ialast;
    b_iblast = iblast;
    bk = b_data[iblast - 1];
    while ((b_iblast < b_size[0]) && (b_data[b_iblast] == bk)) {
      b_iblast++;
    }

    iblast = b_iblast;
    if (ak == bk) {
      nc++;
      c_data[nc] = ak;
      nia++;
      ia_data[nia] = iafirst;
      ialast = b_ialast + 1;
      iafirst = b_ialast + 1;
      iblast = b_iblast + 1;
      ibfirst = b_iblast;
    } else if (ak < bk) {
      nc++;
      nia++;
      c_data[nc] = ak;
      ia_data[nia] = iafirst;
      ialast = b_ialast + 1;
      iafirst = b_ialast + 1;
    } else {
      nc++;
      nib++;
      c_data[nc] = bk;
      ib_data[nib - 1] = ibfirst + 1;
      iblast = b_iblast + 1;
      ibfirst = b_iblast;
    }
  }

  while (ialast <= na) {
    b_ialast = ialast;
    while ((b_ialast < a_size[0]) && (a_data[b_ialast] == a_data[ialast - 1])) {
      b_ialast++;
    }

    nc++;
    nia++;
    c_data[nc] = a_data[ialast - 1];
    ia_data[nia] = ialast;
    ialast = b_ialast + 1;
  }

  while (iblast <= nb) {
    b_iblast = iblast;
    while ((b_iblast < b_size[0]) && (b_data[b_iblast] == b_data[iblast - 1])) {
      b_iblast++;
    }

    nc++;
    nib++;
    c_data[nc] = b_data[iblast - 1];
    ib_data[nib - 1] = iblast;
    iblast = b_iblast + 1;
  }

  if (a_size[0] > 0) {
    if (1 > nia + 1) {
      nb = -1;
    } else {
      nb = nia;
    }

    for (nia = 0; nia <= nb; nia++) {
      b_ia_data[nia] = ia_data[nia];
    }

    ia_size[0] = nb + 1;
    nb++;
    for (nia = 0; nia < nb; nia++) {
      ia_data[nia] = b_ia_data[nia];
    }
  }

  if (b_size[0] > 0) {
    if (1 > nib) {
      nb = 0;
    } else {
      nb = nib;
    }

    na = b_size[0];
    for (nia = 0; nia < na; nia++) {
      b_ib_data[nia] = (signed char)ib_data[nia];
    }

    ib_size[0] = nb;
    for (nia = 0; nia < nb; nia++) {
      ib_data[nia] = b_ib_data[nia];
    }
  }

  if (ncmax > 0) {
    if (1 > nc + 1) {
      nb = -1;
    } else {
      nb = nc;
    }

    for (nia = 0; nia <= nb; nia++) {
      b_c_data[nia] = c_data[nia];
    }

    c_size[0] = nb + 1;
    nb++;
    for (nia = 0; nia < nb; nia++) {
      c_data[nia] = b_c_data[nia];
    }
  }
}

/*
 * Arguments    : const creal_T A[16]
 *                creal_T V[16]
 *                creal_T D[4]
 * Return Type  : void
 */
static void eig_DoaMusicSignal(const creal_T A[16], creal_T V[16], creal_T D[4])
{
  boolean_T p;
  int i;
  int j;
  boolean_T exitg2;
  creal_T At[16];
  creal_T beta1[4];
  int exitg1;
  int coltop;
  double colnorm;
  double scale;
  double t;
  double absxk;
  if (anyNonFinite_DoaMusicSignal(A)) {
    for (i = 0; i < 16; i++) {
      V[i].re = rtNaN;
      V[i].im = 0.0;
    }

    for (i = 0; i < 4; i++) {
      D[i].re = rtNaN;
      D[i].im = 0.0;
    }
  } else {
    p = true;
    j = 0;
    exitg2 = false;
    while ((!exitg2) && (j < 4)) {
      i = 0;
      do {
        exitg1 = 0;
        if (i <= j) {
          if (!((A[i + (j << 2)].re == A[j + (i << 2)].re) && (A[i + (j << 2)].
                im == -A[j + (i << 2)].im))) {
            p = false;
            exitg1 = 1;
          } else {
            i++;
          }
        } else {
          j++;
          exitg1 = 2;
        }
      } while (exitg1 == 0);

      if (exitg1 == 1) {
        exitg2 = true;
      }
    }

    if (p) {
      schur_DoaMusicSignal(A, V, At);
      for (i = 0; i < 4; i++) {
        D[i] = At[i + (i << 2)];
      }
    } else {
      memcpy(&At[0], &A[0], sizeof(creal_T) << 4);
      xzggev_DoaMusicSignal(At, &i, D, beta1, V);
      for (coltop = 0; coltop <= 13; coltop += 4) {
        colnorm = 0.0;
        scale = 2.2250738585072014E-308;
        for (i = coltop; i + 1 <= coltop + 4; i++) {
          absxk = fabs(V[i].re);
          if (absxk > scale) {
            t = scale / absxk;
            colnorm = 1.0 + colnorm * t * t;
            scale = absxk;
          } else {
            t = absxk / scale;
            colnorm += t * t;
          }

          absxk = fabs(V[i].im);
          if (absxk > scale) {
            t = scale / absxk;
            colnorm = 1.0 + colnorm * t * t;
            scale = absxk;
          } else {
            t = absxk / scale;
            colnorm += t * t;
          }
        }

        colnorm = scale * sqrt(colnorm);
        for (j = coltop; j + 1 <= coltop + 4; j++) {
          if (V[j].im == 0.0) {
            V[j].re /= colnorm;
            V[j].im = 0.0;
          } else if (V[j].re == 0.0) {
            V[j].re = 0.0;
            V[j].im /= colnorm;
          } else {
            V[j].re /= colnorm;
            V[j].im /= colnorm;
          }
        }
      }

      for (i = 0; i < 4; i++) {
        t = D[i].re;
        if (beta1[i].im == 0.0) {
          if (D[i].im == 0.0) {
            D[i].re /= beta1[i].re;
            D[i].im = 0.0;
          } else if (D[i].re == 0.0) {
            D[i].re = 0.0;
            D[i].im /= beta1[i].re;
          } else {
            D[i].re /= beta1[i].re;
            D[i].im /= beta1[i].re;
          }
        } else if (beta1[i].re == 0.0) {
          if (D[i].re == 0.0) {
            D[i].re = D[i].im / beta1[i].im;
            D[i].im = 0.0;
          } else if (D[i].im == 0.0) {
            D[i].re = 0.0;
            D[i].im = -(t / beta1[i].im);
          } else {
            D[i].re = D[i].im / beta1[i].im;
            D[i].im = -(t / beta1[i].im);
          }
        } else {
          absxk = fabs(beta1[i].re);
          colnorm = fabs(beta1[i].im);
          if (absxk > colnorm) {
            colnorm = beta1[i].im / beta1[i].re;
            scale = beta1[i].re + colnorm * beta1[i].im;
            D[i].re = (D[i].re + colnorm * D[i].im) / scale;
            D[i].im = (D[i].im - colnorm * t) / scale;
          } else if (colnorm == absxk) {
            if (beta1[i].re > 0.0) {
              colnorm = 0.5;
            } else {
              colnorm = -0.5;
            }

            if (beta1[i].im > 0.0) {
              scale = 0.5;
            } else {
              scale = -0.5;
            }

            D[i].re = (D[i].re * colnorm + D[i].im * scale) / absxk;
            D[i].im = (D[i].im * colnorm - t * scale) / absxk;
          } else {
            colnorm = beta1[i].re / beta1[i].im;
            scale = beta1[i].im + colnorm * beta1[i].re;
            D[i].re = (colnorm * D[i].re + D[i].im) / scale;
            D[i].im = (colnorm * D[i].im - t) / scale;
          }
        }
      }
    }
  }
}

/*
 * Arguments    : creal_T h[16]
 *                creal_T z[16]
 * Return Type  : int
 */
static int eml_zlahqr_DoaMusicSignal(creal_T h[16], creal_T z[16])
{
  int info;
  int i;
  boolean_T exitg1;
  double tst;
  double htmp1;
  double ba;
  int L;
  boolean_T goto140;
  creal_T u2;
  int its;
  boolean_T exitg2;
  int k;
  boolean_T exitg3;
  creal_T y;
  int b_k;
  double t_re;
  double ab;
  boolean_T goto70;
  int m;
  double u_re;
  double u_im;
  double s;
  double aa;
  int c_k;
  double d0;
  creal_T v[2];
  int j;
  int c;
  double b_u_re;
  info = 0;
  h[2].re = 0.0;
  h[2].im = 0.0;
  h[3].re = 0.0;
  h[3].im = 0.0;
  h[7].re = 0.0;
  h[7].im = 0.0;
  for (i = 0; i < 3; i++) {
    if (h[(i + (i << 2)) + 1].im != 0.0) {
      tst = h[(i + (i << 2)) + 1].re;
      htmp1 = h[(i + (i << 2)) + 1].im;
      ba = fabs(h[(i + (i << 2)) + 1].re) + fabs(h[(i + (i << 2)) + 1].im);
      if (htmp1 == 0.0) {
        u2.re = tst / ba;
        u2.im = 0.0;
      } else if (tst == 0.0) {
        u2.re = 0.0;
        u2.im = htmp1 / ba;
      } else {
        u2.re = tst / ba;
        u2.im = htmp1 / ba;
      }

      ba = rt_hypotd_snf_DoaMusicSignal(u2.re, u2.im);
      if (-u2.im == 0.0) {
        u2.re /= ba;
        u2.im = 0.0;
      } else if (u2.re == 0.0) {
        u2.re = 0.0;
        u2.im = -u2.im / ba;
      } else {
        u2.re /= ba;
        u2.im = -u2.im / ba;
      }

      h[(i + (i << 2)) + 1].re = rt_hypotd_snf_DoaMusicSignal(h[(i + (i << 2)) +
        1].re, h[(i + (i << 2)) + 1].im);
      h[(i + (i << 2)) + 1].im = 0.0;
      b_xscal_DoaMusicSignal(3 - i, u2, h, (i + ((i + 1) << 2)) + 2);
      y.re = u2.re;
      y.im = -u2.im;
      b_k = i + 3;
      if (4 < b_k) {
        b_k = 4;
      }

      xscal_DoaMusicSignal(b_k, y, h, 1 + ((i + 1) << 2));
      y.re = u2.re;
      y.im = -u2.im;
      c_xscal_DoaMusicSignal(y, z, 1 + ((i + 1) << 2));
    }
  }

  i = 3;
  exitg1 = false;
  while ((!exitg1) && (i + 1 >= 1)) {
    L = -1;
    goto140 = false;
    its = 0;
    exitg2 = false;
    while ((!exitg2) && (its < 31)) {
      k = i;
      exitg3 = false;
      while ((!exitg3) && ((k + 1 > L + 2) && (!(fabs(h[k + ((k - 1) << 2)].re)
                + fabs(h[k + ((k - 1) << 2)].im) <= 4.0083367200179456E-292))))
      {
        tst = (fabs(h[(k + ((k - 1) << 2)) - 1].re) + fabs(h[(k + ((k - 1) << 2))
                - 1].im)) + (fabs(h[k + (k << 2)].re) + fabs(h[k + (k << 2)].im));
        if (tst == 0.0) {
          if (k - 1 >= 1) {
            tst = fabs(h[(k + ((k - 2) << 2)) - 1].re);
          }

          if (k + 2 <= 4) {
            tst += fabs(h[(k + (k << 2)) + 1].re);
          }
        }

        if (fabs(h[k + ((k - 1) << 2)].re) <= 2.2204460492503131E-16 * tst) {
          htmp1 = fabs(h[k + ((k - 1) << 2)].re) + fabs(h[k + ((k - 1) << 2)].im);
          tst = fabs(h[(k + (k << 2)) - 1].re) + fabs(h[(k + (k << 2)) - 1].im);
          if (htmp1 > tst) {
            ab = htmp1;
            ba = tst;
          } else {
            ab = tst;
            ba = htmp1;
          }

          htmp1 = fabs(h[k + (k << 2)].re) + fabs(h[k + (k << 2)].im);
          tst = fabs(h[(k + ((k - 1) << 2)) - 1].re - h[k + (k << 2)].re) + fabs
            (h[(k + ((k - 1) << 2)) - 1].im - h[k + (k << 2)].im);
          if (htmp1 > tst) {
            aa = htmp1;
            htmp1 = tst;
          } else {
            aa = tst;
          }

          s = aa + ab;
          tst = 2.2204460492503131E-16 * (htmp1 * (aa / s));
          if ((4.0083367200179456E-292 > tst) || rtIsNaN(tst)) {
            d0 = 4.0083367200179456E-292;
          } else {
            d0 = tst;
          }

          if (ba * (ab / s) <= d0) {
            exitg3 = true;
          } else {
            k--;
          }
        } else {
          k--;
        }
      }

      L = k - 1;
      if (k + 1 > 1) {
        h[k + ((k - 1) << 2)].re = 0.0;
        h[k + ((k - 1) << 2)].im = 0.0;
      }

      if (k + 1 >= i + 1) {
        goto140 = true;
        exitg2 = true;
      } else {
        switch (its) {
         case 10:
          t_re = 0.75 * fabs(h[(k + (k << 2)) + 1].re) + h[k + (k << 2)].re;
          ba = h[k + (k << 2)].im;
          break;

         case 20:
          t_re = 0.75 * fabs(h[i + ((i - 1) << 2)].re) + h[i + (i << 2)].re;
          ba = h[i + (i << 2)].im;
          break;

         default:
          t_re = h[i + (i << 2)].re;
          ba = h[i + (i << 2)].im;
          y = h[(i + (i << 2)) - 1];
          sqrt_DoaMusicSignal(&y);
          u2 = h[i + ((i - 1) << 2)];
          sqrt_DoaMusicSignal(&u2);
          u_re = y.re * u2.re - y.im * u2.im;
          u_im = y.re * u2.im + y.im * u2.re;
          s = fabs(u_re) + fabs(u_im);
          if (s != 0.0) {
            htmp1 = 0.5 * (h[(i + ((i - 1) << 2)) - 1].re - h[i + (i << 2)].re);
            ab = 0.5 * (h[(i + ((i - 1) << 2)) - 1].im - h[i + (i << 2)].im);
            aa = fabs(htmp1) + fabs(ab);
            tst = fabs(htmp1) + fabs(ab);
            if (!((s > tst) || rtIsNaN(tst))) {
              s = tst;
            }

            if (ab == 0.0) {
              t_re = htmp1 / s;
              ba = 0.0;
            } else if (htmp1 == 0.0) {
              t_re = 0.0;
              ba = ab / s;
            } else {
              t_re = htmp1 / s;
              ba = ab / s;
            }

            tst = t_re;
            t_re = t_re * t_re - ba * ba;
            ba = tst * ba + ba * tst;
            if (u_im == 0.0) {
              u2.re = u_re / s;
              u2.im = 0.0;
            } else if (u_re == 0.0) {
              u2.re = 0.0;
              u2.im = u_im / s;
            } else {
              u2.re = u_re / s;
              u2.im = u_im / s;
            }

            y.re = t_re + (u2.re * u2.re - u2.im * u2.im);
            y.im = ba + (u2.re * u2.im + u2.im * u2.re);
            sqrt_DoaMusicSignal(&y);
            y.re *= s;
            y.im *= s;
            if (aa > 0.0) {
              if (ab == 0.0) {
                t_re = htmp1 / aa;
                ba = 0.0;
              } else if (htmp1 == 0.0) {
                t_re = 0.0;
                ba = ab / aa;
              } else {
                t_re = htmp1 / aa;
                ba = ab / aa;
              }

              if (t_re * y.re + ba * y.im < 0.0) {
                y.re = -y.re;
                y.im = -y.im;
              }
            }

            ba = htmp1 + y.re;
            aa = ab + y.im;
            if (aa == 0.0) {
              if (u_im == 0.0) {
                b_u_re = u_re / ba;
                tst = 0.0;
              } else if (u_re == 0.0) {
                b_u_re = 0.0;
                tst = u_im / ba;
              } else {
                b_u_re = u_re / ba;
                tst = u_im / ba;
              }
            } else if (ba == 0.0) {
              if (u_re == 0.0) {
                b_u_re = u_im / aa;
                tst = 0.0;
              } else if (u_im == 0.0) {
                b_u_re = 0.0;
                tst = -(u_re / aa);
              } else {
                b_u_re = u_im / aa;
                tst = -(u_re / aa);
              }
            } else {
              ab = fabs(ba);
              tst = fabs(aa);
              if (ab > tst) {
                s = aa / ba;
                tst = ba + s * aa;
                b_u_re = (u_re + s * u_im) / tst;
                tst = (u_im - s * u_re) / tst;
              } else if (tst == ab) {
                if (ba > 0.0) {
                  htmp1 = 0.5;
                } else {
                  htmp1 = -0.5;
                }

                if (aa > 0.0) {
                  tst = 0.5;
                } else {
                  tst = -0.5;
                }

                b_u_re = (u_re * htmp1 + u_im * tst) / ab;
                tst = (u_im * htmp1 - u_re * tst) / ab;
              } else {
                s = ba / aa;
                tst = aa + s * ba;
                b_u_re = (s * u_re + u_im) / tst;
                tst = (s * u_im - u_re) / tst;
              }
            }

            t_re = h[i + (i << 2)].re - (u_re * b_u_re - u_im * tst);
            ba = h[i + (i << 2)].im - (u_re * tst + u_im * b_u_re);
          }
          break;
        }

        goto70 = false;
        m = i;
        exitg3 = false;
        while ((!exitg3) && (m > k + 1)) {
          u2.re = h[(m + ((m - 1) << 2)) - 1].re - t_re;
          u2.im = h[(m + ((m - 1) << 2)) - 1].im - ba;
          tst = h[m + ((m - 1) << 2)].re;
          s = (fabs(u2.re) + fabs(u2.im)) + fabs(tst);
          if (u2.im == 0.0) {
            u2.re /= s;
            u2.im = 0.0;
          } else if (u2.re == 0.0) {
            u2.re = 0.0;
            u2.im /= s;
          } else {
            u2.re /= s;
            u2.im /= s;
          }

          tst /= s;
          v[0] = u2;
          v[1].re = tst;
          v[1].im = 0.0;
          if (fabs(h[(m + ((m - 2) << 2)) - 1].re) * fabs(tst) <=
              2.2204460492503131E-16 * ((fabs(u2.re) + fabs(u2.im)) * ((fabs(h
                  [(m + ((m - 1) << 2)) - 1].re) + fabs(h[(m + ((m - 1) << 2)) -
                  1].im)) + (fabs(h[m + (m << 2)].re) + fabs(h[m + (m << 2)].im)))))
          {
            goto70 = true;
            exitg3 = true;
          } else {
            m--;
          }
        }

        if (!goto70) {
          u2.re = h[k + (k << 2)].re - t_re;
          u2.im = h[k + (k << 2)].im - ba;
          tst = h[(k + (k << 2)) + 1].re;
          s = (fabs(u2.re) + fabs(u2.im)) + fabs(tst);
          if (u2.im == 0.0) {
            u2.re /= s;
            u2.im = 0.0;
          } else if (u2.re == 0.0) {
            u2.re = 0.0;
            u2.im /= s;
          } else {
            u2.re /= s;
            u2.im /= s;
          }

          tst /= s;
          v[0] = u2;
          v[1].re = tst;
          v[1].im = 0.0;
        }

        for (c_k = m; c_k <= i; c_k++) {
          if (c_k > m) {
            v[0] = h[(c_k + ((c_k - 2) << 2)) - 1];
            v[1] = h[c_k + ((c_k - 2) << 2)];
          }

          u2 = xzlarfg_DoaMusicSignal(&v[0], &v[1]);
          if (c_k > m) {
            h[(c_k + ((c_k - 2) << 2)) - 1] = v[0];
            h[c_k + ((c_k - 2) << 2)].re = 0.0;
            h[c_k + ((c_k - 2) << 2)].im = 0.0;
          }

          tst = u2.re * v[1].re - u2.im * v[1].im;
          for (j = c_k - 1; j + 1 < 5; j++) {
            t_re = (u2.re * h[(c_k + (j << 2)) - 1].re - -u2.im * h[(c_k + (j <<
                      2)) - 1].im) + tst * h[c_k + (j << 2)].re;
            ba = (u2.re * h[(c_k + (j << 2)) - 1].im + -u2.im * h[(c_k + (j << 2))
                  - 1].re) + tst * h[c_k + (j << 2)].im;
            h[(c_k + (j << 2)) - 1].re -= t_re;
            h[(c_k + (j << 2)) - 1].im -= ba;
            h[c_k + (j << 2)].re -= t_re * v[1].re - ba * v[1].im;
            h[c_k + (j << 2)].im -= t_re * v[1].im + ba * v[1].re;
          }

          if (c_k + 2 < i + 1) {
            b_k = c_k;
          } else {
            b_k = i - 1;
          }

          for (j = 0; j + 1 <= b_k + 2; j++) {
            t_re = (u2.re * h[j + ((c_k - 1) << 2)].re - u2.im * h[j + ((c_k - 1)
                     << 2)].im) + tst * h[j + (c_k << 2)].re;
            ba = (u2.re * h[j + ((c_k - 1) << 2)].im + u2.im * h[j + ((c_k - 1) <<
                   2)].re) + tst * h[j + (c_k << 2)].im;
            h[j + ((c_k - 1) << 2)].re -= t_re;
            h[j + ((c_k - 1) << 2)].im -= ba;
            h[j + (c_k << 2)].re -= t_re * v[1].re - ba * -v[1].im;
            h[j + (c_k << 2)].im -= t_re * -v[1].im + ba * v[1].re;
          }

          for (j = 0; j < 4; j++) {
            t_re = (u2.re * z[j + ((c_k - 1) << 2)].re - u2.im * z[j + ((c_k - 1)
                     << 2)].im) + tst * z[j + (c_k << 2)].re;
            ba = (u2.re * z[j + ((c_k - 1) << 2)].im + u2.im * z[j + ((c_k - 1) <<
                   2)].re) + tst * z[j + (c_k << 2)].im;
            z[j + ((c_k - 1) << 2)].re -= t_re;
            z[j + ((c_k - 1) << 2)].im -= ba;
            z[j + (c_k << 2)].re -= t_re * v[1].re - ba * -v[1].im;
            z[j + (c_k << 2)].im -= t_re * -v[1].im + ba * v[1].re;
          }

          if ((c_k == m) && (m > k + 1)) {
            u2.re = 1.0 - u2.re;
            u2.im = 0.0 - u2.im;
            ba = rt_hypotd_snf_DoaMusicSignal(u2.re, u2.im);
            if (u2.im == 0.0) {
              u2.re /= ba;
              u2.im = 0.0;
            } else if (u2.re == 0.0) {
              u2.re = 0.0;
              u2.im /= ba;
            } else {
              u2.re /= ba;
              u2.im /= ba;
            }

            tst = h[m + ((m - 1) << 2)].re;
            htmp1 = h[m + ((m - 1) << 2)].im;
            h[m + ((m - 1) << 2)].re = tst * u2.re - htmp1 * -u2.im;
            h[m + ((m - 1) << 2)].im = tst * -u2.im + htmp1 * u2.re;
            if (m + 2 <= i + 1) {
              tst = h[3 + (m << 2)].re;
              htmp1 = h[3 + (m << 2)].im;
              h[3 + (m << 2)].re = tst * u2.re - htmp1 * u2.im;
              h[3 + (m << 2)].im = tst * u2.im + htmp1 * u2.re;
            }

            for (j = m; j <= i + 1; j++) {
              if (j != m + 1) {
                if (4 > j) {
                  c = j + (j << 2);
                  b_k = c + ((3 - j) << 2);
                  while (c <= b_k) {
                    tst = h[c - 1].re;
                    htmp1 = h[c - 1].im;
                    h[c - 1].re = u2.re * tst - u2.im * htmp1;
                    h[c - 1].im = u2.re * htmp1 + u2.im * tst;
                    c += 4;
                  }
                }

                c = (j - 1) << 2;
                y.re = u2.re;
                y.im = -u2.im;
                b_k = (c + j) - 1;
                while (c + 1 <= b_k) {
                  tst = h[c].re;
                  htmp1 = h[c].im;
                  h[c].re = y.re * tst - y.im * htmp1;
                  h[c].im = y.re * htmp1 + y.im * tst;
                  c++;
                }

                c = (j - 1) << 2;
                y.re = u2.re;
                y.im = -u2.im;
                for (b_k = c; b_k + 1 <= c + 4; b_k++) {
                  tst = z[b_k].re;
                  htmp1 = z[b_k].im;
                  z[b_k].re = y.re * tst - y.im * htmp1;
                  z[b_k].im = y.re * htmp1 + y.im * tst;
                }
              }
            }
          }
        }

        u2 = h[i + ((i - 1) << 2)];
        if (h[i + ((i - 1) << 2)].im != 0.0) {
          tst = rt_hypotd_snf_DoaMusicSignal(h[i + ((i - 1) << 2)].re, h[i + ((i
            - 1) << 2)].im);
          h[i + ((i - 1) << 2)].re = tst;
          h[i + ((i - 1) << 2)].im = 0.0;
          if (u2.im == 0.0) {
            u2.re /= tst;
            u2.im = 0.0;
          } else if (u2.re == 0.0) {
            u2.re = 0.0;
            u2.im /= tst;
          } else {
            u2.re /= tst;
            u2.im /= tst;
          }

          if (4 > i + 1) {
            c = i + ((i + 1) << 2);
            y.re = u2.re;
            y.im = -u2.im;
            b_k = (c + ((2 - i) << 2)) + 1;
            while (c + 1 <= b_k) {
              tst = h[c].re;
              htmp1 = h[c].im;
              h[c].re = y.re * tst - y.im * htmp1;
              h[c].im = y.re * htmp1 + y.im * tst;
              c += 4;
            }
          }

          c = i << 2;
          b_k = c + i;
          while (c + 1 <= b_k) {
            tst = h[c].re;
            htmp1 = h[c].im;
            h[c].re = u2.re * tst - u2.im * htmp1;
            h[c].im = u2.re * htmp1 + u2.im * tst;
            c++;
          }

          c = i << 2;
          for (k = c; k + 1 <= c + 4; k++) {
            tst = z[k].re;
            htmp1 = z[k].im;
            z[k].re = u2.re * tst - u2.im * htmp1;
            z[k].im = u2.re * htmp1 + u2.im * tst;
          }
        }

        its++;
      }
    }

    if (!goto140) {
      info = i + 1;
      exitg1 = true;
    } else {
      i = L;
    }
  }

  return info;
}

/*
 * Arguments    : const int idx_data[]
 *                const int idx_size[1]
 *                double bPk_data[]
 *                int bPk_size[1]
 *                double bxPk_data[]
 *                int bxPk_size[2]
 *                double byPk_data[]
 *                int byPk_size[2]
 *                double wxPk_data[]
 *                int wxPk_size[2]
 * Return Type  : void
 */
static void fetchPeakExtents_DoaMusicSignal(const int idx_data[], const int
  idx_size[1], double bPk_data[], int bPk_size[1], double bxPk_data[], int
  bxPk_size[2], double byPk_data[], int byPk_size[2], double wxPk_data[], int
  wxPk_size[2])
{
  int loop_ub;
  int i15;
  double b_bPk_data[246];
  int bxPk_size_idx_0;
  int i16;
  int byPk_size_idx_0;
  double b_bxPk_data[492];
  int b_loop_ub;
  double b_byPk_data[492];
  loop_ub = idx_size[0];
  for (i15 = 0; i15 < loop_ub; i15++) {
    b_bPk_data[i15] = bPk_data[idx_data[i15] - 1];
  }

  bPk_size[0] = idx_size[0];
  loop_ub = idx_size[0];
  for (i15 = 0; i15 < loop_ub; i15++) {
    bPk_data[i15] = b_bPk_data[i15];
  }

  bxPk_size_idx_0 = idx_size[0];
  loop_ub = idx_size[0];
  for (i15 = 0; i15 < 2; i15++) {
    for (i16 = 0; i16 < loop_ub; i16++) {
      b_bxPk_data[i16 + bxPk_size_idx_0 * i15] = bxPk_data[(idx_data[i16] +
        bxPk_size[0] * i15) - 1];
    }
  }

  bxPk_size[0] = idx_size[0];
  bxPk_size[1] = 2;
  byPk_size_idx_0 = idx_size[0];
  loop_ub = idx_size[0];
  b_loop_ub = idx_size[0];
  for (i15 = 0; i15 < 2; i15++) {
    for (i16 = 0; i16 < loop_ub; i16++) {
      bxPk_data[i16 + bxPk_size[0] * i15] = b_bxPk_data[i16 + bxPk_size_idx_0 *
        i15];
    }

    for (i16 = 0; i16 < b_loop_ub; i16++) {
      b_byPk_data[i16 + byPk_size_idx_0 * i15] = byPk_data[(idx_data[i16] +
        byPk_size[0] * i15) - 1];
    }
  }

  byPk_size[0] = idx_size[0];
  byPk_size[1] = 2;
  bxPk_size_idx_0 = idx_size[0];
  loop_ub = idx_size[0];
  b_loop_ub = idx_size[0];
  for (i15 = 0; i15 < 2; i15++) {
    for (i16 = 0; i16 < loop_ub; i16++) {
      byPk_data[i16 + byPk_size[0] * i15] = b_byPk_data[i16 + byPk_size_idx_0 *
        i15];
    }

    for (i16 = 0; i16 < b_loop_ub; i16++) {
      b_bxPk_data[i16 + bxPk_size_idx_0 * i15] = wxPk_data[(idx_data[i16] +
        wxPk_size[0] * i15) - 1];
    }
  }

  wxPk_size[0] = idx_size[0];
  wxPk_size[1] = 2;
  loop_ub = idx_size[0];
  for (i15 = 0; i15 < 2; i15++) {
    for (i16 = 0; i16 < loop_ub; i16++) {
      wxPk_data[i16 + wxPk_size[0] * i15] = b_bxPk_data[i16 + bxPk_size_idx_0 *
        i15];
    }
  }
}

/*
 * Arguments    : const double y[123]
 *                int iPk_data[]
 *                int iPk_size[1]
 *                const int iFin_data[]
 *                const int iFin_size[1]
 *                const int iInf_data[]
 *                const int iInf_size[1]
 *                const int iInflect_data[]
 *                const int iInflect_size[1]
 *                double bPk_data[]
 *                int bPk_size[1]
 *                double bxPk_data[]
 *                int bxPk_size[2]
 *                double byPk_data[]
 *                int byPk_size[2]
 *                double wxPk_data[]
 *                int wxPk_size[2]
 * Return Type  : void
 */
static void findExtents_DoaMusicSignal(const double y[123], int iPk_data[], int
  iPk_size[1], const int iFin_data[], const int iFin_size[1], const int
  iInf_data[], const int iInf_size[1], const int iInflect_data[], const int
  iInflect_size[1], double bPk_data[], int bPk_size[1], double bxPk_data[], int
  bxPk_size[2], double byPk_data[], int byPk_size[2], double wxPk_data[], int
  wxPk_size[2])
{
  double yFinite[123];
  int loop_ub;
  int i13;
  double b_bPk_data[123];
  int b_bPk_size[1];
  int iLB_data[123];
  int iLB_size[1];
  int iRB_data[123];
  int iRB_size[1];
  int b_iPk_size[1];
  int b_iPk_data[123];
  double b_wxPk_data[246];
  int b_wxPk_size[2];
  memcpy(&yFinite[0], &y[0], 123U * sizeof(double));
  loop_ub = iInf_size[0];
  for (i13 = 0; i13 < loop_ub; i13++) {
    yFinite[iInf_data[i13] - 1] = rtNaN;
  }

  getPeakBase_DoaMusicSignal(yFinite, iPk_data, iPk_size, iFin_data, iFin_size,
    iInflect_data, iInflect_size, b_bPk_data, b_bPk_size, iLB_data, iLB_size,
    iRB_data, iRB_size);
  b_iPk_size[0] = iPk_size[0];
  loop_ub = iPk_size[0];
  for (i13 = 0; i13 < loop_ub; i13++) {
    b_iPk_data[i13] = iPk_data[i13];
  }

  c_removePeaksBelowMinPeakPromin(yFinite, b_iPk_data, b_iPk_size, b_bPk_data,
    b_bPk_size, iLB_data, iLB_size, iRB_data, iRB_size);
  getPeakWidth_DoaMusicSignal(yFinite, b_iPk_data, b_iPk_size, b_bPk_data,
    b_bPk_size, iLB_data, iLB_size, iRB_data, iRB_size, b_wxPk_data, b_wxPk_size);
  combineFullPeaks_DoaMusicSignal(y, b_iPk_data, b_iPk_size, b_bPk_data,
    b_bPk_size, iLB_data, iLB_size, iRB_data, iRB_size, b_wxPk_data, b_wxPk_size,
    iInf_data, iInf_size, iPk_data, iPk_size, bPk_data, bPk_size, bxPk_data,
    bxPk_size, byPk_data, byPk_size, wxPk_data, wxPk_size);
}

/*
 * Arguments    : const double Yin[123]
 *                double varargin_2
 *                double varargin_8
 *                double Ypk_data[]
 *                int Ypk_size[2]
 *                double Xpk_data[]
 *                int Xpk_size[2]
 * Return Type  : void
 */
static void findpeaks_DoaMusicSignal(const double Yin[123], double varargin_2,
  double varargin_8, double Ypk_data[], int Ypk_size[2], double Xpk_data[], int
  Xpk_size[2])
{
  double y[123];
  double minD;
  double maxN;
  int iFinite_data[123];
  int iFinite_size[1];
  int iInfinite_data[123];
  int iInfinite_size[1];
  int iInflect_data[123];
  int iInflect_size[1];
  int tmp_data[123];
  int tmp_size[1];
  int iPk_size[1];
  int loop_ub;
  int i3;
  int iPk_data[246];
  double bPk_data[246];
  int bPk_size[1];
  double bxPk_data[492];
  int bxPk_size[2];
  double byPk_data[492];
  int byPk_size[2];
  double wxPk_data[492];
  int wxPk_size[2];
  int idx_data[246];
  int b_iPk_size[1];
  int b_iPk_data[246];
  double Wpk_data[246];
  double Ppk_data[246];
  parse_inputs_DoaMusicSignal(Yin, varargin_2, varargin_8, y, &minD, &maxN);
  getAllPeaksCodegen_DoaMusicSign(y, iFinite_data, iFinite_size, iInfinite_data,
    iInfinite_size, iInflect_data, iInflect_size);
  removeSmallPeaks_DoaMusicSignal(y, iFinite_data, iFinite_size, tmp_data,
    tmp_size);
  iPk_size[0] = tmp_size[0];
  loop_ub = tmp_size[0];
  for (i3 = 0; i3 < loop_ub; i3++) {
    iPk_data[i3] = tmp_data[i3];
  }

  findExtents_DoaMusicSignal(y, iPk_data, iPk_size, iFinite_data, iFinite_size,
    iInfinite_data, iInfinite_size, iInflect_data, iInflect_size, bPk_data,
    bPk_size, bxPk_data, bxPk_size, byPk_data, byPk_size, wxPk_data, wxPk_size);
  c_findPeaksSeparatedByMoreThanM(y, iPk_data, iPk_size, minD, idx_data,
    tmp_size);
  keepAtMostNpPeaks_DoaMusicSigna(tmp_size, maxN);
  fetchPeakExtents_DoaMusicSignal(idx_data, tmp_size, bPk_data, bPk_size,
    bxPk_data, bxPk_size, byPk_data, byPk_size, wxPk_data, wxPk_size);
  b_iPk_size[0] = tmp_size[0];
  loop_ub = tmp_size[0];
  for (i3 = 0; i3 < loop_ub; i3++) {
    b_iPk_data[i3] = iPk_data[idx_data[i3] - 1];
  }

  assignFullOutputs_DoaMusicSigna(y, b_iPk_data, b_iPk_size, wxPk_data,
    wxPk_size, bPk_data, Ypk_data, Ypk_size, Xpk_data, Xpk_size, Wpk_data,
    bxPk_size, Ppk_data, byPk_size);
}

/*
 * Arguments    : const double y[123]
 *                int iPk_data[]
 *                int iPk_size[1]
 *                int iInf_data[]
 *                int iInf_size[1]
 *                int iInflect_data[]
 *                int iInflect_size[1]
 * Return Type  : void
 */
static void getAllPeaksCodegen_DoaMusicSign(const double y[123], int iPk_data[],
  int iPk_size[1], int iInf_data[], int iInf_size[1], int iInflect_data[], int
  iInflect_size[1])
{
  int nPk;
  int nInf;
  int nInflect;
  char dir;
  int kfirst;
  double ykfirst;
  boolean_T isinfykfirst;
  int k;
  double yk;
  boolean_T isinfyk;
  char previousdir;
  int i4;
  nPk = 0;
  nInf = 0;
  nInflect = -1;
  dir = 'n';
  kfirst = 0;
  ykfirst = rtInf;
  isinfykfirst = true;
  for (k = 0; k < 123; k++) {
    yk = y[k];
    if (rtIsNaN(y[k])) {
      yk = rtInf;
      isinfyk = true;
    } else if (rtIsInf(y[k]) && (y[k] > 0.0)) {
      isinfyk = true;
      nInf++;
      iInf_data[nInf - 1] = k + 1;
    } else {
      isinfyk = false;
    }

    if (yk != ykfirst) {
      previousdir = dir;
      if (isinfyk || isinfykfirst) {
        dir = 'n';
        if (kfirst >= 1) {
          nInflect++;
          iInflect_data[nInflect] = kfirst;
        }
      } else if (yk < ykfirst) {
        dir = 'd';
        if ('d' != previousdir) {
          nInflect++;
          iInflect_data[nInflect] = kfirst;
          if (previousdir == 'i') {
            nPk++;
            iPk_data[nPk - 1] = kfirst;
          }
        }
      } else {
        dir = 'i';
        if ('i' != previousdir) {
          nInflect++;
          iInflect_data[nInflect] = kfirst;
        }
      }

      ykfirst = yk;
      kfirst = k + 1;
      isinfykfirst = isinfyk;
    }
  }

  if ((!isinfykfirst) && ((nInflect + 1 == 0) || (iInflect_data[nInflect] < 123)))
  {
    nInflect++;
    iInflect_data[nInflect] = 123;
  }

  if (1 > nPk) {
    iPk_size[0] = 0;
  } else {
    iPk_size[0] = nPk;
  }

  if (1 > nInf) {
    iInf_size[0] = 0;
  } else {
    iInf_size[0] = nInf;
  }

  if (1 > nInflect + 1) {
    i4 = -1;
  } else {
    i4 = nInflect;
  }

  iInflect_size[0] = i4 + 1;
}

/*
 * Arguments    : const double yTemp[123]
 *                const int iPeak_data[]
 *                const int iPeak_size[1]
 *                const int iFinite_data[]
 *                const int iFinite_size[1]
 *                const int iInflect_data[]
 *                int iBase_data[]
 *                int iBase_size[1]
 *                int iSaddle_data[]
 *                int iSaddle_size[1]
 * Return Type  : void
 */
static void getLeftBase_DoaMusicSignal(const double yTemp[123], const int
  iPeak_data[], const int iPeak_size[1], const int iFinite_data[], const int
  iFinite_size[1], const int iInflect_data[], int iBase_data[], int iBase_size[1],
  int iSaddle_data[], int iSaddle_size[1])
{
  int n;
  int i;
  double peak_data[123];
  double valley_data[123];
  int iValley_data[123];
  int j;
  int k;
  double v;
  int iv;
  double p;
  int isv;
  iBase_size[0] = (signed char)iPeak_size[0];
  n = (signed char)iPeak_size[0];
  for (i = 0; i < n; i++) {
    iBase_data[i] = 0;
  }

  iSaddle_size[0] = (signed char)iPeak_size[0];
  n = (signed char)iPeak_size[0];
  for (i = 0; i < n; i++) {
    iSaddle_data[i] = 0;
  }

  n = (signed char)iFinite_size[0];
  for (i = 0; i < n; i++) {
    peak_data[i] = 0.0;
  }

  n = (signed char)iFinite_size[0];
  for (i = 0; i < n; i++) {
    valley_data[i] = 0.0;
  }

  n = (signed char)iFinite_size[0];
  for (i = 0; i < n; i++) {
    iValley_data[i] = 0;
  }

  n = -1;
  i = 0;
  j = 0;
  k = 0;
  v = rtNaN;
  iv = 1;
  while (k + 1 <= iPeak_size[0]) {
    while (iInflect_data[i] != iFinite_data[j]) {
      v = yTemp[iInflect_data[i] - 1];
      iv = iInflect_data[i];
      if (rtIsNaN(yTemp[iInflect_data[i] - 1])) {
        n = -1;
      } else {
        while ((n + 1 > 0) && (valley_data[n] > v)) {
          n--;
        }
      }

      i++;
    }

    p = yTemp[iInflect_data[i] - 1];
    while ((n + 1 > 0) && (peak_data[n] < p)) {
      if (valley_data[n] < v) {
        v = valley_data[n];
        iv = iValley_data[n];
      }

      n--;
    }

    isv = iv;
    while ((n + 1 > 0) && (peak_data[n] <= p)) {
      if (valley_data[n] < v) {
        v = valley_data[n];
        iv = iValley_data[n];
      }

      n--;
    }

    n++;
    peak_data[n] = yTemp[iInflect_data[i] - 1];
    valley_data[n] = v;
    iValley_data[n] = iv;
    if (iInflect_data[i] == iPeak_data[k]) {
      iBase_data[k] = iv;
      iSaddle_data[k] = isv;
      k++;
    }

    i++;
    j++;
  }
}

/*
 * Arguments    : const double yTemp[123]
 *                const int iPk_data[]
 *                const int iPk_size[1]
 *                const int iFin_data[]
 *                const int iFin_size[1]
 *                const int iInflect_data[]
 *                const int iInflect_size[1]
 *                double peakBase_data[]
 *                int peakBase_size[1]
 *                int iLeftSaddle_data[]
 *                int iLeftSaddle_size[1]
 *                int iRightSaddle_data[]
 *                int iRightSaddle_size[1]
 * Return Type  : void
 */
static void getPeakBase_DoaMusicSignal(const double yTemp[123], const int
  iPk_data[], const int iPk_size[1], const int iFin_data[], const int iFin_size
  [1], const int iInflect_data[], const int iInflect_size[1], double
  peakBase_data[], int peakBase_size[1], int iLeftSaddle_data[], int
  iLeftSaddle_size[1], int iRightSaddle_data[], int iRightSaddle_size[1])
{
  int iLeftBase_data[123];
  int iLeftBase_size[1];
  int x_size[1];
  int m;
  int md2;
  int x_data[123];
  int i;
  int b_x_size[1];
  int xtmp;
  int b_x_data[123];
  int c_x_data[123];
  int iRightBase_data[123];
  int iRightBase_size[1];
  signed char csz_idx_0;
  getLeftBase_DoaMusicSignal(yTemp, iPk_data, iPk_size, iFin_data, iFin_size,
    iInflect_data, iLeftBase_data, iLeftBase_size, iLeftSaddle_data,
    iLeftSaddle_size);
  x_size[0] = iPk_size[0];
  m = iPk_size[0];
  for (md2 = 0; md2 < m; md2++) {
    x_data[md2] = iPk_data[md2];
  }

  m = iPk_size[0];
  md2 = iPk_size[0] >> 1;
  for (i = 1; i <= md2; i++) {
    xtmp = x_data[i - 1];
    x_data[i - 1] = x_data[m - i];
    x_data[m - i] = xtmp;
  }

  b_x_size[0] = iFin_size[0];
  m = iFin_size[0];
  for (md2 = 0; md2 < m; md2++) {
    b_x_data[md2] = iFin_data[md2];
  }

  m = iFin_size[0];
  md2 = iFin_size[0] >> 1;
  for (i = 1; i <= md2; i++) {
    xtmp = b_x_data[i - 1];
    b_x_data[i - 1] = b_x_data[m - i];
    b_x_data[m - i] = xtmp;
  }

  m = iInflect_size[0];
  for (md2 = 0; md2 < m; md2++) {
    c_x_data[md2] = iInflect_data[md2];
  }

  m = iInflect_size[0];
  md2 = iInflect_size[0] >> 1;
  for (i = 1; i <= md2; i++) {
    xtmp = c_x_data[i - 1];
    c_x_data[i - 1] = c_x_data[m - i];
    c_x_data[m - i] = xtmp;
  }

  getLeftBase_DoaMusicSignal(yTemp, x_data, x_size, b_x_data, b_x_size, c_x_data,
    iRightBase_data, iRightBase_size, iRightSaddle_data, iRightSaddle_size);
  m = iRightBase_size[0];
  md2 = iRightBase_size[0] >> 1;
  for (i = 1; i <= md2; i++) {
    xtmp = iRightBase_data[i - 1];
    iRightBase_data[i - 1] = iRightBase_data[m - i];
    iRightBase_data[m - i] = xtmp;
  }

  m = iRightSaddle_size[0];
  md2 = iRightSaddle_size[0] >> 1;
  for (i = 1; i <= md2; i++) {
    xtmp = iRightSaddle_data[i - 1];
    iRightSaddle_data[i - 1] = iRightSaddle_data[m - i];
    iRightSaddle_data[m - i] = xtmp;
  }

  if (iLeftBase_size[0] <= iRightBase_size[0]) {
    csz_idx_0 = (signed char)iLeftBase_size[0];
    peakBase_size[0] = (signed char)iLeftBase_size[0];
  } else {
    csz_idx_0 = (signed char)iRightBase_size[0];
    peakBase_size[0] = (signed char)iRightBase_size[0];
  }

  for (m = 0; m + 1 <= csz_idx_0; m++) {
    if ((yTemp[iLeftBase_data[m] - 1] > yTemp[iRightBase_data[m] - 1]) ||
        rtIsNaN(yTemp[iRightBase_data[m] - 1])) {
      peakBase_data[m] = yTemp[iLeftBase_data[m] - 1];
    } else {
      peakBase_data[m] = yTemp[iRightBase_data[m] - 1];
    }
  }
}

/*
 * Arguments    : const double y[123]
 *                const int iPk_data[]
 *                const int iPk_size[1]
 *                const double pbPk_data[]
 *                const int pbPk_size[1]
 *                int iLB_data[]
 *                int iLB_size[1]
 *                int iRB_data[]
 *                int iRB_size[1]
 *                double wxPk_data[]
 *                int wxPk_size[2]
 * Return Type  : void
 */
static void getPeakWidth_DoaMusicSignal(const double y[123], const int iPk_data[],
  const int iPk_size[1], const double pbPk_data[], const int pbPk_size[1], int
  iLB_data[], int iLB_size[1], int iRB_data[], int iRB_size[1], double
  wxPk_data[], int wxPk_size[2])
{
  int iLeft;
  int iRight;
  double base_data[123];
  int i;
  double refHeight;
  double xc;
  if (iPk_size[0] == 0) {
    iLB_size[0] = 0;
    iRB_size[0] = 0;
  } else {
    iLeft = pbPk_size[0];
    for (iRight = 0; iRight < iLeft; iRight++) {
      base_data[iRight] = pbPk_data[iRight];
    }
  }

  wxPk_size[0] = iPk_size[0];
  wxPk_size[1] = 2;
  iLeft = iPk_size[0] << 1;
  for (iRight = 0; iRight < iLeft; iRight++) {
    wxPk_data[iRight] = 0.0;
  }

  for (i = 0; i < iPk_size[0]; i++) {
    refHeight = (y[iPk_data[i] - 1] + base_data[i]) / 2.0;
    iLeft = iPk_data[i];
    while ((iLeft >= iLB_data[i]) && (y[iLeft - 1] > refHeight)) {
      iLeft--;
    }

    if (iLeft < iLB_data[i]) {
      wxPk_data[i] = 1.0 + ((double)iLB_data[i] - 1.0);
    } else {
      xc = (1.0 + ((double)iLeft - 1.0)) + (0.5 * (y[iPk_data[i] - 1] +
        base_data[i]) - y[iLeft - 1]) / (y[iLeft] - y[iLeft - 1]);
      if (rtIsNaN(xc)) {
        if (rtIsInf(base_data[i])) {
          xc = 0.5 * (double)((iLeft + iLeft) + 1);
        } else {
          xc = 1.0 + (double)iLeft;
        }
      }

      wxPk_data[i] = xc;
    }

    iRight = iPk_data[i];
    while ((iRight <= iRB_data[i]) && (y[iRight - 1] > refHeight)) {
      iRight++;
    }

    if (iRight > iRB_data[i]) {
      wxPk_data[i + wxPk_size[0]] = 1.0 + ((double)iRB_data[i] - 1.0);
    } else {
      xc = (1.0 + ((double)iRight - 1.0)) + -(0.5 * (y[iPk_data[i] - 1] +
        base_data[i]) - y[iRight - 1]) / (y[iRight - 2] - y[iRight - 1]);
      if (rtIsNaN(xc)) {
        if (rtIsInf(base_data[i])) {
          xc = 0.5 * (double)((iRight + iRight) - 1);
        } else {
          xc = 1.0 + ((double)iRight - 2.0);
        }
      }

      wxPk_data[i + wxPk_size[0]] = xc;
    }
  }
}

/*
 * Arguments    : int idx_size[1]
 *                double Np
 * Return Type  : void
 */
static void keepAtMostNpPeaks_DoaMusicSigna(int idx_size[1], double Np)
{
  if (idx_size[0] > Np) {
    if (1.0 > Np) {
      idx_size[0] = 0;
    } else {
      idx_size[0] = (int)Np;
    }
  }
}

/*
 * Arguments    : int idx[4]
 *                double x[4]
 *                int offset
 *                int np
 *                int nq
 *                int iwork[4]
 *                double xwork[4]
 * Return Type  : void
 */
static void merge_DoaMusicSignal(int idx[4], double x[4], int offset, int np,
  int nq, int iwork[4], double xwork[4])
{
  int n;
  int qend;
  int p;
  int iout;
  int exitg1;
  if (nq != 0) {
    n = np + nq;
    for (qend = 0; qend + 1 <= n; qend++) {
      iwork[qend] = idx[offset + qend];
      xwork[qend] = x[offset + qend];
    }

    p = 0;
    n = np;
    qend = np + nq;
    iout = offset - 1;
    do {
      exitg1 = 0;
      iout++;
      if (xwork[p] <= xwork[n]) {
        idx[iout] = iwork[p];
        x[iout] = xwork[p];
        if (p + 1 < np) {
          p++;
        } else {
          exitg1 = 1;
        }
      } else {
        idx[iout] = iwork[n];
        x[iout] = xwork[n];
        if (n + 1 < qend) {
          n++;
        } else {
          n = (iout - p) + 1;
          while (p + 1 <= np) {
            idx[n + p] = iwork[p];
            x[n + p] = xwork[p];
            p++;
          }

          exitg1 = 1;
        }
      }
    } while (exitg1 == 0);
  }
}

/*
 * Arguments    : int idx_data[]
 *                int x_data[]
 *                int n
 *                int iwork_data[]
 *                int xwork_data[]
 * Return Type  : void
 */
static void merge_block_DoaMusicSignal(int idx_data[], int x_data[], int n, int
  iwork_data[], int xwork_data[])
{
  int nPairs;
  int bLen;
  int tailOffset;
  int nTail;
  nPairs = n >> 2;
  bLen = 4;
  while (nPairs > 1) {
    if ((nPairs & 1) != 0) {
      nPairs--;
      tailOffset = bLen * nPairs;
      nTail = n - tailOffset;
      if (nTail > bLen) {
        b_merge_DoaMusicSignal(idx_data, x_data, tailOffset, bLen, nTail - bLen,
          iwork_data, xwork_data);
      }
    }

    tailOffset = bLen << 1;
    nPairs >>= 1;
    for (nTail = 1; nTail <= nPairs; nTail++) {
      b_merge_DoaMusicSignal(idx_data, x_data, (nTail - 1) * tailOffset, bLen,
        bLen, iwork_data, xwork_data);
    }

    bLen = tailOffset;
  }

  if (n > bLen) {
    b_merge_DoaMusicSignal(idx_data, x_data, 0, bLen, n - bLen, iwork_data,
      xwork_data);
  }
}

/*
 * Arguments    : const int x_size[1]
 * Return Type  : int
 */
static int nonSingletonDim_DoaMusicSignal(const int x_size[1])
{
  int dim;
  dim = 2;
  if (x_size[0] != 1) {
    dim = 1;
  }

  return dim;
}

/*
 * Arguments    : const double Yin[123]
 *                double varargin_2
 *                double varargin_8
 *                double y[123]
 *                double *Pd
 *                double *NpOut
 * Return Type  : void
 */
static void parse_inputs_DoaMusicSignal(const double Yin[123], double varargin_2,
  double varargin_8, double y[123], double *Pd, double *NpOut)
{
  memcpy(&y[0], &Yin[0], 123U * sizeof(double));
  *Pd = varargin_8;
  *NpOut = varargin_2;
}

/*
 * Arguments    : const double y[121]
 *                double ydB[121]
 * Return Type  : void
 */
static void pow2db_DoaMusicSignal(const double y[121], double ydB[121])
{
  int k;
  for (k = 0; k < 121; k++) {
    ydB[k] = (10.0 * log10(y[k]) + 300.0) - 300.0;
  }
}

/*
 * Arguments    : const creal_T y
 * Return Type  : creal_T
 */
static creal_T recip_DoaMusicSignal(const creal_T y)
{
  creal_T z;
  double brm;
  double bim;
  double d;
  brm = fabs(y.re);
  bim = fabs(y.im);
  if (y.im == 0.0) {
    z.re = 1.0 / y.re;
    z.im = 0.0;
  } else if (y.re == 0.0) {
    z.re = 0.0;
    z.im = -1.0 / y.im;
  } else if (brm > bim) {
    bim = y.im / y.re;
    d = y.re + bim * y.im;
    z.re = 1.0 / d;
    z.im = -bim / d;
  } else if (brm == bim) {
    bim = 0.5;
    if (y.re < 0.0) {
      bim = -0.5;
    }

    d = 0.5;
    if (y.im < 0.0) {
      d = -0.5;
    }

    z.re = bim / brm;
    z.im = -d / brm;
  } else {
    bim = y.re / y.im;
    d = y.im + bim * y.re;
    z.re = bim / d;
    z.im = -1.0 / d;
  }

  return z;
}

/*
 * Arguments    : const double y[123]
 *                const int iFinite_data[]
 *                const int iFinite_size[1]
 *                int iPk_data[]
 *                int iPk_size[1]
 * Return Type  : void
 */
static void removeSmallPeaks_DoaMusicSignal(const double y[123], const int
  iFinite_data[], const int iFinite_size[1], int iPk_data[], int iPk_size[1])
{
  int nPk;
  int k;
  double b_y;
  nPk = 0;
  for (k = 0; k + 1 <= iFinite_size[0]; k++) {
    if (y[iFinite_data[k] - 1] > -15.0) {
      if ((y[iFinite_data[k] - 2] > y[iFinite_data[k]]) || rtIsNaN
          (y[iFinite_data[k]])) {
        b_y = y[iFinite_data[k] - 2];
      } else {
        b_y = y[iFinite_data[k]];
      }

      if (y[iFinite_data[k] - 1] - b_y >= 0.0) {
        nPk++;
        iPk_data[nPk - 1] = iFinite_data[k];
      }
    }
  }

  if (1 > nPk) {
    iPk_size[0] = 0;
  } else {
    iPk_size[0] = nPk;
  }
}

/*
 * Arguments    : double u0
 *                double u1
 * Return Type  : double
 */
static double rt_hypotd_snf_DoaMusicSignal(double u0, double u1)
{
  double y;
  double a;
  double b;
  a = fabs(u0);
  b = fabs(u1);
  if (a < b) {
    a /= b;
    y = b * sqrt(a * a + 1.0);
  } else if (a > b) {
    b /= a;
    y = a * sqrt(b * b + 1.0);
  } else if (rtIsNaN(b)) {
    y = b;
  } else {
    y = a * 1.4142135623730951;
  }

  return y;
}

/*
 * Arguments    : const creal_T A[16]
 *                creal_T V[16]
 *                creal_T T[16]
 * Return Type  : void
 */
static void schur_DoaMusicSignal(const creal_T A[16], creal_T V[16], creal_T T
  [16])
{
  int i1;
  creal_T tau[3];
  int i;
  int j;
  int b_i;
  int itau;
  creal_T work[4];
  int iaii;
  int lastv;
  int lastc;
  double c_re;
  boolean_T exitg2;
  double c_im;
  creal_T b_tau;
  int ia;
  double V_re;
  int exitg1;
  int ix;
  int i2;
  if (anyNonFinite_DoaMusicSignal(A)) {
    for (i1 = 0; i1 < 16; i1++) {
      V[i1].re = rtNaN;
      V[i1].im = 0.0;
    }

    i = 2;
    for (j = 0; j < 3; j++) {
      for (b_i = i; b_i < 5; b_i++) {
        V[(b_i + (j << 2)) - 1].re = 0.0;
        V[(b_i + (j << 2)) - 1].im = 0.0;
      }

      i++;
    }

    for (i1 = 0; i1 < 16; i1++) {
      T[i1].re = rtNaN;
      T[i1].im = 0.0;
    }
  } else {
    memcpy(&T[0], &A[0], sizeof(creal_T) << 4);
    xgehrd_DoaMusicSignal(T, tau);
    memcpy(&V[0], &T[0], sizeof(creal_T) << 4);
    for (j = 2; j >= 0; j += -1) {
      i = (j + 1) << 2;
      for (b_i = 1; b_i <= j + 1; b_i++) {
        V[(i + b_i) - 1].re = 0.0;
        V[(i + b_i) - 1].im = 0.0;
      }

      for (b_i = j; b_i + 3 < 5; b_i++) {
        V[(i + b_i) + 2] = V[(i + b_i) - 2];
      }
    }

    for (b_i = 0; b_i < 4; b_i++) {
      V[b_i].re = 0.0;
      V[b_i].im = 0.0;
      work[b_i].re = 0.0;
      work[b_i].im = 0.0;
    }

    V[0].re = 1.0;
    V[0].im = 0.0;
    itau = 2;
    for (b_i = 2; b_i >= 0; b_i += -1) {
      iaii = (b_i + (b_i << 2)) + 10;
      if (b_i + 1 < 3) {
        V[iaii - 5].re = 1.0;
        V[iaii - 5].im = 0.0;
        if ((tau[itau].re != 0.0) || (tau[itau].im != 0.0)) {
          lastv = 3 - b_i;
          i = iaii - b_i;
          while ((lastv > 0) && ((V[i - 3].re == 0.0) && (V[i - 3].im == 0.0)))
          {
            lastv--;
            i--;
          }

          lastc = 2 - b_i;
          exitg2 = false;
          while ((!exitg2) && (lastc > 0)) {
            i = iaii + ((lastc - 1) << 2);
            ia = i;
            do {
              exitg1 = 0;
              if (ia <= (i + lastv) - 1) {
                if ((V[ia - 1].re != 0.0) || (V[ia - 1].im != 0.0)) {
                  exitg1 = 1;
                } else {
                  ia++;
                }
              } else {
                lastc--;
                exitg1 = 2;
              }
            } while (exitg1 == 0);

            if (exitg1 == 1) {
              exitg2 = true;
            }
          }
        } else {
          lastv = 0;
          lastc = 0;
        }

        if (lastv > 0) {
          if (lastc != 0) {
            for (i = 1; i <= lastc; i++) {
              work[i - 1].re = 0.0;
              work[i - 1].im = 0.0;
            }

            i = 0;
            i1 = iaii + ((lastc - 1) << 2);
            for (j = iaii; j <= i1; j += 4) {
              ix = iaii - 5;
              c_re = 0.0;
              c_im = 0.0;
              i2 = (j + lastv) - 1;
              for (ia = j - 1; ia + 1 <= i2; ia++) {
                c_re += V[ia].re * V[ix].re + V[ia].im * V[ix].im;
                c_im += V[ia].re * V[ix].im - V[ia].im * V[ix].re;
                ix++;
              }

              work[i].re += c_re - 0.0 * c_im;
              work[i].im += c_im + 0.0 * c_re;
              i++;
            }
          }

          b_tau.re = -tau[itau].re;
          b_tau.im = -tau[itau].im;
          xgerc_DoaMusicSignal(lastv, lastc, b_tau, iaii - 4, work, V, iaii);
        }

        c_re = -tau[itau].re;
        c_im = -tau[itau].im;
        i1 = (iaii - b_i) - 2;
        for (i = iaii - 4; i + 1 <= i1; i++) {
          V_re = V[i].re;
          V[i].re = c_re * V[i].re - c_im * V[i].im;
          V[i].im = c_re * V[i].im + c_im * V_re;
        }
      }

      V[iaii - 5].re = 1.0 - tau[itau].re;
      V[iaii - 5].im = 0.0 - tau[itau].im;
      for (j = 1; j <= b_i; j++) {
        V[(iaii - j) - 5].re = 0.0;
        V[(iaii - j) - 5].im = 0.0;
      }

      itau--;
    }

    eml_zlahqr_DoaMusicSignal(T, V);
    T[3].re = 0.0;
    T[3].im = 0.0;
  }
}

/*
 * Arguments    : const double x_data[]
 *                const int x_size[1]
 *                int idx_data[]
 *                int idx_size[1]
 * Return Type  : void
 */
static void sortIdx_DoaMusicSignal(const double x_data[], const int x_size[1],
  int idx_data[], int idx_size[1])
{
  int n;
  int loop_ub;
  int i;
  boolean_T p;
  int i2;
  int j;
  int pEnd;
  int b_p;
  int q;
  int qEnd;
  int kEnd;
  int iwork_data[246];
  n = x_size[0] + 1;
  idx_size[0] = (unsigned char)x_size[0];
  loop_ub = (unsigned char)x_size[0];
  for (i = 0; i < loop_ub; i++) {
    idx_data[i] = 0;
  }

  for (loop_ub = 1; loop_ub <= n - 2; loop_ub += 2) {
    if ((x_data[loop_ub - 1] >= x_data[loop_ub]) || rtIsNaN(x_data[loop_ub - 1]))
    {
      p = true;
    } else {
      p = false;
    }

    if (p) {
      idx_data[loop_ub - 1] = loop_ub;
      idx_data[loop_ub] = loop_ub + 1;
    } else {
      idx_data[loop_ub - 1] = loop_ub + 1;
      idx_data[loop_ub] = loop_ub;
    }
  }

  if ((x_size[0] & 1) != 0) {
    idx_data[x_size[0] - 1] = x_size[0];
  }

  i = 2;
  while (i < n - 1) {
    i2 = i << 1;
    j = 1;
    for (pEnd = 1 + i; pEnd < n; pEnd = qEnd + i) {
      b_p = j - 1;
      q = pEnd;
      qEnd = j + i2;
      if (qEnd > n) {
        qEnd = n;
      }

      loop_ub = 0;
      kEnd = qEnd - j;
      while (loop_ub + 1 <= kEnd) {
        if ((x_data[idx_data[b_p] - 1] >= x_data[idx_data[q - 1] - 1]) ||
            rtIsNaN(x_data[idx_data[b_p] - 1])) {
          p = true;
        } else {
          p = false;
        }

        if (p) {
          iwork_data[loop_ub] = idx_data[b_p];
          b_p++;
          if (b_p + 1 == pEnd) {
            while (q < qEnd) {
              loop_ub++;
              iwork_data[loop_ub] = idx_data[q - 1];
              q++;
            }
          }
        } else {
          iwork_data[loop_ub] = idx_data[q - 1];
          q++;
          if (q == qEnd) {
            while (b_p + 1 < pEnd) {
              loop_ub++;
              iwork_data[loop_ub] = idx_data[b_p];
              b_p++;
            }
          }
        }

        loop_ub++;
      }

      for (loop_ub = 0; loop_ub + 1 <= kEnd; loop_ub++) {
        idx_data[(j + loop_ub) - 1] = iwork_data[loop_ub];
      }

      j = qEnd;
    }

    i = i2;
  }
}

/*
 * Arguments    : double x[4]
 *                int idx[4]
 * Return Type  : void
 */
static void sort_DoaMusicSignal(double x[4], int idx[4])
{
  b_sort_DoaMusicSignal(x, idx);
}

/*
 * Arguments    : creal_T *x
 * Return Type  : void
 */
static void sqrt_DoaMusicSignal(creal_T *x)
{
  double xr;
  double xi;
  double absxi;
  double absxr;
  xr = x->re;
  xi = x->im;
  if (xi == 0.0) {
    if (xr < 0.0) {
      absxi = 0.0;
      xr = sqrt(-xr);
    } else {
      absxi = sqrt(xr);
      xr = 0.0;
    }
  } else if (xr == 0.0) {
    if (xi < 0.0) {
      absxi = sqrt(-xi / 2.0);
      xr = -absxi;
    } else {
      absxi = sqrt(xi / 2.0);
      xr = absxi;
    }
  } else if (rtIsNaN(xr)) {
    absxi = xr;
  } else if (rtIsNaN(xi)) {
    absxi = xi;
    xr = xi;
  } else if (rtIsInf(xi)) {
    absxi = fabs(xi);
    xr = xi;
  } else if (rtIsInf(xr)) {
    if (xr < 0.0) {
      absxi = 0.0;
      xr = xi * -xr;
    } else {
      absxi = xr;
      xr = 0.0;
    }
  } else {
    absxr = fabs(xr);
    absxi = fabs(xi);
    if ((absxr > 4.4942328371557893E+307) || (absxi > 4.4942328371557893E+307))
    {
      absxr *= 0.5;
      absxi *= 0.5;
      absxi = rt_hypotd_snf_DoaMusicSignal(absxr, absxi);
      if (absxi > absxr) {
        absxi = sqrt(absxi) * sqrt(1.0 + absxr / absxi);
      } else {
        absxi = sqrt(absxi) * 1.4142135623730951;
      }
    } else {
      absxi = sqrt((rt_hypotd_snf_DoaMusicSignal(absxr, absxi) + absxr) * 0.5);
    }

    if (xr > 0.0) {
      xr = 0.5 * (xi / absxi);
    } else {
      if (xi < 0.0) {
        xr = -absxi;
      } else {
        xr = absxi;
      }

      absxi = 0.5 * (xi / xr);
    }
  }

  x->re = absxi;
  x->im = xr;
}

/*
 * Arguments    : const double x[4]
 * Return Type  : double
 */
static double sum_DoaMusicSignal(const double x[4])
{
  double y;
  int k;
  y = x[0];
  for (k = 0; k < 3; k++) {
    y += x[k + 1];
  }

  return y;
}

/*
 * Arguments    : double x1
 *                double x2
 *                double x3
 * Return Type  : double
 */
static double xdlapy3_DoaMusicSignal(double x1, double x2, double x3)
{
  double y;
  double a;
  double b;
  double c;
  a = fabs(x1);
  b = fabs(x2);
  c = fabs(x3);
  if ((a > b) || rtIsNaN(b)) {
    y = a;
  } else {
    y = b;
  }

  if (c > y) {
    y = c;
  }

  if ((y > 0.0) && (!rtIsInf(y))) {
    a /= y;
    b /= y;
    c /= y;
    y *= sqrt((a * a + c * c) + b * b);
  } else {
    y = (a + b) + c;
  }

  return y;
}

/*
 * Arguments    : creal_T a[16]
 *                creal_T tau[3]
 * Return Type  : void
 */
static void xgehrd_DoaMusicSignal(creal_T a[16], creal_T tau[3])
{
  int i;
  creal_T work[4];
  int im1n;
  int in;
  creal_T alpha1;
  int ia0;
  double c_re;
  double c_im;
  double xnorm;
  double beta1;
  int knt;
  int jy;
  double temp_im;
  int i7;
  int lastv;
  int lastc;
  int k;
  creal_T b_a;
  boolean_T exitg2;
  int ix;
  int ia;
  int exitg1;
  int i8;
  for (i = 0; i < 4; i++) {
    work[i].re = 0.0;
    work[i].im = 0.0;
  }

  for (i = 0; i < 3; i++) {
    im1n = (i << 2) + 2;
    in = (i + 1) << 2;
    alpha1 = a[(i + (i << 2)) + 1];
    ia0 = i + 3;
    if (ia0 < 4) {
      ia0 = 3;
    } else {
      ia0 = 4;
    }

    ia0 += i << 2;
    c_re = 0.0;
    c_im = 0.0;
    xnorm = xnrm2_DoaMusicSignal(2 - i, a, ia0);
    if ((xnorm != 0.0) || (a[(i + (i << 2)) + 1].im != 0.0)) {
      beta1 = xdlapy3_DoaMusicSignal(a[(i + (i << 2)) + 1].re, a[(i + (i << 2))
        + 1].im, xnorm);
      if (a[(i + (i << 2)) + 1].re >= 0.0) {
        beta1 = -beta1;
      }

      if (fabs(beta1) < 1.0020841800044864E-292) {
        knt = 0;
        i7 = (ia0 - i) + 1;
        do {
          knt++;
          for (k = ia0; k <= i7; k++) {
            xnorm = a[k - 1].re;
            temp_im = a[k - 1].im;
            a[k - 1].re = 9.9792015476736E+291 * xnorm - 0.0 * temp_im;
            a[k - 1].im = 9.9792015476736E+291 * temp_im + 0.0 * xnorm;
          }

          beta1 *= 9.9792015476736E+291;
          alpha1.re *= 9.9792015476736E+291;
          alpha1.im *= 9.9792015476736E+291;
        } while (!(fabs(beta1) >= 1.0020841800044864E-292));

        beta1 = xdlapy3_DoaMusicSignal(alpha1.re, alpha1.im,
          xnrm2_DoaMusicSignal(2 - i, a, ia0));
        if (alpha1.re >= 0.0) {
          beta1 = -beta1;
        }

        xnorm = beta1 - alpha1.re;
        if (0.0 - alpha1.im == 0.0) {
          c_re = xnorm / beta1;
          c_im = 0.0;
        } else if (xnorm == 0.0) {
          c_re = 0.0;
          c_im = (0.0 - alpha1.im) / beta1;
        } else {
          c_re = xnorm / beta1;
          c_im = (0.0 - alpha1.im) / beta1;
        }

        b_a.re = alpha1.re - beta1;
        b_a.im = alpha1.im;
        alpha1 = recip_DoaMusicSignal(b_a);
        i7 = (ia0 - i) + 1;
        while (ia0 <= i7) {
          xnorm = a[ia0 - 1].re;
          temp_im = a[ia0 - 1].im;
          a[ia0 - 1].re = alpha1.re * xnorm - alpha1.im * temp_im;
          a[ia0 - 1].im = alpha1.re * temp_im + alpha1.im * xnorm;
          ia0++;
        }

        for (k = 1; k <= knt; k++) {
          beta1 *= 1.0020841800044864E-292;
        }

        alpha1.re = beta1;
        alpha1.im = 0.0;
      } else {
        xnorm = beta1 - a[(i + (i << 2)) + 1].re;
        temp_im = 0.0 - a[(i + (i << 2)) + 1].im;
        if (temp_im == 0.0) {
          c_re = xnorm / beta1;
          c_im = 0.0;
        } else if (xnorm == 0.0) {
          c_re = 0.0;
          c_im = temp_im / beta1;
        } else {
          c_re = xnorm / beta1;
          c_im = temp_im / beta1;
        }

        b_a.re = a[(i + (i << 2)) + 1].re - beta1;
        b_a.im = a[(i + (i << 2)) + 1].im;
        alpha1 = recip_DoaMusicSignal(b_a);
        i7 = (ia0 - i) + 1;
        while (ia0 <= i7) {
          xnorm = a[ia0 - 1].re;
          temp_im = a[ia0 - 1].im;
          a[ia0 - 1].re = alpha1.re * xnorm - alpha1.im * temp_im;
          a[ia0 - 1].im = alpha1.re * temp_im + alpha1.im * xnorm;
          ia0++;
        }

        alpha1.re = beta1;
        alpha1.im = 0.0;
      }
    }

    tau[i].re = c_re;
    tau[i].im = c_im;
    a[(i + (i << 2)) + 1].re = 1.0;
    a[(i + (i << 2)) + 1].im = 0.0;
    jy = (i + im1n) - 1;
    if ((tau[i].re != 0.0) || (tau[i].im != 0.0)) {
      lastv = 3 - i;
      ia0 = (jy - i) + 2;
      while ((lastv > 0) && ((a[ia0].re == 0.0) && (a[ia0].im == 0.0))) {
        lastv--;
        ia0--;
      }

      lastc = 4;
      exitg2 = false;
      while ((!exitg2) && (lastc > 0)) {
        ia0 = in + lastc;
        ia = ia0;
        do {
          exitg1 = 0;
          if (ia <= ia0 + ((lastv - 1) << 2)) {
            if ((a[ia - 1].re != 0.0) || (a[ia - 1].im != 0.0)) {
              exitg1 = 1;
            } else {
              ia += 4;
            }
          } else {
            lastc--;
            exitg1 = 2;
          }
        } while (exitg1 == 0);

        if (exitg1 == 1) {
          exitg2 = true;
        }
      }
    } else {
      lastv = 0;
      lastc = 0;
    }

    if (lastv > 0) {
      if (lastc != 0) {
        for (ia0 = 1; ia0 <= lastc; ia0++) {
          work[ia0 - 1].re = 0.0;
          work[ia0 - 1].im = 0.0;
        }

        ix = jy;
        i7 = (in + ((lastv - 1) << 2)) + 1;
        for (k = in + 1; k <= i7; k += 4) {
          c_re = a[ix].re - 0.0 * a[ix].im;
          c_im = a[ix].im + 0.0 * a[ix].re;
          ia0 = 0;
          i8 = (k + lastc) - 1;
          for (ia = k; ia <= i8; ia++) {
            work[ia0].re += a[ia - 1].re * c_re - a[ia - 1].im * c_im;
            work[ia0].im += a[ia - 1].re * c_im + a[ia - 1].im * c_re;
            ia0++;
          }

          ix++;
        }
      }

      c_re = -tau[i].re;
      c_im = -tau[i].im;
      if (!((-tau[i].re == 0.0) && (-tau[i].im == 0.0))) {
        ia0 = in;
        for (knt = 1; knt <= lastv; knt++) {
          if ((a[jy].re != 0.0) || (a[jy].im != 0.0)) {
            xnorm = a[jy].re * c_re + a[jy].im * c_im;
            temp_im = a[jy].re * c_im - a[jy].im * c_re;
            ix = 0;
            i7 = lastc + ia0;
            for (k = ia0; k + 1 <= i7; k++) {
              a[k].re += work[ix].re * xnorm - work[ix].im * temp_im;
              a[k].im += work[ix].re * temp_im + work[ix].im * xnorm;
              ix++;
            }
          }

          jy++;
          ia0 += 4;
        }
      }
    }

    jy = i + im1n;
    knt = (i + in) + 2;
    if ((tau[i].re != 0.0) || (-tau[i].im != 0.0)) {
      lastv = 3 - i;
      ia0 = (jy - i) + 1;
      while ((lastv > 0) && ((a[ia0].re == 0.0) && (a[ia0].im == 0.0))) {
        lastv--;
        ia0--;
      }

      lastc = 3 - i;
      exitg2 = false;
      while ((!exitg2) && (lastc > 0)) {
        ia0 = knt + ((lastc - 1) << 2);
        ia = ia0;
        do {
          exitg1 = 0;
          if (ia <= (ia0 + lastv) - 1) {
            if ((a[ia - 1].re != 0.0) || (a[ia - 1].im != 0.0)) {
              exitg1 = 1;
            } else {
              ia++;
            }
          } else {
            lastc--;
            exitg1 = 2;
          }
        } while (exitg1 == 0);

        if (exitg1 == 1) {
          exitg2 = true;
        }
      }
    } else {
      lastv = 0;
      lastc = 0;
    }

    if (lastv > 0) {
      if (lastc != 0) {
        for (ia0 = 1; ia0 <= lastc; ia0++) {
          work[ia0 - 1].re = 0.0;
          work[ia0 - 1].im = 0.0;
        }

        ia0 = 0;
        i7 = knt + ((lastc - 1) << 2);
        for (k = knt; k <= i7; k += 4) {
          ix = jy - 1;
          c_re = 0.0;
          c_im = 0.0;
          i8 = (k + lastv) - 1;
          for (ia = k - 1; ia + 1 <= i8; ia++) {
            c_re += a[ia].re * a[ix].re + a[ia].im * a[ix].im;
            c_im += a[ia].re * a[ix].im - a[ia].im * a[ix].re;
            ix++;
          }

          work[ia0].re += c_re - 0.0 * c_im;
          work[ia0].im += c_im + 0.0 * c_re;
          ia0++;
        }
      }

      b_a.re = -tau[i].re;
      b_a.im = -(-tau[i].im);
      xgerc_DoaMusicSignal(lastv, lastc, b_a, jy, work, a, knt);
    }

    a[(i + (i << 2)) + 1] = alpha1;
  }
}

/*
 * Arguments    : int m
 *                int n
 *                const creal_T alpha1
 *                int ix0
 *                const creal_T y[4]
 *                creal_T A[16]
 *                int ia0
 * Return Type  : void
 */
static void xgerc_DoaMusicSignal(int m, int n, const creal_T alpha1, int ix0,
  const creal_T y[4], creal_T A[16], int ia0)
{
  int jA;
  int jy;
  int j;
  double temp_re;
  double temp_im;
  int ix;
  int i10;
  int ijA;
  double A_im;
  if (!((alpha1.re == 0.0) && (alpha1.im == 0.0))) {
    jA = ia0 - 1;
    jy = 0;
    for (j = 1; j <= n; j++) {
      if ((y[jy].re != 0.0) || (y[jy].im != 0.0)) {
        temp_re = y[jy].re * alpha1.re + y[jy].im * alpha1.im;
        temp_im = y[jy].re * alpha1.im - y[jy].im * alpha1.re;
        ix = ix0;
        i10 = m + jA;
        for (ijA = jA; ijA + 1 <= i10; ijA++) {
          A_im = A[ix - 1].re * temp_im + A[ix - 1].im * temp_re;
          A[ijA].re += A[ix - 1].re * temp_re - A[ix - 1].im * temp_im;
          A[ijA].im += A_im;
          ix++;
        }
      }

      jy++;
      jA += 4;
    }
  }
}

/*
 * Arguments    : int n
 *                const creal_T x[16]
 *                int ix0
 * Return Type  : double
 */
static double xnrm2_DoaMusicSignal(int n, const creal_T x[16], int ix0)
{
  double y;
  double scale;
  int k;
  double absxk;
  double t;
  y = 0.0;
  if (!(n < 1)) {
    if (n == 1) {
      y = rt_hypotd_snf_DoaMusicSignal(x[ix0 - 1].re, x[ix0 - 1].im);
    } else {
      scale = 2.2250738585072014E-308;
      for (k = ix0; k <= ix0 + 1; k++) {
        absxk = fabs(x[k - 1].re);
        if (absxk > scale) {
          t = scale / absxk;
          y = 1.0 + y * t * t;
          scale = absxk;
        } else {
          t = absxk / scale;
          y += t * t;
        }

        absxk = fabs(x[k - 1].im);
        if (absxk > scale) {
          t = scale / absxk;
          y = 1.0 + y * t * t;
          scale = absxk;
        } else {
          t = absxk / scale;
          y += t * t;
        }
      }

      y = scale * sqrt(y);
    }
  }

  return y;
}

/*
 * Arguments    : int n
 *                const creal_T a
 *                creal_T x[16]
 *                int ix0
 * Return Type  : void
 */
static void xscal_DoaMusicSignal(int n, const creal_T a, creal_T x[16], int ix0)
{
  int i9;
  int k;
  double x_re;
  double x_im;
  i9 = (ix0 + n) - 1;
  for (k = ix0; k <= i9; k++) {
    x_re = x[k - 1].re;
    x_im = x[k - 1].im;
    x[k - 1].re = a.re * x_re - a.im * x_im;
    x[k - 1].im = a.re * x_im + a.im * x_re;
  }
}

/*
 * Arguments    : creal_T A[16]
 *                int *info
 *                creal_T alpha1[4]
 *                creal_T beta1[4]
 *                creal_T V[16]
 * Return Type  : void
 */
static void xzggev_DoaMusicSignal(creal_T A[16], int *info, creal_T alpha1[4],
  creal_T beta1[4], creal_T V[16])
{
  double anrm;
  int nzcount;
  boolean_T exitg1;
  double absxk;
  boolean_T ilascl;
  int i;
  double anrmto;
  int ilo;
  int rscale[4];
  int ihi;
  int exitg3;
  int j;
  boolean_T found;
  int ii;
  int jj;
  creal_T atmp;
  boolean_T exitg4;
  int exitg2;
  signed char I[16];
  double mul;
  double stemp_re;
  double cto1;
  double stemp_im;
  *info = 0;
  anrm = 0.0;
  nzcount = 0;
  exitg1 = false;
  while ((!exitg1) && (nzcount < 16)) {
    absxk = rt_hypotd_snf_DoaMusicSignal(A[nzcount].re, A[nzcount].im);
    if (rtIsNaN(absxk)) {
      anrm = rtNaN;
      exitg1 = true;
    } else {
      if (absxk > anrm) {
        anrm = absxk;
      }

      nzcount++;
    }
  }

  if (!((!rtIsInf(anrm)) && (!rtIsNaN(anrm)))) {
    for (i = 0; i < 4; i++) {
      alpha1[i].re = rtNaN;
      alpha1[i].im = 0.0;
      beta1[i].re = rtNaN;
      beta1[i].im = 0.0;
    }

    for (nzcount = 0; nzcount < 16; nzcount++) {
      V[nzcount].re = rtNaN;
      V[nzcount].im = 0.0;
    }
  } else {
    ilascl = false;
    anrmto = anrm;
    if ((anrm > 0.0) && (anrm < 6.7178761075670888E-139)) {
      anrmto = 6.7178761075670888E-139;
      ilascl = true;
    } else {
      if (anrm > 1.4885657073574029E+138) {
        anrmto = 1.4885657073574029E+138;
        ilascl = true;
      }
    }

    if (ilascl) {
      xzlascl_DoaMusicSignal(anrm, anrmto, A);
    }

    for (i = 0; i < 4; i++) {
      rscale[i] = 1;
    }

    ilo = 0;
    ihi = 4;
    do {
      exitg3 = 0;
      i = 0;
      j = 0;
      found = false;
      ii = ihi;
      exitg1 = false;
      while ((!exitg1) && (ii > 0)) {
        nzcount = 0;
        i = ii;
        j = ihi;
        jj = 1;
        exitg4 = false;
        while ((!exitg4) && (jj <= ihi)) {
          if ((A[(ii + ((jj - 1) << 2)) - 1].re != 0.0) || (A[(ii + ((jj - 1) <<
                 2)) - 1].im != 0.0) || (ii == jj)) {
            if (nzcount == 0) {
              j = jj;
              nzcount = 1;
              jj++;
            } else {
              nzcount = 2;
              exitg4 = true;
            }
          } else {
            jj++;
          }
        }

        if (nzcount < 2) {
          found = true;
          exitg1 = true;
        } else {
          ii--;
        }
      }

      if (!found) {
        exitg3 = 2;
      } else {
        if (i != ihi) {
          for (nzcount = 0; nzcount < 4; nzcount++) {
            atmp = A[(i + (nzcount << 2)) - 1];
            A[(i + (nzcount << 2)) - 1] = A[(ihi + (nzcount << 2)) - 1];
            A[(ihi + (nzcount << 2)) - 1] = atmp;
          }
        }

        if (j != ihi) {
          for (nzcount = 0; nzcount + 1 <= ihi; nzcount++) {
            atmp = A[nzcount + ((j - 1) << 2)];
            A[nzcount + ((j - 1) << 2)] = A[nzcount + ((ihi - 1) << 2)];
            A[nzcount + ((ihi - 1) << 2)] = atmp;
          }
        }

        rscale[ihi - 1] = j;
        ihi--;
        if (ihi == 1) {
          rscale[0] = 1;
          exitg3 = 1;
        }
      }
    } while (exitg3 == 0);

    if (exitg3 == 1) {
    } else {
      do {
        exitg2 = 0;
        i = 0;
        j = 0;
        found = false;
        jj = ilo + 1;
        exitg1 = false;
        while ((!exitg1) && (jj <= ihi)) {
          nzcount = 0;
          i = ihi;
          j = jj;
          ii = ilo + 1;
          exitg4 = false;
          while ((!exitg4) && (ii <= ihi)) {
            if ((A[(ii + ((jj - 1) << 2)) - 1].re != 0.0) || (A[(ii + ((jj - 1) <<
                   2)) - 1].im != 0.0) || (ii == jj)) {
              if (nzcount == 0) {
                i = ii;
                nzcount = 1;
                ii++;
              } else {
                nzcount = 2;
                exitg4 = true;
              }
            } else {
              ii++;
            }
          }

          if (nzcount < 2) {
            found = true;
            exitg1 = true;
          } else {
            jj++;
          }
        }

        if (!found) {
          exitg2 = 1;
        } else {
          if (i != ilo + 1) {
            for (nzcount = ilo; nzcount + 1 < 5; nzcount++) {
              atmp = A[(i + (nzcount << 2)) - 1];
              A[(i + (nzcount << 2)) - 1] = A[ilo + (nzcount << 2)];
              A[ilo + (nzcount << 2)] = atmp;
            }
          }

          if (j != ilo + 1) {
            for (nzcount = 0; nzcount + 1 <= ihi; nzcount++) {
              atmp = A[nzcount + ((j - 1) << 2)];
              A[nzcount + ((j - 1) << 2)] = A[nzcount + (ilo << 2)];
              A[nzcount + (ilo << 2)] = atmp;
            }
          }

          rscale[ilo] = j;
          ilo++;
          if (ilo + 1 == ihi) {
            rscale[ilo] = ilo + 1;
            exitg2 = 1;
          }
        }
      } while (exitg2 == 0);
    }

    for (nzcount = 0; nzcount < 16; nzcount++) {
      I[nzcount] = 0;
    }

    for (nzcount = 0; nzcount < 4; nzcount++) {
      I[nzcount + (nzcount << 2)] = 1;
    }

    for (nzcount = 0; nzcount < 16; nzcount++) {
      V[nzcount].re = I[nzcount];
      V[nzcount].im = 0.0;
    }

    if (!(ihi < ilo + 3)) {
      for (ii = ilo; ii + 1 < ihi - 1; ii++) {
        for (nzcount = ihi - 1; nzcount + 1 > ii + 2; nzcount--) {
          xzlartg_DoaMusicSignal(A[(nzcount + (ii << 2)) - 1], A[nzcount + (ii <<
            2)], &mul, &atmp, &A[(nzcount + (ii << 2)) - 1]);
          A[nzcount + (ii << 2)].re = 0.0;
          A[nzcount + (ii << 2)].im = 0.0;
          for (j = ii + 1; j + 1 < 5; j++) {
            stemp_re = mul * A[(nzcount + (j << 2)) - 1].re + (atmp.re *
              A[nzcount + (j << 2)].re - atmp.im * A[nzcount + (j << 2)].im);
            stemp_im = mul * A[(nzcount + (j << 2)) - 1].im + (atmp.re *
              A[nzcount + (j << 2)].im + atmp.im * A[nzcount + (j << 2)].re);
            absxk = A[(nzcount + (j << 2)) - 1].im;
            cto1 = A[(nzcount + (j << 2)) - 1].re;
            A[nzcount + (j << 2)].re = mul * A[nzcount + (j << 2)].re - (atmp.re
              * A[(nzcount + (j << 2)) - 1].re + atmp.im * A[(nzcount + (j << 2))
              - 1].im);
            A[nzcount + (j << 2)].im = mul * A[nzcount + (j << 2)].im - (atmp.re
              * absxk - atmp.im * cto1);
            A[(nzcount + (j << 2)) - 1].re = stemp_re;
            A[(nzcount + (j << 2)) - 1].im = stemp_im;
          }

          atmp.re = -atmp.re;
          atmp.im = -atmp.im;
          for (i = 0; i + 1 <= ihi; i++) {
            stemp_re = mul * A[i + (nzcount << 2)].re + (atmp.re * A[i +
              ((nzcount - 1) << 2)].re - atmp.im * A[i + ((nzcount - 1) << 2)].
              im);
            stemp_im = mul * A[i + (nzcount << 2)].im + (atmp.re * A[i +
              ((nzcount - 1) << 2)].im + atmp.im * A[i + ((nzcount - 1) << 2)].
              re);
            absxk = A[i + (nzcount << 2)].im;
            cto1 = A[i + (nzcount << 2)].re;
            A[i + ((nzcount - 1) << 2)].re = mul * A[i + ((nzcount - 1) << 2)].
              re - (atmp.re * A[i + (nzcount << 2)].re + atmp.im * A[i +
                    (nzcount << 2)].im);
            A[i + ((nzcount - 1) << 2)].im = mul * A[i + ((nzcount - 1) << 2)].
              im - (atmp.re * absxk - atmp.im * cto1);
            A[i + (nzcount << 2)].re = stemp_re;
            A[i + (nzcount << 2)].im = stemp_im;
          }

          for (i = 0; i < 4; i++) {
            stemp_re = mul * V[i + (nzcount << 2)].re + (atmp.re * V[i +
              ((nzcount - 1) << 2)].re - atmp.im * V[i + ((nzcount - 1) << 2)].
              im);
            stemp_im = mul * V[i + (nzcount << 2)].im + (atmp.re * V[i +
              ((nzcount - 1) << 2)].im + atmp.im * V[i + ((nzcount - 1) << 2)].
              re);
            absxk = V[i + (nzcount << 2)].re;
            V[i + ((nzcount - 1) << 2)].re = mul * V[i + ((nzcount - 1) << 2)].
              re - (atmp.re * V[i + (nzcount << 2)].re + atmp.im * V[i +
                    (nzcount << 2)].im);
            V[i + ((nzcount - 1) << 2)].im = mul * V[i + ((nzcount - 1) << 2)].
              im - (atmp.re * V[i + (nzcount << 2)].im - atmp.im * absxk);
            V[i + (nzcount << 2)].re = stemp_re;
            V[i + (nzcount << 2)].im = stemp_im;
          }
        }
      }
    }

    xzhgeqz_DoaMusicSignal(A, ilo + 1, ihi, V, info, alpha1, beta1);
    if (*info == 0) {
      xztgevc_DoaMusicSignal(A, V);
      if (ilo + 1 > 1) {
        for (i = ilo - 1; i + 1 >= 1; i--) {
          nzcount = rscale[i] - 1;
          if (rscale[i] != i + 1) {
            for (j = 0; j < 4; j++) {
              atmp = V[i + (j << 2)];
              V[i + (j << 2)] = V[nzcount + (j << 2)];
              V[nzcount + (j << 2)] = atmp;
            }
          }
        }
      }

      if (ihi < 4) {
        while (ihi + 1 < 5) {
          nzcount = rscale[ihi] - 1;
          if (rscale[ihi] != ihi + 1) {
            for (j = 0; j < 4; j++) {
              atmp = V[ihi + (j << 2)];
              V[ihi + (j << 2)] = V[nzcount + (j << 2)];
              V[nzcount + (j << 2)] = atmp;
            }
          }

          ihi++;
        }
      }

      for (nzcount = 0; nzcount < 4; nzcount++) {
        absxk = fabs(V[nzcount << 2].re) + fabs(V[nzcount << 2].im);
        for (ii = 0; ii < 3; ii++) {
          cto1 = fabs(V[(ii + (nzcount << 2)) + 1].re) + fabs(V[(ii + (nzcount <<
            2)) + 1].im);
          if (cto1 > absxk) {
            absxk = cto1;
          }
        }

        if (absxk >= 6.7178761075670888E-139) {
          absxk = 1.0 / absxk;
          for (ii = 0; ii < 4; ii++) {
            V[ii + (nzcount << 2)].re *= absxk;
            V[ii + (nzcount << 2)].im *= absxk;
          }
        }
      }

      if (ilascl) {
        ilascl = true;
        while (ilascl) {
          absxk = anrmto * 2.0041683600089728E-292;
          cto1 = anrm / 4.9896007738368E+291;
          if ((absxk > anrm) && (anrm != 0.0)) {
            mul = 2.0041683600089728E-292;
            anrmto = absxk;
          } else if (cto1 > anrmto) {
            mul = 4.9896007738368E+291;
            anrm = cto1;
          } else {
            mul = anrm / anrmto;
            ilascl = false;
          }

          for (nzcount = 0; nzcount < 4; nzcount++) {
            alpha1[nzcount].re *= mul;
            alpha1[nzcount].im *= mul;
          }
        }
      }
    }
  }
}

/*
 * Arguments    : creal_T A[16]
 *                int ilo
 *                int ihi
 *                creal_T Z[16]
 *                int *info
 *                creal_T alpha1[4]
 *                creal_T beta1[4]
 * Return Type  : void
 */
static void xzhgeqz_DoaMusicSignal(creal_T A[16], int ilo, int ihi, creal_T Z[16],
  int *info, creal_T alpha1[4], creal_T beta1[4])
{
  int i;
  double eshift_re;
  double eshift_im;
  creal_T ctemp;
  double anorm;
  double scale;
  double reAij;
  double sumsq;
  double b_atol;
  boolean_T firstNonZero;
  int j;
  int jp1;
  double ascale;
  boolean_T failed;
  boolean_T guard1 = false;
  double imAij;
  boolean_T guard2 = false;
  int ifirst;
  int istart;
  int ilast;
  double temp2;
  int ilastm1;
  int iiter;
  boolean_T goto60;
  boolean_T goto70;
  boolean_T goto90;
  int jiter;
  int exitg1;
  boolean_T exitg2;
  creal_T b_ascale;
  creal_T shift;
  double ad22_re;
  double ad22_im;
  double t1_im;
  *info = 0;
  for (i = 0; i < 4; i++) {
    alpha1[i].re = 0.0;
    alpha1[i].im = 0.0;
    beta1[i].re = 1.0;
    beta1[i].im = 0.0;
  }

  eshift_re = 0.0;
  eshift_im = 0.0;
  ctemp.re = 0.0;
  ctemp.im = 0.0;
  anorm = 0.0;
  if (!(ilo > ihi)) {
    scale = 0.0;
    sumsq = 0.0;
    firstNonZero = true;
    for (j = ilo; j <= ihi; j++) {
      jp1 = j + 1;
      if (ihi < j + 1) {
        jp1 = ihi;
      }

      for (i = ilo; i <= jp1; i++) {
        reAij = A[(i + ((j - 1) << 2)) - 1].re;
        imAij = A[(i + ((j - 1) << 2)) - 1].im;
        if (reAij != 0.0) {
          anorm = fabs(reAij);
          if (firstNonZero) {
            sumsq = 1.0;
            scale = anorm;
            firstNonZero = false;
          } else if (scale < anorm) {
            temp2 = scale / anorm;
            sumsq = 1.0 + sumsq * temp2 * temp2;
            scale = anorm;
          } else {
            temp2 = anorm / scale;
            sumsq += temp2 * temp2;
          }
        }

        if (imAij != 0.0) {
          anorm = fabs(imAij);
          if (firstNonZero) {
            sumsq = 1.0;
            scale = anorm;
            firstNonZero = false;
          } else if (scale < anorm) {
            temp2 = scale / anorm;
            sumsq = 1.0 + sumsq * temp2 * temp2;
            scale = anorm;
          } else {
            temp2 = anorm / scale;
            sumsq += temp2 * temp2;
          }
        }
      }
    }

    anorm = scale * sqrt(sumsq);
  }

  reAij = 2.2204460492503131E-16 * anorm;
  b_atol = 2.2250738585072014E-308;
  if (reAij > 2.2250738585072014E-308) {
    b_atol = reAij;
  }

  reAij = 2.2250738585072014E-308;
  if (anorm > 2.2250738585072014E-308) {
    reAij = anorm;
  }

  ascale = 1.0 / reAij;
  failed = true;
  for (j = ihi; j + 1 < 5; j++) {
    alpha1[j] = A[j + (j << 2)];
  }

  guard1 = false;
  guard2 = false;
  if (ihi >= ilo) {
    ifirst = ilo;
    istart = ilo;
    ilast = ihi - 1;
    ilastm1 = ihi - 2;
    iiter = 0;
    goto60 = false;
    goto70 = false;
    goto90 = false;
    jiter = 1;
    do {
      exitg1 = 0;
      if (jiter <= 30 * ((ihi - ilo) + 1)) {
        if (ilast + 1 == ilo) {
          goto60 = true;
        } else if (fabs(A[ilast + (ilastm1 << 2)].re) + fabs(A[ilast + (ilastm1 <<
          2)].im) <= b_atol) {
          A[ilast + (ilastm1 << 2)].re = 0.0;
          A[ilast + (ilastm1 << 2)].im = 0.0;
          goto60 = true;
        } else {
          j = ilastm1;
          exitg2 = false;
          while ((!exitg2) && (j + 1 >= ilo)) {
            if (j + 1 == ilo) {
              firstNonZero = true;
            } else if (fabs(A[j + ((j - 1) << 2)].re) + fabs(A[j + ((j - 1) << 2)]
                        .im) <= b_atol) {
              A[j + ((j - 1) << 2)].re = 0.0;
              A[j + ((j - 1) << 2)].im = 0.0;
              firstNonZero = true;
            } else {
              firstNonZero = false;
            }

            if (firstNonZero) {
              ifirst = j + 1;
              goto70 = true;
              exitg2 = true;
            } else {
              j--;
            }
          }
        }

        if (goto60 || goto70) {
          firstNonZero = true;
        } else {
          firstNonZero = false;
        }

        if (!firstNonZero) {
          for (i = 0; i < 4; i++) {
            alpha1[i].re = rtNaN;
            alpha1[i].im = 0.0;
            beta1[i].re = rtNaN;
            beta1[i].im = 0.0;
          }

          for (jp1 = 0; jp1 < 16; jp1++) {
            Z[jp1].re = rtNaN;
            Z[jp1].im = 0.0;
          }

          *info = 1;
          exitg1 = 1;
        } else if (goto60) {
          goto60 = false;
          alpha1[ilast] = A[ilast + (ilast << 2)];
          ilast = ilastm1;
          ilastm1--;
          if (ilast + 1 < ilo) {
            failed = false;
            guard2 = true;
            exitg1 = 1;
          } else {
            iiter = 0;
            eshift_re = 0.0;
            eshift_im = 0.0;
            jiter++;
          }
        } else {
          if (goto70) {
            goto70 = false;
            iiter++;
            if (iiter - iiter / 10 * 10 != 0) {
              anorm = ascale * A[ilastm1 + (ilastm1 << 2)].re;
              reAij = ascale * A[ilastm1 + (ilastm1 << 2)].im;
              if (reAij == 0.0) {
                shift.re = anorm / 0.5;
                shift.im = 0.0;
              } else if (anorm == 0.0) {
                shift.re = 0.0;
                shift.im = reAij / 0.5;
              } else {
                shift.re = anorm / 0.5;
                shift.im = reAij / 0.5;
              }

              anorm = ascale * A[ilast + (ilast << 2)].re;
              reAij = ascale * A[ilast + (ilast << 2)].im;
              if (reAij == 0.0) {
                ad22_re = anorm / 0.5;
                ad22_im = 0.0;
              } else if (anorm == 0.0) {
                ad22_re = 0.0;
                ad22_im = reAij / 0.5;
              } else {
                ad22_re = anorm / 0.5;
                ad22_im = reAij / 0.5;
              }

              temp2 = 0.5 * (shift.re + ad22_re);
              t1_im = 0.5 * (shift.im + ad22_im);
              anorm = ascale * A[ilastm1 + (ilast << 2)].re;
              reAij = ascale * A[ilastm1 + (ilast << 2)].im;
              if (reAij == 0.0) {
                sumsq = anorm / 0.5;
                imAij = 0.0;
              } else if (anorm == 0.0) {
                sumsq = 0.0;
                imAij = reAij / 0.5;
              } else {
                sumsq = anorm / 0.5;
                imAij = reAij / 0.5;
              }

              anorm = ascale * A[ilast + (ilastm1 << 2)].re;
              reAij = ascale * A[ilast + (ilastm1 << 2)].im;
              if (reAij == 0.0) {
                scale = anorm / 0.5;
                anorm = 0.0;
              } else if (anorm == 0.0) {
                scale = 0.0;
                anorm = reAij / 0.5;
              } else {
                scale = anorm / 0.5;
                anorm = reAij / 0.5;
              }

              reAij = shift.re * ad22_im + shift.im * ad22_re;
              shift.re = ((temp2 * temp2 - t1_im * t1_im) + (sumsq * scale -
                imAij * anorm)) - (shift.re * ad22_re - shift.im * ad22_im);
              shift.im = ((temp2 * t1_im + t1_im * temp2) + (sumsq * anorm +
                imAij * scale)) - reAij;
              sqrt_DoaMusicSignal(&shift);
              if ((temp2 - ad22_re) * shift.re + (t1_im - ad22_im) * shift.im <=
                  0.0) {
                shift.re += temp2;
                shift.im += t1_im;
              } else {
                shift.re = temp2 - shift.re;
                shift.im = t1_im - shift.im;
              }
            } else {
              anorm = ascale * A[ilast + (ilastm1 << 2)].re;
              reAij = ascale * A[ilast + (ilastm1 << 2)].im;
              if (reAij == 0.0) {
                sumsq = anorm / 0.5;
                imAij = 0.0;
              } else if (anorm == 0.0) {
                sumsq = 0.0;
                imAij = reAij / 0.5;
              } else {
                sumsq = anorm / 0.5;
                imAij = reAij / 0.5;
              }

              eshift_re += sumsq;
              eshift_im += imAij;
              shift.re = eshift_re;
              shift.im = eshift_im;
            }

            j = ilastm1;
            jp1 = ilastm1 + 1;
            exitg2 = false;
            while ((!exitg2) && (j + 1 > ifirst)) {
              istart = j + 1;
              ctemp.re = ascale * A[j + (j << 2)].re - shift.re * 0.5;
              ctemp.im = ascale * A[j + (j << 2)].im - shift.im * 0.5;
              anorm = fabs(ctemp.re) + fabs(ctemp.im);
              temp2 = ascale * (fabs(A[jp1 + (j << 2)].re) + fabs(A[jp1 + (j <<
                2)].im));
              reAij = anorm;
              if (temp2 > anorm) {
                reAij = temp2;
              }

              if ((reAij < 1.0) && (reAij != 0.0)) {
                anorm /= reAij;
                temp2 /= reAij;
              }

              if ((fabs(A[j + ((j - 1) << 2)].re) + fabs(A[j + ((j - 1) << 2)].
                    im)) * temp2 <= anorm * b_atol) {
                goto90 = true;
                exitg2 = true;
              } else {
                jp1 = j;
                j--;
              }
            }

            if (!goto90) {
              istart = ifirst;
              ctemp.re = ascale * A[(ifirst + ((ifirst - 1) << 2)) - 1].re -
                shift.re * 0.5;
              ctemp.im = ascale * A[(ifirst + ((ifirst - 1) << 2)) - 1].im -
                shift.im * 0.5;
              goto90 = true;
            }
          }

          if (goto90) {
            goto90 = false;
            b_ascale.re = ascale * A[istart + ((istart - 1) << 2)].re;
            b_ascale.im = ascale * A[istart + ((istart - 1) << 2)].im;
            b_xzlartg_DoaMusicSignal(ctemp, b_ascale, &scale, &shift);
            j = istart;
            jp1 = istart - 2;
            while (j < ilast + 1) {
              if (j > istart) {
                xzlartg_DoaMusicSignal(A[(j + (jp1 << 2)) - 1], A[j + (jp1 << 2)],
                  &scale, &shift, &A[(j + (jp1 << 2)) - 1]);
                A[j + (jp1 << 2)].re = 0.0;
                A[j + (jp1 << 2)].im = 0.0;
              }

              for (jp1 = j - 1; jp1 + 1 < 5; jp1++) {
                ad22_re = scale * A[(j + (jp1 << 2)) - 1].re + (shift.re * A[j +
                  (jp1 << 2)].re - shift.im * A[j + (jp1 << 2)].im);
                ad22_im = scale * A[(j + (jp1 << 2)) - 1].im + (shift.re * A[j +
                  (jp1 << 2)].im + shift.im * A[j + (jp1 << 2)].re);
                anorm = A[(j + (jp1 << 2)) - 1].im;
                reAij = A[(j + (jp1 << 2)) - 1].re;
                A[j + (jp1 << 2)].re = scale * A[j + (jp1 << 2)].re - (shift.re *
                  A[(j + (jp1 << 2)) - 1].re + shift.im * A[(j + (jp1 << 2)) - 1]
                  .im);
                A[j + (jp1 << 2)].im = scale * A[j + (jp1 << 2)].im - (shift.re *
                  anorm - shift.im * reAij);
                A[(j + (jp1 << 2)) - 1].re = ad22_re;
                A[(j + (jp1 << 2)) - 1].im = ad22_im;
              }

              shift.re = -shift.re;
              shift.im = -shift.im;
              jp1 = j;
              if (ilast + 1 < j + 2) {
                jp1 = ilast - 1;
              }

              for (i = 0; i + 1 <= jp1 + 2; i++) {
                ad22_re = scale * A[i + (j << 2)].re + (shift.re * A[i + ((j - 1)
                  << 2)].re - shift.im * A[i + ((j - 1) << 2)].im);
                ad22_im = scale * A[i + (j << 2)].im + (shift.re * A[i + ((j - 1)
                  << 2)].im + shift.im * A[i + ((j - 1) << 2)].re);
                anorm = A[i + (j << 2)].im;
                reAij = A[i + (j << 2)].re;
                A[i + ((j - 1) << 2)].re = scale * A[i + ((j - 1) << 2)].re -
                  (shift.re * A[i + (j << 2)].re + shift.im * A[i + (j << 2)].im);
                A[i + ((j - 1) << 2)].im = scale * A[i + ((j - 1) << 2)].im -
                  (shift.re * anorm - shift.im * reAij);
                A[i + (j << 2)].re = ad22_re;
                A[i + (j << 2)].im = ad22_im;
              }

              for (i = 0; i < 4; i++) {
                ad22_re = scale * Z[i + (j << 2)].re + (shift.re * Z[i + ((j - 1)
                  << 2)].re - shift.im * Z[i + ((j - 1) << 2)].im);
                ad22_im = scale * Z[i + (j << 2)].im + (shift.re * Z[i + ((j - 1)
                  << 2)].im + shift.im * Z[i + ((j - 1) << 2)].re);
                anorm = Z[i + (j << 2)].im;
                reAij = Z[i + (j << 2)].re;
                Z[i + ((j - 1) << 2)].re = scale * Z[i + ((j - 1) << 2)].re -
                  (shift.re * Z[i + (j << 2)].re + shift.im * Z[i + (j << 2)].im);
                Z[i + ((j - 1) << 2)].im = scale * Z[i + ((j - 1) << 2)].im -
                  (shift.re * anorm - shift.im * reAij);
                Z[i + (j << 2)].re = ad22_re;
                Z[i + (j << 2)].im = ad22_im;
              }

              jp1 = j - 1;
              j++;
            }
          }

          jiter++;
        }
      } else {
        guard2 = true;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  } else {
    guard1 = true;
  }

  if (guard2) {
    if (failed) {
      *info = ilast + 1;
      for (jp1 = 0; jp1 + 1 <= ilast + 1; jp1++) {
        alpha1[jp1].re = rtNaN;
        alpha1[jp1].im = 0.0;
        beta1[jp1].re = rtNaN;
        beta1[jp1].im = 0.0;
      }

      for (jp1 = 0; jp1 < 16; jp1++) {
        Z[jp1].re = rtNaN;
        Z[jp1].im = 0.0;
      }
    } else {
      guard1 = true;
    }
  }

  if (guard1) {
    for (j = 0; j + 1 < ilo; j++) {
      alpha1[j] = A[j + (j << 2)];
    }
  }
}

/*
 * Arguments    : creal_T *alpha1
 *                creal_T *x
 * Return Type  : creal_T
 */
static creal_T xzlarfg_DoaMusicSignal(creal_T *alpha1, creal_T *x)
{
  creal_T tau;
  double xnorm;
  double beta1;
  int knt;
  double ai;
  creal_T b_alpha1;
  double x_re;
  double x_im;
  int k;
  tau.re = 0.0;
  tau.im = 0.0;
  xnorm = rt_hypotd_snf_DoaMusicSignal(x->re, x->im);
  if ((xnorm != 0.0) || (alpha1->im != 0.0)) {
    beta1 = xdlapy3_DoaMusicSignal(alpha1->re, alpha1->im, xnorm);
    if (alpha1->re >= 0.0) {
      beta1 = -beta1;
    }

    if (fabs(beta1) < 1.0020841800044864E-292) {
      knt = 0;
      do {
        knt++;
        x->re *= 9.9792015476736E+291;
        x->im *= 9.9792015476736E+291;
        beta1 *= 9.9792015476736E+291;
        alpha1->re *= 9.9792015476736E+291;
        alpha1->im *= 9.9792015476736E+291;
      } while (!(fabs(beta1) >= 1.0020841800044864E-292));

      beta1 = xdlapy3_DoaMusicSignal(alpha1->re, alpha1->im,
        rt_hypotd_snf_DoaMusicSignal(x->re, x->im));
      if (alpha1->re >= 0.0) {
        beta1 = -beta1;
      }

      xnorm = beta1 - alpha1->re;
      ai = 0.0 - alpha1->im;
      if (ai == 0.0) {
        tau.re = xnorm / beta1;
        tau.im = 0.0;
      } else if (xnorm == 0.0) {
        tau.re = 0.0;
        tau.im = ai / beta1;
      } else {
        tau.re = xnorm / beta1;
        tau.im = ai / beta1;
      }

      b_alpha1.re = alpha1->re - beta1;
      b_alpha1.im = alpha1->im;
      *alpha1 = recip_DoaMusicSignal(b_alpha1);
      xnorm = alpha1->re;
      ai = alpha1->im;
      x_re = x->re;
      x_im = x->im;
      x->re = xnorm * x_re - ai * x_im;
      x->im = xnorm * x_im + ai * x_re;
      for (k = 1; k <= knt; k++) {
        beta1 *= 1.0020841800044864E-292;
      }

      alpha1->re = beta1;
      alpha1->im = 0.0;
    } else {
      xnorm = beta1 - alpha1->re;
      ai = 0.0 - alpha1->im;
      if (ai == 0.0) {
        tau.re = xnorm / beta1;
        tau.im = 0.0;
      } else if (xnorm == 0.0) {
        tau.re = 0.0;
        tau.im = ai / beta1;
      } else {
        tau.re = xnorm / beta1;
        tau.im = ai / beta1;
      }

      b_alpha1.re = alpha1->re - beta1;
      b_alpha1.im = alpha1->im;
      *alpha1 = recip_DoaMusicSignal(b_alpha1);
      xnorm = alpha1->re;
      ai = alpha1->im;
      x_re = x->re;
      x_im = x->im;
      x->re = xnorm * x_re - ai * x_im;
      x->im = xnorm * x_im + ai * x_re;
      alpha1->re = beta1;
      alpha1->im = 0.0;
    }
  }

  return tau;
}

/*
 * Arguments    : const creal_T f
 *                const creal_T g
 *                double *cs
 *                creal_T *sn
 *                creal_T *r
 * Return Type  : void
 */
static void xzlartg_DoaMusicSignal(const creal_T f, const creal_T g, double *cs,
  creal_T *sn, creal_T *r)
{
  double scale;
  double f2s;
  double x;
  double fs_re;
  double fs_im;
  double gs_re;
  double gs_im;
  int count;
  int rescaledir;
  boolean_T guard1 = false;
  double g2;
  double g2s;
  scale = fabs(f.re);
  f2s = fabs(f.im);
  if (f2s > scale) {
    scale = f2s;
  }

  x = fabs(g.re);
  f2s = fabs(g.im);
  if (f2s > x) {
    x = f2s;
  }

  if (x > scale) {
    scale = x;
  }

  fs_re = f.re;
  fs_im = f.im;
  gs_re = g.re;
  gs_im = g.im;
  count = 0;
  rescaledir = 0;
  guard1 = false;
  if (scale >= 7.4428285367870146E+137) {
    do {
      count++;
      fs_re *= 1.3435752215134178E-138;
      fs_im *= 1.3435752215134178E-138;
      gs_re *= 1.3435752215134178E-138;
      gs_im *= 1.3435752215134178E-138;
      scale *= 1.3435752215134178E-138;
    } while (!(scale < 7.4428285367870146E+137));

    rescaledir = 1;
    guard1 = true;
  } else if (scale <= 1.3435752215134178E-138) {
    if ((g.re == 0.0) && (g.im == 0.0)) {
      *cs = 1.0;
      sn->re = 0.0;
      sn->im = 0.0;
      *r = f;
    } else {
      do {
        count++;
        fs_re *= 7.4428285367870146E+137;
        fs_im *= 7.4428285367870146E+137;
        gs_re *= 7.4428285367870146E+137;
        gs_im *= 7.4428285367870146E+137;
        scale *= 7.4428285367870146E+137;
      } while (!(scale > 1.3435752215134178E-138));

      rescaledir = -1;
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1) {
    scale = fs_re * fs_re + fs_im * fs_im;
    g2 = gs_re * gs_re + gs_im * gs_im;
    x = g2;
    if (1.0 > g2) {
      x = 1.0;
    }

    if (scale <= x * 2.0041683600089728E-292) {
      if ((f.re == 0.0) && (f.im == 0.0)) {
        *cs = 0.0;
        r->re = rt_hypotd_snf_DoaMusicSignal(g.re, g.im);
        r->im = 0.0;
        g2 = rt_hypotd_snf_DoaMusicSignal(gs_re, gs_im);
        sn->re = gs_re / g2;
        sn->im = -gs_im / g2;
      } else {
        g2s = sqrt(g2);
        *cs = rt_hypotd_snf_DoaMusicSignal(fs_re, fs_im) / g2s;
        x = fabs(f.re);
        f2s = fabs(f.im);
        if (f2s > x) {
          x = f2s;
        }

        if (x > 1.0) {
          g2 = rt_hypotd_snf_DoaMusicSignal(f.re, f.im);
          fs_re = f.re / g2;
          fs_im = f.im / g2;
        } else {
          scale = 7.4428285367870146E+137 * f.re;
          f2s = 7.4428285367870146E+137 * f.im;
          g2 = rt_hypotd_snf_DoaMusicSignal(scale, f2s);
          fs_re = scale / g2;
          fs_im = f2s / g2;
        }

        gs_re /= g2s;
        gs_im = -gs_im / g2s;
        sn->re = fs_re * gs_re - fs_im * gs_im;
        sn->im = fs_re * gs_im + fs_im * gs_re;
        r->re = *cs * f.re + (sn->re * g.re - sn->im * g.im);
        r->im = *cs * f.im + (sn->re * g.im + sn->im * g.re);
      }
    } else {
      f2s = sqrt(1.0 + g2 / scale);
      r->re = f2s * fs_re;
      r->im = f2s * fs_im;
      *cs = 1.0 / f2s;
      g2 += scale;
      scale = r->re / g2;
      f2s = r->im / g2;
      sn->re = scale * gs_re - f2s * -gs_im;
      sn->im = scale * -gs_im + f2s * gs_re;
      if (rescaledir > 0) {
        for (rescaledir = 1; rescaledir <= count; rescaledir++) {
          r->re *= 7.4428285367870146E+137;
          r->im *= 7.4428285367870146E+137;
        }
      } else {
        if (rescaledir < 0) {
          for (rescaledir = 1; rescaledir <= count; rescaledir++) {
            r->re *= 1.3435752215134178E-138;
            r->im *= 1.3435752215134178E-138;
          }
        }
      }
    }
  }
}

/*
 * Arguments    : double cfrom
 *                double cto
 *                creal_T A[16]
 * Return Type  : void
 */
static void xzlascl_DoaMusicSignal(double cfrom, double cto, creal_T A[16])
{
  double cfromc;
  double ctoc;
  boolean_T notdone;
  double cfrom1;
  double cto1;
  double mul;
  int i12;
  cfromc = cfrom;
  ctoc = cto;
  notdone = true;
  while (notdone) {
    cfrom1 = cfromc * 2.0041683600089728E-292;
    cto1 = ctoc / 4.9896007738368E+291;
    if ((fabs(cfrom1) > fabs(ctoc)) && (ctoc != 0.0)) {
      mul = 2.0041683600089728E-292;
      cfromc = cfrom1;
    } else if (fabs(cto1) > fabs(cfromc)) {
      mul = 4.9896007738368E+291;
      ctoc = cto1;
    } else {
      mul = ctoc / cfromc;
      notdone = false;
    }

    for (i12 = 0; i12 < 16; i12++) {
      A[i12].re *= mul;
      A[i12].im *= mul;
    }
  }
}

/*
 * Arguments    : const creal_T A[16]
 *                creal_T V[16]
 * Return Type  : void
 */
static void xztgevc_DoaMusicSignal(const creal_T A[16], creal_T V[16])
{
  int i;
  double anorm;
  double rworka[4];
  int j;
  double xmx;
  double ascale;
  double d_re;
  int je;
  double temp;
  double salpha_re;
  double salpha_im;
  double acoeff;
  boolean_T lscalea;
  boolean_T lscaleb;
  double scale;
  double acoefa;
  int jr;
  creal_T work1[4];
  double dmin;
  int b_j;
  creal_T work2[4];
  double d_im;
  double work1_re;
  for (i = 0; i < 4; i++) {
    rworka[i] = 0.0;
  }

  anorm = fabs(A[0].re) + fabs(A[0].im);
  for (j = 0; j < 3; j++) {
    for (i = 0; i <= j; i++) {
      rworka[j + 1] += fabs(A[i + ((j + 1) << 2)].re) + fabs(A[i + ((j + 1) << 2)]
        .im);
    }

    d_re = rworka[j + 1] + (fabs(A[(j + ((j + 1) << 2)) + 1].re) + fabs(A[(j +
      ((j + 1) << 2)) + 1].im));
    if (d_re > anorm) {
      anorm = d_re;
    }
  }

  xmx = anorm;
  if (2.2250738585072014E-308 > anorm) {
    xmx = 2.2250738585072014E-308;
  }

  ascale = 1.0 / xmx;
  for (je = 0; je < 4; je++) {
    xmx = (fabs(A[(((3 - je) << 2) - je) + 3].re) + fabs(A[(((3 - je) << 2) - je)
            + 3].im)) * ascale;
    if (1.0 > xmx) {
      xmx = 1.0;
    }

    temp = 1.0 / xmx;
    salpha_re = ascale * (temp * A[(((3 - je) << 2) - je) + 3].re);
    salpha_im = ascale * (temp * A[(((3 - je) << 2) - je) + 3].im);
    acoeff = temp * ascale;
    if ((fabs(temp) >= 2.2250738585072014E-308) && (fabs(acoeff) <
         4.0083367200179456E-292)) {
      lscalea = true;
    } else {
      lscalea = false;
    }

    if ((fabs(salpha_re) + fabs(salpha_im) >= 2.2250738585072014E-308) && (fabs
         (salpha_re) + fabs(salpha_im) < 4.0083367200179456E-292)) {
      lscaleb = true;
    } else {
      lscaleb = false;
    }

    scale = 1.0;
    if (lscalea) {
      xmx = anorm;
      if (2.4948003869184E+291 < anorm) {
        xmx = 2.4948003869184E+291;
      }

      scale = 4.0083367200179456E-292 / fabs(temp) * xmx;
    }

    if (lscaleb) {
      d_re = 4.0083367200179456E-292 / (fabs(salpha_re) + fabs(salpha_im));
      if (d_re > scale) {
        scale = d_re;
      }
    }

    if (lscalea || lscaleb) {
      xmx = fabs(acoeff);
      d_re = fabs(salpha_re) + fabs(salpha_im);
      if (1.0 > xmx) {
        xmx = 1.0;
      }

      if (d_re > xmx) {
        xmx = d_re;
      }

      d_re = 1.0 / (2.2250738585072014E-308 * xmx);
      if (d_re < scale) {
        scale = d_re;
      }

      if (lscalea) {
        acoeff = ascale * (scale * temp);
      } else {
        acoeff *= scale;
      }

      salpha_re *= scale;
      salpha_im *= scale;
    }

    acoefa = fabs(acoeff);
    for (jr = 0; jr < 4; jr++) {
      work1[jr].re = 0.0;
      work1[jr].im = 0.0;
    }

    work1[3 - je].re = 1.0;
    work1[3 - je].im = 0.0;
    dmin = 2.2204460492503131E-16 * acoefa * anorm;
    d_re = 2.2204460492503131E-16 * (fabs(salpha_re) + fabs(salpha_im));
    if (d_re > dmin) {
      dmin = d_re;
    }

    if (2.2250738585072014E-308 > dmin) {
      dmin = 2.2250738585072014E-308;
    }

    for (jr = 0; jr <= 2 - je; jr++) {
      work1[jr].re = acoeff * A[jr + ((3 - je) << 2)].re;
      work1[jr].im = acoeff * A[jr + ((3 - je) << 2)].im;
    }

    work1[3 - je].re = 1.0;
    work1[3 - je].im = 0.0;
    i = (int)((1.0 + (-1.0 - ((4.0 + -(double)je) - 1.0))) / -1.0);
    for (j = 0; j < i; j++) {
      b_j = 2 - (je + j);
      d_re = acoeff * A[b_j + (b_j << 2)].re - salpha_re;
      d_im = acoeff * A[b_j + (b_j << 2)].im - salpha_im;
      if (fabs(d_re) + fabs(d_im) <= dmin) {
        d_re = dmin;
        d_im = 0.0;
      }

      if ((fabs(d_re) + fabs(d_im) < 1.0) && (fabs(work1[b_j].re) + fabs
           (work1[b_j].im) >= 1.1235582092889474E+307 * (fabs(d_re) + fabs(d_im))))
      {
        temp = 1.0 / (fabs(work1[b_j].re) + fabs(work1[b_j].im));
        for (jr = 0; jr <= 3 - je; jr++) {
          work1[jr].re *= temp;
          work1[jr].im *= temp;
        }
      }

      work1_re = -work1[b_j].re;
      if (d_im == 0.0) {
        if (-work1[b_j].im == 0.0) {
          work1[b_j].re = -work1[b_j].re / d_re;
          work1[b_j].im = 0.0;
        } else if (-work1[b_j].re == 0.0) {
          work1[b_j].re = 0.0;
          work1[b_j].im = -work1[b_j].im / d_re;
        } else {
          work1[b_j].re = -work1[b_j].re / d_re;
          work1[b_j].im = -work1[b_j].im / d_re;
        }
      } else if (d_re == 0.0) {
        if (-work1[b_j].re == 0.0) {
          work1[b_j].re = -work1[b_j].im / d_im;
          work1[b_j].im = 0.0;
        } else if (-work1[b_j].im == 0.0) {
          work1[b_j].re = 0.0;
          work1[b_j].im = -(work1_re / d_im);
        } else {
          work1[b_j].re = -work1[b_j].im / d_im;
          work1[b_j].im = -(work1_re / d_im);
        }
      } else {
        temp = fabs(d_re);
        xmx = fabs(d_im);
        if (temp > xmx) {
          scale = d_im / d_re;
          xmx = d_re + scale * d_im;
          work1[b_j].re = (-work1[b_j].re + scale * -work1[b_j].im) / xmx;
          work1[b_j].im = (-work1[b_j].im - scale * work1_re) / xmx;
        } else if (xmx == temp) {
          if (d_re > 0.0) {
            scale = 0.5;
          } else {
            scale = -0.5;
          }

          if (d_im > 0.0) {
            xmx = 0.5;
          } else {
            xmx = -0.5;
          }

          work1[b_j].re = (-work1[b_j].re * scale + -work1[b_j].im * xmx) / temp;
          work1[b_j].im = (-work1[b_j].im * scale - work1_re * xmx) / temp;
        } else {
          scale = d_re / d_im;
          xmx = d_im + scale * d_re;
          work1[b_j].re = (scale * -work1[b_j].re + -work1[b_j].im) / xmx;
          work1[b_j].im = (scale * -work1[b_j].im - work1_re) / xmx;
        }
      }

      if (b_j + 1 > 1) {
        if (fabs(work1[b_j].re) + fabs(work1[b_j].im) > 1.0) {
          temp = 1.0 / (fabs(work1[b_j].re) + fabs(work1[b_j].im));
          if (acoefa * rworka[b_j] >= 1.1235582092889474E+307 * temp) {
            for (jr = 0; jr <= 3 - je; jr++) {
              work1[jr].re *= temp;
              work1[jr].im *= temp;
            }
          }
        }

        d_re = acoeff * work1[b_j].re;
        d_im = acoeff * work1[b_j].im;
        for (jr = 0; jr < b_j; jr++) {
          work1[jr].re += d_re * A[jr + (b_j << 2)].re - d_im * A[jr + (b_j << 2)]
            .im;
          work1[jr].im += d_re * A[jr + (b_j << 2)].im + d_im * A[jr + (b_j << 2)]
            .re;
        }
      }
    }

    for (jr = 0; jr < 4; jr++) {
      work2[jr].re = 0.0;
      work2[jr].im = 0.0;
    }

    for (i = 0; i <= 3 - je; i++) {
      for (jr = 0; jr < 4; jr++) {
        work2[jr].re += V[jr + (i << 2)].re * work1[i].re - V[jr + (i << 2)].im *
          work1[i].im;
        work2[jr].im += V[jr + (i << 2)].re * work1[i].im + V[jr + (i << 2)].im *
          work1[i].re;
      }
    }

    xmx = fabs(work2[0].re) + fabs(work2[0].im);
    for (jr = 0; jr < 3; jr++) {
      d_re = fabs(work2[jr + 1].re) + fabs(work2[jr + 1].im);
      if (d_re > xmx) {
        xmx = d_re;
      }
    }

    if (xmx > 2.2250738585072014E-308) {
      temp = 1.0 / xmx;
      for (jr = 0; jr < 4; jr++) {
        V[jr + ((3 - je) << 2)].re = temp * work2[jr].re;
        V[jr + ((3 - je) << 2)].im = temp * work2[jr].im;
      }
    } else {
      for (jr = 0; jr < 4; jr++) {
        V[jr + ((3 - je) << 2)].re = 0.0;
        V[jr + ((3 - je) << 2)].im = 0.0;
      }
    }
  }
}

/*
 * DOA estimation using MUSIC method. but filter only the signal.
 *  input:
 *     % recStvPartition, MxK complex, matrix of steering vectors, each column is one steering vector for a specific Azimuth angle. M is the number of channel. K is the number of azimuth scan angle.
 *     % rxSigNoise: NxM complex, N is the number of snapshots, M is the number of channel. each colum is one snapshot
 *     % AzimuthScanAngles: 1xK double, azimuth scan angle in degree, should be in assending order.
 *     % MaxNumSig: 1x1 double, the number of maximum signals in DOA search.
 *  output:
 *     % spatialSpectrum, 1xK double, it is a matrix representing the magnitude of the estimated spatial spectrum.
 *     % doas, 1xP double, the signal's direction of arrival (DOA) .
 *  2017-10-18 V1.0 Collus Wang and Wayne Zhang. inherited from old repo.
 * Arguments    : const creal_T recStvPartition[484]
 *                const creal_T rxSigNoise[2048]
 *                const double AzimuthScanAngles[121]
 *                double MaxNumSig
 *                double spatialSpectrum[121]
 *                double doas_data[]
 *                int doas_size[1]
 * Return Type  : void
 */
void DoaEstimatorMUSICSignalImplement(const creal_T recStvPartition[484], const
  creal_T rxSigNoise[2048], const double AzimuthScanAngles[121], double
  MaxNumSig, double spatialSpectrum[121], double doas_data[], int doas_size[1])
{
  int i0;
  creal_T Pxs[4];
  int i;
  static const creal_T b[512] = { { 0.597750197628676,/* re */
      -0.899287820462048               /* im */
    }, { 0.832619582099781,            /* re */
      -0.131116226113365               /* im */
    }, { 0.791277450536945,            /* re */
      0.870126619551477                /* im */
    }, { 0.00511199813821906,          /* re */
      0.812875746714423                /* im */
    }, { -0.798163847058874,           /* re */
      0.597925131295389                /* im */
    }, { -0.832866975663762,           /* re */
      0.838791622717269                /* im */
    }, { -0.586766442514103,           /* re */
      0.799582096855205                /* im */
    }, { -0.833370426379568,           /* re */
      -0.0146346813542591              /* im */
    }, { -0.818914680331913,           /* re */
      -0.792434692124505               /* im */
    }, { 0.0385749092847886,           /* re */
      -0.822980859313228               /* im */
    }, { 0.732202685437865,            /* re */
      -0.657215980004006               /* im */
    }, { 0.923622193220723,            /* re */
      -0.70099345133522                /* im */
    }, { 0.806820371797992,            /* re */
      -0.714344198108465               /* im */
    }, { -0.109820602127619,           /* re */
      -0.699557220994909               /* im */
    }, { -0.886386230493411,           /* re */
      -0.678510982596137               /* im */
    }, { -0.134397997564108,           /* re */
      -0.79501166923593                /* im */
    }, { 0.875863014400597,            /* re */
      -0.846858771129085               /* im */
    }, { 0.806596527013989,            /* re */
      0.0794641122889465               /* im */
    }, { 0.63222503187051,             /* re */
      0.9735628794035                  /* im */
    }, { 0.758091986539724,            /* re */
      -0.0024279704931971              /* im */
    }, { 0.649466857913873,            /* re */
      -1.00972746024489                /* im */
    }, { 0.780072996585994,            /* re */
      0.0146729892893962               /* im */
    }, { 0.88657895454894,             /* re */
      0.941910343383084                /* im */
    }, { -0.122462658277827,           /* re */
      0.110029687756464                /* im */
    }, { -0.949398457264446,           /* re */
      -0.855163324627926               /* im */
    }, { 0.00846865711721725,          /* re */
      -0.813260313752596               /* im */
    }, { 0.933265080733581,            /* re */
      -0.593814839863572               /* im */
    }, { 0.127440458315457,            /* re */
      -0.844338769244911               /* im */
    }, { -0.868352809497298,           /* re */
      -0.809490755568833               /* im */
    }, { -0.810260021395785,           /* re */
      0.0331278753277856               /* im */
    }, { -0.599168354605588,           /* re */
      0.737707031737225                /* im */
    }, { -0.838247501269642,           /* re */
      0.92116602231154                 /* im */
    }, { -0.801456028123654,           /* re */
      0.812228990335624                /* im */
    }, { 0.0181892026778493,           /* re */
      -0.117982423842039               /* im */
    }, { 0.790508039425551,            /* re */
      -0.899555635428278               /* im */
    }, { 0.820821416287692,            /* re */
      -0.108559853196637               /* im */
    }, { 0.6665229213582,              /* re */
      0.820436640360084                /* im */
    }, { 0.690938920087664,            /* re */
      0.901465701765124                /* im */
    }, { 0.722256991775696,            /* re */
      0.800254604492219                /* im */
    }, { 0.69956006510203,             /* re */
      -0.0765486180798176              /* im */
    }, { 0.65700200030132,             /* re */
      -0.967092004484677               /* im */
    }, { 0.827567025800378,            /* re */
      -0.0116597453063136              /* im */
    }, { 0.806727490498474,            /* re */
      0.968213386836347                /* im */
    }, { -0.0120666932797497,          /* re */
      0.0953131836281251               /* im */
    }, { -0.759048227460663,           /* re */
      -0.854771564796316               /* im */
    }, { -0.909834246311703,           /* re */
      -0.800809053434673               /* im */
    }, { -0.808331502893841,           /* re */
      -0.660959449088361               /* im */
    }, { 0.0996902644864311,           /* re */
      -0.720721359720704               /* im */
    }, { 0.949635363363849,            /* re */
      -0.717178160636984               /* im */
    }, { 0.0138969199672255,           /* re */
      -0.678862316188488               /* im */
    }, { -0.962342218189525,           /* re */
      -0.7212767877617                 /* im */
    }, { -0.106235036280923,           /* re */
      -0.710363646654112               /* im */
    }, { 0.863180354503709,            /* re */
      -0.64566636676589                /* im */
    }, { 0.796416658153411,            /* re */
      -0.833104261708592               /* im */
    }, { 0.654747571290877,            /* re */
      -0.798918407063083               /* im */
    }, { 0.732687940429815,            /* re */
      0.00477696231943516              /* im */
    }, { 0.700630933252572,            /* re */
      0.754427088881499                /* im */
    }, { 0.690988451307054,            /* re */
      0.925251582190004                /* im */
    }, { 0.731021341740936,            /* re */
      0.754276350143574                /* im */
    }, { 0.685667367539991,            /* re */
      0.00339781102125576              /* im */
    }, { 0.702592609812637,            /* re */
      -0.802593096957289               /* im */
    }, { 0.735115910923013,            /* re */
      -0.826265606137574               /* im */
    }, { 0.641047239274157,            /* re */
      -0.653105781391609               /* im */
    }, { 0.815528729836338,            /* re */
      -0.703449622244404               /* im */
    }, { 0.865591648333791,            /* re */
      -0.705284991785995               /* im */
    }, { -0.12849448441428,            /* re */
      -0.711742797952292               /* im */
    }, { -0.890215774119824,           /* re */
      -0.665483591373724               /* im */
    }, { -0.110045614756338,           /* re */
      -0.801678300081658               /* im */
    }, { 0.805970919406834,            /* re */
      -0.868023022098378               /* im */
    }, { 0.92649701669803,             /* re */
      0.116752916333887                /* im */
    }, { 0.740007653878974,            /* re */
      0.91557236888813                 /* im */
    }, { 0.0244712664854036,           /* re */
      0.0834060447578302               /* im */
    }, { -0.811357446922529,           /* re */
      -0.796911805903784               /* im */
    }, { -0.831856464403881,           /* re */
      -0.913241486641951               /* im */
    }, { -0.634018921859194,           /* re */
      -0.811687234321449               /* im */
    }, { -0.727398098085583,           /* re */
      0.106322678535725                /* im */
    }, { -0.70721164448495,            /* re */
      0.8978788216679                  /* im */
    }, { -0.685332331721207,           /* re */
      0.121261351185662                /* im */
    }, { -0.734444181609135,           /* re */
      -0.815593972765416               /* im */
    }, { -0.685034356805976,           /* re */
      -0.919423437878867               /* im */
    }, { -0.714746786872397,           /* re */
      -0.741071921347597               /* im */
    }, { -0.716658180777503,           /* re */
      -0.030039743816448               /* im */
    }, { -0.644199417713915,           /* re */
      0.813967869348111                /* im */
    }, { -0.826296847560404,           /* re */
      0.833470538950206                /* im */
    }, { -0.795389845875613,           /* re */
      0.633404271660588                /* im */
    }, { -0.00542826285000829,         /* re */
      0.728101773942665                /* im */
    }, { 0.794219764268299,            /* re */
      0.710151854309453                /* im */
    }, { 0.83595795128222,             /* re */
      0.680207863267152                /* im */
    }, { 0.605165417325606,            /* re */
      0.736145190298302                /* im */
    }, { 0.803830676594888,            /* re */
      0.68749052771516                 /* im */
    }, { 0.86371369489048,             /* re */
      0.699876373248363                /* im */
    }, { -0.112929867542636,           /* re */
      0.737252973013286                /* im */
    }, { -0.938129932169607,           /* re */
      0.640646661597657                /* im */
    }, { -0.0170473374245001,          /* re */
      0.812365842063228                /* im */
    }, { 0.997312615314229,            /* re */
      0.862319640022937                /* im */
    }, { 0.0214115322897759,           /* re */
      -0.117854110855414               /* im */
    }, { -1.018383984984,              /* re */
      -0.898872298858942               /* im */
    }, { 0.0053593917022003,           /* re */
      -0.105093171027573               /* im */
    }, { 1.00740022986943,             /* re */
      0.85020156971752                 /* im */
    }, { -0.0188745887383731,          /* re */
      0.817361800630935                /* im */
    }, { -0.989187017656964,           /* re */
      0.652336277460795                /* im */
    }, { 0.00278129610853988,          /* re */
      0.71382326231087                 /* im */
    }, { 0.955776450883752,            /* re */
      0.714746786872397                /* im */
    }, { 0.100100056566987,            /* re */
      0.688936187364462                /* im */
    }, { -0.876883099825346,           /* re */
      0.673513461269261                /* im */
    }, { -0.773324542966187,           /* re */
      0.811107937239366                /* im */
    }, { -0.668316811346884,           /* re */
      0.794445408278086                /* im */
    }, { -0.73300184234492,            /* re */
      0.0234013133867066               /* im */
    }, { -0.631377590566783,           /* re */
      -0.82074845173135                /* im */
    }, { -0.831173922450478,           /* re */
      -0.815221894433541               /* im */
    }, { -0.803154932905969,           /* re */
      -0.598951528440691               /* im */
    }, { 0.0131366463784466,           /* re */
      -0.832024879300903               /* im */
    }, { 0.735906180292048,            /* re */
      -0.79663105809838                /* im */
    }, { 0.943775820686637,            /* re */
      0.00357565522726951              /* im */
    }, { 0.749294515298662,            /* re */
      0.788056585726458                /* im */
    }, { -0.00499311446058607,         /* re */
      0.838639134820122                /* im */
    }, { -0.737779833102237,           /* re */
      0.6073510671459                  /* im */
    }, { -0.951975950336194,           /* re */
      0.797795809451591                /* im */
    }, { -0.743903130233326,           /* re */
      0.866499050982776                /* im */
    }, { 0.00808409007904414,          /* re */
      -0.11109679674804                /* im */
    }, { 0.751356220253577,            /* re */
      -0.942759888593662               /* im */
    }, { 0.926597129268668,            /* re */
      -0.0107652736169457              /* im */
    }, { 0.786153694798999,            /* re */
      0.993956883886621                /* im */
    }, { -0.0800989169982213,          /* re */
      0.0199940730564594               /* im */
    }, { -0.956933599651893,           /* re */
      -1.00757516353614                /* im */
    }, { -0.0228571919390786,          /* re */
      -0.00623148245630531             /* im */
    }, { 1.0235098446288,              /* re */
      1.01437950769088                 /* im */
    }, { -0.0138220324389705,          /* re */
      -0.0146135474505797              /* im */
    }, { -0.948995868500514,           /* re */
      -1.00749311116895                /* im */
    }, { -0.0990301034682904,          /* re */
      0.0265488867368607               /* im */
    }, { 0.843763707572375,            /* re */
      0.950566868122202                /* im */
    }, { 0.82028436135237,             /* re */
      0.0842004038765598               /* im */
    }, { 0.598789527613151,            /* re */
      -0.809326650834442               /* im */
    }, { 0.8316090708399,              /* re */
      -0.895787201244015               /* im */
    }, { 0.85294063985909,             /* re */
      -0.798692763053295               /* im */
    }, { -0.122003334977882,           /* re */
      0.0714394640487189               /* im */
    }, { -0.880625733534922,           /* re */
      0.956563930842221                /* im */
    }, { -0.133212004894899,           /* re */
      0.0305909317763828               /* im */
    }, { 0.864244621972332,            /* re */
      -1.02548949721652                /* im */
    }, { 0.821888525279268,            /* re */
      0.00893504692946981              /* im */
    }, { 0.582300157667146,            /* re */
      1.01044414992577                 /* im */
    }, { 0.853896916288968,            /* re */
      -0.0251626689263745              /* im */
    }, { 0.794635285871404,            /* re */
      -0.94034850194416                /* im */
    }, { -0.0211046968869782,          /* re */
      -0.0989706616294739              /* im */
    }, { -0.736784685161636,           /* re */
      0.855028550830224                /* im */
    }, { -0.934421552367619,           /* re */
      0.801324974466315                /* im */
    }, { -0.752787310069662,           /* re */
      0.643989460186091                /* im */
    }, { 0.00366633848891637,          /* re */
      0.743375482411386                /* im */
    }, { 0.795918669050615,            /* re */
      0.664397232883164                /* im */
    }, { 0.824842327423534,            /* re */
      0.771463074855881                /* im */
    }, { 0.649373976614355,            /* re */
      0.882904264654734                /* im */
    }, { 0.711742797952292,            /* re */
      -0.108393232274876               /* im */
    }, { 0.673491370247324,            /* re */
      -0.971918985597381               /* im */
    }, { 0.788213684396734,            /* re */
      0.0300991856552645               /* im */
    }, { 0.818160120327704,            /* re */
      0.935386747033754                /* im */
    }, { 0.0076489416896219,           /* re */
      0.103072148507813                /* im */
    }, { -0.823391794111192,           /* re */
      -0.796507113233001               /* im */
    }, { -0.795731272092887,           /* re */
      -0.931840481400356               /* im */
    }, { -0.656154558997593,           /* re */
      -0.738733428882527               /* im */
    }, { -0.730883070051205,           /* re */
      -0.0213114197191376              /* im */
    }, { -0.651734560101362,           /* re */
      0.751336140319071                /* im */
    }, { -0.801034066063392,           /* re */
      0.957087948474413                /* im */
    }, { -0.864162569605137,           /* re */
      0.723460426494562                /* im */
    }, { 0.110530294365149,            /* re */
      0.0179730505366983               /* im */
    }, { 0.904413680106844,            /* re */
      -0.750933551555139               /* im */
    }, { 0.104198699338206,            /* re */
      -0.951540801946772               /* im */
    }, { -0.85340244741292,            /* re */
      -0.718064647976684               /* im */
    }, { -0.8118217206156,             /* re */
      -0.0327433082896124              /* im */
    }, { -0.657193888982068,           /* re */
      0.805970919406834                /* im */
    }, { -0.713704378633237,           /* re */
      0.849194710231305                /* im */
    }, { -0.703004449578752,           /* re */
      0.570112967833708                /* im */
    }, { -0.704785258703641,           /* re */
      0.845656115907589                /* im */
    }, { -0.674249952426396,           /* re */
      0.807269339332069                /* im */
    }, { -0.794336193794834,           /* re */
      -0.03408178885597                /* im */
    }, { -0.847363492194718,           /* re */
      -0.724630508101876               /* im */
    }, { 0.0795024202240836,           /* re */
      -0.940535201278152               /* im */
    }, { 0.9673019620125,              /* re */
      -0.758846345222371               /* im */
    }, { 0.0053210837670631,           /* re */
      0.017019137008514                /* im */
    }, { -1.01942331496848,            /* re */
      0.746741207756127                /* im */
    }, { 0.022538083120169,            /* re */
      0.924307579281247                /* im */
    }, { 0.956130340392041,            /* re */
      0.787273066063239                /* im */
    }, { 0.0773742186213774,           /* re */
      -0.0808409007904413              /* im */
    }, { -0.799274400478222,           /* re */
      -0.953612892085396               /* im */
    }, { -0.902085192051443,           /* re */
      -0.0254817777452841              /* im */
    }, { -0.800513601613559,           /* re */
      1.03150469066323                 /* im */
    }, { 0.0791267136734779,           /* re */
      -0.0241432971789265              /* im */
    }, { 0.944131017064489,            /* re */
      -0.952858332081187               /* im */
    }, { 0.0396573326993212,           /* re */
      -0.0832464903483755              /* im */
    }, { -1.02348490714465,            /* re */
      0.791737247003344                /* im */
    }, { -0.00282244815079745,         /* re */
      0.918879316431239                /* im */
    }, { 1.03161050480192,             /* re */
      0.745619825404457                /* im */
    }, { -0.0457415341622837,          /* re */
      0.0253628940676512               /* im */
    }, { -0.945593851122181,           /* re */
      -0.796688172981428               /* im */
    }, { -0.0751535397817638,          /* re */
      -0.852401725420276               /* im */
    }, { 0.777823275621812,            /* re */
      -0.582879784004642               /* im */
    }, { 0.931155095339833,            /* re */
      -0.822564000720365               /* im */
    }, { 0.762426049910208,            /* re */
      -0.869677744836819               /* im */
    }, { -0.0140311180678146,          /* re */
      0.138768011910108                /* im */
    }, { -0.738483589943952,           /* re */
      0.877754643238441                /* im */
    }, { -0.939474108667022,           /* re */
      0.120626546476387                /* im */
    }, { -0.807389169203165,           /* re */
      -0.84180203101231                /* im */
    }, { 0.126620742887862,            /* re */
      -0.84370700554248                /* im */
    }, { 0.878690262991077,            /* re */
      -0.594042494960791               /* im */
    }, { 0.128910292875284,            /* re */
      -0.815281336272357               /* im */
    }, { -0.806149968067829,           /* re */
      -0.86879051494176                /* im */
    }, { -0.943516153706544,           /* re */
      0.131941826654925                /* im */
    }, { -0.727723467751735,           /* re */
      0.940386372267482                /* im */
    }, { -0.0271083226074448,          /* re */
      -0.00489300188994777             /* im */
    }, { 0.755727519894165,            /* re */
      -0.937340348304288               /* im */
    }, { 0.952375831797323,            /* re */
      -0.126582434952725               /* im */
    }, { 0.720213262848436,            /* re */
      0.859273616059743                /* im */
    }, { 0.0288696781471126,           /* re */
      0.823881347383043                /* im */
    }, { -0.789753479421342,           /* re */
      0.594299480994699                /* im */
    }, { -0.86894740610423,            /* re */
      0.831965437462087                /* im */
    }, { -0.576303094947128,           /* re */
      0.862213825884245                /* im */
    }, { -0.815556930252325,           /* re */
      -0.140154229720594               /* im */
    }, { -0.881001806884568,           /* re */
      -0.883460129220734               /* im */
    }, { 0.152718554235426,            /* re */
      -0.109579224944085               /* im */
    }, { 0.887450497962035,            /* re */
      0.795790423552113                /* im */
    }, { 0.0899949439681823,           /* re */
      0.942330161037335                /* im */
    }, { -0.790156068185274,           /* re */
      0.741684467639352                /* im */
    }, { -0.931214537178649,           /* re */
      0.00652945737153563              /* im */
    }, { -0.790969846979382,           /* re */
      -0.751511073985784               /* im */
    }, { 0.0941866327977319,           /* re */
      -0.940991680470977               /* im */
    }, { 0.894985640349482,            /* re */
      -0.785209257201472               /* im */
    }, { 0.137488973182566,            /* re */
      0.0927762400767222               /* im */
    }, { -0.87000753223574,            /* re */
      0.896996356503062                /* im */
    }, { -0.820818572180571,           /* re */
      0.135793075862162                /* im */
    }, { -0.602876057273472,           /* re */
      -0.882893435722411               /* im */
    }, { -0.822254802520882,           /* re */
      -0.797667496464966               /* im */
    }, { -0.848712529643608,           /* re */
      -0.648759326415749               /* im */
    }, { 0.109519783105269,            /* re */
      -0.740168467222415               /* im */
    }, { 0.951666159451935,            /* re */
      -0.64711753651648                /* im */
    }, { -0.00177362895577977,         /* re */
      -0.798278126263717               /* im */
    }, { -0.965105483259884,           /* re */
      -0.820805566614397               /* im */
    }, { -0.0879144796096048,          /* re */
      0.00786793793789321              /* im */
    }, { 0.81396585826068,             /* re */
      0.811733520272174                /* im */
    }, { 0.891229235172851,            /* re */
      0.795872536705783                /* im */
    }, { 0.818253001627222,            /* re */
      0.665921203998767                /* im */
    }, { -0.0937867513366027,          /* re */
      0.716619872842366                /* im */
    }, { -0.923498095394534,           /* re */
      0.656400282941886                /* im */
    }, { -0.0963742762392546,          /* re */
      0.811239291232835                /* im */
    }, { 0.820036062683584,            /* re */
      0.818432050288217                /* im */
    }, { 0.888254299124905,            /* re */
      -0.0156423485070192              /* im */
    }, { 0.813695939387598,            /* re */
      -0.766691195074232               /* im */
    }, { -0.0845578206306066,          /* re */
      -0.896397831042766               /* im */
    }, { -0.969569664199989,           /* re */
      -0.813563176677329               /* im */
    }, { 0.00270356447316448,          /* re */
      0.094034144900584                /* im */
    }, { 0.956815780868228,            /* re */
      0.964870588247913                /* im */
    }, { 0.099089545307107,            /* re */
      -0.005462348379959               /* im */
    }, { -0.815219910503201,           /* re */
      -0.965530163045753               /* im */
    }, { -0.900439876082288,           /* re */
      -0.0838158368383867              /* im */
    }, { -0.750778697822933,           /* re */
      0.800703479206876                /* im */
    }, { -0.033346871576057,           /* re */
      0.905057283992268                /* im */
    }, { 0.824146354115401,            /* re */
      0.808911129231337                /* im */
    }, { 0.820362092987746,            /* re */
      -0.0940935867394005              /* im */
    }, { 0.597750197628676,            /* re */
      -0.899287820462048               /* im */
    }, { 0.832619582099781,            /* re */
      -0.131116226113365               /* im */
    }, { 0.791277450536945,            /* re */
      0.870126619551477                /* im */
    }, { 0.00511199813821906,          /* re */
      0.812875746714423                /* im */
    }, { -0.798163847058874,           /* re */
      0.597925131295389                /* im */
    }, { -0.832866975663762,           /* re */
      0.838791622717269                /* im */
    }, { -0.586766442514103,           /* re */
      0.799582096855205                /* im */
    }, { -0.833370426379568,           /* re */
      -0.0146346813542591              /* im */
    }, { -0.818914680331913,           /* re */
      -0.792434692124505               /* im */
    }, { 0.0385749092847886,           /* re */
      -0.822980859313228               /* im */
    }, { 0.732202685437865,            /* re */
      -0.657215980004006               /* im */
    }, { 0.923622193220723,            /* re */
      -0.70099345133522                /* im */
    }, { 0.806820371797992,            /* re */
      -0.714344198108465               /* im */
    }, { -0.109820602127619,           /* re */
      -0.699557220994909               /* im */
    }, { -0.886386230493411,           /* re */
      -0.678510982596137               /* im */
    }, { -0.134397997564108,           /* re */
      -0.79501166923593                /* im */
    }, { 0.875863014400597,            /* re */
      -0.846858771129085               /* im */
    }, { 0.806596527013989,            /* re */
      0.0794641122889465               /* im */
    }, { 0.63222503187051,             /* re */
      0.9735628794035                  /* im */
    }, { 0.758091986539724,            /* re */
      -0.0024279704931971              /* im */
    }, { 0.649466857913873,            /* re */
      -1.00972746024489                /* im */
    }, { 0.780072996585994,            /* re */
      0.0146729892893962               /* im */
    }, { 0.88657895454894,             /* re */
      0.941910343383084                /* im */
    }, { -0.122462658277827,           /* re */
      0.110029687756464                /* im */
    }, { -0.949398457264446,           /* re */
      -0.855163324627926               /* im */
    }, { 0.00846865711721725,          /* re */
      -0.813260313752596               /* im */
    }, { 0.933265080733581,            /* re */
      -0.593814839863572               /* im */
    }, { 0.127440458315457,            /* re */
      -0.844338769244911               /* im */
    }, { -0.868352809497298,           /* re */
      -0.809490755568833               /* im */
    }, { -0.810260021395785,           /* re */
      0.0331278753277856               /* im */
    }, { -0.599168354605588,           /* re */
      0.737707031737225                /* im */
    }, { -0.838247501269642,           /* re */
      0.92116602231154                 /* im */
    }, { -0.801456028123654,           /* re */
      0.812228990335624                /* im */
    }, { 0.0181892026778493,           /* re */
      -0.117982423842039               /* im */
    }, { 0.790508039425551,            /* re */
      -0.899555635428278               /* im */
    }, { 0.820821416287692,            /* re */
      -0.108559853196637               /* im */
    }, { 0.6665229213582,              /* re */
      0.820436640360084                /* im */
    }, { 0.690938920087664,            /* re */
      0.901465701765124                /* im */
    }, { 0.722256991775696,            /* re */
      0.800254604492219                /* im */
    }, { 0.69956006510203,             /* re */
      -0.0765486180798176              /* im */
    }, { 0.65700200030132,             /* re */
      -0.967092004484677               /* im */
    }, { 0.827567025800378,            /* re */
      -0.0116597453063136              /* im */
    }, { 0.806727490498474,            /* re */
      0.968213386836347                /* im */
    }, { -0.0120666932797497,          /* re */
      0.0953131836281251               /* im */
    }, { -0.759048227460663,           /* re */
      -0.854771564796316               /* im */
    }, { -0.909834246311703,           /* re */
      -0.800809053434673               /* im */
    }, { -0.808331502893841,           /* re */
      -0.660959449088361               /* im */
    }, { 0.0996902644864311,           /* re */
      -0.720721359720704               /* im */
    }, { 0.949635363363849,            /* re */
      -0.717178160636984               /* im */
    }, { 0.0138969199672255,           /* re */
      -0.678862316188488               /* im */
    }, { -0.962342218189525,           /* re */
      -0.7212767877617                 /* im */
    }, { -0.106235036280923,           /* re */
      -0.710363646654112               /* im */
    }, { 0.863180354503709,            /* re */
      -0.64566636676589                /* im */
    }, { 0.796416658153411,            /* re */
      -0.833104261708592               /* im */
    }, { 0.654747571290877,            /* re */
      -0.798918407063083               /* im */
    }, { 0.732687940429815,            /* re */
      0.00477696231943516              /* im */
    }, { 0.700630933252572,            /* re */
      0.754427088881499                /* im */
    }, { 0.690988451307054,            /* re */
      0.925251582190004                /* im */
    }, { 0.731021341740936,            /* re */
      0.754276350143574                /* im */
    }, { 0.685667367539991,            /* re */
      0.00339781102125576              /* im */
    }, { 0.702592609812637,            /* re */
      -0.802593096957289               /* im */
    }, { 0.735115910923013,            /* re */
      -0.826265606137574               /* im */
    }, { 0.641047239274157,            /* re */
      -0.653105781391609               /* im */
    }, { 0.815528729836338,            /* re */
      -0.703449622244404               /* im */
    }, { 0.865591648333791,            /* re */
      -0.705284991785995               /* im */
    }, { -0.12849448441428,            /* re */
      -0.711742797952292               /* im */
    }, { -0.890215774119824,           /* re */
      -0.665483591373724               /* im */
    }, { -0.110045614756338,           /* re */
      -0.801678300081658               /* im */
    }, { 0.805970919406834,            /* re */
      -0.868023022098378               /* im */
    }, { 0.92649701669803,             /* re */
      0.116752916333887                /* im */
    }, { 0.740007653878974,            /* re */
      0.91557236888813                 /* im */
    }, { 0.0244712664854036,           /* re */
      0.0834060447578302               /* im */
    }, { -0.811357446922529,           /* re */
      -0.796911805903784               /* im */
    }, { -0.831856464403881,           /* re */
      -0.913241486641951               /* im */
    }, { -0.634018921859194,           /* re */
      -0.811687234321449               /* im */
    }, { -0.727398098085583,           /* re */
      0.106322678535725                /* im */
    }, { -0.70721164448495,            /* re */
      0.8978788216679                  /* im */
    }, { -0.685332331721207,           /* re */
      0.121261351185662                /* im */
    }, { -0.734444181609135,           /* re */
      -0.815593972765416               /* im */
    }, { -0.685034356805976,           /* re */
      -0.919423437878867               /* im */
    }, { -0.714746786872397,           /* re */
      -0.741071921347597               /* im */
    }, { -0.716658180777503,           /* re */
      -0.030039743816448               /* im */
    }, { -0.644199417713915,           /* re */
      0.813967869348111                /* im */
    }, { -0.826296847560404,           /* re */
      0.833470538950206                /* im */
    }, { -0.795389845875613,           /* re */
      0.633404271660588                /* im */
    }, { -0.00542826285000829,         /* re */
      0.728101773942665                /* im */
    }, { 0.794219764268299,            /* re */
      0.710151854309453                /* im */
    }, { 0.83595795128222,             /* re */
      0.680207863267152                /* im */
    }, { 0.605165417325606,            /* re */
      0.736145190298302                /* im */
    }, { 0.803830676594888,            /* re */
      0.68749052771516                 /* im */
    }, { 0.86371369489048,             /* re */
      0.699876373248363                /* im */
    }, { -0.112929867542636,           /* re */
      0.737252973013286                /* im */
    }, { -0.938129932169607,           /* re */
      0.640646661597657                /* im */
    }, { -0.0170473374245001,          /* re */
      0.812365842063228                /* im */
    }, { 0.997312615314229,            /* re */
      0.862319640022937                /* im */
    }, { 0.0214115322897759,           /* re */
      -0.117854110855414               /* im */
    }, { -1.018383984984,              /* re */
      -0.898872298858942               /* im */
    }, { 0.0053593917022003,           /* re */
      -0.105093171027573               /* im */
    }, { 1.00740022986943,             /* re */
      0.85020156971752                 /* im */
    }, { -0.0188745887383731,          /* re */
      0.817361800630935                /* im */
    }, { -0.989187017656964,           /* re */
      0.652336277460795                /* im */
    }, { 0.00278129610853988,          /* re */
      0.71382326231087                 /* im */
    }, { 0.955776450883752,            /* re */
      0.714746786872397                /* im */
    }, { 0.100100056566987,            /* re */
      0.688936187364462                /* im */
    }, { -0.876883099825346,           /* re */
      0.673513461269261                /* im */
    }, { -0.773324542966187,           /* re */
      0.811107937239366                /* im */
    }, { -0.668316811346884,           /* re */
      0.794445408278086                /* im */
    }, { -0.73300184234492,            /* re */
      0.0234013133867066               /* im */
    }, { -0.631377590566783,           /* re */
      -0.82074845173135                /* im */
    }, { -0.831173922450478,           /* re */
      -0.815221894433541               /* im */
    }, { -0.803154932905969,           /* re */
      -0.598951528440691               /* im */
    }, { 0.0131366463784466,           /* re */
      -0.832024879300903               /* im */
    }, { 0.735906180292048,            /* re */
      -0.79663105809838                /* im */
    }, { 0.943775820686637,            /* re */
      0.00357565522726951              /* im */
    }, { 0.749294515298662,            /* re */
      0.788056585726458                /* im */
    }, { -0.00499311446058607,         /* re */
      0.838639134820122                /* im */
    }, { -0.737779833102237,           /* re */
      0.6073510671459                  /* im */
    }, { -0.951975950336194,           /* re */
      0.797795809451591                /* im */
    }, { -0.743903130233326,           /* re */
      0.866499050982776                /* im */
    }, { 0.00808409007904414,          /* re */
      -0.11109679674804                /* im */
    }, { 0.751356220253577,            /* re */
      -0.942759888593662               /* im */
    }, { 0.926597129268668,            /* re */
      -0.0107652736169457              /* im */
    }, { 0.786153694798999,            /* re */
      0.993956883886621                /* im */
    }, { -0.0800989169982213,          /* re */
      0.0199940730564594               /* im */
    }, { -0.956933599651893,           /* re */
      -1.00757516353614                /* im */
    }, { -0.0228571919390786,          /* re */
      -0.00623148245630531             /* im */
    }, { 1.0235098446288,              /* re */
      1.01437950769088                 /* im */
    }, { -0.0138220324389705,          /* re */
      -0.0146135474505797              /* im */
    }, { -0.948995868500514,           /* re */
      -1.00749311116895                /* im */
    }, { -0.0990301034682904,          /* re */
      0.0265488867368607               /* im */
    }, { 0.843763707572375,            /* re */
      0.950566868122202                /* im */
    }, { 0.82028436135237,             /* re */
      0.0842004038765598               /* im */
    }, { 0.598789527613151,            /* re */
      -0.809326650834442               /* im */
    }, { 0.8316090708399,              /* re */
      -0.895787201244015               /* im */
    }, { 0.85294063985909,             /* re */
      -0.798692763053295               /* im */
    }, { -0.122003334977882,           /* re */
      0.0714394640487189               /* im */
    }, { -0.880625733534922,           /* re */
      0.956563930842221                /* im */
    }, { -0.133212004894899,           /* re */
      0.0305909317763828               /* im */
    }, { 0.864244621972332,            /* re */
      -1.02548949721652                /* im */
    }, { 0.821888525279268,            /* re */
      0.00893504692946981              /* im */
    }, { 0.582300157667146,            /* re */
      1.01044414992577                 /* im */
    }, { 0.853896916288968,            /* re */
      -0.0251626689263745              /* im */
    }, { 0.794635285871404,            /* re */
      -0.94034850194416                /* im */
    }, { -0.0211046968869782,          /* re */
      -0.0989706616294739              /* im */
    }, { -0.736784685161636,           /* re */
      0.855028550830224                /* im */
    }, { -0.934421552367619,           /* re */
      0.801324974466315                /* im */
    }, { -0.752787310069662,           /* re */
      0.643989460186091                /* im */
    }, { 0.00366633848891637,          /* re */
      0.743375482411386                /* im */
    }, { 0.795918669050615,            /* re */
      0.664397232883164                /* im */
    }, { 0.824842327423534,            /* re */
      0.771463074855881                /* im */
    }, { 0.649373976614355,            /* re */
      0.882904264654734                /* im */
    }, { 0.711742797952292,            /* re */
      -0.108393232274876               /* im */
    }, { 0.673491370247324,            /* re */
      -0.971918985597381               /* im */
    }, { 0.788213684396734,            /* re */
      0.0300991856552645               /* im */
    }, { 0.818160120327704,            /* re */
      0.935386747033754                /* im */
    }, { 0.0076489416896219,           /* re */
      0.103072148507813                /* im */
    }, { -0.823391794111192,           /* re */
      -0.796507113233001               /* im */
    }, { -0.795731272092887,           /* re */
      -0.931840481400356               /* im */
    }, { -0.656154558997593,           /* re */
      -0.738733428882527               /* im */
    }, { -0.730883070051205,           /* re */
      -0.0213114197191376              /* im */
    }, { -0.651734560101362,           /* re */
      0.751336140319071                /* im */
    }, { -0.801034066063392,           /* re */
      0.957087948474413                /* im */
    }, { -0.864162569605137,           /* re */
      0.723460426494562                /* im */
    }, { 0.110530294365149,            /* re */
      0.0179730505366983               /* im */
    }, { 0.904413680106844,            /* re */
      -0.750933551555139               /* im */
    }, { 0.104198699338206,            /* re */
      -0.951540801946772               /* im */
    }, { -0.85340244741292,            /* re */
      -0.718064647976684               /* im */
    }, { -0.8118217206156,             /* re */
      -0.0327433082896124              /* im */
    }, { -0.657193888982068,           /* re */
      0.805970919406834                /* im */
    }, { -0.713704378633237,           /* re */
      0.849194710231305                /* im */
    }, { -0.703004449578752,           /* re */
      0.570112967833708                /* im */
    }, { -0.704785258703641,           /* re */
      0.845656115907589                /* im */
    }, { -0.674249952426396,           /* re */
      0.807269339332069                /* im */
    }, { -0.794336193794834,           /* re */
      -0.03408178885597                /* im */
    }, { -0.847363492194718,           /* re */
      -0.724630508101876               /* im */
    }, { 0.0795024202240836,           /* re */
      -0.940535201278152               /* im */
    }, { 0.9673019620125,              /* re */
      -0.758846345222371               /* im */
    }, { 0.0053210837670631,           /* re */
      0.017019137008514                /* im */
    }, { -1.01942331496848,            /* re */
      0.746741207756127                /* im */
    }, { 0.022538083120169,            /* re */
      0.924307579281247                /* im */
    }, { 0.956130340392041,            /* re */
      0.787273066063239                /* im */
    }, { 0.0773742186213774,           /* re */
      -0.0808409007904413              /* im */
    }, { -0.799274400478222,           /* re */
      -0.953612892085396               /* im */
    }, { -0.902085192051443,           /* re */
      -0.0254817777452841              /* im */
    }, { -0.800513601613559,           /* re */
      1.03150469066323                 /* im */
    }, { 0.0791267136734779,           /* re */
      -0.0241432971789265              /* im */
    }, { 0.944131017064489,            /* re */
      -0.952858332081187               /* im */
    }, { 0.0396573326993212,           /* re */
      -0.0832464903483755              /* im */
    }, { -1.02348490714465,            /* re */
      0.791737247003344                /* im */
    }, { -0.00282244815079745,         /* re */
      0.918879316431239                /* im */
    }, { 1.03161050480192,             /* re */
      0.745619825404457                /* im */
    }, { -0.0457415341622837,          /* re */
      0.0253628940676512               /* im */
    }, { -0.945593851122181,           /* re */
      -0.796688172981428               /* im */
    }, { -0.0751535397817638,          /* re */
      -0.852401725420276               /* im */
    }, { 0.777823275621812,            /* re */
      -0.582879784004642               /* im */
    }, { 0.931155095339833,            /* re */
      -0.822564000720365               /* im */
    }, { 0.762426049910208,            /* re */
      -0.869677744836819               /* im */
    }, { -0.0140311180678146,          /* re */
      0.138768011910108                /* im */
    }, { -0.738483589943952,           /* re */
      0.877754643238441                /* im */
    }, { -0.939474108667022,           /* re */
      0.120626546476387                /* im */
    }, { -0.807389169203165,           /* re */
      -0.84180203101231                /* im */
    }, { 0.126620742887862,            /* re */
      -0.84370700554248                /* im */
    }, { 0.878690262991077,            /* re */
      -0.594042494960791               /* im */
    }, { 0.128910292875284,            /* re */
      -0.815281336272357               /* im */
    }, { -0.806149968067829,           /* re */
      -0.86879051494176                /* im */
    }, { -0.943516153706544,           /* re */
      0.131941826654925                /* im */
    }, { -0.727723467751735,           /* re */
      0.940386372267482                /* im */
    }, { -0.0271083226074448,          /* re */
      -0.00489300188994777             /* im */
    }, { 0.755727519894165,            /* re */
      -0.937340348304288               /* im */
    }, { 0.952375831797323,            /* re */
      -0.126582434952725               /* im */
    }, { 0.720213262848436,            /* re */
      0.859273616059743                /* im */
    }, { 0.0288696781471126,           /* re */
      0.823881347383043                /* im */
    }, { -0.789753479421342,           /* re */
      0.594299480994699                /* im */
    }, { -0.86894740610423,            /* re */
      0.831965437462087                /* im */
    }, { -0.576303094947128,           /* re */
      0.862213825884245                /* im */
    }, { -0.815556930252325,           /* re */
      -0.140154229720594               /* im */
    }, { -0.881001806884568,           /* re */
      -0.883460129220734               /* im */
    }, { 0.152718554235426,            /* re */
      -0.109579224944085               /* im */
    }, { 0.887450497962035,            /* re */
      0.795790423552113                /* im */
    }, { 0.0899949439681823,           /* re */
      0.942330161037335                /* im */
    }, { -0.790156068185274,           /* re */
      0.741684467639352                /* im */
    }, { -0.931214537178649,           /* re */
      0.00652945737153563              /* im */
    }, { -0.790969846979382,           /* re */
      -0.751511073985784               /* im */
    }, { 0.0941866327977319,           /* re */
      -0.940991680470977               /* im */
    }, { 0.894985640349482,            /* re */
      -0.785209257201472               /* im */
    }, { 0.137488973182566,            /* re */
      0.0927762400767222               /* im */
    }, { -0.87000753223574,            /* re */
      0.896996356503062                /* im */
    }, { -0.820818572180571,           /* re */
      0.135793075862162                /* im */
    }, { -0.602876057273472,           /* re */
      -0.882893435722411               /* im */
    }, { -0.822254802520882,           /* re */
      -0.797667496464966               /* im */
    }, { -0.848712529643608,           /* re */
      -0.648759326415749               /* im */
    }, { 0.109519783105269,            /* re */
      -0.740168467222415               /* im */
    }, { 0.951666159451935,            /* re */
      -0.64711753651648                /* im */
    }, { -0.00177362895577977,         /* re */
      -0.798278126263717               /* im */
    }, { -0.965105483259884,           /* re */
      -0.820805566614397               /* im */
    }, { -0.0879144796096048,          /* re */
      0.00786793793789321              /* im */
    }, { 0.81396585826068,             /* re */
      0.811733520272174                /* im */
    }, { 0.891229235172851,            /* re */
      0.795872536705783                /* im */
    }, { 0.818253001627222,            /* re */
      0.665921203998767                /* im */
    }, { -0.0937867513366027,          /* re */
      0.716619872842366                /* im */
    }, { -0.923498095394534,           /* re */
      0.656400282941886                /* im */
    }, { -0.0963742762392546,          /* re */
      0.811239291232835                /* im */
    }, { 0.820036062683584,            /* re */
      0.818432050288217                /* im */
    }, { 0.888254299124905,            /* re */
      -0.0156423485070192              /* im */
    }, { 0.813695939387598,            /* re */
      -0.766691195074232               /* im */
    }, { -0.0845578206306066,          /* re */
      -0.896397831042766               /* im */
    }, { -0.969569664199989,           /* re */
      -0.813563176677329               /* im */
    }, { 0.00270356447316448,          /* re */
      0.094034144900584                /* im */
    }, { 0.956815780868228,            /* re */
      0.964870588247913                /* im */
    }, { 0.099089545307107,            /* re */
      -0.005462348379959               /* im */
    }, { -0.815219910503201,           /* re */
      -0.965530163045753               /* im */
    }, { -0.900439876082288,           /* re */
      -0.0838158368383867              /* im */
    }, { -0.750778697822933,           /* re */
      0.800703479206876                /* im */
    }, { -0.033346871576057,           /* re */
      0.905057283992268                /* im */
    }, { 0.824146354115401,            /* re */
      0.808911129231337                /* im */
    }, { 0.820362092987746,            /* re */
      -0.0940935867394005              /* im */
    } };

  creal_T b_Pxs[16];
  creal_T eigV[16];
  double eigD[4];
  double x[4];
  int iidx[4];
  double b_eigD[4];
  double SigThd;
  double pwrSum;
  int NumSig;
  boolean_T exitg1;
  int ia;
  creal_T Vnoise_data[12];
  creal_T Rnn[16];
  creal_T b_data[12];
  int br;
  int ic;
  int ar;
  creal_T b_recStvPartition[484];
  creal_T dcv0[121];
  int ib;
  creal_T dcv1[121];
  creal_T c_recStvPartition[484];
  creal_T dcv2[121];
  double brm;
  double idxDoa_data[247];
  double b_spatialSpectrum[121];
  double processSpectrum[121];
  double b_processSpectrum[123];
  double unusedU2_data[246];
  int unusedU2_size[2];
  double b_idxDoa_data[246];
  int idxDoa_size[2];
  int b_idxDoa_size[2];
  boolean_T c_idxDoa_data[246];
  double itmp_data[247];

  /* 'DoaEstimatorMUSICSignalImplement:13' PilotSequence = [0.597750197628676 + 0.899287820462048i,0.832619582099781 + 0.131116226113365i,0.791277450536945 - 0.870126619551477i,0.00511199813821906 - 0.812875746714423i,-0.798163847058874 - 0.597925131295389i,-0.832866975663762 - 0.838791622717269i,-0.586766442514103 - 0.799582096855205i,-0.833370426379568 + 0.0146346813542591i,-0.818914680331913 + 0.792434692124505i,0.0385749092847886 + 0.822980859313228i,0.732202685437865 + 0.657215980004006i,0.923622193220723 + 0.700993451335220i,0.806820371797992 + 0.714344198108465i,-0.109820602127619 + 0.699557220994909i,-0.886386230493411 + 0.678510982596137i,-0.134397997564108 + 0.795011669235930i,0.875863014400597 + 0.846858771129085i,0.806596527013989 - 0.0794641122889465i,0.632225031870510 - 0.973562879403500i,0.758091986539724 + 0.00242797049319710i,0.649466857913873 + 1.00972746024489i,0.780072996585994 - 0.0146729892893962i,0.886578954548940 - 0.941910343383084i,-0.122462658277827 - 0.110029687756464i,-0.949398457264446 + 0.855163324627926i,0.00846865711721725 + 0.813260313752596i,0.933265080733581 + 0.593814839863572i,0.127440458315457 + 0.844338769244911i,-0.868352809497298 + 0.809490755568833i,-0.810260021395785 - 0.0331278753277856i,-0.599168354605588 - 0.737707031737225i,-0.838247501269642 - 0.921166022311540i,-0.801456028123654 - 0.812228990335624i,0.0181892026778493 + 0.117982423842039i,0.790508039425551 + 0.899555635428278i,0.820821416287692 + 0.108559853196637i,0.666522921358200 - 0.820436640360084i,0.690938920087664 - 0.901465701765124i,0.722256991775696 - 0.800254604492219i,0.699560065102030 + 0.0765486180798176i,0.657002000301320 + 0.967092004484677i,0.827567025800378 + 0.0116597453063136i,0.806727490498474 - 0.968213386836347i,-0.0120666932797497 - 0.0953131836281251i,-0.759048227460663 + 0.854771564796316i,-0.909834246311703 + 0.800809053434673i,-0.808331502893841 + 0.660959449088361i,0.0996902644864311 + 0.720721359720704i,0.949635363363849 + 0.717178160636984i,0.0138969199672255 + 0.678862316188488i,-0.962342218189525 + 0.721276787761700i,-0.106235036280923 + 0.710363646654112i,0.863180354503709 + 0.645666366765890i,0.796416658153411 + 0.833104261708592i,0.654747571290877 + 0.798918407063083i,0.732687940429815 - 0.00477696231943516i,0.700630933252572 - 0.754427088881499i,0.690988451307054 - 0.925251582190004i,0.731021341740936 - 0.754276350143574i,0.685667367539991 - 0.00339781102125576i,0.702592609812637 + 0.802593096957289i,0.735115910923013 + 0.826265606137574i,0.641047239274157 + 0.653105781391609i,0.815528729836338 + 0.703449622244404i,0.865591648333791 + 0.705284991785995i,-0.128494484414280 + 0.711742797952292i,-0.890215774119824 + 0.665483591373724i,-0.110045614756338 + 0.801678300081658i,0.805970919406834 + 0.868023022098378i,0.926497016698030 - 0.116752916333887i,0.740007653878974 - 0.915572368888130i,0.0244712664854036 - 0.0834060447578302i,-0.811357446922529 + 0.796911805903784i,-0.831856464403881 + 0.913241486641951i,-0.634018921859194 + 0.811687234321449i,-0.727398098085583 - 0.106322678535725i,-0.707211644484950 - 0.897878821667900i,-0.685332331721207 - 0.121261351185662i,-0.734444181609135 + 0.815593972765416i,-0.685034356805976 + 0.919423437878867i,-0.714746786872397 + 0.741071921347597i,-0.716658180777503 + 0.0300397438164480i,-0.644199417713915 - 0.813967869348111i,-0.826296847560404 - 0.833470538950206i,-0.795389845875613 - 0.633404271660588i,-0.00542826285000829 - 0.728101773942665i,0.794219764268299 - 0.710151854309453i,0.835957951282220 - 0.680207863267152i,0.605165417325606 - 0.736145190298302i,0.803830676594888 - 0.687490527715160i,0.863713694890480 - 0.699876373248363i,-0.112929867542636 - 0.737252973013286i,-0.938129932169607 - 0.640646661597657i,-0.0170473374245001 - 0.812365842063228i,0.997312615314229 - 0.862319640022937i,0.0214115322897759 + 0.117854110855414i,-1.01838398498400 + 0.898872298858942i,0.00535939170220030 + 0.105093171027573i,1.00740022986943 - 0.850201569717520i,-0.0188745887383731 - 0.817361800630935i,-0.989187017656964 - 0.652336277460795i,0.00278129610853988 - 0.713823262310870i,0.955776450883752 - 0.714746786872397i,0.100100056566987 - 0.688936187364462i,-0.876883099825346 - 0.673513461269261i,-0.773324542966187 - 0.811107937239366i,-0.668316811346884 - 0.794445408278086i,-0.733001842344920 - 0.0234013133867066i,-0.631377590566783 + 0.820748451731350i,-0.831173922450478 + 0.815221894433541i,-0.803154932905969 + 0.598951528440691i,0.0131366463784466 + 0.832024879300903i,0.735906180292048 + 0.796631058098380i,0.943775820686637 - 0.00357565522726951i,0.749294515298662 - 0.788056585726458i,-0.00499311446058607 - 0.838639134820122i,-0.737779833102237 - 0.607351067145900i,-0.951975950336194 - 0.797795809451591i,-0.743903130233326 - 0.866499050982776i,0.00808409007904414 + 0.111096796748040i,0.751356220253577 + 0.942759888593662i,0.926597129268668 + 0.0107652736169457i,0.786153694798999 - 0.993956883886621i,-0.0800989169982213 - 0.0199940730564594i,-0.956933599651893 + 1.00757516353614i,-0.0228571919390786 + 0.00623148245630531i,1.02350984462880 - 1.01437950769088i,-0.0138220324389705 + 0.0146135474505797i,-0.948995868500514 + 1.00749311116895i,-0.0990301034682904 - 0.0265488867368607i,0.843763707572375 - 0.950566868122202i,0.820284361352370 - 0.0842004038765598i,0.598789527613151 + 0.809326650834442i,0.831609070839900 + 0.895787201244015i,0.852940639859090 + 0.798692763053295i,-0.122003334977882 - 0.0714394640487189i,-0.880625733534922 - 0.956563930842221i,-0.133212004894899 - 0.0305909317763828i,0.864244621972332 + 1.02548949721652i,0.821888525279268 - 0.00893504692946981i,0.582300157667146 - 1.01044414992577i,0.853896916288968 + 0.0251626689263745i,0.794635285871404 + 0.940348501944160i,-0.0211046968869782 + 0.0989706616294739i,-0.736784685161636 - 0.855028550830224i,-0.934421552367619 - 0.801324974466315i,-0.752787310069662 - 0.643989460186091i,0.00366633848891637 - 0.743375482411386i,0.795918669050615 - 0.664397232883164i,0.824842327423534 - 0.771463074855881i,0.649373976614355 - 0.882904264654734i,0.711742797952292 + 0.108393232274876i,0.673491370247324 + 0.971918985597381i,0.788213684396734 - 0.0300991856552645i,0.818160120327704 - 0.935386747033754i,0.00764894168962190 - 0.103072148507813i,-0.823391794111192 + 0.796507113233001i,-0.795731272092887 + 0.931840481400356i,-0.656154558997593 + 0.738733428882527i,-0.730883070051205 + 0.0213114197191376i,-0.651734560101362 - 0.751336140319071i,-0.801034066063392 - 0.957087948474413i,-0.864162569605137 - 0.723460426494562i,0.110530294365149 - 0.0179730505366983i,0.904413680106844 + 0.750933551555139i,0.104198699338206 + 0.951540801946772i,-0.853402447412920 + 0.718064647976684i,-0.811821720615600 + 0.0327433082896124i,-0.657193888982068 - 0.805970919406834i,-0.713704378633237 - 0.849194710231305i,-0.703004449578752 - 0.570112967833708i,-0.704785258703641 - 0.845656115907589i,-0.674249952426396 - 0.807269339332069i,-0.794336193794834 + 0.0340817888559700i,-0.847363492194718 + 0.724630508101876i,0.0795024202240836 + 0.940535201278152i,0.967301962012500 + 0.758846345222371i,0.00532108376706310 - 0.0170191370085140i,-1.01942331496848 - 0.746741207756127i,0.0225380831201690 - 0.924307579281247i,0.956130340392041 - 0.787273066063239i,0.0773742186213774 + 0.0808409007904413i,-0.799274400478222 + 0.953612892085396i,-0.902085192051443 + 0.0254817777452841i,-0.800513601613559 - 1.03150469066323i,0.0791267136734779 + 0.0241432971789265i,0.944131017064489 + 0.952858332081187i,0.0396573326993212 + 0.0832464903483755i,-1.02348490714465 - 0.791737247003344i,-0.00282244815079745 - 0.918879316431239i,1.03161050480192 - 0.745619825404457i,-0.0457415341622837 - 0.0253628940676512i,-0.945593851122181 + 0.796688172981428i,-0.0751535397817638 + 0.852401725420276i,0.777823275621812 + 0.582879784004642i,0.931155095339833 + 0.822564000720365i,0.762426049910208 + 0.869677744836819i,-0.0140311180678146 - 0.138768011910108i,-0.738483589943952 - 0.877754643238441i,-0.939474108667022 - 0.120626546476387i,-0.807389169203165 + 0.841802031012310i,0.126620742887862 + 0.843707005542480i,0.878690262991077 + 0.594042494960791i,0.128910292875284 + 0.815281336272357i,-0.806149968067829 + 0.868790514941760i,-0.943516153706544 - 0.131941826654925i,-0.727723467751735 - 0.940386372267482i,-0.0271083226074448 + 0.00489300188994777i,0.755727519894165 + 0.937340348304288i,0.952375831797323 + 0.126582434952725i,0.720213262848436 - 0.859273616059743i,0.0288696781471126 - 0.823881347383043i,-0.789753479421342 - 0.594299480994699i,-0.868947406104230 - 0.831965437462087i,-0.576303094947128 - 0.862213825884245i,-0.815556930252325 + 0.140154229720594i,-0.881001806884568 + 0.883460129220734i,0.152718554235426 + 0.109579224944085i,0.887450497962035 - 0.795790423552113i,0.0899949439681823 - 0.942330161037335i,-0.790156068185274 - 0.741684467639352i,-0.931214537178649 - 0.00652945737153563i,-0.790969846979382 + 0.751511073985784i,0.0941866327977319 + 0.940991680470977i,0.894985640349482 + 0.785209257201472i,0.137488973182566 - 0.0927762400767222i,-0.870007532235740 - 0.896996356503062i,-0.820818572180571 - 0.135793075862162i,-0.602876057273472 + 0.882893435722411i,-0.822254802520882 + 0.797667496464966i,-0.848712529643608 + 0.648759326415749i,0.109519783105269 + 0.740168467222415i,0.951666159451935 + 0.647117536516480i,-0.00177362895577977 + 0.798278126263717i,-0.965105483259884 + 0.820805566614397i,-0.0879144796096048 - 0.00786793793789321i,0.813965858260680 - 0.811733520272174i,0.891229235172851 - 0.795872536705783i,0.818253001627222 - 0.665921203998767i,-0.0937867513366027 - 0.716619872842366i,-0.923498095394534 - 0.656400282941886i,-0.0963742762392546 - 0.811239291232835i,0.820036062683584 - 0.818432050288217i,0.888254299124905 + 0.0156423485070192i,0.813695939387598 + 0.766691195074232i,-0.0845578206306066 + 0.896397831042766i,-0.969569664199989 + 0.813563176677329i,0.00270356447316448 - 0.0940341449005840i,0.956815780868228 - 0.964870588247913i,0.0990895453071070 + 0.00546234837995900i,-0.815219910503201 + 0.965530163045753i,-0.900439876082288 + 0.0838158368383867i,-0.750778697822933 - 0.800703479206876i,-0.0333468715760570 - 0.905057283992268i,0.824146354115401 - 0.808911129231337i,0.820362092987746 + 0.0940935867394005i,0.597750197628676 + 0.899287820462048i,0.832619582099781 + 0.131116226113365i,0.791277450536945 - 0.870126619551477i,0.00511199813821906 - 0.812875746714423i,-0.798163847058874 - 0.597925131295389i,-0.832866975663762 - 0.838791622717269i,-0.586766442514103 - 0.799582096855205i,-0.833370426379568 + 0.0146346813542591i,-0.818914680331913 + 0.792434692124505i,0.0385749092847886 + 0.822980859313228i,0.732202685437865 + 0.657215980004006i,0.923622193220723 + 0.700993451335220i,0.806820371797992 + 0.714344198108465i,-0.109820602127619 + 0.699557220994909i,-0.886386230493411 + 0.678510982596137i,-0.134397997564108 + 0.795011669235930i,0.875863014400597 + 0.846858771129085i,0.806596527013989 - 0.0794641122889465i,0.632225031870510 - 0.973562879403500i,0.758091986539724 + 0.00242797049319710i,0.649466857913873 + 1.00972746024489i,0.780072996585994 - 0.0146729892893962i,0.886578954548940 - 0.941910343383084i,-0.122462658277827 - 0.110029687756464i,-0.949398457264446 + 0.855163324627926i,0.00846865711721725 + 0.813260313752596i,0.933265080733581 + 0.593814839863572i,0.127440458315457 + 0.844338769244911i,-0.868352809497298 + 0.809490755568833i,-0.810260021395785 - 0.0331278753277856i,-0.599168354605588 - 0.737707031737225i,-0.838247501269642 - 0.921166022311540i,-0.801456028123654 - 0.812228990335624i,0.0181892026778493 + 0.117982423842039i,0.790508039425551 + 0.899555635428278i,0.820821416287692 + 0.108559853196637i,0.666522921358200 - 0.820436640360084i,0.690938920087664 - 0.901465701765124i,0.722256991775696 - 0.800254604492219i,0.699560065102030 + 0.0765486180798176i,0.657002000301320 + 0.967092004484677i,0.827567025800378 + 0.0116597453063136i,0.806727490498474 - 0.968213386836347i,-0.0120666932797497 - 0.0953131836281251i,-0.759048227460663 + 0.854771564796316i,-0.909834246311703 + 0.800809053434673i,-0.808331502893841 + 0.660959449088361i,0.0996902644864311 + 0.720721359720704i,0.949635363363849 + 0.717178160636984i,0.0138969199672255 + 0.678862316188488i,-0.962342218189525 + 0.721276787761700i,-0.106235036280923 + 0.710363646654112i,0.863180354503709 + 0.645666366765890i,0.796416658153411 + 0.833104261708592i,0.654747571290877 + 0.798918407063083i,0.732687940429815 - 0.00477696231943516i,0.700630933252572 - 0.754427088881499i,0.690988451307054 - 0.925251582190004i,0.731021341740936 - 0.754276350143574i,0.685667367539991 - 0.00339781102125576i,0.702592609812637 + 0.802593096957289i,0.735115910923013 + 0.826265606137574i,0.641047239274157 + 0.653105781391609i,0.815528729836338 + 0.703449622244404i,0.865591648333791 + 0.705284991785995i,-0.128494484414280 + 0.711742797952292i,-0.890215774119824 + 0.665483591373724i,-0.110045614756338 + 0.801678300081658i,0.805970919406834 + 0.868023022098378i,0.926497016698030 - 0.116752916333887i,0.740007653878974 - 0.915572368888130i,0.0244712664854036 - 0.0834060447578302i,-0.811357446922529 + 0.796911805903784i,-0.831856464403881 + 0.913241486641951i,-0.634018921859194 + 0.811687234321449i,-0.727398098085583 - 0.106322678535725i,-0.707211644484950 - 0.897878821667900i,-0.685332331721207 - 0.121261351185662i,-0.734444181609135 + 0.815593972765416i,-0.685034356805976 + 0.919423437878867i,-0.714746786872397 + 0.741071921347597i,-0.716658180777503 + 0.0300397438164480i,-0.644199417713915 - 0.813967869348111i,-0.826296847560404 - 0.833470538950206i,-0.795389845875613 - 0.633404271660588i,-0.00542826285000829 - 0.728101773942665i,0.794219764268299 - 0.710151854309453i,0.835957951282220 - 0.680207863267152i,0.605165417325606 - 0.736145190298302i,0.803830676594888 - 0.687490527715160i,0.863713694890480 - 0.699876373248363i,-0.112929867542636 - 0.737252973013286i,-0.938129932169607 - 0.640646661597657i,-0.0170473374245001 - 0.812365842063228i,0.997312615314229 - 0.862319640022937i,0.0214115322897759 + 0.117854110855414i,-1.01838398498400 + 0.898872298858942i,0.00535939170220030 + 0.105093171027573i,1.00740022986943 - 0.850201569717520i,-0.0188745887383731 - 0.817361800630935i,-0.989187017656964 - 0.652336277460795i,0.00278129610853988 - 0.713823262310870i,0.955776450883752 - 0.714746786872397i,0.100100056566987 - 0.688936187364462i,-0.876883099825346 - 0.673513461269261i,-0.773324542966187 - 0.811107937239366i,-0.668316811346884 - 0.794445408278086i,-0.733001842344920 - 0.0234013133867066i,-0.631377590566783 + 0.820748451731350i,-0.831173922450478 + 0.815221894433541i,-0.803154932905969 + 0.598951528440691i,0.0131366463784466 + 0.832024879300903i,0.735906180292048 + 0.796631058098380i,0.943775820686637 - 0.00357565522726951i,0.749294515298662 - 0.788056585726458i,-0.00499311446058607 - 0.838639134820122i,-0.737779833102237 - 0.607351067145900i,-0.951975950336194 - 0.797795809451591i,-0.743903130233326 - 0.866499050982776i,0.00808409007904414 + 0.111096796748040i,0.751356220253577 + 0.942759888593662i,0.926597129268668 + 0.0107652736169457i,0.786153694798999 - 0.993956883886621i,-0.0800989169982213 - 0.0199940730564594i,-0.956933599651893 + 1.00757516353614i,-0.0228571919390786 + 0.00623148245630531i,1.02350984462880 - 1.01437950769088i,-0.0138220324389705 + 0.0146135474505797i,-0.948995868500514 + 1.00749311116895i,-0.0990301034682904 - 0.0265488867368607i,0.843763707572375 - 0.950566868122202i,0.820284361352370 - 0.0842004038765598i,0.598789527613151 + 0.809326650834442i,0.831609070839900 + 0.895787201244015i,0.852940639859090 + 0.798692763053295i,-0.122003334977882 - 0.0714394640487189i,-0.880625733534922 - 0.956563930842221i,-0.133212004894899 - 0.0305909317763828i,0.864244621972332 + 1.02548949721652i,0.821888525279268 - 0.00893504692946981i,0.582300157667146 - 1.01044414992577i,0.853896916288968 + 0.0251626689263745i,0.794635285871404 + 0.940348501944160i,-0.0211046968869782 + 0.0989706616294739i,-0.736784685161636 - 0.855028550830224i,-0.934421552367619 - 0.801324974466315i,-0.752787310069662 - 0.643989460186091i,0.00366633848891637 - 0.743375482411386i,0.795918669050615 - 0.664397232883164i,0.824842327423534 - 0.771463074855881i,0.649373976614355 - 0.882904264654734i,0.711742797952292 + 0.108393232274876i,0.673491370247324 + 0.971918985597381i,0.788213684396734 - 0.0300991856552645i,0.818160120327704 - 0.935386747033754i,0.00764894168962190 - 0.103072148507813i,-0.823391794111192 + 0.796507113233001i,-0.795731272092887 + 0.931840481400356i,-0.656154558997593 + 0.738733428882527i,-0.730883070051205 + 0.0213114197191376i,-0.651734560101362 - 0.751336140319071i,-0.801034066063392 - 0.957087948474413i,-0.864162569605137 - 0.723460426494562i,0.110530294365149 - 0.0179730505366983i,0.904413680106844 + 0.750933551555139i,0.104198699338206 + 0.951540801946772i,-0.853402447412920 + 0.718064647976684i,-0.811821720615600 + 0.0327433082896124i,-0.657193888982068 - 0.805970919406834i,-0.713704378633237 - 0.849194710231305i,-0.703004449578752 - 0.570112967833708i,-0.704785258703641 - 0.845656115907589i,-0.674249952426396 - 0.807269339332069i,-0.794336193794834 + 0.0340817888559700i,-0.847363492194718 + 0.724630508101876i,0.0795024202240836 + 0.940535201278152i,0.967301962012500 + 0.758846345222371i,0.00532108376706310 - 0.0170191370085140i,-1.01942331496848 - 0.746741207756127i,0.0225380831201690 - 0.924307579281247i,0.956130340392041 - 0.787273066063239i,0.0773742186213774 + 0.0808409007904413i,-0.799274400478222 + 0.953612892085396i,-0.902085192051443 + 0.0254817777452841i,-0.800513601613559 - 1.03150469066323i,0.0791267136734779 + 0.0241432971789265i,0.944131017064489 + 0.952858332081187i,0.0396573326993212 + 0.0832464903483755i,-1.02348490714465 - 0.791737247003344i,-0.00282244815079745 - 0.918879316431239i,1.03161050480192 - 0.745619825404457i,-0.0457415341622837 - 0.0253628940676512i,-0.945593851122181 + 0.796688172981428i,-0.0751535397817638 + 0.852401725420276i,0.777823275621812 + 0.582879784004642i,0.931155095339833 + 0.822564000720365i,0.762426049910208 + 0.869677744836819i,-0.0140311180678146 - 0.138768011910108i,-0.738483589943952 - 0.877754643238441i,-0.939474108667022 - 0.120626546476387i,-0.807389169203165 + 0.841802031012310i,0.126620742887862 + 0.843707005542480i,0.878690262991077 + 0.594042494960791i,0.128910292875284 + 0.815281336272357i,-0.806149968067829 + 0.868790514941760i,-0.943516153706544 - 0.131941826654925i,-0.727723467751735 - 0.940386372267482i,-0.0271083226074448 + 0.00489300188994777i,0.755727519894165 + 0.937340348304288i,0.952375831797323 + 0.126582434952725i,0.720213262848436 - 0.859273616059743i,0.0288696781471126 - 0.823881347383043i,-0.789753479421342 - 0.594299480994699i,-0.868947406104230 - 0.831965437462087i,-0.576303094947128 - 0.862213825884245i,-0.815556930252325 + 0.140154229720594i,-0.881001806884568 + 0.883460129220734i,0.152718554235426 + 0.109579224944085i,0.887450497962035 - 0.795790423552113i,0.0899949439681823 - 0.942330161037335i,-0.790156068185274 - 0.741684467639352i,-0.931214537178649 - 0.00652945737153563i,-0.790969846979382 + 0.751511073985784i,0.0941866327977319 + 0.940991680470977i,0.894985640349482 + 0.785209257201472i,0.137488973182566 - 0.0927762400767222i,-0.870007532235740 - 0.896996356503062i,-0.820818572180571 - 0.135793075862162i,-0.602876057273472 + 0.882893435722411i,-0.822254802520882 + 0.797667496464966i,-0.848712529643608 + 0.648759326415749i,0.109519783105269 + 0.740168467222415i,0.951666159451935 + 0.647117536516480i,-0.00177362895577977 + 0.798278126263717i,-0.965105483259884 + 0.820805566614397i,-0.0879144796096048 - 0.00786793793789321i,0.813965858260680 - 0.811733520272174i,0.891229235172851 - 0.795872536705783i,0.818253001627222 - 0.665921203998767i,-0.0937867513366027 - 0.716619872842366i,-0.923498095394534 - 0.656400282941886i,-0.0963742762392546 - 0.811239291232835i,0.820036062683584 - 0.818432050288217i,0.888254299124905 + 0.0156423485070192i,0.813695939387598 + 0.766691195074232i,-0.0845578206306066 + 0.896397831042766i,-0.969569664199989 + 0.813563176677329i,0.00270356447316448 - 0.0940341449005840i,0.956815780868228 - 0.964870588247913i,0.0990895453071070 + 0.00546234837995900i,-0.815219910503201 + 0.965530163045753i,-0.900439876082288 + 0.0838158368383867i,-0.750778697822933 - 0.800703479206876i,-0.0333468715760570 - 0.905057283992268i,0.824146354115401 - 0.808911129231337i,0.820362092987746 + 0.0940935867394005i]; */
  /* 'DoaEstimatorMUSICSignalImplement:15' Pxs = rxSigNoise.'*PilotSequence'; */
  for (i0 = 0; i0 < 4; i0++) {
    Pxs[i0].re = 0.0;
    Pxs[i0].im = 0.0;
    for (i = 0; i < 512; i++) {
      Pxs[i0].re += rxSigNoise[i + (i0 << 9)].re * b[i].re - rxSigNoise[i + (i0 <<
        9)].im * b[i].im;
      Pxs[i0].im += rxSigNoise[i + (i0 << 9)].re * b[i].im + rxSigNoise[i + (i0 <<
        9)].im * b[i].re;
    }
  }

  /*  PN code filtering in time. */
  /* Pxs = rxSigNoise; */
  /* 'DoaEstimatorMUSICSignalImplement:18' Rxx = Pxs*Pxs'; */
  /* 'DoaEstimatorMUSICSignalImplement:19' [eigV, eigD] = eig(Rxx, 'vector'); */
  for (i0 = 0; i0 < 4; i0++) {
    for (i = 0; i < 4; i++) {
      b_Pxs[i0 + (i << 2)].re = Pxs[i0].re * Pxs[i].re - Pxs[i0].im * -Pxs[i].im;
      b_Pxs[i0 + (i << 2)].im = Pxs[i0].re * -Pxs[i].im + Pxs[i0].im * Pxs[i].re;
    }
  }

  eig_DoaMusicSignal(b_Pxs, eigV, Pxs);

  /* 'DoaEstimatorMUSICSignalImplement:20' eigD = abs(eigD); */
  abs_DoaMusicSignal(Pxs, eigD);

  /* 'DoaEstimatorMUSICSignalImplement:21' [~,idx] = sort(eigD, 'ascend'); */
  for (i = 0; i < 4; i++) {
    x[i] = eigD[i];
  }

  sort_DoaMusicSignal(x, iidx);

  /* 'DoaEstimatorMUSICSignalImplement:21' ~ */
  /* 'DoaEstimatorMUSICSignalImplement:22' eigD = eigD(idx); */
  for (i = 0; i < 4; i++) {
    b_eigD[i] = eigD[iidx[i] - 1];
    x[i] = iidx[i];
  }

  for (i0 = 0; i0 < 4; i0++) {
    eigD[i0] = b_eigD[i0];
  }

  /* 'DoaEstimatorMUSICSignalImplement:23' eigV = eigV(:,idx); */
  /*  find out the Number of signal. */
  /* 'DoaEstimatorMUSICSignalImplement:26' SigThd = 0.8*sum(eigD); */
  SigThd = 0.8 * sum_DoaMusicSignal(eigD);

  /*  assume the signals power should exceed certurn percentage of the total power. */
  /* 'DoaEstimatorMUSICSignalImplement:27' NumCh = length(eigD); */
  /* 'DoaEstimatorMUSICSignalImplement:28' pwrSum = 0; */
  pwrSum = 0.0;

  /* 'DoaEstimatorMUSICSignalImplement:29' NumSig = NumCh-1; */
  NumSig = 3;

  /*  at least one column for noise space */
  /* 'DoaEstimatorMUSICSignalImplement:30' for idx = 1:NumCh-1 */
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 3)) {
    /* 'DoaEstimatorMUSICSignalImplement:31' pwrSum = pwrSum + eigD(NumCh-idx+1); */
    pwrSum += eigD[3 - i];

    /* 'DoaEstimatorMUSICSignalImplement:32' if pwrSum>SigThd */
    if (pwrSum > SigThd) {
      /* 'DoaEstimatorMUSICSignalImplement:33' NumSig = idx; */
      NumSig = 1 + i;
      exitg1 = true;
    } else {
      i++;
    }
  }

  /*  noise space construction */
  /* 'DoaEstimatorMUSICSignalImplement:39' Vnoise = eigV(:, 1:NumCh-NumSig ); */
  ia = 4 - NumSig;
  for (i0 = 0; i0 < 4; i0++) {
    for (i = 0; i < 4; i++) {
      b_Pxs[i + (i0 << 2)] = eigV[i + (((int)x[i0] - 1) << 2)];
    }
  }

  for (i0 = 0; i0 < ia; i0++) {
    memcpy(&Vnoise_data[i0 << 2], &b_Pxs[i0 << 2], sizeof(creal_T) << 2);
  }

  /* 'DoaEstimatorMUSICSignalImplement:40' Rnn = Vnoise*Vnoise'; */
  ia = 4 - NumSig;
  for (i0 = 0; i0 < 4; i0++) {
    for (i = 0; i < ia; i++) {
      b_data[i + (4 - NumSig) * i0].re = Vnoise_data[i0 + (i << 2)].re;
      b_data[i + (4 - NumSig) * i0].im = -Vnoise_data[i0 + (i << 2)].im;
    }
  }

  if (4 - NumSig == 1) {
    ia = 4 - NumSig;
    for (i0 = 0; i0 < 4; i0++) {
      for (i = 0; i < 4; i++) {
        Rnn[i0 + (i << 2)].re = 0.0;
        Rnn[i0 + (i << 2)].im = 0.0;
        for (br = 0; br < ia; br++) {
          Rnn[i0 + (i << 2)].re += Vnoise_data[i0 + (br << 2)].re * b_data[br +
            (4 - NumSig) * i].re - Vnoise_data[i0 + (br << 2)].im * b_data[br +
            (4 - NumSig) * i].im;
          Rnn[i0 + (i << 2)].im += Vnoise_data[i0 + (br << 2)].re * b_data[br +
            (4 - NumSig) * i].im + Vnoise_data[i0 + (br << 2)].im * b_data[br +
            (4 - NumSig) * i].re;
        }
      }
    }
  } else {
    memset(&Rnn[0], 0, sizeof(creal_T) << 4);
    for (i = 0; i <= 13; i += 4) {
      for (ic = i; ic + 1 <= i + 4; ic++) {
        Rnn[ic].re = 0.0;
        Rnn[ic].im = 0.0;
      }
    }

    br = 0;
    for (i = 0; i <= 13; i += 4) {
      ar = 0;
      i0 = (br - NumSig) + 4;
      for (ib = br; ib + 1 <= i0; ib++) {
        if ((b_data[ib].re != 0.0) || (b_data[ib].im != 0.0)) {
          SigThd = b_data[ib].re - 0.0 * b_data[ib].im;
          pwrSum = b_data[ib].im + 0.0 * b_data[ib].re;
          ia = ar;
          for (ic = i; ic + 1 <= i + 4; ic++) {
            ia++;
            Rnn[ic].re += SigThd * Vnoise_data[ia - 1].re - pwrSum *
              Vnoise_data[ia - 1].im;
            Rnn[ic].im += SigThd * Vnoise_data[ia - 1].im + pwrSum *
              Vnoise_data[ia - 1].re;
          }
        }

        ar += 4;
      }

      br = (br - NumSig) + 4;
    }
  }

  /* 'DoaEstimatorMUSICSignalImplement:42' spatialSpectrum = abs(sum(conj(recStvPartition).*recStvPartition)./sum((recStvPartition'*Rnn).'.*recStvPartition)); */
  for (i0 = 0; i0 < 484; i0++) {
    b_recStvPartition[i0].re = recStvPartition[i0].re * recStvPartition[i0].re -
      -recStvPartition[i0].im * recStvPartition[i0].im;
    b_recStvPartition[i0].im = recStvPartition[i0].re * recStvPartition[i0].im +
      -recStvPartition[i0].im * recStvPartition[i0].re;
  }

  b_sum_DoaMusicSignal(b_recStvPartition, dcv0);
  for (i0 = 0; i0 < 4; i0++) {
    for (i = 0; i < 121; i++) {
      c_recStvPartition[i0 + (i << 2)].re = 0.0;
      c_recStvPartition[i0 + (i << 2)].im = 0.0;
      for (br = 0; br < 4; br++) {
        SigThd = recStvPartition[br + (i << 2)].re;
        pwrSum = -recStvPartition[br + (i << 2)].im;
        c_recStvPartition[i0 + (i << 2)].re += SigThd * Rnn[br + (i0 << 2)].re -
          pwrSum * Rnn[br + (i0 << 2)].im;
        c_recStvPartition[i0 + (i << 2)].im += SigThd * Rnn[br + (i0 << 2)].im +
          pwrSum * Rnn[br + (i0 << 2)].re;
      }
    }
  }

  for (i0 = 0; i0 < 121; i0++) {
    for (i = 0; i < 4; i++) {
      b_recStvPartition[i + (i0 << 2)].re = c_recStvPartition[i + (i0 << 2)].re *
        recStvPartition[i + (i0 << 2)].re - c_recStvPartition[i + (i0 << 2)].im *
        recStvPartition[i + (i0 << 2)].im;
      b_recStvPartition[i + (i0 << 2)].im = c_recStvPartition[i + (i0 << 2)].re *
        recStvPartition[i + (i0 << 2)].im + c_recStvPartition[i + (i0 << 2)].im *
        recStvPartition[i + (i0 << 2)].re;
    }
  }

  b_sum_DoaMusicSignal(b_recStvPartition, dcv1);
  for (i0 = 0; i0 < 121; i0++) {
    if (dcv1[i0].im == 0.0) {
      if (dcv0[i0].im == 0.0) {
        dcv2[i0].re = dcv0[i0].re / dcv1[i0].re;
        dcv2[i0].im = 0.0;
      } else if (dcv0[i0].re == 0.0) {
        dcv2[i0].re = 0.0;
        dcv2[i0].im = dcv0[i0].im / dcv1[i0].re;
      } else {
        dcv2[i0].re = dcv0[i0].re / dcv1[i0].re;
        dcv2[i0].im = dcv0[i0].im / dcv1[i0].re;
      }
    } else if (dcv1[i0].re == 0.0) {
      if (dcv0[i0].re == 0.0) {
        dcv2[i0].re = dcv0[i0].im / dcv1[i0].im;
        dcv2[i0].im = 0.0;
      } else if (dcv0[i0].im == 0.0) {
        dcv2[i0].re = 0.0;
        dcv2[i0].im = -(dcv0[i0].re / dcv1[i0].im);
      } else {
        dcv2[i0].re = dcv0[i0].im / dcv1[i0].im;
        dcv2[i0].im = -(dcv0[i0].re / dcv1[i0].im);
      }
    } else {
      brm = fabs(dcv1[i0].re);
      SigThd = fabs(dcv1[i0].im);
      if (brm > SigThd) {
        SigThd = dcv1[i0].im / dcv1[i0].re;
        pwrSum = dcv1[i0].re + SigThd * dcv1[i0].im;
        dcv2[i0].re = (dcv0[i0].re + SigThd * dcv0[i0].im) / pwrSum;
        dcv2[i0].im = (dcv0[i0].im - SigThd * dcv0[i0].re) / pwrSum;
      } else if (SigThd == brm) {
        if (dcv1[i0].re > 0.0) {
          SigThd = 0.5;
        } else {
          SigThd = -0.5;
        }

        if (dcv1[i0].im > 0.0) {
          pwrSum = 0.5;
        } else {
          pwrSum = -0.5;
        }

        dcv2[i0].re = (dcv0[i0].re * SigThd + dcv0[i0].im * pwrSum) / brm;
        dcv2[i0].im = (dcv0[i0].im * SigThd - dcv0[i0].re * pwrSum) / brm;
      } else {
        SigThd = dcv1[i0].re / dcv1[i0].im;
        pwrSum = dcv1[i0].im + SigThd * dcv1[i0].re;
        dcv2[i0].re = (SigThd * dcv0[i0].re + dcv0[i0].im) / pwrSum;
        dcv2[i0].im = (SigThd * dcv0[i0].im - dcv0[i0].re) / pwrSum;
      }
    }
  }

  b_abs_DoaMusicSignal(dcv2, spatialSpectrum);

  /* 'DoaEstimatorMUSICSignalImplement:44' if MaxNumSig ==1 */
  if (MaxNumSig == 1.0) {
    /* 'DoaEstimatorMUSICSignalImplement:45' [~,idxDoa] = max(spatialSpectrum); */
    i = 1;
    SigThd = spatialSpectrum[0];
    ib = 1;
    if (rtIsNaN(spatialSpectrum[0])) {
      br = 2;
      exitg1 = false;
      while ((!exitg1) && (br < 122)) {
        i = br;
        if (!rtIsNaN(spatialSpectrum[br - 1])) {
          SigThd = spatialSpectrum[br - 1];
          ib = br;
          exitg1 = true;
        } else {
          br++;
        }
      }
    }

    if (i < 121) {
      while (i + 1 < 122) {
        if (spatialSpectrum[i] > SigThd) {
          SigThd = spatialSpectrum[i];
          ib = i + 1;
        }

        i++;
      }
    }

    ar = 1;
    idxDoa_data[0] = ib;

    /* 'DoaEstimatorMUSICSignalImplement:45' ~ */
  } else {
    /* 'DoaEstimatorMUSICSignalImplement:46' else */
    /* 'DoaEstimatorMUSICSignalImplement:47' processSpectrum = spatialSpectrum/max(spatialSpectrum); */
    i = 1;
    SigThd = spatialSpectrum[0];
    if (rtIsNaN(spatialSpectrum[0])) {
      br = 2;
      exitg1 = false;
      while ((!exitg1) && (br < 122)) {
        i = br;
        if (!rtIsNaN(spatialSpectrum[br - 1])) {
          SigThd = spatialSpectrum[br - 1];
          exitg1 = true;
        } else {
          br++;
        }
      }
    }

    if (i < 121) {
      while (i + 1 < 122) {
        if (spatialSpectrum[i] > SigThd) {
          SigThd = spatialSpectrum[i];
        }

        i++;
      }
    }

    /* 'DoaEstimatorMUSICSignalImplement:48' processSpectrum = pow2db(processSpectrum); */
    for (i0 = 0; i0 < 121; i0++) {
      b_spatialSpectrum[i0] = spatialSpectrum[i0] / SigThd;
    }

    pow2db_DoaMusicSignal(b_spatialSpectrum, processSpectrum);

    /* 'DoaEstimatorMUSICSignalImplement:49' processSpectrumExpand = [processSpectrum(2), processSpectrum, processSpectrum(end-1) ]; */
    /*  expand the spectrum so that findpeaks can return peaks at the boundary. */
    /*  peak para. */
    /* 'DoaEstimatorMUSICSignalImplement:51' minPeakHeight = -15; */
    /* 'DoaEstimatorMUSICSignalImplement:52' minPeakProminence = .5; */
    /* 'DoaEstimatorMUSICSignalImplement:53' minPeakDistance = 1/(AzimuthScanAngles(2)-AzimuthScanAngles(1)); */
    /*  degrees / reselution */
    /*  find peaks */
    /* 'DoaEstimatorMUSICSignalImplement:55' [~, idxDoa] = findpeaks(processSpectrumExpand, 'NPeaks', min([MaxNumSig,NumSig]), 'MinPeakProminence', minPeakProminence, 'MinPeakHeight', minPeakHeight, 'MinPeakDistance', minPeakDistance); */
    i = 1;
    SigThd = MaxNumSig;
    if (rtIsNaN(MaxNumSig)) {
      i = 2;
      SigThd = NumSig;
    }

    if ((i < 2) && (NumSig < SigThd)) {
      SigThd = NumSig;
    }

    b_processSpectrum[0] = processSpectrum[1];
    memcpy(&b_processSpectrum[1], &processSpectrum[0], 121U * sizeof(double));
    b_processSpectrum[122] = processSpectrum[119];
    findpeaks_DoaMusicSignal(b_processSpectrum, SigThd, 1.0 /
      (AzimuthScanAngles[1] - AzimuthScanAngles[0]), unusedU2_data,
      unusedU2_size, b_idxDoa_data, idxDoa_size);

    /* 'DoaEstimatorMUSICSignalImplement:55' ~ */
    /* 'DoaEstimatorMUSICSignalImplement:56' idxDoa = idxDoa - 1; */
    ar = idxDoa_size[1];
    ia = idxDoa_size[0] * idxDoa_size[1];
    for (i0 = 0; i0 < ia; i0++) {
      idxDoa_data[i0] = b_idxDoa_data[i0] - 1.0;
    }

    /*  index of processSpectrum and processSpectrumExpand differs 1 point */
    /*  if max is not in the peak list, add max */
    /* 'DoaEstimatorMUSICSignalImplement:58' [~,idxMax] = max(processSpectrum); */
    i = 1;
    SigThd = processSpectrum[0];
    ib = 1;
    if (rtIsNaN(processSpectrum[0])) {
      br = 2;
      exitg1 = false;
      while ((!exitg1) && (br < 122)) {
        i = br;
        if (!rtIsNaN(processSpectrum[br - 1])) {
          SigThd = processSpectrum[br - 1];
          ib = br;
          exitg1 = true;
        } else {
          br++;
        }
      }
    }

    if (i < 121) {
      while (i + 1 < 122) {
        if (processSpectrum[i] > SigThd) {
          SigThd = processSpectrum[i];
          ib = i + 1;
        }

        i++;
      }
    }

    /* 'DoaEstimatorMUSICSignalImplement:58' ~ */
    /* 'DoaEstimatorMUSICSignalImplement:59' if ~sum(idxDoa == idxMax) */
    b_idxDoa_size[0] = 1;
    b_idxDoa_size[1] = idxDoa_size[1];
    ia = idxDoa_size[1];
    for (i0 = 0; i0 < ia; i0++) {
      c_idxDoa_data[i0] = (idxDoa_data[i0] == ib);
    }

    SigThd = c_sum_DoaMusicSignal(c_idxDoa_data, b_idxDoa_size);
    if (!(SigThd != 0.0)) {
      /* 'DoaEstimatorMUSICSignalImplement:60' idxDoa = [idxMax, idxDoa]; */
      itmp_data[0] = ib;
      ia = idxDoa_size[1];
      for (i0 = 0; i0 < ia; i0++) {
        itmp_data[i0 + 1] = idxDoa_data[i0];
      }

      ar = 1 + idxDoa_size[1];
      ia = 1 + idxDoa_size[1];
      for (i0 = 0; i0 < ia; i0++) {
        idxDoa_data[i0] = itmp_data[i0];
      }
    }
  }

  /* 'DoaEstimatorMUSICSignalImplement:63' doas = AzimuthScanAngles(idxDoa); */
  doas_size[0] = ar;
  for (i0 = 0; i0 < ar; i0++) {
    doas_data[i0] = AzimuthScanAngles[(int)idxDoa_data[i0] - 1];
  }
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void DoaEstimatorMUSICSignalImplement_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void DoaEstimatorMUSICSignalImplement_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for DoaEstimatorMUSICSignalImplement.c
 *
 * [EOF]
 */
