/*
 * File: DoaEstimatorMUSICSignalImplement.c
 *
 * MATLAB Coder version            : 3.1
 * C/C++ source code generated on  : 21-Oct-2017 09:32:04
 */

/* Include Files */
#include "rt_nonfinite.h"
#include "DoaEstimatorMUSICSignalImplement.h"

/* Type Definitions */
#ifndef struct_emxArray_int32_T_246_DoaMusicSi
#define struct_emxArray_int32_T_246_DoaMusicSi

struct emxArray_int32_T_246_DoaMusicSi
{
  int data_DoaMusicSignal[246];
  int size_DoaMusicSignal[1];
};

#endif                                 /*struct_emxArray_int32_T_246_DoaMusicSi*/

#ifndef typedef_emxArray_int32_T_246_DoaMusicSi
#define typedef_emxArray_int32_T_246_DoaMusicSi

typedef struct emxArray_int32_T_246_DoaMusicSi emxArray_int32_T_246_DoaMusicSi;

#endif                                 /*typedef_emxArray_int32_T_246_DoaMusicSi*/

/* Function Declarations */
static void abs_DoaMusicSignal(const creal_T x[4], double y[4]);
static void assignFullOutputs_DoaMusicSigna(const double y[123], const double
  iPk_data[], const int iPk_size[1], const double wxPk_data[], const int
  wxPk_size[2], const double bPk_data[], double YpkOut_data[], int YpkOut_size[2],
  double XpkOut_data[], int XpkOut_size[2], double WpkOut_data[], int
  WpkOut_size[2], double PpkOut_data[], int PpkOut_size[2]);
static void b_abs_DoaMusicSignal(const creal_T x[121], double y[121]);
static void b_diff_DoaMusicSignal(const double x_data[], const int x_size[2],
  double y_data[], int y_size[1]);
static void b_do_vectors_DoaMusicSignal(const double a_data[], const int a_size
  [1], const double b_data[], const int b_size[1], double c_data[], int c_size[1],
  int ia_data[], int ia_size[1], int ib_data[], int ib_size[1]);
static void b_merge_DoaMusicSignal(int idx_data[], double x_data[], int offset,
  int np, int nq, int iwork_data[], double xwork_data[]);
static void b_merge_block_DoaMusicSignal(int idx_data[], double x_data[], int n,
  int iwork_data[], double xwork_data[]);
static void b_sortIdx_DoaMusicSignal(double x_data[], int x_size[1], int
  idx_data[], int idx_size[1]);
static void b_sort_DoaMusicSignal(double x[4], int idx[4]);
static void b_sum_DoaMusicSignal(const creal_T x[484], creal_T y[121]);
static void b_xzlartg_DoaMusicSignal(const creal_T f, const creal_T g, double
  *cs, creal_T *sn);
static void c_findPeaksSeparatedByMoreThanM(const double y[123], const double
  iPk_data[], const int iPk_size[1], double Pd, double idx_data[], int idx_size
  [1]);
static void c_merge_DoaMusicSignal(int idx_data[], double x_data[], int offset,
  int np, int nq, int iwork_data[], double xwork_data[]);
static void c_removePeaksBelowMinPeakPromin(const double y[123], double
  iPk_data[], int iPk_size[1], double pbPk_data[], int pbPk_size[1], double
  iLB_data[], int iLB_size[1], double iRB_data[], int iRB_size[1]);
static void c_sort_DoaMusicSignal(double x_data[], int x_size[1], int idx_data[],
  int idx_size[1]);
static double c_sum_DoaMusicSignal(const boolean_T x_data[], const int x_size[2]);
static void combineFullPeaks_DoaMusicSignal(const double y[123], const double
  iPk_data[], const int iPk_size[1], const double bPk_data[], const int
  bPk_size[1], const double iLBw_data[], const int iLBw_size[1], const double
  iRBw_data[], const int iRBw_size[1], const double wPk_data[], const int
  wPk_size[2], const double iInf_data[], const int iInf_size[1], double
  iPkOut_data[], int iPkOut_size[1], double bPkOut_data[], int bPkOut_size[1],
  double bxPkOut_data[], int bxPkOut_size[2], double byPkOut_data[], int
  byPkOut_size[2], double wxPkOut_data[], int wxPkOut_size[2]);
static void d_sort_DoaMusicSignal(double x_data[], int x_size[1], int dim, int
  idx_data[], int idx_size[1]);
static void diff_DoaMusicSignal(const double x_data[], const int x_size[1],
  double y_data[], int y_size[1]);
static void do_vectors_DoaMusicSignal(const double a_data[], const int a_size[1],
  const double b_data[], const int b_size[1], double c_data[], int c_size[1],
  int ia_data[], int ia_size[1], int ib_data[], int ib_size[1]);
static void e_sort_DoaMusicSignal(double x_data[], int x_size[1]);
static void eig_DoaMusicSignal(const creal_T A[16], creal_T V[16], creal_T D[4]);
static void fetchPeakExtents_DoaMusicSignal(const double idx_data[], const int
  idx_size[1], double bPk_data[], int bPk_size[1], double bxPk_data[], int
  bxPk_size[2], double byPk_data[], int byPk_size[2], double wxPk_data[], int
  wxPk_size[2]);
static void findExtents_DoaMusicSignal(const double y[123], double iPk_data[],
  int iPk_size[1], const double iFin_data[], const int iFin_size[1], const
  double iInf_data[], const int iInf_size[1], const double iInflect_data[],
  const int iInflect_size[1], double bPk_data[], int bPk_size[1], double
  bxPk_data[], int bxPk_size[2], double byPk_data[], int byPk_size[2], double
  wxPk_data[], int wxPk_size[2]);
static void findLocalMaxima_DoaMusicSignal(const double yTemp[123], double
  iPk_data[], int iPk_size[1], double iInflect_data[], int iInflect_size[1]);
static void findpeaks_DoaMusicSignal(const double Yin[123], double varargin_2,
  double varargin_8, double Ypk_data[], int Ypk_size[2], double Xpk_data[], int
  Xpk_size[2]);
static void flipud_DoaMusicSignal(double x_data[], int x_size[1]);
static void getAllPeaks_DoaMusicSignal(const double y[123], double iPk_data[],
  int iPk_size[1], double iInf_data[], int iInf_size[1], double iInflect_data[],
  int iInflect_size[1]);
static void getLeftBase_DoaMusicSignal(const double yTemp[123], const double
  iPeak_data[], const int iPeak_size[1], const double iFinite_data[], const int
  iFinite_size[1], const double iInflect_data[], double iBase_data[], int
  iBase_size[1], double iSaddle_data[], int iSaddle_size[1]);
static void getPeakBase_DoaMusicSignal(const double yTemp[123], const double
  iPk_data[], const int iPk_size[1], const double iFin_data[], const int
  iFin_size[1], const double iInflect_data[], const int iInflect_size[1], double
  peakBase_data[], int peakBase_size[1], double iLeftSaddle_data[], int
  iLeftSaddle_size[1], double iRightSaddle_data[], int iRightSaddle_size[1]);
static void getPeakWidth_DoaMusicSignal(const double y[123], const double
  iPk_data[], const int iPk_size[1], const double pbPk_data[], const int
  pbPk_size[1], double iLB_data[], int iLB_size[1], double iRB_data[], int
  iRB_size[1], double wxPk_data[], int wxPk_size[2]);
static void keepAtMostNpPeaks_DoaMusicSigna(int idx_size[1], double Np);
static void merge_DoaMusicSignal(int idx[4], double x[4], int offset, int np,
  int nq, int iwork[4], double xwork[4]);
static void merge_block_DoaMusicSignal(int idx_data[], double x_data[], int n,
  int iwork_data[], double xwork_data[]);
static int nonSingletonDim_DoaMusicSignal(const int x_size[1]);
static void parse_inputs_DoaMusicSignal(const double Yin[123], double varargin_2,
  double varargin_8, double y[123], double *Pd, double *NpOut);
static void pow2db_DoaMusicSignal(const double y[121], double ydB[121]);
static void removePeaksBelowMinPeakHeight_D(const double Y[123], double
  iPk_data[], int iPk_size[1]);
static void removePeaksBelowThreshold_DoaMu(const double Y[123], double
  iPk_data[], int iPk_size[1]);
static double rt_hypotd_snf_DoaMusicSignal(double u0, double u1);
static void sign_DoaMusicSignal(double x_data[], int x_size[1]);
static double skip_to_last_equal_value_DoaMus(int *k, const double x_data[],
  const int x_size[1]);
static void sortIdx_DoaMusicSignal(double x_data[], int x_size[1], int idx_data[],
  int idx_size[1]);
static void sort_DoaMusicSignal(double x[4], int idx[4]);
static void sqrt_DoaMusicSignal(creal_T *x);
static double sum_DoaMusicSignal(const double x[4]);
static void xzggev_DoaMusicSignal(creal_T A[16], int *info, creal_T alpha1[4],
  creal_T beta1[4], creal_T V[16]);
static void xzhgeqz_DoaMusicSignal(creal_T A[16], int ilo, int ihi, creal_T Z[16],
  int *info, creal_T alpha1[4], creal_T beta1[4]);
static double xzlangeM_DoaMusicSignal(const creal_T x[16]);
static void xzlartg_DoaMusicSignal(const creal_T f, const creal_T g, double *cs,
  creal_T *sn, creal_T *r);
static void xztgevc_DoaMusicSignal(const creal_T A[16], creal_T V[16]);

/* Function Definitions */

/*
 * Arguments    : const creal_T x[4]
 *                double y[4]
 * Return Type  : void
 */
static void abs_DoaMusicSignal(const creal_T x[4], double y[4])
{
  int k;
  for (k = 0; k < 4; k++) {
    y[k] = rt_hypotd_snf_DoaMusicSignal(x[k].re, x[k].im);
  }
}

/*
 * Arguments    : const double y[123]
 *                const double iPk_data[]
 *                const int iPk_size[1]
 *                const double wxPk_data[]
 *                const int wxPk_size[2]
 *                const double bPk_data[]
 *                double YpkOut_data[]
 *                int YpkOut_size[2]
 *                double XpkOut_data[]
 *                int XpkOut_size[2]
 *                double WpkOut_data[]
 *                int WpkOut_size[2]
 *                double PpkOut_data[]
 *                int PpkOut_size[2]
 * Return Type  : void
 */
static void assignFullOutputs_DoaMusicSigna(const double y[123], const double
  iPk_data[], const int iPk_size[1], const double wxPk_data[], const int
  wxPk_size[2], const double bPk_data[], double YpkOut_data[], int YpkOut_size[2],
  double XpkOut_data[], int XpkOut_size[2], double WpkOut_data[], int
  WpkOut_size[2], double PpkOut_data[], int PpkOut_size[2])
{
  int loop_ub;
  int i8;
  double Wpk_data[246];
  int Wpk_size[1];
  double Ypk_data[246];
  loop_ub = iPk_size[0];
  for (i8 = 0; i8 < loop_ub; i8++) {
    Ypk_data[i8] = y[(int)iPk_data[i8] - 1];
  }

  b_diff_DoaMusicSignal(wxPk_data, wxPk_size, Wpk_data, Wpk_size);
  YpkOut_size[0] = 1;
  YpkOut_size[1] = iPk_size[0];
  loop_ub = iPk_size[0];
  for (i8 = 0; i8 < loop_ub; i8++) {
    YpkOut_data[i8] = Ypk_data[i8];
  }

  PpkOut_size[0] = 1;
  PpkOut_size[1] = iPk_size[0];
  loop_ub = iPk_size[0];
  for (i8 = 0; i8 < loop_ub; i8++) {
    PpkOut_data[i8] = Ypk_data[i8] - bPk_data[i8];
  }

  XpkOut_size[0] = 1;
  XpkOut_size[1] = iPk_size[0];
  loop_ub = iPk_size[0];
  for (i8 = 0; i8 < loop_ub; i8++) {
    XpkOut_data[i8] = 1.0 + (double)((int)iPk_data[i8] - 1);
  }

  WpkOut_size[0] = 1;
  WpkOut_size[1] = Wpk_size[0];
  loop_ub = Wpk_size[0];
  for (i8 = 0; i8 < loop_ub; i8++) {
    WpkOut_data[i8] = Wpk_data[i8];
  }
}

/*
 * Arguments    : const creal_T x[121]
 *                double y[121]
 * Return Type  : void
 */
static void b_abs_DoaMusicSignal(const creal_T x[121], double y[121])
{
  int k;
  for (k = 0; k < 121; k++) {
    y[k] = rt_hypotd_snf_DoaMusicSignal(x[k].re, x[k].im);
  }
}

/*
 * Arguments    : const double x_data[]
 *                const int x_size[2]
 *                double y_data[]
 *                int y_size[1]
 * Return Type  : void
 */
static void b_diff_DoaMusicSignal(const double x_data[], const int x_size[2],
  double y_data[], int y_size[1])
{
  int stride;
  int ix;
  int iy;
  int s;
  y_size[0] = (unsigned char)x_size[0];
  if (!((unsigned char)x_size[0] == 0)) {
    stride = x_size[0];
    ix = 0;
    iy = 0;
    for (s = 1; s <= stride; s++) {
      y_data[iy] = x_data[ix + stride] - x_data[ix];
      ix++;
      iy++;
    }
  }
}

/*
 * Arguments    : const double a_data[]
 *                const int a_size[1]
 *                const double b_data[]
 *                const int b_size[1]
 *                double c_data[]
 *                int c_size[1]
 *                int ia_data[]
 *                int ia_size[1]
 *                int ib_data[]
 *                int ib_size[1]
 * Return Type  : void
 */
static void b_do_vectors_DoaMusicSignal(const double a_data[], const int a_size
  [1], const double b_data[], const int b_size[1], double c_data[], int c_size[1],
  int ia_data[], int ia_size[1], int ib_data[], int ib_size[1])
{
  int ncmax;
  int nc;
  int iafirst;
  int ialast;
  int ibfirst;
  int iblast;
  int b_ialast;
  double ak;
  int b_iblast;
  int b_ia_data[123];
  double bk;
  double absxk;
  double b_c_data[123];
  int exponent;
  boolean_T p;
  if (a_size[0] <= b_size[0]) {
    ncmax = a_size[0];
  } else {
    ncmax = b_size[0];
  }

  c_size[0] = (signed char)ncmax;
  ia_size[0] = ncmax;
  ib_size[0] = ncmax;
  nc = 0;
  iafirst = 0;
  ialast = 1;
  ibfirst = 0;
  iblast = 1;
  while ((ialast <= a_size[0]) && (iblast <= b_size[0])) {
    b_ialast = ialast;
    ak = skip_to_last_equal_value_DoaMus(&b_ialast, a_data, a_size);
    ialast = b_ialast;
    b_iblast = iblast;
    bk = skip_to_last_equal_value_DoaMus(&b_iblast, b_data, b_size);
    iblast = b_iblast;
    absxk = fabs(bk / 2.0);
    if ((!rtIsInf(absxk)) && (!rtIsNaN(absxk))) {
      if (absxk <= 2.2250738585072014E-308) {
        absxk = 4.94065645841247E-324;
      } else {
        frexp(absxk, &exponent);
        absxk = ldexp(1.0, exponent - 53);
      }
    } else {
      absxk = rtNaN;
    }

    if ((fabs(bk - ak) < absxk) || (rtIsInf(ak) && rtIsInf(bk) && ((ak > 0.0) ==
          (bk > 0.0)))) {
      p = true;
    } else {
      p = false;
    }

    if (p) {
      nc++;
      c_data[nc - 1] = ak;
      ia_data[nc - 1] = iafirst + 1;
      ib_data[nc - 1] = ibfirst + 1;
      ialast = b_ialast + 1;
      iafirst = b_ialast;
      iblast = b_iblast + 1;
      ibfirst = b_iblast;
    } else {
      if ((ak < bk) || rtIsNaN(bk)) {
        p = true;
      } else {
        p = false;
      }

      if (p) {
        ialast = b_ialast + 1;
        iafirst = b_ialast;
      } else {
        iblast = b_iblast + 1;
        ibfirst = b_iblast;
      }
    }
  }

  if (ncmax > 0) {
    if (1 > nc) {
      iafirst = 0;
    } else {
      iafirst = nc;
    }

    for (ialast = 0; ialast < iafirst; ialast++) {
      b_ia_data[ialast] = ia_data[ialast];
    }

    ia_size[0] = iafirst;
    for (ialast = 0; ialast < iafirst; ialast++) {
      ia_data[ialast] = b_ia_data[ialast];
    }
  }

  if (ncmax > 0) {
    if (1 > nc) {
      iafirst = 0;
    } else {
      iafirst = nc;
    }

    for (ialast = 0; ialast < iafirst; ialast++) {
      b_ia_data[ialast] = ib_data[ialast];
    }

    ib_size[0] = iafirst;
    for (ialast = 0; ialast < iafirst; ialast++) {
      ib_data[ialast] = b_ia_data[ialast];
    }
  }

  if (ncmax > 0) {
    if (1 > nc) {
      iafirst = 0;
    } else {
      iafirst = nc;
    }

    for (ialast = 0; ialast < iafirst; ialast++) {
      b_c_data[ialast] = c_data[ialast];
    }

    c_size[0] = iafirst;
    for (ialast = 0; ialast < iafirst; ialast++) {
      c_data[ialast] = b_c_data[ialast];
    }
  }
}

/*
 * Arguments    : int idx_data[]
 *                double x_data[]
 *                int offset
 *                int np
 *                int nq
 *                int iwork_data[]
 *                double xwork_data[]
 * Return Type  : void
 */
static void b_merge_DoaMusicSignal(int idx_data[], double x_data[], int offset,
  int np, int nq, int iwork_data[], double xwork_data[])
{
  int n;
  int qend;
  int p;
  int iout;
  int exitg1;
  if (nq == 0) {
  } else {
    n = np + nq;
    for (qend = 0; qend + 1 <= n; qend++) {
      iwork_data[qend] = idx_data[offset + qend];
      xwork_data[qend] = x_data[offset + qend];
    }

    p = 0;
    n = np;
    qend = np + nq;
    iout = offset - 1;
    do {
      exitg1 = 0;
      iout++;
      if (xwork_data[p] >= xwork_data[n]) {
        idx_data[iout] = iwork_data[p];
        x_data[iout] = xwork_data[p];
        if (p + 1 < np) {
          p++;
        } else {
          exitg1 = 1;
        }
      } else {
        idx_data[iout] = iwork_data[n];
        x_data[iout] = xwork_data[n];
        if (n + 1 < qend) {
          n++;
        } else {
          n = (iout - p) + 1;
          while (p + 1 <= np) {
            idx_data[n + p] = iwork_data[p];
            x_data[n + p] = xwork_data[p];
            p++;
          }

          exitg1 = 1;
        }
      }
    } while (exitg1 == 0);
  }
}

/*
 * Arguments    : int idx_data[]
 *                double x_data[]
 *                int n
 *                int iwork_data[]
 *                double xwork_data[]
 * Return Type  : void
 */
static void b_merge_block_DoaMusicSignal(int idx_data[], double x_data[], int n,
  int iwork_data[], double xwork_data[])
{
  int nPairs;
  int bLen;
  int tailOffset;
  int nTail;
  nPairs = n >> 2;
  bLen = 4;
  while (nPairs > 1) {
    if ((nPairs & 1) != 0) {
      nPairs--;
      tailOffset = bLen * nPairs;
      nTail = n - tailOffset;
      if (nTail > bLen) {
        c_merge_DoaMusicSignal(idx_data, x_data, tailOffset, bLen, nTail - bLen,
          iwork_data, xwork_data);
      }
    }

    tailOffset = bLen << 1;
    nPairs >>= 1;
    for (nTail = 1; nTail <= nPairs; nTail++) {
      c_merge_DoaMusicSignal(idx_data, x_data, (nTail - 1) * tailOffset, bLen,
        bLen, iwork_data, xwork_data);
    }

    bLen = tailOffset;
  }

  if (n > bLen) {
    c_merge_DoaMusicSignal(idx_data, x_data, 0, bLen, n - bLen, iwork_data,
      xwork_data);
  }
}

/*
 * Arguments    : double x_data[]
 *                int x_size[1]
 *                int idx_data[]
 *                int idx_size[1]
 * Return Type  : void
 */
static void b_sortIdx_DoaMusicSignal(double x_data[], int x_size[1], int
  idx_data[], int idx_size[1])
{
  unsigned char unnamed_idx_0;
  int x_size_idx_0;
  int m;
  int ib;
  double b_x_data[246];
  int n;
  double x4[4];
  unsigned char idx4[4];
  int iwork_data[246];
  int nNaNs;
  double xwork_data[246];
  int k;
  int wOffset;
  signed char perm[4];
  int i3;
  int i4;
  unnamed_idx_0 = (unsigned char)x_size[0];
  x_size_idx_0 = x_size[0];
  m = x_size[0];
  for (ib = 0; ib < m; ib++) {
    b_x_data[ib] = x_data[ib];
  }

  idx_size[0] = unnamed_idx_0;
  m = unnamed_idx_0;
  for (ib = 0; ib < m; ib++) {
    idx_data[ib] = 0;
  }

  n = x_size[0];
  for (m = 0; m < 4; m++) {
    x4[m] = 0.0;
    idx4[m] = 0;
  }

  m = unnamed_idx_0;
  for (ib = 0; ib < m; ib++) {
    iwork_data[ib] = 0;
  }

  m = (unsigned char)x_size[0];
  for (ib = 0; ib < m; ib++) {
    xwork_data[ib] = 0.0;
  }

  nNaNs = 1;
  ib = 0;
  for (k = 0; k + 1 <= n; k++) {
    if (rtIsNaN(b_x_data[k])) {
      idx_data[n - nNaNs] = k + 1;
      xwork_data[n - nNaNs] = b_x_data[k];
      nNaNs++;
    } else {
      ib++;
      idx4[ib - 1] = (unsigned char)(k + 1);
      x4[ib - 1] = b_x_data[k];
      if (ib == 4) {
        ib = k - nNaNs;
        if (x4[0] <= x4[1]) {
          m = 1;
          wOffset = 2;
        } else {
          m = 2;
          wOffset = 1;
        }

        if (x4[2] <= x4[3]) {
          i3 = 3;
          i4 = 4;
        } else {
          i3 = 4;
          i4 = 3;
        }

        if (x4[m - 1] <= x4[i3 - 1]) {
          if (x4[wOffset - 1] <= x4[i3 - 1]) {
            perm[0] = (signed char)m;
            perm[1] = (signed char)wOffset;
            perm[2] = (signed char)i3;
            perm[3] = (signed char)i4;
          } else if (x4[wOffset - 1] <= x4[i4 - 1]) {
            perm[0] = (signed char)m;
            perm[1] = (signed char)i3;
            perm[2] = (signed char)wOffset;
            perm[3] = (signed char)i4;
          } else {
            perm[0] = (signed char)m;
            perm[1] = (signed char)i3;
            perm[2] = (signed char)i4;
            perm[3] = (signed char)wOffset;
          }
        } else if (x4[m - 1] <= x4[i4 - 1]) {
          if (x4[wOffset - 1] <= x4[i4 - 1]) {
            perm[0] = (signed char)i3;
            perm[1] = (signed char)m;
            perm[2] = (signed char)wOffset;
            perm[3] = (signed char)i4;
          } else {
            perm[0] = (signed char)i3;
            perm[1] = (signed char)m;
            perm[2] = (signed char)i4;
            perm[3] = (signed char)wOffset;
          }
        } else {
          perm[0] = (signed char)i3;
          perm[1] = (signed char)i4;
          perm[2] = (signed char)m;
          perm[3] = (signed char)wOffset;
        }

        idx_data[ib - 2] = idx4[perm[0] - 1];
        idx_data[ib - 1] = idx4[perm[1] - 1];
        idx_data[ib] = idx4[perm[2] - 1];
        idx_data[ib + 1] = idx4[perm[3] - 1];
        b_x_data[ib - 2] = x4[perm[0] - 1];
        b_x_data[ib - 1] = x4[perm[1] - 1];
        b_x_data[ib] = x4[perm[2] - 1];
        b_x_data[ib + 1] = x4[perm[3] - 1];
        ib = 0;
      }
    }
  }

  wOffset = x_size[0] - nNaNs;
  if (ib > 0) {
    for (m = 0; m < 4; m++) {
      perm[m] = 0;
    }

    switch (ib) {
     case 1:
      perm[0] = 1;
      break;

     case 2:
      if (x4[0] <= x4[1]) {
        perm[0] = 1;
        perm[1] = 2;
      } else {
        perm[0] = 2;
        perm[1] = 1;
      }
      break;

     default:
      if (x4[0] <= x4[1]) {
        if (x4[1] <= x4[2]) {
          perm[0] = 1;
          perm[1] = 2;
          perm[2] = 3;
        } else if (x4[0] <= x4[2]) {
          perm[0] = 1;
          perm[1] = 3;
          perm[2] = 2;
        } else {
          perm[0] = 3;
          perm[1] = 1;
          perm[2] = 2;
        }
      } else if (x4[0] <= x4[2]) {
        perm[0] = 2;
        perm[1] = 1;
        perm[2] = 3;
      } else if (x4[1] <= x4[2]) {
        perm[0] = 2;
        perm[1] = 3;
        perm[2] = 1;
      } else {
        perm[0] = 3;
        perm[1] = 2;
        perm[2] = 1;
      }
      break;
    }

    for (k = 1; k <= ib; k++) {
      idx_data[(wOffset - ib) + k] = idx4[perm[k - 1] - 1];
      b_x_data[(wOffset - ib) + k] = x4[perm[k - 1] - 1];
    }
  }

  m = (nNaNs - 1) >> 1;
  for (k = 1; k <= m; k++) {
    ib = idx_data[wOffset + k];
    idx_data[wOffset + k] = idx_data[n - k];
    idx_data[n - k] = ib;
    b_x_data[wOffset + k] = xwork_data[n - k];
    b_x_data[n - k] = xwork_data[wOffset + k];
  }

  if (((nNaNs - 1) & 1) != 0) {
    b_x_data[(wOffset + m) + 1] = xwork_data[(wOffset + m) + 1];
  }

  m = (x_size[0] - nNaNs) + 1;
  if (m > 1) {
    b_merge_block_DoaMusicSignal(idx_data, b_x_data, m, iwork_data, xwork_data);
  }

  x_size[0] = x_size_idx_0;
  for (ib = 0; ib < x_size_idx_0; ib++) {
    x_data[ib] = b_x_data[ib];
  }
}

/*
 * Arguments    : double x[4]
 *                int idx[4]
 * Return Type  : void
 */
static void b_sort_DoaMusicSignal(double x[4], int idx[4])
{
  double x4[4];
  int idx4[4];
  double xwork[4];
  int m;
  int nNaNs;
  int ib;
  int k;
  signed char perm[4];
  int bLen;
  int nPairs;
  int i4;
  for (m = 0; m < 4; m++) {
    idx[m] = 0;
    x4[m] = 0.0;
    idx4[m] = 0;
    xwork[m] = 0.0;
  }

  nNaNs = -3;
  ib = 0;
  for (k = 0; k < 4; k++) {
    if (rtIsNaN(x[k])) {
      idx[-nNaNs] = k + 1;
      xwork[-nNaNs] = x[k];
      nNaNs++;
    } else {
      ib++;
      idx4[ib - 1] = k + 1;
      x4[ib - 1] = x[k];
      if (ib == 4) {
        ib = (k - nNaNs) - 6;
        if (x4[0] <= x4[1]) {
          m = 1;
          bLen = 2;
        } else {
          m = 2;
          bLen = 1;
        }

        if (x4[2] <= x4[3]) {
          nPairs = 3;
          i4 = 4;
        } else {
          nPairs = 4;
          i4 = 3;
        }

        if (x4[m - 1] <= x4[nPairs - 1]) {
          if (x4[bLen - 1] <= x4[nPairs - 1]) {
            perm[0] = (signed char)m;
            perm[1] = (signed char)bLen;
            perm[2] = (signed char)nPairs;
            perm[3] = (signed char)i4;
          } else if (x4[bLen - 1] <= x4[i4 - 1]) {
            perm[0] = (signed char)m;
            perm[1] = (signed char)nPairs;
            perm[2] = (signed char)bLen;
            perm[3] = (signed char)i4;
          } else {
            perm[0] = (signed char)m;
            perm[1] = (signed char)nPairs;
            perm[2] = (signed char)i4;
            perm[3] = (signed char)bLen;
          }
        } else if (x4[m - 1] <= x4[i4 - 1]) {
          if (x4[bLen - 1] <= x4[i4 - 1]) {
            perm[0] = (signed char)nPairs;
            perm[1] = (signed char)m;
            perm[2] = (signed char)bLen;
            perm[3] = (signed char)i4;
          } else {
            perm[0] = (signed char)nPairs;
            perm[1] = (signed char)m;
            perm[2] = (signed char)i4;
            perm[3] = (signed char)bLen;
          }
        } else {
          perm[0] = (signed char)nPairs;
          perm[1] = (signed char)i4;
          perm[2] = (signed char)m;
          perm[3] = (signed char)bLen;
        }

        idx[ib] = idx4[perm[0] - 1];
        idx[ib + 1] = idx4[perm[1] - 1];
        idx[ib + 2] = idx4[perm[2] - 1];
        idx[ib + 3] = idx4[perm[3] - 1];
        x[ib] = x4[perm[0] - 1];
        x[ib + 1] = x4[perm[1] - 1];
        x[ib + 2] = x4[perm[2] - 1];
        x[ib + 3] = x4[perm[3] - 1];
        ib = 0;
      }
    }
  }

  if (ib > 0) {
    for (m = 0; m < 4; m++) {
      perm[m] = 0;
    }

    switch (ib) {
     case 1:
      perm[0] = 1;
      break;

     case 2:
      if (x4[0] <= x4[1]) {
        perm[0] = 1;
        perm[1] = 2;
      } else {
        perm[0] = 2;
        perm[1] = 1;
      }
      break;

     default:
      if (x4[0] <= x4[1]) {
        if (x4[1] <= x4[2]) {
          perm[0] = 1;
          perm[1] = 2;
          perm[2] = 3;
        } else if (x4[0] <= x4[2]) {
          perm[0] = 1;
          perm[1] = 3;
          perm[2] = 2;
        } else {
          perm[0] = 3;
          perm[1] = 1;
          perm[2] = 2;
        }
      } else if (x4[0] <= x4[2]) {
        perm[0] = 2;
        perm[1] = 1;
        perm[2] = 3;
      } else if (x4[1] <= x4[2]) {
        perm[0] = 2;
        perm[1] = 3;
        perm[2] = 1;
      } else {
        perm[0] = 3;
        perm[1] = 2;
        perm[2] = 1;
      }
      break;
    }

    for (k = 1; k <= ib; k++) {
      idx[(k - nNaNs) - ib] = idx4[perm[k - 1] - 1];
      x[(k - nNaNs) - ib] = x4[perm[k - 1] - 1];
    }
  }

  m = (nNaNs + 3) >> 1;
  for (k = 1; k <= m; k++) {
    ib = idx[k - nNaNs];
    idx[k - nNaNs] = idx[4 - k];
    idx[4 - k] = ib;
    x[k - nNaNs] = xwork[4 - k];
    x[4 - k] = xwork[k - nNaNs];
  }

  if (((nNaNs + 3) & 1) != 0) {
    x[(m - nNaNs) + 1] = xwork[(m - nNaNs) + 1];
  }

  if (1 - nNaNs > 1) {
    for (m = 0; m < 4; m++) {
      idx4[m] = 0;
    }

    nPairs = (1 - nNaNs) >> 2;
    bLen = 4;
    while (nPairs > 1) {
      if ((nPairs & 1) != 0) {
        nPairs--;
        ib = bLen * nPairs;
        m = 1 - (nNaNs + ib);
        if (m > bLen) {
          merge_DoaMusicSignal(idx, x, ib, bLen, m - bLen, idx4, xwork);
        }
      }

      ib = bLen << 1;
      nPairs >>= 1;
      for (k = 1; k <= nPairs; k++) {
        merge_DoaMusicSignal(idx, x, (k - 1) * ib, bLen, bLen, idx4, xwork);
      }

      bLen = ib;
    }

    if (1 - nNaNs > bLen) {
      merge_DoaMusicSignal(idx, x, 0, bLen, 1 - (nNaNs + bLen), idx4, xwork);
    }
  }
}

/*
 * Arguments    : const creal_T x[484]
 *                creal_T y[121]
 * Return Type  : void
 */
static void b_sum_DoaMusicSignal(const creal_T x[484], creal_T y[121])
{
  int i;
  int xoffset;
  double s_re;
  double s_im;
  int k;
  for (i = 0; i < 121; i++) {
    xoffset = i << 2;
    s_re = x[xoffset].re;
    s_im = x[xoffset].im;
    for (k = 0; k < 3; k++) {
      s_re += x[(xoffset + k) + 1].re;
      s_im += x[(xoffset + k) + 1].im;
    }

    y[i].re = s_re;
    y[i].im = s_im;
  }
}

/*
 * Arguments    : const creal_T f
 *                const creal_T g
 *                double *cs
 *                creal_T *sn
 * Return Type  : void
 */
static void b_xzlartg_DoaMusicSignal(const creal_T f, const creal_T g, double
  *cs, creal_T *sn)
{
  double scale;
  double g2;
  double f2s;
  double fs_re;
  double fs_im;
  double gs_re;
  double gs_im;
  boolean_T guard1 = false;
  double g2s;
  double d;
  scale = fabs(f.re);
  g2 = fabs(f.im);
  if (g2 > scale) {
    scale = g2;
  }

  f2s = fabs(g.re);
  g2 = fabs(g.im);
  if (g2 > f2s) {
    f2s = g2;
  }

  if (f2s > scale) {
    scale = f2s;
  }

  fs_re = f.re;
  fs_im = f.im;
  gs_re = g.re;
  gs_im = g.im;
  guard1 = false;
  if (scale >= 7.4428285367870146E+137) {
    do {
      fs_re *= 1.3435752215134178E-138;
      fs_im *= 1.3435752215134178E-138;
      gs_re *= 1.3435752215134178E-138;
      gs_im *= 1.3435752215134178E-138;
      scale *= 1.3435752215134178E-138;
    } while (!(scale < 7.4428285367870146E+137));

    guard1 = true;
  } else if (scale <= 1.3435752215134178E-138) {
    if ((g.re == 0.0) && (g.im == 0.0)) {
      *cs = 1.0;
      sn->re = 0.0;
      sn->im = 0.0;
    } else {
      do {
        fs_re *= 7.4428285367870146E+137;
        fs_im *= 7.4428285367870146E+137;
        gs_re *= 7.4428285367870146E+137;
        gs_im *= 7.4428285367870146E+137;
        scale *= 7.4428285367870146E+137;
      } while (!(scale > 1.3435752215134178E-138));

      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1) {
    scale = fs_re * fs_re + fs_im * fs_im;
    g2 = gs_re * gs_re + gs_im * gs_im;
    f2s = g2;
    if (1.0 > g2) {
      f2s = 1.0;
    }

    if (scale <= f2s * 2.0041683600089728E-292) {
      if ((f.re == 0.0) && (f.im == 0.0)) {
        *cs = 0.0;
        d = rt_hypotd_snf_DoaMusicSignal(gs_re, gs_im);
        sn->re = gs_re / d;
        sn->im = -gs_im / d;
      } else {
        g2s = sqrt(g2);
        *cs = rt_hypotd_snf_DoaMusicSignal(fs_re, fs_im) / g2s;
        f2s = fabs(f.re);
        g2 = fabs(f.im);
        if (g2 > f2s) {
          f2s = g2;
        }

        if (f2s > 1.0) {
          d = rt_hypotd_snf_DoaMusicSignal(f.re, f.im);
          fs_re = f.re / d;
          fs_im = f.im / d;
        } else {
          g2 = 7.4428285367870146E+137 * f.re;
          scale = 7.4428285367870146E+137 * f.im;
          d = rt_hypotd_snf_DoaMusicSignal(g2, scale);
          fs_re = g2 / d;
          fs_im = scale / d;
        }

        gs_re /= g2s;
        gs_im = -gs_im / g2s;
        sn->re = fs_re * gs_re - fs_im * gs_im;
        sn->im = fs_re * gs_im + fs_im * gs_re;
      }
    } else {
      f2s = sqrt(1.0 + g2 / scale);
      *cs = 1.0 / f2s;
      d = scale + g2;
      fs_re = f2s * fs_re / d;
      fs_im = f2s * fs_im / d;
      sn->re = fs_re * gs_re - fs_im * -gs_im;
      sn->im = fs_re * -gs_im + fs_im * gs_re;
    }
  }
}

/*
 * Arguments    : const double y[123]
 *                const double iPk_data[]
 *                const int iPk_size[1]
 *                double Pd
 *                double idx_data[]
 *                int idx_size[1]
 * Return Type  : void
 */
static void c_findPeaksSeparatedByMoreThanM(const double y[123], const double
  iPk_data[], const int iPk_size[1], double Pd, double idx_data[], int idx_size
  [1])
{
  int cdiff;
  int i7;
  int ndbl;
  int apnd;
  int locs_temp_size[1];
  double locs_data[246];
  double locs_temp_data[246];
  int iidx_data[246];
  int iidx_size[1];
  int k;
  int sortIdx_data[246];
  boolean_T idelete_data[246];
  double locs;
  double b_locs;
  boolean_T tmp_data[246];
  if ((iPk_size[0] == 0) || (Pd == 0.0)) {
    if (iPk_size[0] < 1) {
      ndbl = 0;
      apnd = 0;
    } else {
      ndbl = (int)floor(((double)iPk_size[0] - 1.0) + 0.5);
      apnd = ndbl + 1;
      cdiff = (ndbl - iPk_size[0]) + 1;
      if (fabs(cdiff) < 4.4408920985006262E-16 * (double)iPk_size[0]) {
        ndbl++;
        apnd = iPk_size[0];
      } else if (cdiff > 0) {
        apnd = ndbl;
      } else {
        ndbl++;
      }
    }

    if (ndbl > 0) {
      locs_temp_data[0] = 1.0;
      if (ndbl > 1) {
        locs_temp_data[ndbl - 1] = apnd;
        cdiff = (ndbl - 1) / 2;
        for (k = 1; k < cdiff; k++) {
          locs_temp_data[k] = 1.0 + (double)k;
          locs_temp_data[(ndbl - k) - 1] = apnd - k;
        }

        if (cdiff << 1 == ndbl - 1) {
          locs_temp_data[cdiff] = (1.0 + (double)apnd) / 2.0;
        } else {
          locs_temp_data[cdiff] = 1.0 + (double)cdiff;
          locs_temp_data[cdiff + 1] = apnd - cdiff;
        }
      }
    }

    idx_size[0] = ndbl;
    for (i7 = 0; i7 < ndbl; i7++) {
      idx_data[i7] = locs_temp_data[i7];
    }
  } else {
    cdiff = iPk_size[0];
    for (i7 = 0; i7 < cdiff; i7++) {
      locs_data[i7] = 1.0 + (double)((int)iPk_data[i7] - 1);
    }

    locs_temp_size[0] = iPk_size[0];
    cdiff = iPk_size[0];
    for (i7 = 0; i7 < cdiff; i7++) {
      locs_temp_data[i7] = y[(int)iPk_data[i7] - 1];
    }

    c_sort_DoaMusicSignal(locs_temp_data, locs_temp_size, iidx_data, iidx_size);
    k = iidx_size[0];
    cdiff = iidx_size[0];
    for (i7 = 0; i7 < cdiff; i7++) {
      sortIdx_data[i7] = iidx_data[i7];
    }

    cdiff = iidx_size[0];
    for (i7 = 0; i7 < cdiff; i7++) {
      locs_temp_data[i7] = locs_data[sortIdx_data[i7] - 1];
    }

    cdiff = (unsigned char)iidx_size[0];
    for (i7 = 0; i7 < cdiff; i7++) {
      idelete_data[i7] = false;
    }

    for (ndbl = 0; ndbl < k; ndbl++) {
      if (!idelete_data[ndbl]) {
        locs = locs_data[sortIdx_data[ndbl] - 1] - Pd;
        b_locs = locs_data[sortIdx_data[ndbl] - 1] + Pd;
        for (i7 = 0; i7 < k; i7++) {
          tmp_data[i7] = ((locs_temp_data[i7] >= locs) && (locs_temp_data[i7] <=
            b_locs));
        }

        cdiff = (unsigned char)k;
        for (i7 = 0; i7 < cdiff; i7++) {
          idelete_data[i7] = (idelete_data[i7] || tmp_data[i7]);
        }

        idelete_data[ndbl] = false;
      }
    }

    cdiff = (unsigned char)iidx_size[0] - 1;
    apnd = 0;
    for (ndbl = 0; ndbl <= cdiff; ndbl++) {
      if (!idelete_data[ndbl]) {
        apnd++;
      }
    }

    k = 0;
    for (ndbl = 0; ndbl <= cdiff; ndbl++) {
      if (!idelete_data[ndbl]) {
        iidx_data[k] = ndbl + 1;
        k++;
      }
    }

    idx_size[0] = apnd;
    for (i7 = 0; i7 < apnd; i7++) {
      idx_data[i7] = sortIdx_data[iidx_data[i7] - 1];
    }

    e_sort_DoaMusicSignal(idx_data, idx_size);
  }
}

/*
 * Arguments    : int idx_data[]
 *                double x_data[]
 *                int offset
 *                int np
 *                int nq
 *                int iwork_data[]
 *                double xwork_data[]
 * Return Type  : void
 */
static void c_merge_DoaMusicSignal(int idx_data[], double x_data[], int offset,
  int np, int nq, int iwork_data[], double xwork_data[])
{
  int n;
  int qend;
  int p;
  int iout;
  int exitg1;
  if (nq == 0) {
  } else {
    n = np + nq;
    for (qend = 0; qend + 1 <= n; qend++) {
      iwork_data[qend] = idx_data[offset + qend];
      xwork_data[qend] = x_data[offset + qend];
    }

    p = 0;
    n = np;
    qend = np + nq;
    iout = offset - 1;
    do {
      exitg1 = 0;
      iout++;
      if (xwork_data[p] <= xwork_data[n]) {
        idx_data[iout] = iwork_data[p];
        x_data[iout] = xwork_data[p];
        if (p + 1 < np) {
          p++;
        } else {
          exitg1 = 1;
        }
      } else {
        idx_data[iout] = iwork_data[n];
        x_data[iout] = xwork_data[n];
        if (n + 1 < qend) {
          n++;
        } else {
          n = (iout - p) + 1;
          while (p + 1 <= np) {
            idx_data[n + p] = iwork_data[p];
            x_data[n + p] = xwork_data[p];
            p++;
          }

          exitg1 = 1;
        }
      }
    } while (exitg1 == 0);
  }
}

/*
 * Arguments    : const double y[123]
 *                double iPk_data[]
 *                int iPk_size[1]
 *                double pbPk_data[]
 *                int pbPk_size[1]
 *                double iLB_data[]
 *                int iLB_size[1]
 *                double iRB_data[]
 *                int iRB_size[1]
 * Return Type  : void
 */
static void c_removePeaksBelowMinPeakPromin(const double y[123], double
  iPk_data[], int iPk_size[1], double pbPk_data[], int pbPk_size[1], double
  iLB_data[], int iLB_size[1], double iRB_data[], int iRB_size[1])
{
  int x_size_idx_0;
  int idx;
  int ii;
  boolean_T x_data[123];
  int ii_data[123];
  boolean_T exitg1;
  boolean_T guard1 = false;
  double b_iPk_data[123];
  int idx_data[123];
  x_size_idx_0 = iPk_size[0];
  idx = iPk_size[0];
  for (ii = 0; ii < idx; ii++) {
    x_data[ii] = (y[(int)iPk_data[ii] - 1] - pbPk_data[ii] >= 0.5);
  }

  idx = 0;
  ii = 1;
  exitg1 = false;
  while ((!exitg1) && (ii <= x_size_idx_0)) {
    guard1 = false;
    if (x_data[ii - 1]) {
      idx++;
      ii_data[idx - 1] = ii;
      if (idx >= x_size_idx_0) {
        exitg1 = true;
      } else {
        guard1 = true;
      }
    } else {
      guard1 = true;
    }

    if (guard1) {
      ii++;
    }
  }

  if (x_size_idx_0 == 1) {
    if (idx == 0) {
      x_size_idx_0 = 0;
    }
  } else if (1 > idx) {
    x_size_idx_0 = 0;
  } else {
    x_size_idx_0 = idx;
  }

  for (ii = 0; ii < x_size_idx_0; ii++) {
    idx_data[ii] = ii_data[ii];
  }

  for (ii = 0; ii < x_size_idx_0; ii++) {
    b_iPk_data[ii] = iPk_data[idx_data[ii] - 1];
  }

  iPk_size[0] = x_size_idx_0;
  for (ii = 0; ii < x_size_idx_0; ii++) {
    iPk_data[ii] = b_iPk_data[ii];
  }

  for (ii = 0; ii < x_size_idx_0; ii++) {
    b_iPk_data[ii] = pbPk_data[idx_data[ii] - 1];
  }

  pbPk_size[0] = x_size_idx_0;
  for (ii = 0; ii < x_size_idx_0; ii++) {
    pbPk_data[ii] = b_iPk_data[ii];
  }

  for (ii = 0; ii < x_size_idx_0; ii++) {
    b_iPk_data[ii] = iLB_data[idx_data[ii] - 1];
  }

  iLB_size[0] = x_size_idx_0;
  for (ii = 0; ii < x_size_idx_0; ii++) {
    iLB_data[ii] = b_iPk_data[ii];
  }

  for (ii = 0; ii < x_size_idx_0; ii++) {
    b_iPk_data[ii] = iRB_data[idx_data[ii] - 1];
  }

  iRB_size[0] = x_size_idx_0;
  for (ii = 0; ii < x_size_idx_0; ii++) {
    iRB_data[ii] = b_iPk_data[ii];
  }
}

/*
 * Arguments    : double x_data[]
 *                int x_size[1]
 *                int idx_data[]
 *                int idx_size[1]
 * Return Type  : void
 */
static void c_sort_DoaMusicSignal(double x_data[], int x_size[1], int idx_data[],
  int idx_size[1])
{
  int dim;
  dim = 2;
  if (x_size[0] != 1) {
    dim = 1;
  }

  d_sort_DoaMusicSignal(x_data, x_size, dim, idx_data, idx_size);
}

/*
 * Arguments    : const boolean_T x_data[]
 *                const int x_size[2]
 * Return Type  : double
 */
static double c_sum_DoaMusicSignal(const boolean_T x_data[], const int x_size[2])
{
  double y;
  int k;
  if (x_size[1] == 0) {
    y = 0.0;
  } else {
    y = x_data[0];
    for (k = 2; k <= x_size[1]; k++) {
      y += (double)x_data[k - 1];
    }
  }

  return y;
}

/*
 * Arguments    : const double y[123]
 *                const double iPk_data[]
 *                const int iPk_size[1]
 *                const double bPk_data[]
 *                const int bPk_size[1]
 *                const double iLBw_data[]
 *                const int iLBw_size[1]
 *                const double iRBw_data[]
 *                const int iRBw_size[1]
 *                const double wPk_data[]
 *                const int wPk_size[2]
 *                const double iInf_data[]
 *                const int iInf_size[1]
 *                double iPkOut_data[]
 *                int iPkOut_size[1]
 *                double bPkOut_data[]
 *                int bPkOut_size[1]
 *                double bxPkOut_data[]
 *                int bxPkOut_size[2]
 *                double byPkOut_data[]
 *                int byPkOut_size[2]
 *                double wxPkOut_data[]
 *                int wxPkOut_size[2]
 * Return Type  : void
 */
static void combineFullPeaks_DoaMusicSignal(const double y[123], const double
  iPk_data[], const int iPk_size[1], const double bPk_data[], const int
  bPk_size[1], const double iLBw_data[], const int iLBw_size[1], const double
  iRBw_data[], const int iRBw_size[1], const double wPk_data[], const int
  wPk_size[2], const double iInf_data[], const int iInf_size[1], double
  iPkOut_data[], int iPkOut_size[1], double bPkOut_data[], int bPkOut_size[1],
  double bxPkOut_data[], int bxPkOut_size[2], double byPkOut_data[], int
  byPkOut_size[2], double wxPkOut_data[], int wxPkOut_size[2])
{
  int ia_data[123];
  int ia_size[1];
  int ib_data[123];
  int ib_size[1];
  double c_data[123];
  int c_size[1];
  int k;
  int i5;
  int iFinite_data[123];
  int iPkOut;
  int iInfinite_data[123];
  double iInfL_data[123];
  double iInfR_data[123];
  int i6;
  do_vectors_DoaMusicSignal(iPk_data, iPk_size, iInf_data, iInf_size,
    iPkOut_data, iPkOut_size, ia_data, ia_size, ib_data, ib_size);
  b_do_vectors_DoaMusicSignal(iPkOut_data, iPkOut_size, iPk_data, iPk_size,
    c_data, c_size, ia_data, ia_size, ib_data, ib_size);
  k = ia_size[0];
  for (i5 = 0; i5 < k; i5++) {
    iFinite_data[i5] = ia_data[i5];
  }

  b_do_vectors_DoaMusicSignal(iPkOut_data, iPkOut_size, iInf_data, iInf_size,
    c_data, c_size, ia_data, ia_size, ib_data, ib_size);
  k = ia_size[0];
  for (i5 = 0; i5 < k; i5++) {
    iInfinite_data[i5] = ia_data[i5];
  }

  iPkOut = iPkOut_size[0];
  bPkOut_size[0] = (unsigned char)iPkOut_size[0];
  k = (unsigned char)iPkOut_size[0];
  for (i5 = 0; i5 < k; i5++) {
    bPkOut_data[i5] = 0.0;
  }

  k = bPk_size[0];
  for (i5 = 0; i5 < k; i5++) {
    bPkOut_data[iFinite_data[i5] - 1] = bPk_data[i5];
  }

  k = ia_size[0];
  for (i5 = 0; i5 < k; i5++) {
    ia_data[i5] = iInfinite_data[i5];
  }

  k = ia_size[0];
  for (i5 = 0; i5 < k; i5++) {
    bPkOut_data[ia_data[i5] - 1] = 0.0;
  }

  k = iInf_size[0];
  for (i5 = 0; i5 < k; i5++) {
    c_data[i5] = iInf_data[i5] - 1.0;
  }

  for (k = 0; k + 1 <= (signed char)iInf_size[0]; k++) {
    if ((1.0 >= c_data[k]) || rtIsNaN(c_data[k])) {
      iInfL_data[k] = 1.0;
    } else {
      iInfL_data[k] = c_data[k];
    }
  }

  k = iInf_size[0];
  for (i5 = 0; i5 < k; i5++) {
    c_data[i5] = iInf_data[i5] + 1.0;
  }

  for (k = 0; k + 1 <= (signed char)iInf_size[0]; k++) {
    if (c_data[k] <= 123.0) {
      iInfR_data[k] = c_data[k];
    } else {
      iInfR_data[k] = 123.0;
    }
  }

  bxPkOut_size[0] = iPkOut;
  bxPkOut_size[1] = 2;
  k = iPkOut << 1;
  for (i5 = 0; i5 < k; i5++) {
    bxPkOut_data[i5] = 0.0;
  }

  k = iLBw_size[0];
  for (i5 = 0; i5 < k; i5++) {
    bxPkOut_data[iFinite_data[i5] - 1] = 1.0 + (double)((int)iLBw_data[i5] - 1);
  }

  k = iRBw_size[0];
  for (i5 = 0; i5 < k; i5++) {
    bxPkOut_data[(iFinite_data[i5] + iPkOut) - 1] = 1.0 + (double)((int)
      iRBw_data[i5] - 1);
  }

  k = iInf_size[0];
  for (i5 = 0; i5 < k; i5++) {
    bxPkOut_data[iInfinite_data[i5] - 1] = 0.5 * ((1.0 + (double)((int)
      iInf_data[i5] - 1)) + (1.0 + (double)((int)iInfL_data[i5] - 1)));
  }

  k = iInf_size[0];
  for (i5 = 0; i5 < k; i5++) {
    bxPkOut_data[(iInfinite_data[i5] + iPkOut) - 1] = 0.5 * ((1.0 + (double)
      ((int)iInf_data[i5] - 1)) + (1.0 + (double)((int)iInfR_data[i5] - 1)));
  }

  byPkOut_size[0] = iPkOut;
  byPkOut_size[1] = 2;
  k = iPkOut << 1;
  for (i5 = 0; i5 < k; i5++) {
    byPkOut_data[i5] = 0.0;
  }

  k = iLBw_size[0];
  for (i5 = 0; i5 < k; i5++) {
    byPkOut_data[iFinite_data[i5] - 1] = y[(int)iLBw_data[i5] - 1];
  }

  k = iRBw_size[0];
  for (i5 = 0; i5 < k; i5++) {
    byPkOut_data[(iFinite_data[i5] + iPkOut) - 1] = y[(int)iRBw_data[i5] - 1];
  }

  k = (signed char)iInf_size[0];
  for (i5 = 0; i5 < k; i5++) {
    byPkOut_data[iInfinite_data[i5] - 1] = y[(int)iInfL_data[i5] - 1];
  }

  k = (signed char)iInf_size[0];
  for (i5 = 0; i5 < k; i5++) {
    byPkOut_data[(iInfinite_data[i5] + iPkOut) - 1] = y[(int)iInfR_data[i5] - 1];
  }

  wxPkOut_size[0] = iPkOut;
  wxPkOut_size[1] = 2;
  k = iPkOut << 1;
  for (i5 = 0; i5 < k; i5++) {
    wxPkOut_data[i5] = 0.0;
  }

  for (i5 = 0; i5 < 2; i5++) {
    k = wPk_size[0];
    for (i6 = 0; i6 < k; i6++) {
      wxPkOut_data[(iFinite_data[i6] + iPkOut * i5) - 1] = wPk_data[i6 +
        wPk_size[0] * i5];
    }
  }

  k = iInf_size[0];
  for (i5 = 0; i5 < k; i5++) {
    wxPkOut_data[iInfinite_data[i5] - 1] = 0.5 * ((1.0 + (double)((int)
      iInf_data[i5] - 1)) + (1.0 + (double)((int)iInfL_data[i5] - 1)));
  }

  k = iInf_size[0];
  for (i5 = 0; i5 < k; i5++) {
    wxPkOut_data[(iInfinite_data[i5] + iPkOut) - 1] = 0.5 * ((1.0 + (double)
      ((int)iInf_data[i5] - 1)) + (1.0 + (double)((int)iInfR_data[i5] - 1)));
  }
}

/*
 * Arguments    : double x_data[]
 *                int x_size[1]
 *                int dim
 *                int idx_data[]
 *                int idx_size[1]
 * Return Type  : void
 */
static void d_sort_DoaMusicSignal(double x_data[], int x_size[1], int dim, int
  idx_data[], int idx_size[1])
{
  int i11;
  double vwork_data[246];
  int vwork_size[1];
  int vstride;
  int k;
  int j;
  int iidx_data[246];
  int iidx_size[1];
  if (dim <= 1) {
    i11 = x_size[0];
  } else {
    i11 = 1;
  }

  vwork_size[0] = (unsigned char)i11;
  idx_size[0] = (unsigned char)x_size[0];
  vstride = 1;
  k = 1;
  while (k <= dim - 1) {
    vstride *= x_size[0];
    k = 2;
  }

  for (j = 0; j + 1 <= vstride; j++) {
    for (k = 0; k + 1 <= i11; k++) {
      vwork_data[k] = x_data[j + k * vstride];
    }

    sortIdx_DoaMusicSignal(vwork_data, vwork_size, iidx_data, iidx_size);
    for (k = 0; k + 1 <= i11; k++) {
      x_data[j + k * vstride] = vwork_data[k];
      idx_data[j + k * vstride] = iidx_data[k];
    }
  }
}

/*
 * Arguments    : const double x_data[]
 *                const int x_size[1]
 *                double y_data[]
 *                int y_size[1]
 * Return Type  : void
 */
static void diff_DoaMusicSignal(const double x_data[], const int x_size[1],
  double y_data[], int y_size[1])
{
  int b_x_size;
  int ixLead;
  int iyLead;
  double work_data_idx_0;
  int m;
  double tmp2;
  if (x_size[0] == 0) {
    y_size[0] = 0;
  } else {
    if (x_size[0] - 1 <= 1) {
      b_x_size = x_size[0] - 1;
    } else {
      b_x_size = 1;
    }

    if (b_x_size < 1) {
      y_size[0] = 0;
    } else {
      y_size[0] = (signed char)(x_size[0] - 1);
      if (!((signed char)(x_size[0] - 1) == 0)) {
        ixLead = 1;
        iyLead = 0;
        work_data_idx_0 = x_data[0];
        for (m = 2; m <= x_size[0]; m++) {
          tmp2 = work_data_idx_0;
          work_data_idx_0 = x_data[ixLead];
          tmp2 = x_data[ixLead] - tmp2;
          ixLead++;
          y_data[iyLead] = tmp2;
          iyLead++;
        }
      }
    }
  }
}

/*
 * Arguments    : const double a_data[]
 *                const int a_size[1]
 *                const double b_data[]
 *                const int b_size[1]
 *                double c_data[]
 *                int c_size[1]
 *                int ia_data[]
 *                int ia_size[1]
 *                int ib_data[]
 *                int ib_size[1]
 * Return Type  : void
 */
static void do_vectors_DoaMusicSignal(const double a_data[], const int a_size[1],
  const double b_data[], const int b_size[1], double c_data[], int c_size[1],
  int ia_data[], int ia_size[1], int ib_data[], int ib_size[1])
{
  int na;
  int nb;
  int ncmax;
  int nc;
  int nia;
  int nib;
  int iafirst;
  int ialast;
  int ibfirst;
  int iblast;
  int b_ialast;
  double ak;
  int b_iblast;
  double bk;
  double absxk;
  int b_ia_data[123];
  int exponent;
  boolean_T p;
  double b_c_data[246];
  na = a_size[0];
  nb = b_size[0];
  ncmax = a_size[0] + b_size[0];
  c_size[0] = (unsigned char)ncmax;
  ia_size[0] = a_size[0];
  ib_size[0] = b_size[0];
  nc = -1;
  nia = -1;
  nib = 0;
  iafirst = 1;
  ialast = 1;
  ibfirst = 0;
  iblast = 1;
  while ((ialast <= na) && (iblast <= nb)) {
    b_ialast = ialast;
    ak = skip_to_last_equal_value_DoaMus(&b_ialast, a_data, a_size);
    ialast = b_ialast;
    b_iblast = iblast;
    bk = skip_to_last_equal_value_DoaMus(&b_iblast, b_data, b_size);
    iblast = b_iblast;
    absxk = fabs(bk / 2.0);
    if ((!rtIsInf(absxk)) && (!rtIsNaN(absxk))) {
      if (absxk <= 2.2250738585072014E-308) {
        absxk = 4.94065645841247E-324;
      } else {
        frexp(absxk, &exponent);
        absxk = ldexp(1.0, exponent - 53);
      }
    } else {
      absxk = rtNaN;
    }

    if ((fabs(bk - ak) < absxk) || (rtIsInf(ak) && rtIsInf(bk) && ((ak > 0.0) ==
          (bk > 0.0)))) {
      p = true;
    } else {
      p = false;
    }

    if (p) {
      nc++;
      c_data[nc] = ak;
      nia++;
      ia_data[nia] = iafirst;
      ialast = b_ialast + 1;
      iafirst = b_ialast + 1;
      iblast = b_iblast + 1;
      ibfirst = b_iblast;
    } else {
      if ((ak < bk) || rtIsNaN(bk)) {
        p = true;
      } else {
        p = false;
      }

      if (p) {
        nc++;
        nia++;
        c_data[nc] = ak;
        ia_data[nia] = iafirst;
        ialast = b_ialast + 1;
        iafirst = b_ialast + 1;
      } else {
        nc++;
        nib++;
        c_data[nc] = bk;
        ib_data[nib - 1] = ibfirst + 1;
        iblast = b_iblast + 1;
        ibfirst = b_iblast;
      }
    }
  }

  while (ialast <= na) {
    iafirst = ialast;
    ak = skip_to_last_equal_value_DoaMus(&iafirst, a_data, a_size);
    nc++;
    nia++;
    c_data[nc] = ak;
    ia_data[nia] = ialast;
    ialast = iafirst + 1;
  }

  while (iblast <= nb) {
    iafirst = iblast;
    bk = skip_to_last_equal_value_DoaMus(&iafirst, b_data, b_size);
    nc++;
    nib++;
    c_data[nc] = bk;
    ib_data[nib - 1] = iblast;
    iblast = iafirst + 1;
  }

  if (a_size[0] > 0) {
    if (1 > nia + 1) {
      iafirst = -1;
    } else {
      iafirst = nia;
    }

    for (ibfirst = 0; ibfirst <= iafirst; ibfirst++) {
      b_ia_data[ibfirst] = ia_data[ibfirst];
    }

    ia_size[0] = iafirst + 1;
    iafirst++;
    for (ibfirst = 0; ibfirst < iafirst; ibfirst++) {
      ia_data[ibfirst] = b_ia_data[ibfirst];
    }
  }

  if (b_size[0] > 0) {
    if (1 > nib) {
      iafirst = 0;
    } else {
      iafirst = nib;
    }

    for (ibfirst = 0; ibfirst < iafirst; ibfirst++) {
      b_ia_data[ibfirst] = ib_data[ibfirst];
    }

    ib_size[0] = iafirst;
    for (ibfirst = 0; ibfirst < iafirst; ibfirst++) {
      ib_data[ibfirst] = b_ia_data[ibfirst];
    }
  }

  if (ncmax > 0) {
    if (1 > nc + 1) {
      iafirst = -1;
    } else {
      iafirst = nc;
    }

    for (ibfirst = 0; ibfirst <= iafirst; ibfirst++) {
      b_c_data[ibfirst] = c_data[ibfirst];
    }

    c_size[0] = iafirst + 1;
    iafirst++;
    for (ibfirst = 0; ibfirst < iafirst; ibfirst++) {
      c_data[ibfirst] = b_c_data[ibfirst];
    }
  }
}

/*
 * Arguments    : double x_data[]
 *                int x_size[1]
 * Return Type  : void
 */
static void e_sort_DoaMusicSignal(double x_data[], int x_size[1])
{
  int dim;
  int i12;
  double vwork_data[246];
  int vwork_size[1];
  int vstride;
  int k;
  emxArray_int32_T_246_DoaMusicSi b_vwork_data;
  dim = nonSingletonDim_DoaMusicSignal(x_size);
  if (dim <= 1) {
    i12 = x_size[0];
  } else {
    i12 = 1;
  }

  vwork_size[0] = (unsigned char)i12;
  vstride = 1;
  k = 1;
  while (k <= dim - 1) {
    vstride *= x_size[0];
    k = 2;
  }

  for (dim = 0; dim + 1 <= vstride; dim++) {
    for (k = 0; k + 1 <= i12; k++) {
      vwork_data[k] = x_data[dim + k * vstride];
    }

    b_sortIdx_DoaMusicSignal(vwork_data, vwork_size,
      b_vwork_data.data_DoaMusicSignal, b_vwork_data.size_DoaMusicSignal);
    for (k = 0; k + 1 <= i12; k++) {
      x_data[dim + k * vstride] = vwork_data[k];
    }
  }
}

/*
 * Arguments    : const creal_T A[16]
 *                creal_T V[16]
 *                creal_T D[4]
 * Return Type  : void
 */
static void eig_DoaMusicSignal(const creal_T A[16], creal_T V[16], creal_T D[4])
{
  creal_T At[16];
  int info;
  creal_T beta1[4];
  int coltop;
  double colnorm;
  double scale;
  double t;
  double absxk;
  memcpy(&At[0], &A[0], sizeof(creal_T) << 4);
  xzggev_DoaMusicSignal(At, &info, D, beta1, V);
  for (coltop = 0; coltop <= 13; coltop += 4) {
    colnorm = 0.0;
    scale = 2.2250738585072014E-308;
    for (info = coltop; info + 1 <= coltop + 4; info++) {
      absxk = fabs(V[info].re);
      if (absxk > scale) {
        t = scale / absxk;
        colnorm = 1.0 + colnorm * t * t;
        scale = absxk;
      } else {
        t = absxk / scale;
        colnorm += t * t;
      }

      absxk = fabs(V[info].im);
      if (absxk > scale) {
        t = scale / absxk;
        colnorm = 1.0 + colnorm * t * t;
        scale = absxk;
      } else {
        t = absxk / scale;
        colnorm += t * t;
      }
    }

    colnorm = scale * sqrt(colnorm);
    for (info = coltop; info + 1 <= coltop + 4; info++) {
      if (V[info].im == 0.0) {
        V[info].re /= colnorm;
        V[info].im = 0.0;
      } else if (V[info].re == 0.0) {
        V[info].re = 0.0;
        V[info].im /= colnorm;
      } else {
        V[info].re /= colnorm;
        V[info].im /= colnorm;
      }
    }
  }

  for (info = 0; info < 4; info++) {
    t = D[info].re;
    if (beta1[info].im == 0.0) {
      if (D[info].im == 0.0) {
        D[info].re /= beta1[info].re;
        D[info].im = 0.0;
      } else if (D[info].re == 0.0) {
        D[info].re = 0.0;
        D[info].im /= beta1[info].re;
      } else {
        D[info].re /= beta1[info].re;
        D[info].im /= beta1[info].re;
      }
    } else if (beta1[info].re == 0.0) {
      if (D[info].re == 0.0) {
        D[info].re = D[info].im / beta1[info].im;
        D[info].im = 0.0;
      } else if (D[info].im == 0.0) {
        D[info].re = 0.0;
        D[info].im = -(t / beta1[info].im);
      } else {
        D[info].re = D[info].im / beta1[info].im;
        D[info].im = -(t / beta1[info].im);
      }
    } else {
      absxk = fabs(beta1[info].re);
      colnorm = fabs(beta1[info].im);
      if (absxk > colnorm) {
        colnorm = beta1[info].im / beta1[info].re;
        scale = beta1[info].re + colnorm * beta1[info].im;
        D[info].re = (D[info].re + colnorm * D[info].im) / scale;
        D[info].im = (D[info].im - colnorm * t) / scale;
      } else if (colnorm == absxk) {
        if (beta1[info].re > 0.0) {
          colnorm = 0.5;
        } else {
          colnorm = -0.5;
        }

        if (beta1[info].im > 0.0) {
          scale = 0.5;
        } else {
          scale = -0.5;
        }

        D[info].re = (D[info].re * colnorm + D[info].im * scale) / absxk;
        D[info].im = (D[info].im * colnorm - t * scale) / absxk;
      } else {
        colnorm = beta1[info].re / beta1[info].im;
        scale = beta1[info].im + colnorm * beta1[info].re;
        D[info].re = (colnorm * D[info].re + D[info].im) / scale;
        D[info].im = (colnorm * D[info].im - t) / scale;
      }
    }
  }
}

/*
 * Arguments    : const double idx_data[]
 *                const int idx_size[1]
 *                double bPk_data[]
 *                int bPk_size[1]
 *                double bxPk_data[]
 *                int bxPk_size[2]
 *                double byPk_data[]
 *                int byPk_size[2]
 *                double wxPk_data[]
 *                int wxPk_size[2]
 * Return Type  : void
 */
static void fetchPeakExtents_DoaMusicSignal(const double idx_data[], const int
  idx_size[1], double bPk_data[], int bPk_size[1], double bxPk_data[], int
  bxPk_size[2], double byPk_data[], int byPk_size[2], double wxPk_data[], int
  wxPk_size[2])
{
  double b_bPk_data[246];
  int loop_ub;
  int i13;
  double b_bxPk_data[492];
  int bxPk_size_idx_0;
  int i14;
  double b_byPk_data[492];
  int byPk_size_idx_0;
  loop_ub = idx_size[0];
  for (i13 = 0; i13 < loop_ub; i13++) {
    b_bPk_data[i13] = bPk_data[(int)idx_data[i13] - 1];
  }

  bPk_size[0] = idx_size[0];
  loop_ub = idx_size[0];
  for (i13 = 0; i13 < loop_ub; i13++) {
    bPk_data[i13] = b_bPk_data[i13];
  }

  bxPk_size_idx_0 = idx_size[0];
  for (i13 = 0; i13 < 2; i13++) {
    loop_ub = idx_size[0];
    for (i14 = 0; i14 < loop_ub; i14++) {
      b_bxPk_data[i14 + bxPk_size_idx_0 * i13] = bxPk_data[((int)idx_data[i14] +
        bxPk_size[0] * i13) - 1];
    }
  }

  bxPk_size[0] = idx_size[0];
  bxPk_size[1] = 2;
  byPk_size_idx_0 = idx_size[0];
  for (i13 = 0; i13 < 2; i13++) {
    for (i14 = 0; i14 < bxPk_size_idx_0; i14++) {
      bxPk_data[i14 + bxPk_size[0] * i13] = b_bxPk_data[i14 + bxPk_size_idx_0 *
        i13];
    }

    loop_ub = idx_size[0];
    for (i14 = 0; i14 < loop_ub; i14++) {
      b_byPk_data[i14 + byPk_size_idx_0 * i13] = byPk_data[((int)idx_data[i14] +
        byPk_size[0] * i13) - 1];
    }
  }

  byPk_size[0] = idx_size[0];
  byPk_size[1] = 2;
  bxPk_size_idx_0 = idx_size[0];
  for (i13 = 0; i13 < 2; i13++) {
    for (i14 = 0; i14 < byPk_size_idx_0; i14++) {
      byPk_data[i14 + byPk_size[0] * i13] = b_byPk_data[i14 + byPk_size_idx_0 *
        i13];
    }

    loop_ub = idx_size[0];
    for (i14 = 0; i14 < loop_ub; i14++) {
      b_bxPk_data[i14 + bxPk_size_idx_0 * i13] = wxPk_data[((int)idx_data[i14] +
        wxPk_size[0] * i13) - 1];
    }
  }

  wxPk_size[0] = idx_size[0];
  wxPk_size[1] = 2;
  for (i13 = 0; i13 < 2; i13++) {
    for (i14 = 0; i14 < bxPk_size_idx_0; i14++) {
      wxPk_data[i14 + wxPk_size[0] * i13] = b_bxPk_data[i14 + bxPk_size_idx_0 *
        i13];
    }
  }
}

/*
 * Arguments    : const double y[123]
 *                double iPk_data[]
 *                int iPk_size[1]
 *                const double iFin_data[]
 *                const int iFin_size[1]
 *                const double iInf_data[]
 *                const int iInf_size[1]
 *                const double iInflect_data[]
 *                const int iInflect_size[1]
 *                double bPk_data[]
 *                int bPk_size[1]
 *                double bxPk_data[]
 *                int bxPk_size[2]
 *                double byPk_data[]
 *                int byPk_size[2]
 *                double wxPk_data[]
 *                int wxPk_size[2]
 * Return Type  : void
 */
static void findExtents_DoaMusicSignal(const double y[123], double iPk_data[],
  int iPk_size[1], const double iFin_data[], const int iFin_size[1], const
  double iInf_data[], const int iInf_size[1], const double iInflect_data[],
  const int iInflect_size[1], double bPk_data[], int bPk_size[1], double
  bxPk_data[], int bxPk_size[2], double byPk_data[], int byPk_size[2], double
  wxPk_data[], int wxPk_size[2])
{
  double yFinite[123];
  int loop_ub;
  int i9;
  int tmp_data[123];
  double b_bPk_data[123];
  int b_bPk_size[1];
  double iLB_data[123];
  int iLB_size[1];
  double iRB_data[123];
  int iRB_size[1];
  int b_iPk_size[1];
  double b_iPk_data[123];
  double b_wxPk_data[246];
  int b_wxPk_size[2];
  memcpy(&yFinite[0], &y[0], 123U * sizeof(double));
  loop_ub = iInf_size[0];
  for (i9 = 0; i9 < loop_ub; i9++) {
    tmp_data[i9] = (int)iInf_data[i9];
  }

  loop_ub = iInf_size[0];
  for (i9 = 0; i9 < loop_ub; i9++) {
    yFinite[tmp_data[i9] - 1] = rtNaN;
  }

  getPeakBase_DoaMusicSignal(yFinite, iPk_data, iPk_size, iFin_data, iFin_size,
    iInflect_data, iInflect_size, b_bPk_data, b_bPk_size, iLB_data, iLB_size,
    iRB_data, iRB_size);
  b_iPk_size[0] = iPk_size[0];
  loop_ub = iPk_size[0];
  for (i9 = 0; i9 < loop_ub; i9++) {
    b_iPk_data[i9] = iPk_data[i9];
  }

  c_removePeaksBelowMinPeakPromin(yFinite, b_iPk_data, b_iPk_size, b_bPk_data,
    b_bPk_size, iLB_data, iLB_size, iRB_data, iRB_size);
  getPeakWidth_DoaMusicSignal(yFinite, b_iPk_data, b_iPk_size, b_bPk_data,
    b_bPk_size, iLB_data, iLB_size, iRB_data, iRB_size, b_wxPk_data, b_wxPk_size);
  combineFullPeaks_DoaMusicSignal(y, b_iPk_data, b_iPk_size, b_bPk_data,
    b_bPk_size, iLB_data, iLB_size, iRB_data, iRB_size, b_wxPk_data, b_wxPk_size,
    iInf_data, iInf_size, iPk_data, iPk_size, bPk_data, bPk_size, bxPk_data,
    bxPk_size, byPk_data, byPk_size, wxPk_data, wxPk_size);
}

/*
 * Arguments    : const double yTemp[123]
 *                double iPk_data[]
 *                int iPk_size[1]
 *                double iInflect_data[]
 *                int iInflect_size[1]
 * Return Type  : void
 */
static void findLocalMaxima_DoaMusicSignal(const double yTemp[123], double
  iPk_data[], int iPk_size[1], double iInflect_data[], int iInflect_size[1])
{
  double b_yTemp[125];
  boolean_T yFinite[125];
  int nx;
  boolean_T x[124];
  int idx;
  signed char ii_data[124];
  int ii;
  boolean_T exitg3;
  boolean_T guard3 = false;
  int loop_ub;
  signed char tmp_data[125];
  int i3;
  double yTemp_data[125];
  signed char iTemp_data[125];
  int yTemp_size[1];
  double s_data[124];
  int s_size[1];
  double b_tmp_data[124];
  boolean_T x_data[123];
  int b_ii_data[123];
  int ii_size_idx_0;
  boolean_T exitg2;
  boolean_T guard2 = false;
  int c_ii_data[123];
  boolean_T exitg1;
  boolean_T guard1 = false;
  b_yTemp[0] = rtNaN;
  memcpy(&b_yTemp[1], &yTemp[0], 123U * sizeof(double));
  b_yTemp[124] = rtNaN;
  for (nx = 0; nx < 125; nx++) {
    yFinite[nx] = !rtIsNaN(b_yTemp[nx]);
  }

  for (nx = 0; nx < 124; nx++) {
    x[nx] = ((b_yTemp[nx] != b_yTemp[nx + 1]) && (yFinite[nx] || yFinite[nx + 1]));
  }

  idx = 0;
  ii = 1;
  exitg3 = false;
  while ((!exitg3) && (ii < 125)) {
    guard3 = false;
    if (x[ii - 1]) {
      idx++;
      ii_data[idx - 1] = (signed char)ii;
      if (idx >= 124) {
        exitg3 = true;
      } else {
        guard3 = true;
      }
    } else {
      guard3 = true;
    }

    if (guard3) {
      ii++;
    }
  }

  if (1 > idx) {
    loop_ub = 0;
  } else {
    loop_ub = idx;
  }

  tmp_data[0] = 1;
  for (ii = 0; ii < loop_ub; ii++) {
    tmp_data[ii + 1] = (signed char)(ii_data[ii] + 1);
  }

  if (1 > idx) {
    i3 = 0;
  } else {
    i3 = idx;
  }

  nx = 1 + i3;
  for (ii = 0; ii < nx; ii++) {
    iTemp_data[ii] = tmp_data[ii];
  }

  yTemp_size[0] = 1 + loop_ub;
  loop_ub++;
  for (ii = 0; ii < loop_ub; ii++) {
    yTemp_data[ii] = b_yTemp[iTemp_data[ii] - 1];
  }

  diff_DoaMusicSignal(yTemp_data, yTemp_size, s_data, s_size);
  sign_DoaMusicSignal(s_data, s_size);
  diff_DoaMusicSignal(s_data, s_size, b_tmp_data, yTemp_size);
  loop_ub = yTemp_size[0];
  for (ii = 0; ii < loop_ub; ii++) {
    x_data[ii] = (b_tmp_data[ii] < 0.0);
  }

  nx = yTemp_size[0];
  idx = 0;
  ii_size_idx_0 = yTemp_size[0];
  ii = 1;
  exitg2 = false;
  while ((!exitg2) && (ii <= nx)) {
    guard2 = false;
    if (x_data[ii - 1]) {
      idx++;
      b_ii_data[idx - 1] = ii;
      if (idx >= nx) {
        exitg2 = true;
      } else {
        guard2 = true;
      }
    } else {
      guard2 = true;
    }

    if (guard2) {
      ii++;
    }
  }

  if (yTemp_size[0] == 1) {
    if (idx == 0) {
      ii_size_idx_0 = 0;
    }
  } else if (1 > idx) {
    ii_size_idx_0 = 0;
  } else {
    ii_size_idx_0 = idx;
  }

  if (1 > s_size[0] - 1) {
    loop_ub = 0;
  } else {
    loop_ub = s_size[0] - 1;
  }

  if (2 > s_size[0]) {
    ii = 0;
  } else {
    ii = 1;
  }

  for (nx = 0; nx < loop_ub; nx++) {
    x_data[nx] = (s_data[nx] != s_data[ii + nx]);
  }

  idx = 0;
  ii = 1;
  exitg1 = false;
  while ((!exitg1) && (ii <= loop_ub)) {
    guard1 = false;
    if (x_data[ii - 1]) {
      idx++;
      c_ii_data[idx - 1] = ii;
      if (idx >= loop_ub) {
        exitg1 = true;
      } else {
        guard1 = true;
      }
    } else {
      guard1 = true;
    }

    if (guard1) {
      ii++;
    }
  }

  if (loop_ub == 1) {
    if (idx == 0) {
      loop_ub = 0;
    }
  } else if (1 > idx) {
    loop_ub = 0;
  } else {
    loop_ub = idx;
  }

  iInflect_size[0] = loop_ub;
  for (ii = 0; ii < loop_ub; ii++) {
    iInflect_data[ii] = (double)iTemp_data[c_ii_data[ii]] - 1.0;
  }

  iPk_size[0] = ii_size_idx_0;
  for (ii = 0; ii < ii_size_idx_0; ii++) {
    iPk_data[ii] = (double)iTemp_data[b_ii_data[ii]] - 1.0;
  }
}

/*
 * Arguments    : const double Yin[123]
 *                double varargin_2
 *                double varargin_8
 *                double Ypk_data[]
 *                int Ypk_size[2]
 *                double Xpk_data[]
 *                int Xpk_size[2]
 * Return Type  : void
 */
static void findpeaks_DoaMusicSignal(const double Yin[123], double varargin_2,
  double varargin_8, double Ypk_data[], int Ypk_size[2], double Xpk_data[], int
  Xpk_size[2])
{
  double y[123];
  double minD;
  double maxN;
  double iFinite_data[123];
  int iFinite_size[1];
  double iInfite_data[123];
  int iInfite_size[1];
  double iInflect_data[123];
  int iInflect_size[1];
  int tmp_size[1];
  int loop_ub;
  int i2;
  double tmp_data[123];
  int iPk_size[1];
  double iPk_data[246];
  double bPk_data[246];
  int bPk_size[1];
  double bxPk_data[492];
  int bxPk_size[2];
  double byPk_data[492];
  int byPk_size[2];
  double wxPk_data[492];
  int wxPk_size[2];
  double idx_data[246];
  double b_iPk_data[246];
  int b_iPk_size[1];
  parse_inputs_DoaMusicSignal(Yin, varargin_2, varargin_8, y, &minD, &maxN);
  getAllPeaks_DoaMusicSignal(y, iFinite_data, iFinite_size, iInfite_data,
    iInfite_size, iInflect_data, iInflect_size);
  tmp_size[0] = iFinite_size[0];
  loop_ub = iFinite_size[0];
  for (i2 = 0; i2 < loop_ub; i2++) {
    tmp_data[i2] = iFinite_data[i2];
  }

  removePeaksBelowMinPeakHeight_D(y, tmp_data, tmp_size);
  iPk_size[0] = tmp_size[0];
  loop_ub = tmp_size[0];
  for (i2 = 0; i2 < loop_ub; i2++) {
    iPk_data[i2] = tmp_data[i2];
  }

  loop_ub = iPk_size[0];
  for (i2 = 0; i2 < loop_ub; i2++) {
    tmp_data[i2] = iPk_data[i2];
  }

  removePeaksBelowThreshold_DoaMu(y, tmp_data, tmp_size);
  iPk_size[0] = tmp_size[0];
  loop_ub = tmp_size[0];
  for (i2 = 0; i2 < loop_ub; i2++) {
    iPk_data[i2] = tmp_data[i2];
  }

  findExtents_DoaMusicSignal(y, iPk_data, iPk_size, iFinite_data, iFinite_size,
    iInfite_data, iInfite_size, iInflect_data, iInflect_size, bPk_data, bPk_size,
    bxPk_data, bxPk_size, byPk_data, byPk_size, wxPk_data, wxPk_size);
  c_findPeaksSeparatedByMoreThanM(y, iPk_data, iPk_size, minD, idx_data,
    tmp_size);
  keepAtMostNpPeaks_DoaMusicSigna(tmp_size, maxN);
  fetchPeakExtents_DoaMusicSignal(idx_data, tmp_size, bPk_data, bPk_size,
    bxPk_data, bxPk_size, byPk_data, byPk_size, wxPk_data, wxPk_size);
  b_iPk_size[0] = tmp_size[0];
  loop_ub = tmp_size[0];
  for (i2 = 0; i2 < loop_ub; i2++) {
    b_iPk_data[i2] = iPk_data[(int)idx_data[i2] - 1];
  }

  assignFullOutputs_DoaMusicSigna(y, b_iPk_data, b_iPk_size, wxPk_data,
    wxPk_size, bPk_data, Ypk_data, Ypk_size, Xpk_data, Xpk_size, iPk_data,
    bxPk_size, idx_data, byPk_size);
}

/*
 * Arguments    : double x_data[]
 *                int x_size[1]
 * Return Type  : void
 */
static void flipud_DoaMusicSignal(double x_data[], int x_size[1])
{
  int m;
  int md2;
  int i;
  double xtmp;
  m = x_size[0];
  md2 = x_size[0] >> 1;
  for (i = 1; i <= md2; i++) {
    xtmp = x_data[i - 1];
    x_data[i - 1] = x_data[m - i];
    x_data[m - i] = xtmp;
  }
}

/*
 * Arguments    : const double y[123]
 *                double iPk_data[]
 *                int iPk_size[1]
 *                double iInf_data[]
 *                int iInf_size[1]
 *                double iInflect_data[]
 *                int iInflect_size[1]
 * Return Type  : void
 */
static void getAllPeaks_DoaMusicSignal(const double y[123], double iPk_data[],
  int iPk_size[1], double iInf_data[], int iInf_size[1], double iInflect_data[],
  int iInflect_size[1])
{
  boolean_T x[123];
  int idx;
  signed char ii_data[123];
  int ii;
  boolean_T exitg1;
  boolean_T guard1 = false;
  double yTemp[123];
  for (idx = 0; idx < 123; idx++) {
    x[idx] = (rtIsInf(y[idx]) && (y[idx] > 0.0));
  }

  idx = 0;
  ii = 1;
  exitg1 = false;
  while ((!exitg1) && (ii < 124)) {
    guard1 = false;
    if (x[ii - 1]) {
      idx++;
      ii_data[idx - 1] = (signed char)ii;
      if (idx >= 123) {
        exitg1 = true;
      } else {
        guard1 = true;
      }
    } else {
      guard1 = true;
    }

    if (guard1) {
      ii++;
    }
  }

  if (1 > idx) {
    idx = 0;
  }

  iInf_size[0] = idx;
  for (ii = 0; ii < idx; ii++) {
    iInf_data[ii] = ii_data[ii];
  }

  memcpy(&yTemp[0], &y[0], 123U * sizeof(double));
  for (ii = 0; ii < idx; ii++) {
    ii_data[ii] = (signed char)iInf_data[ii];
  }

  for (ii = 0; ii < idx; ii++) {
    yTemp[ii_data[ii] - 1] = rtNaN;
  }

  findLocalMaxima_DoaMusicSignal(yTemp, iPk_data, iPk_size, iInflect_data,
    iInflect_size);
}

/*
 * Arguments    : const double yTemp[123]
 *                const double iPeak_data[]
 *                const int iPeak_size[1]
 *                const double iFinite_data[]
 *                const int iFinite_size[1]
 *                const double iInflect_data[]
 *                double iBase_data[]
 *                int iBase_size[1]
 *                double iSaddle_data[]
 *                int iSaddle_size[1]
 * Return Type  : void
 */
static void getLeftBase_DoaMusicSignal(const double yTemp[123], const double
  iPeak_data[], const int iPeak_size[1], const double iFinite_data[], const int
  iFinite_size[1], const double iInflect_data[], double iBase_data[], int
  iBase_size[1], double iSaddle_data[], int iSaddle_size[1])
{
  int n;
  int i;
  double peak_data[123];
  double valley_data[123];
  double iValley_data[123];
  int j;
  int k;
  double v;
  double iv;
  double p;
  double isv;
  iBase_size[0] = (signed char)iPeak_size[0];
  n = (signed char)iPeak_size[0];
  for (i = 0; i < n; i++) {
    iBase_data[i] = 0.0;
  }

  iSaddle_size[0] = (signed char)iPeak_size[0];
  n = (signed char)iPeak_size[0];
  for (i = 0; i < n; i++) {
    iSaddle_data[i] = 0.0;
  }

  n = (signed char)iFinite_size[0];
  for (i = 0; i < n; i++) {
    peak_data[i] = 0.0;
  }

  n = (signed char)iFinite_size[0];
  for (i = 0; i < n; i++) {
    valley_data[i] = 0.0;
  }

  n = (signed char)iFinite_size[0];
  for (i = 0; i < n; i++) {
    iValley_data[i] = 0.0;
  }

  n = -1;
  i = 0;
  j = 0;
  k = 0;
  v = rtNaN;
  iv = 1.0;
  while (k + 1 <= iPeak_size[0]) {
    while (iInflect_data[i] != iFinite_data[j]) {
      v = yTemp[(int)iInflect_data[i] - 1];
      iv = iInflect_data[i];
      if (rtIsNaN(yTemp[(int)iInflect_data[i] - 1])) {
        n = -1;
      } else {
        while ((n + 1 > 0) && (valley_data[n] > v)) {
          n--;
        }
      }

      i++;
    }

    p = yTemp[(int)iInflect_data[i] - 1];
    while ((n + 1 > 0) && (peak_data[n] < p)) {
      if (valley_data[n] < v) {
        v = valley_data[n];
        iv = iValley_data[n];
      }

      n--;
    }

    isv = iv;
    while ((n + 1 > 0) && (peak_data[n] <= p)) {
      if (valley_data[n] < v) {
        v = valley_data[n];
        iv = iValley_data[n];
      }

      n--;
    }

    n++;
    peak_data[n] = yTemp[(int)iInflect_data[i] - 1];
    valley_data[n] = v;
    iValley_data[n] = iv;
    if (iInflect_data[i] == iPeak_data[k]) {
      iBase_data[k] = iv;
      iSaddle_data[k] = isv;
      k++;
    }

    i++;
    j++;
  }
}

/*
 * Arguments    : const double yTemp[123]
 *                const double iPk_data[]
 *                const int iPk_size[1]
 *                const double iFin_data[]
 *                const int iFin_size[1]
 *                const double iInflect_data[]
 *                const int iInflect_size[1]
 *                double peakBase_data[]
 *                int peakBase_size[1]
 *                double iLeftSaddle_data[]
 *                int iLeftSaddle_size[1]
 *                double iRightSaddle_data[]
 *                int iRightSaddle_size[1]
 * Return Type  : void
 */
static void getPeakBase_DoaMusicSignal(const double yTemp[123], const double
  iPk_data[], const int iPk_size[1], const double iFin_data[], const int
  iFin_size[1], const double iInflect_data[], const int iInflect_size[1], double
  peakBase_data[], int peakBase_size[1], double iLeftSaddle_data[], int
  iLeftSaddle_size[1], double iRightSaddle_data[], int iRightSaddle_size[1])
{
  double iLeftBase_data[123];
  int iLeftBase_size[1];
  int tmp_size[1];
  int k;
  int i4;
  double tmp_data[123];
  int b_tmp_size[1];
  double b_tmp_data[123];
  int c_tmp_size[1];
  double c_tmp_data[123];
  double iRightBase_data[123];
  signed char csz_idx_0;
  getLeftBase_DoaMusicSignal(yTemp, iPk_data, iPk_size, iFin_data, iFin_size,
    iInflect_data, iLeftBase_data, iLeftBase_size, iLeftSaddle_data,
    iLeftSaddle_size);
  tmp_size[0] = iPk_size[0];
  k = iPk_size[0];
  for (i4 = 0; i4 < k; i4++) {
    tmp_data[i4] = iPk_data[i4];
  }

  flipud_DoaMusicSignal(tmp_data, tmp_size);
  b_tmp_size[0] = iFin_size[0];
  k = iFin_size[0];
  for (i4 = 0; i4 < k; i4++) {
    b_tmp_data[i4] = iFin_data[i4];
  }

  flipud_DoaMusicSignal(b_tmp_data, b_tmp_size);
  c_tmp_size[0] = iInflect_size[0];
  k = iInflect_size[0];
  for (i4 = 0; i4 < k; i4++) {
    c_tmp_data[i4] = iInflect_data[i4];
  }

  flipud_DoaMusicSignal(c_tmp_data, c_tmp_size);
  getLeftBase_DoaMusicSignal(yTemp, tmp_data, tmp_size, b_tmp_data, b_tmp_size,
    c_tmp_data, iRightBase_data, c_tmp_size, iRightSaddle_data,
    iRightSaddle_size);
  flipud_DoaMusicSignal(iRightBase_data, c_tmp_size);
  flipud_DoaMusicSignal(iRightSaddle_data, iRightSaddle_size);
  if (iLeftBase_size[0] <= c_tmp_size[0]) {
    csz_idx_0 = (signed char)iLeftBase_size[0];
  } else {
    csz_idx_0 = (signed char)c_tmp_size[0];
  }

  if (iLeftBase_size[0] <= c_tmp_size[0]) {
    peakBase_size[0] = (signed char)iLeftBase_size[0];
  } else {
    peakBase_size[0] = (signed char)c_tmp_size[0];
  }

  for (k = 0; k + 1 <= csz_idx_0; k++) {
    if ((yTemp[(int)iLeftBase_data[k] - 1] >= yTemp[(int)iRightBase_data[k] - 1])
        || rtIsNaN(yTemp[(int)iRightBase_data[k] - 1])) {
      peakBase_data[k] = yTemp[(int)iLeftBase_data[k] - 1];
    } else {
      peakBase_data[k] = yTemp[(int)iRightBase_data[k] - 1];
    }
  }
}

/*
 * Arguments    : const double y[123]
 *                const double iPk_data[]
 *                const int iPk_size[1]
 *                const double pbPk_data[]
 *                const int pbPk_size[1]
 *                double iLB_data[]
 *                int iLB_size[1]
 *                double iRB_data[]
 *                int iRB_size[1]
 *                double wxPk_data[]
 *                int wxPk_size[2]
 * Return Type  : void
 */
static void getPeakWidth_DoaMusicSignal(const double y[123], const double
  iPk_data[], const int iPk_size[1], const double pbPk_data[], const int
  pbPk_size[1], double iLB_data[], int iLB_size[1], double iRB_data[], int
  iRB_size[1], double wxPk_data[], int wxPk_size[2])
{
  int i;
  int i10;
  double base_data[123];
  double refHeight;
  double iLeft;
  double xLeft;
  double iRight;
  if (iPk_size[0] == 0) {
    iLB_size[0] = 0;
    iRB_size[0] = 0;
  } else {
    i = pbPk_size[0];
    for (i10 = 0; i10 < i; i10++) {
      base_data[i10] = pbPk_data[i10];
    }
  }

  wxPk_size[0] = iPk_size[0];
  wxPk_size[1] = 2;
  i = iPk_size[0] << 1;
  for (i10 = 0; i10 < i; i10++) {
    wxPk_data[i10] = 0.0;
  }

  for (i = 0; i < iPk_size[0]; i++) {
    refHeight = (y[(int)iPk_data[i] - 1] + base_data[i]) / 2.0;
    iLeft = iPk_data[i];
    while ((iLeft >= iLB_data[i]) && (y[(int)iLeft - 1] > refHeight)) {
      iLeft--;
    }

    if (iLeft < iLB_data[i]) {
      xLeft = 1.0 + (double)((int)iLB_data[i] - 1);
    } else {
      xLeft = (1.0 + (double)((int)iLeft - 1)) + ((1.0 + (double)((int)(iLeft +
        1.0) - 1)) - (1.0 + (double)((int)iLeft - 1))) * (0.5 * (y[(int)
        iPk_data[i] - 1] + base_data[i]) - y[(int)iLeft - 1]) / (y[(int)(iLeft +
        1.0) - 1] - y[(int)iLeft - 1]);
      if (rtIsNaN(xLeft)) {
        if (rtIsInf(base_data[i])) {
          xLeft = 0.5 * ((1.0 + (double)((int)iLeft - 1)) + (1.0 + (double)((int)
            (iLeft + 1.0) - 1)));
        } else {
          xLeft = 1.0 + (double)((int)(iLeft + 1.0) - 1);
        }
      }
    }

    iRight = iPk_data[i];
    while ((iRight <= iRB_data[i]) && (y[(int)iRight - 1] > refHeight)) {
      iRight++;
    }

    if (iRight > iRB_data[i]) {
      iLeft = 1.0 + (double)((int)iRB_data[i] - 1);
    } else {
      iLeft = (1.0 + (double)((int)iRight - 1)) + ((1.0 + (double)((int)(iRight
        - 1.0) - 1)) - (1.0 + (double)((int)iRight - 1))) * (0.5 * (y[(int)
        iPk_data[i] - 1] + base_data[i]) - y[(int)iRight - 1]) / (y[(int)(iRight
        - 1.0) - 1] - y[(int)iRight - 1]);
      if (rtIsNaN(iLeft)) {
        if (rtIsInf(base_data[i])) {
          iLeft = 0.5 * ((1.0 + (double)((int)iRight - 1)) + (1.0 + (double)
            ((int)(iRight - 1.0) - 1)));
        } else {
          iLeft = 1.0 + (double)((int)(iRight - 1.0) - 1);
        }
      }
    }

    wxPk_data[i] = xLeft;
    wxPk_data[i + wxPk_size[0]] = iLeft;
  }
}

/*
 * Arguments    : int idx_size[1]
 *                double Np
 * Return Type  : void
 */
static void keepAtMostNpPeaks_DoaMusicSigna(int idx_size[1], double Np)
{
  if (idx_size[0] > Np) {
    if (1.0 > Np) {
      idx_size[0] = 0;
    } else {
      idx_size[0] = (int)Np;
    }
  }
}

/*
 * Arguments    : int idx[4]
 *                double x[4]
 *                int offset
 *                int np
 *                int nq
 *                int iwork[4]
 *                double xwork[4]
 * Return Type  : void
 */
static void merge_DoaMusicSignal(int idx[4], double x[4], int offset, int np,
  int nq, int iwork[4], double xwork[4])
{
  int n;
  int qend;
  int p;
  int iout;
  int exitg1;
  if (nq == 0) {
  } else {
    n = np + nq;
    for (qend = 0; qend + 1 <= n; qend++) {
      iwork[qend] = idx[offset + qend];
      xwork[qend] = x[offset + qend];
    }

    p = 0;
    n = np;
    qend = np + nq;
    iout = offset - 1;
    do {
      exitg1 = 0;
      iout++;
      if (xwork[p] <= xwork[n]) {
        idx[iout] = iwork[p];
        x[iout] = xwork[p];
        if (p + 1 < np) {
          p++;
        } else {
          exitg1 = 1;
        }
      } else {
        idx[iout] = iwork[n];
        x[iout] = xwork[n];
        if (n + 1 < qend) {
          n++;
        } else {
          n = (iout - p) + 1;
          while (p + 1 <= np) {
            idx[n + p] = iwork[p];
            x[n + p] = xwork[p];
            p++;
          }

          exitg1 = 1;
        }
      }
    } while (exitg1 == 0);
  }
}

/*
 * Arguments    : int idx_data[]
 *                double x_data[]
 *                int n
 *                int iwork_data[]
 *                double xwork_data[]
 * Return Type  : void
 */
static void merge_block_DoaMusicSignal(int idx_data[], double x_data[], int n,
  int iwork_data[], double xwork_data[])
{
  int nPairs;
  int bLen;
  int tailOffset;
  int nTail;
  nPairs = n >> 2;
  bLen = 4;
  while (nPairs > 1) {
    if ((nPairs & 1) != 0) {
      nPairs--;
      tailOffset = bLen * nPairs;
      nTail = n - tailOffset;
      if (nTail > bLen) {
        b_merge_DoaMusicSignal(idx_data, x_data, tailOffset, bLen, nTail - bLen,
          iwork_data, xwork_data);
      }
    }

    tailOffset = bLen << 1;
    nPairs >>= 1;
    for (nTail = 1; nTail <= nPairs; nTail++) {
      b_merge_DoaMusicSignal(idx_data, x_data, (nTail - 1) * tailOffset, bLen,
        bLen, iwork_data, xwork_data);
    }

    bLen = tailOffset;
  }

  if (n > bLen) {
    b_merge_DoaMusicSignal(idx_data, x_data, 0, bLen, n - bLen, iwork_data,
      xwork_data);
  }
}

/*
 * Arguments    : const int x_size[1]
 * Return Type  : int
 */
static int nonSingletonDim_DoaMusicSignal(const int x_size[1])
{
  int dim;
  dim = 2;
  if (x_size[0] != 1) {
    dim = 1;
  }

  return dim;
}

/*
 * Arguments    : const double Yin[123]
 *                double varargin_2
 *                double varargin_8
 *                double y[123]
 *                double *Pd
 *                double *NpOut
 * Return Type  : void
 */
static void parse_inputs_DoaMusicSignal(const double Yin[123], double varargin_2,
  double varargin_8, double y[123], double *Pd, double *NpOut)
{
  memcpy(&y[0], &Yin[0], 123U * sizeof(double));
  *Pd = varargin_8;
  *NpOut = varargin_2;
}

/*
 * Arguments    : const double y[121]
 *                double ydB[121]
 * Return Type  : void
 */
static void pow2db_DoaMusicSignal(const double y[121], double ydB[121])
{
  int k;
  for (k = 0; k < 121; k++) {
    ydB[k] = (10.0 * log10(y[k]) + 300.0) - 300.0;
  }
}

/*
 * Arguments    : const double Y[123]
 *                double iPk_data[]
 *                int iPk_size[1]
 * Return Type  : void
 */
static void removePeaksBelowMinPeakHeight_D(const double Y[123], double
  iPk_data[], int iPk_size[1])
{
  int end;
  int trueCount;
  int i;
  int partialTrueCount;
  if (!(iPk_size[0] == 0)) {
    end = iPk_size[0] - 1;
    trueCount = 0;
    for (i = 0; i <= end; i++) {
      if (Y[(int)iPk_data[i] - 1] > -15.0) {
        trueCount++;
      }
    }

    partialTrueCount = 0;
    for (i = 0; i <= end; i++) {
      if (Y[(int)iPk_data[i] - 1] > -15.0) {
        iPk_data[partialTrueCount] = iPk_data[i];
        partialTrueCount++;
      }
    }

    iPk_size[0] = trueCount;
  }
}

/*
 * Arguments    : const double Y[123]
 *                double iPk_data[]
 *                int iPk_size[1]
 * Return Type  : void
 */
static void removePeaksBelowThreshold_DoaMu(const double Y[123], double
  iPk_data[], int iPk_size[1])
{
  signed char csz_idx_0;
  double base_data[123];
  int k;
  int trueCount;
  int i;
  int partialTrueCount;
  csz_idx_0 = (signed char)iPk_size[0];
  for (k = 0; k + 1 <= csz_idx_0; k++) {
    if ((Y[(int)(iPk_data[k] - 1.0) - 1] >= Y[(int)(iPk_data[k] + 1.0) - 1]) ||
        rtIsNaN(Y[(int)(iPk_data[k] + 1.0) - 1])) {
      base_data[k] = Y[(int)(iPk_data[k] - 1.0) - 1];
    } else {
      base_data[k] = Y[(int)(iPk_data[k] + 1.0) - 1];
    }
  }

  k = iPk_size[0] - 1;
  trueCount = 0;
  for (i = 0; i <= k; i++) {
    if (Y[(int)iPk_data[i] - 1] - base_data[i] >= 0.0) {
      trueCount++;
    }
  }

  partialTrueCount = 0;
  for (i = 0; i <= k; i++) {
    if (Y[(int)iPk_data[i] - 1] - base_data[i] >= 0.0) {
      iPk_data[partialTrueCount] = iPk_data[i];
      partialTrueCount++;
    }
  }

  iPk_size[0] = trueCount;
}

/*
 * Arguments    : double u0
 *                double u1
 * Return Type  : double
 */
static double rt_hypotd_snf_DoaMusicSignal(double u0, double u1)
{
  double y;
  double a;
  double b;
  a = fabs(u0);
  b = fabs(u1);
  if (a < b) {
    a /= b;
    y = b * sqrt(a * a + 1.0);
  } else if (a > b) {
    b /= a;
    y = a * sqrt(b * b + 1.0);
  } else if (rtIsNaN(b)) {
    y = b;
  } else {
    y = a * 1.4142135623730951;
  }

  return y;
}

/*
 * Arguments    : double x_data[]
 *                int x_size[1]
 * Return Type  : void
 */
static void sign_DoaMusicSignal(double x_data[], int x_size[1])
{
  int nx;
  int k;
  nx = x_size[0];
  for (k = 0; k + 1 <= nx; k++) {
    if (x_data[k] < 0.0) {
      x_data[k] = -1.0;
    } else if (x_data[k] > 0.0) {
      x_data[k] = 1.0;
    } else {
      if (x_data[k] == 0.0) {
        x_data[k] = 0.0;
      }
    }
  }
}

/*
 * Arguments    : int *k
 *                const double x_data[]
 *                const int x_size[1]
 * Return Type  : double
 */
static double skip_to_last_equal_value_DoaMus(int *k, const double x_data[],
  const int x_size[1])
{
  double xk;
  boolean_T exitg1;
  double absxk;
  int exponent;
  boolean_T p;
  xk = x_data[*k - 1];
  exitg1 = false;
  while ((!exitg1) && (*k < x_size[0])) {
    absxk = fabs(xk / 2.0);
    if ((!rtIsInf(absxk)) && (!rtIsNaN(absxk))) {
      if (absxk <= 2.2250738585072014E-308) {
        absxk = 4.94065645841247E-324;
      } else {
        frexp(absxk, &exponent);
        absxk = ldexp(1.0, exponent - 53);
      }
    } else {
      absxk = rtNaN;
    }

    if ((fabs(xk - x_data[*k]) < absxk) || (rtIsInf(x_data[*k]) && rtIsInf(xk) &&
         ((x_data[*k] > 0.0) == (xk > 0.0)))) {
      p = true;
    } else {
      p = false;
    }

    if (p) {
      (*k)++;
    } else {
      exitg1 = true;
    }
  }

  return xk;
}

/*
 * Arguments    : double x_data[]
 *                int x_size[1]
 *                int idx_data[]
 *                int idx_size[1]
 * Return Type  : void
 */
static void sortIdx_DoaMusicSignal(double x_data[], int x_size[1], int idx_data[],
  int idx_size[1])
{
  unsigned char unnamed_idx_0;
  int x_size_idx_0;
  int m;
  int ib;
  double b_x_data[246];
  int n;
  double x4[4];
  unsigned char idx4[4];
  int iwork_data[246];
  int nNaNs;
  double xwork_data[246];
  int k;
  int wOffset;
  signed char perm[4];
  int i3;
  int i4;
  unnamed_idx_0 = (unsigned char)x_size[0];
  x_size_idx_0 = x_size[0];
  m = x_size[0];
  for (ib = 0; ib < m; ib++) {
    b_x_data[ib] = x_data[ib];
  }

  idx_size[0] = unnamed_idx_0;
  m = unnamed_idx_0;
  for (ib = 0; ib < m; ib++) {
    idx_data[ib] = 0;
  }

  n = x_size[0];
  for (m = 0; m < 4; m++) {
    x4[m] = 0.0;
    idx4[m] = 0;
  }

  m = unnamed_idx_0;
  for (ib = 0; ib < m; ib++) {
    iwork_data[ib] = 0;
  }

  m = (unsigned char)x_size[0];
  for (ib = 0; ib < m; ib++) {
    xwork_data[ib] = 0.0;
  }

  nNaNs = 0;
  ib = 0;
  for (k = 0; k + 1 <= n; k++) {
    if (rtIsNaN(b_x_data[k])) {
      idx_data[(n - nNaNs) - 1] = k + 1;
      xwork_data[(n - nNaNs) - 1] = b_x_data[k];
      nNaNs++;
    } else {
      ib++;
      idx4[ib - 1] = (unsigned char)(k + 1);
      x4[ib - 1] = b_x_data[k];
      if (ib == 4) {
        ib = k - nNaNs;
        if (x4[0] >= x4[1]) {
          m = 1;
          wOffset = 2;
        } else {
          m = 2;
          wOffset = 1;
        }

        if (x4[2] >= x4[3]) {
          i3 = 3;
          i4 = 4;
        } else {
          i3 = 4;
          i4 = 3;
        }

        if (x4[m - 1] >= x4[i3 - 1]) {
          if (x4[wOffset - 1] >= x4[i3 - 1]) {
            perm[0] = (signed char)m;
            perm[1] = (signed char)wOffset;
            perm[2] = (signed char)i3;
            perm[3] = (signed char)i4;
          } else if (x4[wOffset - 1] >= x4[i4 - 1]) {
            perm[0] = (signed char)m;
            perm[1] = (signed char)i3;
            perm[2] = (signed char)wOffset;
            perm[3] = (signed char)i4;
          } else {
            perm[0] = (signed char)m;
            perm[1] = (signed char)i3;
            perm[2] = (signed char)i4;
            perm[3] = (signed char)wOffset;
          }
        } else if (x4[m - 1] >= x4[i4 - 1]) {
          if (x4[wOffset - 1] >= x4[i4 - 1]) {
            perm[0] = (signed char)i3;
            perm[1] = (signed char)m;
            perm[2] = (signed char)wOffset;
            perm[3] = (signed char)i4;
          } else {
            perm[0] = (signed char)i3;
            perm[1] = (signed char)m;
            perm[2] = (signed char)i4;
            perm[3] = (signed char)wOffset;
          }
        } else {
          perm[0] = (signed char)i3;
          perm[1] = (signed char)i4;
          perm[2] = (signed char)m;
          perm[3] = (signed char)wOffset;
        }

        idx_data[ib - 3] = idx4[perm[0] - 1];
        idx_data[ib - 2] = idx4[perm[1] - 1];
        idx_data[ib - 1] = idx4[perm[2] - 1];
        idx_data[ib] = idx4[perm[3] - 1];
        b_x_data[ib - 3] = x4[perm[0] - 1];
        b_x_data[ib - 2] = x4[perm[1] - 1];
        b_x_data[ib - 1] = x4[perm[2] - 1];
        b_x_data[ib] = x4[perm[3] - 1];
        ib = 0;
      }
    }
  }

  wOffset = (x_size[0] - nNaNs) - 1;
  if (ib > 0) {
    for (m = 0; m < 4; m++) {
      perm[m] = 0;
    }

    switch (ib) {
     case 1:
      perm[0] = 1;
      break;

     case 2:
      if (x4[0] >= x4[1]) {
        perm[0] = 1;
        perm[1] = 2;
      } else {
        perm[0] = 2;
        perm[1] = 1;
      }
      break;

     default:
      if (x4[0] >= x4[1]) {
        if (x4[1] >= x4[2]) {
          perm[0] = 1;
          perm[1] = 2;
          perm[2] = 3;
        } else if (x4[0] >= x4[2]) {
          perm[0] = 1;
          perm[1] = 3;
          perm[2] = 2;
        } else {
          perm[0] = 3;
          perm[1] = 1;
          perm[2] = 2;
        }
      } else if (x4[0] >= x4[2]) {
        perm[0] = 2;
        perm[1] = 1;
        perm[2] = 3;
      } else if (x4[1] >= x4[2]) {
        perm[0] = 2;
        perm[1] = 3;
        perm[2] = 1;
      } else {
        perm[0] = 3;
        perm[1] = 2;
        perm[2] = 1;
      }
      break;
    }

    for (k = 1; k <= ib; k++) {
      idx_data[(wOffset - ib) + k] = idx4[perm[k - 1] - 1];
      b_x_data[(wOffset - ib) + k] = x4[perm[k - 1] - 1];
    }
  }

  m = nNaNs >> 1;
  for (k = 1; k <= m; k++) {
    ib = idx_data[wOffset + k];
    idx_data[wOffset + k] = idx_data[n - k];
    idx_data[n - k] = ib;
    b_x_data[wOffset + k] = xwork_data[n - k];
    b_x_data[n - k] = xwork_data[wOffset + k];
  }

  if ((nNaNs & 1) != 0) {
    b_x_data[(wOffset + m) + 1] = xwork_data[(wOffset + m) + 1];
  }

  m = x_size[0] - nNaNs;
  if (m > 1) {
    merge_block_DoaMusicSignal(idx_data, b_x_data, m, iwork_data, xwork_data);
  }

  if ((nNaNs > 0) && (m > 0)) {
    for (k = 0; k + 1 <= nNaNs; k++) {
      xwork_data[k] = b_x_data[m + k];
      iwork_data[k] = idx_data[m + k];
    }

    for (k = m - 1; k + 1 > 0; k--) {
      b_x_data[nNaNs + k] = b_x_data[k];
      idx_data[nNaNs + k] = idx_data[k];
    }

    for (k = 0; k + 1 <= nNaNs; k++) {
      b_x_data[k] = xwork_data[k];
      idx_data[k] = iwork_data[k];
    }
  }

  x_size[0] = x_size_idx_0;
  for (ib = 0; ib < x_size_idx_0; ib++) {
    x_data[ib] = b_x_data[ib];
  }
}

/*
 * Arguments    : double x[4]
 *                int idx[4]
 * Return Type  : void
 */
static void sort_DoaMusicSignal(double x[4], int idx[4])
{
  b_sort_DoaMusicSignal(x, idx);
}

/*
 * Arguments    : creal_T *x
 * Return Type  : void
 */
static void sqrt_DoaMusicSignal(creal_T *x)
{
  double absxi;
  double absxr;
  if (x->im == 0.0) {
    if (x->re < 0.0) {
      absxi = 0.0;
      absxr = sqrt(fabs(x->re));
    } else {
      absxi = sqrt(x->re);
      absxr = 0.0;
    }
  } else if (x->re == 0.0) {
    if (x->im < 0.0) {
      absxi = sqrt(-x->im / 2.0);
      absxr = -absxi;
    } else {
      absxi = sqrt(x->im / 2.0);
      absxr = absxi;
    }
  } else if (rtIsNaN(x->re) || rtIsNaN(x->im)) {
    absxi = rtNaN;
    absxr = rtNaN;
  } else if (rtIsInf(x->im)) {
    absxi = rtInf;
    absxr = x->im;
  } else if (rtIsInf(x->re)) {
    if (x->re < 0.0) {
      absxi = 0.0;
      absxr = rtInf;
    } else {
      absxi = rtInf;
      absxr = 0.0;
    }
  } else {
    absxr = fabs(x->re);
    absxi = fabs(x->im);
    if ((absxr > 4.4942328371557893E+307) || (absxi > 4.4942328371557893E+307))
    {
      absxr *= 0.5;
      absxi *= 0.5;
      absxi = rt_hypotd_snf_DoaMusicSignal(absxr, absxi);
      if (absxi > absxr) {
        absxi = sqrt(absxi) * sqrt(1.0 + absxr / absxi);
      } else {
        absxi = sqrt(absxi) * 1.4142135623730951;
      }
    } else {
      absxi = sqrt((rt_hypotd_snf_DoaMusicSignal(absxr, absxi) + absxr) * 0.5);
    }

    if (x->re > 0.0) {
      absxr = 0.5 * (x->im / absxi);
    } else {
      if (x->im < 0.0) {
        absxr = -absxi;
      } else {
        absxr = absxi;
      }

      absxi = 0.5 * (x->im / absxr);
    }
  }

  x->re = absxi;
  x->im = absxr;
}

/*
 * Arguments    : const double x[4]
 * Return Type  : double
 */
static double sum_DoaMusicSignal(const double x[4])
{
  double y;
  int k;
  y = x[0];
  for (k = 0; k < 3; k++) {
    y += x[k + 1];
  }

  return y;
}

/*
 * Arguments    : creal_T A[16]
 *                int *info
 *                creal_T alpha1[4]
 *                creal_T beta1[4]
 *                creal_T V[16]
 * Return Type  : void
 */
static void xzggev_DoaMusicSignal(creal_T A[16], int *info, creal_T alpha1[4],
  creal_T beta1[4], creal_T V[16])
{
  double anrm;
  boolean_T ilascl;
  double anrmto;
  int i;
  int nzcount;
  double cfromc;
  int rscale[4];
  double ctoc;
  boolean_T notdone;
  int ilo;
  int ihi;
  double cfrom1;
  double stemp_re;
  int exitg2;
  double stemp_im;
  int j;
  int ii;
  boolean_T exitg5;
  int jj;
  creal_T atmp;
  boolean_T exitg6;
  int exitg1;
  signed char I[16];
  boolean_T guard2 = false;
  boolean_T exitg3;
  boolean_T exitg4;
  boolean_T guard1 = false;
  *info = 0;
  anrm = xzlangeM_DoaMusicSignal(A);
  if (!((!rtIsInf(anrm)) && (!rtIsNaN(anrm)))) {
    for (i = 0; i < 4; i++) {
      alpha1[i].re = rtNaN;
      alpha1[i].im = 0.0;
      beta1[i].re = rtNaN;
      beta1[i].im = 0.0;
    }

    for (nzcount = 0; nzcount < 16; nzcount++) {
      V[nzcount].re = rtNaN;
      V[nzcount].im = 0.0;
    }
  } else {
    ilascl = false;
    anrmto = anrm;
    if ((anrm > 0.0) && (anrm < 6.7178761075670888E-139)) {
      anrmto = 6.7178761075670888E-139;
      ilascl = true;
    } else {
      if (anrm > 1.4885657073574029E+138) {
        anrmto = 1.4885657073574029E+138;
        ilascl = true;
      }
    }

    if (ilascl) {
      cfromc = anrm;
      ctoc = anrmto;
      notdone = true;
      while (notdone) {
        cfrom1 = cfromc * 2.0041683600089728E-292;
        stemp_re = ctoc / 4.9896007738368E+291;
        if ((fabs(cfrom1) > fabs(ctoc)) && (ctoc != 0.0)) {
          stemp_im = 2.0041683600089728E-292;
          cfromc = cfrom1;
        } else if (fabs(stemp_re) > fabs(cfromc)) {
          stemp_im = 4.9896007738368E+291;
          ctoc = stemp_re;
        } else {
          stemp_im = ctoc / cfromc;
          notdone = false;
        }

        for (nzcount = 0; nzcount < 16; nzcount++) {
          A[nzcount].re *= stemp_im;
          A[nzcount].im *= stemp_im;
        }
      }
    }

    for (i = 0; i < 4; i++) {
      rscale[i] = 1;
    }

    ilo = 0;
    ihi = 4;
    do {
      exitg2 = 0;
      i = 0;
      j = 0;
      notdone = false;
      ii = ihi;
      exitg5 = false;
      while ((!exitg5) && (ii > 0)) {
        nzcount = 0;
        i = ii;
        j = ihi;
        jj = 1;
        exitg6 = false;
        while ((!exitg6) && (jj <= ihi)) {
          guard2 = false;
          if ((A[(ii + ((jj - 1) << 2)) - 1].re != 0.0) || (A[(ii + ((jj - 1) <<
                 2)) - 1].im != 0.0) || (ii == jj)) {
            if (nzcount == 0) {
              j = jj;
              nzcount = 1;
              guard2 = true;
            } else {
              nzcount = 2;
              exitg6 = true;
            }
          } else {
            guard2 = true;
          }

          if (guard2) {
            jj++;
          }
        }

        if (nzcount < 2) {
          notdone = true;
          exitg5 = true;
        } else {
          ii--;
        }
      }

      if (!notdone) {
        exitg2 = 2;
      } else {
        if (i != ihi) {
          for (nzcount = 0; nzcount < 4; nzcount++) {
            atmp = A[(i + (nzcount << 2)) - 1];
            A[(i + (nzcount << 2)) - 1] = A[(ihi + (nzcount << 2)) - 1];
            A[(ihi + (nzcount << 2)) - 1] = atmp;
          }
        }

        if (j != ihi) {
          for (nzcount = 0; nzcount + 1 <= ihi; nzcount++) {
            atmp = A[nzcount + ((j - 1) << 2)];
            A[nzcount + ((j - 1) << 2)] = A[nzcount + ((ihi - 1) << 2)];
            A[nzcount + ((ihi - 1) << 2)] = atmp;
          }
        }

        rscale[ihi - 1] = j;
        ihi--;
        if (ihi == 1) {
          rscale[0] = 1;
          exitg2 = 1;
        }
      }
    } while (exitg2 == 0);

    if (exitg2 == 1) {
    } else {
      do {
        exitg1 = 0;
        i = 0;
        j = 0;
        notdone = false;
        jj = ilo + 1;
        exitg3 = false;
        while ((!exitg3) && (jj <= ihi)) {
          nzcount = 0;
          i = ihi;
          j = jj;
          ii = ilo + 1;
          exitg4 = false;
          while ((!exitg4) && (ii <= ihi)) {
            guard1 = false;
            if ((A[(ii + ((jj - 1) << 2)) - 1].re != 0.0) || (A[(ii + ((jj - 1) <<
                   2)) - 1].im != 0.0) || (ii == jj)) {
              if (nzcount == 0) {
                i = ii;
                nzcount = 1;
                guard1 = true;
              } else {
                nzcount = 2;
                exitg4 = true;
              }
            } else {
              guard1 = true;
            }

            if (guard1) {
              ii++;
            }
          }

          if (nzcount < 2) {
            notdone = true;
            exitg3 = true;
          } else {
            jj++;
          }
        }

        if (!notdone) {
          exitg1 = 1;
        } else {
          if (i != ilo + 1) {
            for (nzcount = ilo; nzcount + 1 < 5; nzcount++) {
              atmp = A[(i + (nzcount << 2)) - 1];
              A[(i + (nzcount << 2)) - 1] = A[ilo + (nzcount << 2)];
              A[ilo + (nzcount << 2)] = atmp;
            }
          }

          if (j != ilo + 1) {
            for (nzcount = 0; nzcount + 1 <= ihi; nzcount++) {
              atmp = A[nzcount + ((j - 1) << 2)];
              A[nzcount + ((j - 1) << 2)] = A[nzcount + (ilo << 2)];
              A[nzcount + (ilo << 2)] = atmp;
            }
          }

          rscale[ilo] = j;
          ilo++;
          if (ilo + 1 == ihi) {
            rscale[ilo] = ilo + 1;
            exitg1 = 1;
          }
        }
      } while (exitg1 == 0);
    }

    for (nzcount = 0; nzcount < 16; nzcount++) {
      I[nzcount] = 0;
    }

    for (nzcount = 0; nzcount < 4; nzcount++) {
      I[nzcount + (nzcount << 2)] = 1;
    }

    for (nzcount = 0; nzcount < 16; nzcount++) {
      V[nzcount].re = I[nzcount];
      V[nzcount].im = 0.0;
    }

    if (ihi < ilo + 3) {
    } else {
      for (ii = ilo; ii + 1 < ihi - 1; ii++) {
        for (nzcount = ihi - 1; nzcount + 1 > ii + 2; nzcount--) {
          xzlartg_DoaMusicSignal(A[(nzcount + (ii << 2)) - 1], A[nzcount + (ii <<
            2)], &cfrom1, &atmp, &A[(nzcount + (ii << 2)) - 1]);
          A[nzcount + (ii << 2)].re = 0.0;
          A[nzcount + (ii << 2)].im = 0.0;
          for (j = ii + 1; j + 1 < 5; j++) {
            stemp_re = cfrom1 * A[(nzcount + (j << 2)) - 1].re + (atmp.re *
              A[nzcount + (j << 2)].re - atmp.im * A[nzcount + (j << 2)].im);
            stemp_im = cfrom1 * A[(nzcount + (j << 2)) - 1].im + (atmp.re *
              A[nzcount + (j << 2)].im + atmp.im * A[nzcount + (j << 2)].re);
            cfromc = A[(nzcount + (j << 2)) - 1].im;
            ctoc = A[(nzcount + (j << 2)) - 1].re;
            A[nzcount + (j << 2)].re = cfrom1 * A[nzcount + (j << 2)].re -
              (atmp.re * A[(nzcount + (j << 2)) - 1].re + atmp.im * A[(nzcount +
                (j << 2)) - 1].im);
            A[nzcount + (j << 2)].im = cfrom1 * A[nzcount + (j << 2)].im -
              (atmp.re * cfromc - atmp.im * ctoc);
            A[(nzcount + (j << 2)) - 1].re = stemp_re;
            A[(nzcount + (j << 2)) - 1].im = stemp_im;
          }

          atmp.re = -atmp.re;
          atmp.im = -atmp.im;
          for (i = 0; i + 1 <= ihi; i++) {
            stemp_re = cfrom1 * A[i + (nzcount << 2)].re + (atmp.re * A[i +
              ((nzcount - 1) << 2)].re - atmp.im * A[i + ((nzcount - 1) << 2)].
              im);
            stemp_im = cfrom1 * A[i + (nzcount << 2)].im + (atmp.re * A[i +
              ((nzcount - 1) << 2)].im + atmp.im * A[i + ((nzcount - 1) << 2)].
              re);
            cfromc = A[i + (nzcount << 2)].im;
            ctoc = A[i + (nzcount << 2)].re;
            A[i + ((nzcount - 1) << 2)].re = cfrom1 * A[i + ((nzcount - 1) << 2)]
              .re - (atmp.re * A[i + (nzcount << 2)].re + atmp.im * A[i +
                     (nzcount << 2)].im);
            A[i + ((nzcount - 1) << 2)].im = cfrom1 * A[i + ((nzcount - 1) << 2)]
              .im - (atmp.re * cfromc - atmp.im * ctoc);
            A[i + (nzcount << 2)].re = stemp_re;
            A[i + (nzcount << 2)].im = stemp_im;
          }

          for (i = 0; i < 4; i++) {
            stemp_re = cfrom1 * V[i + (nzcount << 2)].re + (atmp.re * V[i +
              ((nzcount - 1) << 2)].re - atmp.im * V[i + ((nzcount - 1) << 2)].
              im);
            stemp_im = cfrom1 * V[i + (nzcount << 2)].im + (atmp.re * V[i +
              ((nzcount - 1) << 2)].im + atmp.im * V[i + ((nzcount - 1) << 2)].
              re);
            cfromc = V[i + (nzcount << 2)].re;
            V[i + ((nzcount - 1) << 2)].re = cfrom1 * V[i + ((nzcount - 1) << 2)]
              .re - (atmp.re * V[i + (nzcount << 2)].re + atmp.im * V[i +
                     (nzcount << 2)].im);
            V[i + ((nzcount - 1) << 2)].im = cfrom1 * V[i + ((nzcount - 1) << 2)]
              .im - (atmp.re * V[i + (nzcount << 2)].im - atmp.im * cfromc);
            V[i + (nzcount << 2)].re = stemp_re;
            V[i + (nzcount << 2)].im = stemp_im;
          }
        }
      }
    }

    xzhgeqz_DoaMusicSignal(A, ilo + 1, ihi, V, info, alpha1, beta1);
    if (*info != 0) {
    } else {
      xztgevc_DoaMusicSignal(A, V);
      if (ilo + 1 > 1) {
        for (i = ilo - 1; i + 1 >= 1; i--) {
          nzcount = rscale[i] - 1;
          if (rscale[i] != i + 1) {
            for (j = 0; j < 4; j++) {
              atmp = V[i + (j << 2)];
              V[i + (j << 2)] = V[nzcount + (j << 2)];
              V[nzcount + (j << 2)] = atmp;
            }
          }
        }
      }

      if (ihi < 4) {
        while (ihi + 1 < 5) {
          nzcount = rscale[ihi] - 1;
          if (rscale[ihi] != ihi + 1) {
            for (j = 0; j < 4; j++) {
              atmp = V[ihi + (j << 2)];
              V[ihi + (j << 2)] = V[nzcount + (j << 2)];
              V[nzcount + (j << 2)] = atmp;
            }
          }

          ihi++;
        }
      }

      for (nzcount = 0; nzcount < 4; nzcount++) {
        cfromc = fabs(V[nzcount << 2].re) + fabs(V[nzcount << 2].im);
        for (ii = 0; ii < 3; ii++) {
          ctoc = fabs(V[(ii + (nzcount << 2)) + 1].re) + fabs(V[(ii + (nzcount <<
            2)) + 1].im);
          if (ctoc > cfromc) {
            cfromc = ctoc;
          }
        }

        if (cfromc >= 6.7178761075670888E-139) {
          cfromc = 1.0 / cfromc;
          for (ii = 0; ii < 4; ii++) {
            V[ii + (nzcount << 2)].re *= cfromc;
            V[ii + (nzcount << 2)].im *= cfromc;
          }
        }
      }

      if (ilascl) {
        notdone = true;
        while (notdone) {
          cfrom1 = anrmto * 2.0041683600089728E-292;
          stemp_re = anrm / 4.9896007738368E+291;
          if ((fabs(cfrom1) > fabs(anrm)) && (anrm != 0.0)) {
            stemp_im = 2.0041683600089728E-292;
            anrmto = cfrom1;
          } else if (fabs(stemp_re) > fabs(anrmto)) {
            stemp_im = 4.9896007738368E+291;
            anrm = stemp_re;
          } else {
            stemp_im = anrm / anrmto;
            notdone = false;
          }

          for (nzcount = 0; nzcount < 4; nzcount++) {
            alpha1[nzcount].re *= stemp_im;
            alpha1[nzcount].im *= stemp_im;
          }
        }
      }
    }
  }
}

/*
 * Arguments    : creal_T A[16]
 *                int ilo
 *                int ihi
 *                creal_T Z[16]
 *                int *info
 *                creal_T alpha1[4]
 *                creal_T beta1[4]
 * Return Type  : void
 */
static void xzhgeqz_DoaMusicSignal(creal_T A[16], int ilo, int ihi, creal_T Z[16],
  int *info, creal_T alpha1[4], creal_T beta1[4])
{
  int i;
  double eshift_re;
  double eshift_im;
  creal_T ctemp;
  double anorm;
  double scale;
  double sumsq;
  double reAij;
  boolean_T firstNonZero;
  double b_atol;
  int j;
  int jp1;
  double ascale;
  boolean_T failed;
  double imAij;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  int ifirst;
  int istart;
  double temp2;
  int ilast;
  int ilastm1;
  int iiter;
  boolean_T goto60;
  boolean_T goto70;
  boolean_T goto90;
  int jiter;
  int exitg1;
  boolean_T exitg3;
  boolean_T b_guard1 = false;
  creal_T b_ascale;
  creal_T shift;
  double ad22_re;
  double ad22_im;
  boolean_T exitg2;
  double t1_im;
  *info = 0;
  for (i = 0; i < 4; i++) {
    alpha1[i].re = 0.0;
    alpha1[i].im = 0.0;
    beta1[i].re = 1.0;
    beta1[i].im = 0.0;
  }

  eshift_re = 0.0;
  eshift_im = 0.0;
  ctemp.re = 0.0;
  ctemp.im = 0.0;
  anorm = 0.0;
  if (ilo > ihi) {
  } else {
    scale = 0.0;
    sumsq = 0.0;
    firstNonZero = true;
    for (j = ilo; j <= ihi; j++) {
      jp1 = j + 1;
      if (ihi < j + 1) {
        jp1 = ihi;
      }

      for (i = ilo; i <= jp1; i++) {
        reAij = A[(i + ((j - 1) << 2)) - 1].re;
        imAij = A[(i + ((j - 1) << 2)) - 1].im;
        if (reAij != 0.0) {
          anorm = fabs(reAij);
          if (firstNonZero) {
            sumsq = 1.0;
            scale = anorm;
            firstNonZero = false;
          } else if (scale < anorm) {
            temp2 = scale / anorm;
            sumsq = 1.0 + sumsq * temp2 * temp2;
            scale = anorm;
          } else {
            temp2 = anorm / scale;
            sumsq += temp2 * temp2;
          }
        }

        if (imAij != 0.0) {
          anorm = fabs(imAij);
          if (firstNonZero) {
            sumsq = 1.0;
            scale = anorm;
            firstNonZero = false;
          } else if (scale < anorm) {
            temp2 = scale / anorm;
            sumsq = 1.0 + sumsq * temp2 * temp2;
            scale = anorm;
          } else {
            temp2 = anorm / scale;
            sumsq += temp2 * temp2;
          }
        }
      }
    }

    anorm = scale * sqrt(sumsq);
  }

  reAij = 2.2204460492503131E-16 * anorm;
  b_atol = 2.2250738585072014E-308;
  if (reAij > 2.2250738585072014E-308) {
    b_atol = reAij;
  }

  reAij = 2.2250738585072014E-308;
  if (anorm > 2.2250738585072014E-308) {
    reAij = anorm;
  }

  ascale = 1.0 / reAij;
  failed = true;
  for (j = ihi; j + 1 < 5; j++) {
    alpha1[j] = A[j + (j << 2)];
  }

  guard1 = false;
  guard2 = false;
  if (ihi >= ilo) {
    ifirst = ilo;
    istart = ilo;
    ilast = ihi - 1;
    ilastm1 = ihi - 2;
    iiter = 0;
    goto60 = false;
    goto70 = false;
    goto90 = false;
    jiter = 1;
    do {
      exitg1 = 0;
      if (jiter <= 30 * ((ihi - ilo) + 1)) {
        if (ilast + 1 == ilo) {
          goto60 = true;
        } else if (fabs(A[ilast + (ilastm1 << 2)].re) + fabs(A[ilast + (ilastm1 <<
          2)].im) <= b_atol) {
          A[ilast + (ilastm1 << 2)].re = 0.0;
          A[ilast + (ilastm1 << 2)].im = 0.0;
          goto60 = true;
        } else {
          j = ilastm1;
          exitg3 = false;
          while ((!exitg3) && (j + 1 >= ilo)) {
            if (j + 1 == ilo) {
              firstNonZero = true;
            } else if (fabs(A[j + ((j - 1) << 2)].re) + fabs(A[j + ((j - 1) << 2)]
                        .im) <= b_atol) {
              A[j + ((j - 1) << 2)].re = 0.0;
              A[j + ((j - 1) << 2)].im = 0.0;
              firstNonZero = true;
            } else {
              firstNonZero = false;
            }

            if (firstNonZero) {
              ifirst = j + 1;
              goto70 = true;
              exitg3 = true;
            } else {
              j--;
            }
          }
        }

        if (goto60 || goto70) {
          firstNonZero = true;
        } else {
          firstNonZero = false;
        }

        if (!firstNonZero) {
          for (i = 0; i < 4; i++) {
            alpha1[i].re = rtNaN;
            alpha1[i].im = 0.0;
            beta1[i].re = rtNaN;
            beta1[i].im = 0.0;
          }

          for (jp1 = 0; jp1 < 16; jp1++) {
            Z[jp1].re = rtNaN;
            Z[jp1].im = 0.0;
          }

          *info = 1;
          exitg1 = 1;
        } else {
          b_guard1 = false;
          if (goto60) {
            goto60 = false;
            alpha1[ilast] = A[ilast + (ilast << 2)];
            ilast = ilastm1;
            ilastm1--;
            if (ilast + 1 < ilo) {
              failed = false;
              guard2 = true;
              exitg1 = 1;
            } else {
              iiter = 0;
              eshift_re = 0.0;
              eshift_im = 0.0;
              b_guard1 = true;
            }
          } else {
            if (goto70) {
              goto70 = false;
              iiter++;
              if (iiter - iiter / 10 * 10 != 0) {
                anorm = ascale * A[ilastm1 + (ilastm1 << 2)].re;
                reAij = ascale * A[ilastm1 + (ilastm1 << 2)].im;
                if (reAij == 0.0) {
                  shift.re = anorm / 0.5;
                  shift.im = 0.0;
                } else if (anorm == 0.0) {
                  shift.re = 0.0;
                  shift.im = reAij / 0.5;
                } else {
                  shift.re = anorm / 0.5;
                  shift.im = reAij / 0.5;
                }

                anorm = ascale * A[ilast + (ilast << 2)].re;
                reAij = ascale * A[ilast + (ilast << 2)].im;
                if (reAij == 0.0) {
                  ad22_re = anorm / 0.5;
                  ad22_im = 0.0;
                } else if (anorm == 0.0) {
                  ad22_re = 0.0;
                  ad22_im = reAij / 0.5;
                } else {
                  ad22_re = anorm / 0.5;
                  ad22_im = reAij / 0.5;
                }

                temp2 = 0.5 * (shift.re + ad22_re);
                t1_im = 0.5 * (shift.im + ad22_im);
                anorm = ascale * A[ilastm1 + (ilast << 2)].re;
                reAij = ascale * A[ilastm1 + (ilast << 2)].im;
                if (reAij == 0.0) {
                  sumsq = anorm / 0.5;
                  imAij = 0.0;
                } else if (anorm == 0.0) {
                  sumsq = 0.0;
                  imAij = reAij / 0.5;
                } else {
                  sumsq = anorm / 0.5;
                  imAij = reAij / 0.5;
                }

                anorm = ascale * A[ilast + (ilastm1 << 2)].re;
                reAij = ascale * A[ilast + (ilastm1 << 2)].im;
                if (reAij == 0.0) {
                  scale = anorm / 0.5;
                  anorm = 0.0;
                } else if (anorm == 0.0) {
                  scale = 0.0;
                  anorm = reAij / 0.5;
                } else {
                  scale = anorm / 0.5;
                  anorm = reAij / 0.5;
                }

                reAij = shift.re * ad22_im + shift.im * ad22_re;
                shift.re = ((temp2 * temp2 - t1_im * t1_im) + (sumsq * scale -
                  imAij * anorm)) - (shift.re * ad22_re - shift.im * ad22_im);
                shift.im = ((temp2 * t1_im + t1_im * temp2) + (sumsq * anorm +
                  imAij * scale)) - reAij;
                sqrt_DoaMusicSignal(&shift);
                if ((temp2 - ad22_re) * shift.re + (t1_im - ad22_im) * shift.im <=
                    0.0) {
                  shift.re += temp2;
                  shift.im += t1_im;
                } else {
                  shift.re = temp2 - shift.re;
                  shift.im = t1_im - shift.im;
                }
              } else {
                anorm = ascale * A[ilast + (ilastm1 << 2)].re;
                reAij = ascale * A[ilast + (ilastm1 << 2)].im;
                if (reAij == 0.0) {
                  sumsq = anorm / 0.5;
                  imAij = 0.0;
                } else if (anorm == 0.0) {
                  sumsq = 0.0;
                  imAij = reAij / 0.5;
                } else {
                  sumsq = anorm / 0.5;
                  imAij = reAij / 0.5;
                }

                eshift_re += sumsq;
                eshift_im += imAij;
                shift.re = eshift_re;
                shift.im = eshift_im;
              }

              j = ilastm1;
              jp1 = ilastm1 + 1;
              exitg2 = false;
              while ((!exitg2) && (j + 1 > ifirst)) {
                istart = j + 1;
                ctemp.re = ascale * A[j + (j << 2)].re - shift.re * 0.5;
                ctemp.im = ascale * A[j + (j << 2)].im - shift.im * 0.5;
                anorm = fabs(ctemp.re) + fabs(ctemp.im);
                temp2 = ascale * (fabs(A[jp1 + (j << 2)].re) + fabs(A[jp1 + (j <<
                  2)].im));
                reAij = anorm;
                if (temp2 > anorm) {
                  reAij = temp2;
                }

                if ((reAij < 1.0) && (reAij != 0.0)) {
                  anorm /= reAij;
                  temp2 /= reAij;
                }

                if ((fabs(A[j + ((j - 1) << 2)].re) + fabs(A[j + ((j - 1) << 2)]
                      .im)) * temp2 <= anorm * b_atol) {
                  goto90 = true;
                  exitg2 = true;
                } else {
                  jp1 = j;
                  j--;
                }
              }

              if (!goto90) {
                istart = ifirst;
                ctemp.re = ascale * A[(ifirst + ((ifirst - 1) << 2)) - 1].re -
                  shift.re * 0.5;
                ctemp.im = ascale * A[(ifirst + ((ifirst - 1) << 2)) - 1].im -
                  shift.im * 0.5;
                goto90 = true;
              }
            }

            if (goto90) {
              goto90 = false;
              b_ascale.re = ascale * A[istart + ((istart - 1) << 2)].re;
              b_ascale.im = ascale * A[istart + ((istart - 1) << 2)].im;
              b_xzlartg_DoaMusicSignal(ctemp, b_ascale, &scale, &shift);
              j = istart;
              jp1 = istart - 2;
              while (j < ilast + 1) {
                if (j > istart) {
                  xzlartg_DoaMusicSignal(A[(j + (jp1 << 2)) - 1], A[j + (jp1 <<
                    2)], &scale, &shift, &A[(j + (jp1 << 2)) - 1]);
                  A[j + (jp1 << 2)].re = 0.0;
                  A[j + (jp1 << 2)].im = 0.0;
                }

                for (jp1 = j - 1; jp1 + 1 < 5; jp1++) {
                  ad22_re = scale * A[(j + (jp1 << 2)) - 1].re + (shift.re * A[j
                    + (jp1 << 2)].re - shift.im * A[j + (jp1 << 2)].im);
                  ad22_im = scale * A[(j + (jp1 << 2)) - 1].im + (shift.re * A[j
                    + (jp1 << 2)].im + shift.im * A[j + (jp1 << 2)].re);
                  anorm = A[(j + (jp1 << 2)) - 1].im;
                  reAij = A[(j + (jp1 << 2)) - 1].re;
                  A[j + (jp1 << 2)].re = scale * A[j + (jp1 << 2)].re -
                    (shift.re * A[(j + (jp1 << 2)) - 1].re + shift.im * A[(j +
                      (jp1 << 2)) - 1].im);
                  A[j + (jp1 << 2)].im = scale * A[j + (jp1 << 2)].im -
                    (shift.re * anorm - shift.im * reAij);
                  A[(j + (jp1 << 2)) - 1].re = ad22_re;
                  A[(j + (jp1 << 2)) - 1].im = ad22_im;
                }

                shift.re = -shift.re;
                shift.im = -shift.im;
                jp1 = j;
                if (ilast + 1 < j + 2) {
                  jp1 = ilast - 1;
                }

                for (i = 0; i + 1 <= jp1 + 2; i++) {
                  ad22_re = scale * A[i + (j << 2)].re + (shift.re * A[i + ((j -
                    1) << 2)].re - shift.im * A[i + ((j - 1) << 2)].im);
                  ad22_im = scale * A[i + (j << 2)].im + (shift.re * A[i + ((j -
                    1) << 2)].im + shift.im * A[i + ((j - 1) << 2)].re);
                  anorm = A[i + (j << 2)].im;
                  reAij = A[i + (j << 2)].re;
                  A[i + ((j - 1) << 2)].re = scale * A[i + ((j - 1) << 2)].re -
                    (shift.re * A[i + (j << 2)].re + shift.im * A[i + (j << 2)].
                     im);
                  A[i + ((j - 1) << 2)].im = scale * A[i + ((j - 1) << 2)].im -
                    (shift.re * anorm - shift.im * reAij);
                  A[i + (j << 2)].re = ad22_re;
                  A[i + (j << 2)].im = ad22_im;
                }

                for (i = 0; i < 4; i++) {
                  ad22_re = scale * Z[i + (j << 2)].re + (shift.re * Z[i + ((j -
                    1) << 2)].re - shift.im * Z[i + ((j - 1) << 2)].im);
                  ad22_im = scale * Z[i + (j << 2)].im + (shift.re * Z[i + ((j -
                    1) << 2)].im + shift.im * Z[i + ((j - 1) << 2)].re);
                  anorm = Z[i + (j << 2)].im;
                  reAij = Z[i + (j << 2)].re;
                  Z[i + ((j - 1) << 2)].re = scale * Z[i + ((j - 1) << 2)].re -
                    (shift.re * Z[i + (j << 2)].re + shift.im * Z[i + (j << 2)].
                     im);
                  Z[i + ((j - 1) << 2)].im = scale * Z[i + ((j - 1) << 2)].im -
                    (shift.re * anorm - shift.im * reAij);
                  Z[i + (j << 2)].re = ad22_re;
                  Z[i + (j << 2)].im = ad22_im;
                }

                jp1 = j - 1;
                j++;
              }
            }

            b_guard1 = true;
          }

          if (b_guard1) {
            jiter++;
          }
        }
      } else {
        guard2 = true;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  } else {
    guard1 = true;
  }

  if (guard2) {
    if (failed) {
      *info = ilast + 1;
      for (jp1 = 0; jp1 + 1 <= ilast + 1; jp1++) {
        alpha1[jp1].re = rtNaN;
        alpha1[jp1].im = 0.0;
        beta1[jp1].re = rtNaN;
        beta1[jp1].im = 0.0;
      }

      for (jp1 = 0; jp1 < 16; jp1++) {
        Z[jp1].re = rtNaN;
        Z[jp1].im = 0.0;
      }
    } else {
      guard1 = true;
    }
  }

  if (guard1) {
    for (j = 0; j + 1 < ilo; j++) {
      alpha1[j] = A[j + (j << 2)];
    }
  }
}

/*
 * Arguments    : const creal_T x[16]
 * Return Type  : double
 */
static double xzlangeM_DoaMusicSignal(const creal_T x[16])
{
  double y;
  int k;
  boolean_T exitg1;
  double absxk;
  y = 0.0;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 16)) {
    absxk = rt_hypotd_snf_DoaMusicSignal(x[k].re, x[k].im);
    if (rtIsNaN(absxk)) {
      y = rtNaN;
      exitg1 = true;
    } else {
      if (absxk > y) {
        y = absxk;
      }

      k++;
    }
  }

  return y;
}

/*
 * Arguments    : const creal_T f
 *                const creal_T g
 *                double *cs
 *                creal_T *sn
 *                creal_T *r
 * Return Type  : void
 */
static void xzlartg_DoaMusicSignal(const creal_T f, const creal_T g, double *cs,
  creal_T *sn, creal_T *r)
{
  double scale;
  double f2s;
  double x;
  double fs_re;
  double fs_im;
  double gs_re;
  double gs_im;
  int count;
  int rescaledir;
  boolean_T guard1 = false;
  double g2;
  double g2s;
  scale = fabs(f.re);
  f2s = fabs(f.im);
  if (f2s > scale) {
    scale = f2s;
  }

  x = fabs(g.re);
  f2s = fabs(g.im);
  if (f2s > x) {
    x = f2s;
  }

  if (x > scale) {
    scale = x;
  }

  fs_re = f.re;
  fs_im = f.im;
  gs_re = g.re;
  gs_im = g.im;
  count = 0;
  rescaledir = 0;
  guard1 = false;
  if (scale >= 7.4428285367870146E+137) {
    do {
      count++;
      fs_re *= 1.3435752215134178E-138;
      fs_im *= 1.3435752215134178E-138;
      gs_re *= 1.3435752215134178E-138;
      gs_im *= 1.3435752215134178E-138;
      scale *= 1.3435752215134178E-138;
    } while (!(scale < 7.4428285367870146E+137));

    rescaledir = 1;
    guard1 = true;
  } else if (scale <= 1.3435752215134178E-138) {
    if ((g.re == 0.0) && (g.im == 0.0)) {
      *cs = 1.0;
      sn->re = 0.0;
      sn->im = 0.0;
      *r = f;
    } else {
      do {
        count++;
        fs_re *= 7.4428285367870146E+137;
        fs_im *= 7.4428285367870146E+137;
        gs_re *= 7.4428285367870146E+137;
        gs_im *= 7.4428285367870146E+137;
        scale *= 7.4428285367870146E+137;
      } while (!(scale > 1.3435752215134178E-138));

      rescaledir = -1;
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1) {
    scale = fs_re * fs_re + fs_im * fs_im;
    g2 = gs_re * gs_re + gs_im * gs_im;
    x = g2;
    if (1.0 > g2) {
      x = 1.0;
    }

    if (scale <= x * 2.0041683600089728E-292) {
      if ((f.re == 0.0) && (f.im == 0.0)) {
        *cs = 0.0;
        r->re = rt_hypotd_snf_DoaMusicSignal(g.re, g.im);
        r->im = 0.0;
        g2 = rt_hypotd_snf_DoaMusicSignal(gs_re, gs_im);
        sn->re = gs_re / g2;
        sn->im = -gs_im / g2;
      } else {
        g2s = sqrt(g2);
        *cs = rt_hypotd_snf_DoaMusicSignal(fs_re, fs_im) / g2s;
        x = fabs(f.re);
        f2s = fabs(f.im);
        if (f2s > x) {
          x = f2s;
        }

        if (x > 1.0) {
          g2 = rt_hypotd_snf_DoaMusicSignal(f.re, f.im);
          fs_re = f.re / g2;
          fs_im = f.im / g2;
        } else {
          scale = 7.4428285367870146E+137 * f.re;
          f2s = 7.4428285367870146E+137 * f.im;
          g2 = rt_hypotd_snf_DoaMusicSignal(scale, f2s);
          fs_re = scale / g2;
          fs_im = f2s / g2;
        }

        gs_re /= g2s;
        gs_im = -gs_im / g2s;
        sn->re = fs_re * gs_re - fs_im * gs_im;
        sn->im = fs_re * gs_im + fs_im * gs_re;
        r->re = *cs * f.re + (sn->re * g.re - sn->im * g.im);
        r->im = *cs * f.im + (sn->re * g.im + sn->im * g.re);
      }
    } else {
      f2s = sqrt(1.0 + g2 / scale);
      r->re = f2s * fs_re;
      r->im = f2s * fs_im;
      *cs = 1.0 / f2s;
      g2 += scale;
      scale = r->re / g2;
      f2s = r->im / g2;
      sn->re = scale * gs_re - f2s * -gs_im;
      sn->im = scale * -gs_im + f2s * gs_re;
      if (rescaledir > 0) {
        for (rescaledir = 1; rescaledir <= count; rescaledir++) {
          r->re *= 7.4428285367870146E+137;
          r->im *= 7.4428285367870146E+137;
        }
      } else {
        if (rescaledir < 0) {
          for (rescaledir = 1; rescaledir <= count; rescaledir++) {
            r->re *= 1.3435752215134178E-138;
            r->im *= 1.3435752215134178E-138;
          }
        }
      }
    }
  }
}

/*
 * Arguments    : const creal_T A[16]
 *                creal_T V[16]
 * Return Type  : void
 */
static void xztgevc_DoaMusicSignal(const creal_T A[16], creal_T V[16])
{
  double rworka[4];
  int jc;
  double anorm;
  int j;
  double xmx;
  double ascale;
  double d_re;
  int je;
  double temp;
  double salpha_re;
  double salpha_im;
  double acoeff;
  boolean_T b0;
  boolean_T b1;
  double scale;
  double acoefa;
  creal_T work1[4];
  int jr;
  double dmin;
  creal_T work2[4];
  double d_im;
  double work1_re;
  for (jc = 0; jc < 4; jc++) {
    rworka[jc] = 0.0;
  }

  anorm = fabs(A[0].re) + fabs(A[0].im);
  for (j = 0; j < 3; j++) {
    for (jc = 0; jc <= j; jc++) {
      rworka[j + 1] += fabs(A[jc + ((j + 1) << 2)].re) + fabs(A[jc + ((j + 1) <<
        2)].im);
    }

    d_re = rworka[j + 1] + (fabs(A[(j + ((j + 1) << 2)) + 1].re) + fabs(A[(j +
      ((j + 1) << 2)) + 1].im));
    if (d_re > anorm) {
      anorm = d_re;
    }
  }

  xmx = anorm;
  if (2.2250738585072014E-308 > anorm) {
    xmx = 2.2250738585072014E-308;
  }

  ascale = 1.0 / xmx;
  for (je = 0; je < 4; je++) {
    xmx = (fabs(A[(((3 - je) << 2) - je) + 3].re) + fabs(A[(((3 - je) << 2) - je)
            + 3].im)) * ascale;
    if (1.0 > xmx) {
      xmx = 1.0;
    }

    temp = 1.0 / xmx;
    salpha_re = ascale * (temp * A[(((3 - je) << 2) - je) + 3].re);
    salpha_im = ascale * (temp * A[(((3 - je) << 2) - je) + 3].im);
    acoeff = temp * ascale;
    if ((fabs(temp) >= 2.2250738585072014E-308) && (fabs(acoeff) <
         4.0083367200179456E-292)) {
      b0 = true;
    } else {
      b0 = false;
    }

    if ((fabs(salpha_re) + fabs(salpha_im) >= 2.2250738585072014E-308) && (fabs
         (salpha_re) + fabs(salpha_im) < 4.0083367200179456E-292)) {
      b1 = true;
    } else {
      b1 = false;
    }

    scale = 1.0;
    if (b0) {
      xmx = anorm;
      if (2.4948003869184E+291 < anorm) {
        xmx = 2.4948003869184E+291;
      }

      scale = 4.0083367200179456E-292 / fabs(temp) * xmx;
    }

    if (b1) {
      d_re = 4.0083367200179456E-292 / (fabs(salpha_re) + fabs(salpha_im));
      if (d_re > scale) {
        scale = d_re;
      }
    }

    if (b0 || b1) {
      xmx = fabs(acoeff);
      d_re = fabs(salpha_re) + fabs(salpha_im);
      if (1.0 > xmx) {
        xmx = 1.0;
      }

      if (d_re > xmx) {
        xmx = d_re;
      }

      d_re = 1.0 / (2.2250738585072014E-308 * xmx);
      if (d_re < scale) {
        scale = d_re;
      }

      if (b0) {
        acoeff = ascale * (scale * temp);
      } else {
        acoeff *= scale;
      }

      if (b1) {
        salpha_re *= scale;
        salpha_im *= scale;
      } else {
        salpha_re *= scale;
        salpha_im *= scale;
      }
    }

    acoefa = fabs(acoeff);
    for (jr = 0; jr < 4; jr++) {
      work1[jr].re = 0.0;
      work1[jr].im = 0.0;
    }

    work1[3 - je].re = 1.0;
    work1[3 - je].im = 0.0;
    dmin = 2.2204460492503131E-16 * acoefa * anorm;
    d_re = 2.2204460492503131E-16 * (fabs(salpha_re) + fabs(salpha_im));
    if (d_re > dmin) {
      dmin = d_re;
    }

    if (2.2250738585072014E-308 > dmin) {
      dmin = 2.2250738585072014E-308;
    }

    for (jr = 0; jr <= 2 - je; jr++) {
      work1[jr].re = acoeff * A[jr + ((3 - je) << 2)].re;
      work1[jr].im = acoeff * A[jr + ((3 - je) << 2)].im;
    }

    work1[3 - je].re = 1.0;
    work1[3 - je].im = 0.0;
    for (j = 0; j <= 2 - je; j++) {
      jc = (-je - j) + 2;
      d_re = acoeff * A[jc + (jc << 2)].re - salpha_re;
      d_im = acoeff * A[jc + (jc << 2)].im - salpha_im;
      if (fabs(d_re) + fabs(d_im) <= dmin) {
        d_re = dmin;
        d_im = 0.0;
      }

      if ((fabs(d_re) + fabs(d_im) < 1.0) && (fabs(work1[jc].re) + fabs(work1[jc]
            .im) >= 1.1235582092889474E+307 * (fabs(d_re) + fabs(d_im)))) {
        temp = 1.0 / (fabs(work1[jc].re) + fabs(work1[jc].im));
        for (jr = 0; jr <= 3 - je; jr++) {
          work1[jr].re *= temp;
          work1[jr].im *= temp;
        }
      }

      work1_re = -work1[jc].re;
      if (d_im == 0.0) {
        if (-work1[jc].im == 0.0) {
          work1[jc].re = -work1[jc].re / d_re;
          work1[jc].im = 0.0;
        } else if (-work1[jc].re == 0.0) {
          work1[jc].re = 0.0;
          work1[jc].im = -work1[jc].im / d_re;
        } else {
          work1[jc].re = -work1[jc].re / d_re;
          work1[jc].im = -work1[jc].im / d_re;
        }
      } else if (d_re == 0.0) {
        if (-work1[jc].re == 0.0) {
          work1[jc].re = -work1[jc].im / d_im;
          work1[jc].im = 0.0;
        } else if (-work1[jc].im == 0.0) {
          work1[jc].re = 0.0;
          work1[jc].im = -(work1_re / d_im);
        } else {
          work1[jc].re = -work1[jc].im / d_im;
          work1[jc].im = -(work1_re / d_im);
        }
      } else {
        temp = fabs(d_re);
        xmx = fabs(d_im);
        if (temp > xmx) {
          scale = d_im / d_re;
          xmx = d_re + scale * d_im;
          work1[jc].re = (-work1[jc].re + scale * -work1[jc].im) / xmx;
          work1[jc].im = (-work1[jc].im - scale * work1_re) / xmx;
        } else if (xmx == temp) {
          if (d_re > 0.0) {
            scale = 0.5;
          } else {
            scale = -0.5;
          }

          if (d_im > 0.0) {
            xmx = 0.5;
          } else {
            xmx = -0.5;
          }

          work1[jc].re = (-work1[jc].re * scale + -work1[jc].im * xmx) / temp;
          work1[jc].im = (-work1[jc].im * scale - work1_re * xmx) / temp;
        } else {
          scale = d_re / d_im;
          xmx = d_im + scale * d_re;
          work1[jc].re = (scale * -work1[jc].re + -work1[jc].im) / xmx;
          work1[jc].im = (scale * -work1[jc].im - work1_re) / xmx;
        }
      }

      if (jc + 1 > 1) {
        if (fabs(work1[jc].re) + fabs(work1[jc].im) > 1.0) {
          temp = 1.0 / (fabs(work1[jc].re) + fabs(work1[jc].im));
          if (acoefa * rworka[jc] >= 1.1235582092889474E+307 * temp) {
            for (jr = 0; jr <= 3 - je; jr++) {
              work1[jr].re *= temp;
              work1[jr].im *= temp;
            }
          }
        }

        d_re = acoeff * work1[jc].re;
        d_im = acoeff * work1[jc].im;
        for (jr = 0; jr < jc; jr++) {
          work1[jr].re += d_re * A[jr + (jc << 2)].re - d_im * A[jr + (jc << 2)]
            .im;
          work1[jr].im += d_re * A[jr + (jc << 2)].im + d_im * A[jr + (jc << 2)]
            .re;
        }
      }
    }

    for (jr = 0; jr < 4; jr++) {
      work2[jr].re = 0.0;
      work2[jr].im = 0.0;
    }

    for (jc = 0; jc <= 3 - je; jc++) {
      for (jr = 0; jr < 4; jr++) {
        work2[jr].re += V[jr + (jc << 2)].re * work1[jc].re - V[jr + (jc << 2)].
          im * work1[jc].im;
        work2[jr].im += V[jr + (jc << 2)].re * work1[jc].im + V[jr + (jc << 2)].
          im * work1[jc].re;
      }
    }

    xmx = fabs(work2[0].re) + fabs(work2[0].im);
    for (jr = 0; jr < 3; jr++) {
      d_re = fabs(work2[jr + 1].re) + fabs(work2[jr + 1].im);
      if (d_re > xmx) {
        xmx = d_re;
      }
    }

    if (xmx > 2.2250738585072014E-308) {
      temp = 1.0 / xmx;
      for (jr = 0; jr < 4; jr++) {
        V[jr + ((3 - je) << 2)].re = temp * work2[jr].re;
        V[jr + ((3 - je) << 2)].im = temp * work2[jr].im;
      }
    } else {
      for (jr = 0; jr < 4; jr++) {
        V[jr + ((3 - je) << 2)].re = 0.0;
        V[jr + ((3 - je) << 2)].im = 0.0;
      }
    }
  }
}

/*
 * DOA estimation using MUSIC method. but filter only the signal.
 *  input:
 *     % recStvPartition, MxK complex, matrix of steering vectors, each column is one steering vector for a specific Azimuth angle. M is the number of channel. K is the number of azimuth scan angle.
 *     % rxSigNoise: NxM complex, N is the number of snapshots, M is the number of channel. each colum is one snapshot
 *     % AzimuthScanAngles: 1xK double, azimuth scan angle in degree, should be in assending order.
 *     % MaxNumSig: 1x1 double, the number of maximum signals in DOA search.
 *  output:
 *     % spatialSpectrum, 1xK double, it is a matrix representing the magnitude of the estimated spatial spectrum.
 *     % doas, 1xP double, the signal's direction of arrival (DOA) .
 *  2017-10-18 V1.0 Collus Wang and Wayne Zhang. inherited from old repo.
 *  2017-10-20 V1.1 Collus Wang. eigD convert to double.
 * Arguments    : const creal_T recStvPartition[484]
 *                const creal_T rxSigNoise[2048]
 *                const double AzimuthScanAngles[121]
 *                double MaxNumSig
 *                double spatialSpectrum[121]
 *                double doas_data[]
 *                int doas_size[1]
 * Return Type  : void
 */
void DoaEstimatorMUSICSignalImplement(const creal_T recStvPartition[484], const
  creal_T rxSigNoise[2048], const double AzimuthScanAngles[121], double
  MaxNumSig, double spatialSpectrum[121], double doas_data[], int doas_size[1])
{
  int i0;
  creal_T Pxs[4];
  int i1;
  creal_T b_Pxs[16];
  static const creal_T b[512] = { { 0.597750197628676, -0.899287820462048 }, {
      0.832619582099781, -0.131116226113365 }, { 0.791277450536945,
      0.870126619551477 }, { 0.00511199813821906, 0.812875746714423 }, { -
      0.798163847058874, 0.597925131295389 }, { -0.832866975663762,
      0.838791622717269 }, { -0.586766442514103, 0.799582096855205 }, { -
      0.833370426379568, -0.0146346813542591 }, { -0.818914680331913,
      -0.792434692124505 }, { 0.0385749092847886, -0.822980859313228 }, {
      0.732202685437865, -0.657215980004006 }, { 0.923622193220723,
      -0.70099345133522 }, { 0.806820371797992, -0.714344198108465 }, { -
      0.109820602127619, -0.699557220994909 }, { -0.886386230493411,
      -0.678510982596137 }, { -0.134397997564108, -0.79501166923593 }, {
      0.875863014400597, -0.846858771129085 }, { 0.806596527013989,
      0.0794641122889465 }, { 0.63222503187051, 0.9735628794035 }, {
      0.758091986539724, -0.0024279704931971 }, { 0.649466857913873,
      -1.00972746024489 }, { 0.780072996585994, 0.0146729892893962 }, {
      0.88657895454894, 0.941910343383084 }, { -0.122462658277827,
      0.110029687756464 }, { -0.949398457264446, -0.855163324627926 }, {
      0.00846865711721725, -0.813260313752596 }, { 0.933265080733581,
      -0.593814839863572 }, { 0.127440458315457, -0.844338769244911 }, { -
      0.868352809497298, -0.809490755568833 }, { -0.810260021395785,
      0.0331278753277856 }, { -0.599168354605588, 0.737707031737225 }, { -
      0.838247501269642, 0.92116602231154 }, { -0.801456028123654,
      0.812228990335624 }, { 0.0181892026778493, -0.117982423842039 }, {
      0.790508039425551, -0.899555635428278 }, { 0.820821416287692,
      -0.108559853196637 }, { 0.6665229213582, 0.820436640360084 }, {
      0.690938920087664, 0.901465701765124 }, { 0.722256991775696,
      0.800254604492219 }, { 0.69956006510203, -0.0765486180798176 }, {
      0.65700200030132, -0.967092004484677 }, { 0.827567025800378,
      -0.0116597453063136 }, { 0.806727490498474, 0.968213386836347 }, { -
      0.0120666932797497, 0.0953131836281251 }, { -0.759048227460663,
      -0.854771564796316 }, { -0.909834246311703, -0.800809053434673 }, { -
      0.808331502893841, -0.660959449088361 }, { 0.0996902644864311,
      -0.720721359720704 }, { 0.949635363363849, -0.717178160636984 }, {
      0.0138969199672255, -0.678862316188488 }, { -0.962342218189525,
      -0.7212767877617 }, { -0.106235036280923, -0.710363646654112 }, {
      0.863180354503709, -0.64566636676589 }, { 0.796416658153411,
      -0.833104261708592 }, { 0.654747571290877, -0.798918407063083 }, {
      0.732687940429815, 0.00477696231943516 }, { 0.700630933252572,
      0.754427088881499 }, { 0.690988451307054, 0.925251582190004 }, {
      0.731021341740936, 0.754276350143574 }, { 0.685667367539991,
      0.00339781102125576 }, { 0.702592609812637, -0.802593096957289 }, {
      0.735115910923013, -0.826265606137574 }, { 0.641047239274157,
      -0.653105781391609 }, { 0.815528729836338, -0.703449622244404 }, {
      0.865591648333791, -0.705284991785995 }, { -0.12849448441428,
      -0.711742797952292 }, { -0.890215774119824, -0.665483591373724 }, { -
      0.110045614756338, -0.801678300081658 }, { 0.805970919406834,
      -0.868023022098378 }, { 0.92649701669803, 0.116752916333887 }, {
      0.740007653878974, 0.91557236888813 }, { 0.0244712664854036,
      0.0834060447578302 }, { -0.811357446922529, -0.796911805903784 }, { -
      0.831856464403881, -0.913241486641951 }, { -0.634018921859194,
      -0.811687234321449 }, { -0.727398098085583, 0.106322678535725 }, { -
      0.70721164448495, 0.8978788216679 }, { -0.685332331721207,
      0.121261351185662 }, { -0.734444181609135, -0.815593972765416 }, { -
      0.685034356805976, -0.919423437878867 }, { -0.714746786872397,
      -0.741071921347597 }, { -0.716658180777503, -0.030039743816448 }, { -
      0.644199417713915, 0.813967869348111 }, { -0.826296847560404,
      0.833470538950206 }, { -0.795389845875613, 0.633404271660588 }, { -
      0.00542826285000829, 0.728101773942665 }, { 0.794219764268299,
      0.710151854309453 }, { 0.83595795128222, 0.680207863267152 }, {
      0.605165417325606, 0.736145190298302 }, { 0.803830676594888,
      0.68749052771516 }, { 0.86371369489048, 0.699876373248363 }, { -
      0.112929867542636, 0.737252973013286 }, { -0.938129932169607,
      0.640646661597657 }, { -0.0170473374245001, 0.812365842063228 }, {
      0.997312615314229, 0.862319640022937 }, { 0.0214115322897759,
      -0.117854110855414 }, { -1.018383984984, -0.898872298858942 }, {
      0.0053593917022003, -0.105093171027573 }, { 1.00740022986943,
      0.85020156971752 }, { -0.0188745887383731, 0.817361800630935 }, { -
      0.989187017656964, 0.652336277460795 }, { 0.00278129610853988,
      0.71382326231087 }, { 0.955776450883752, 0.714746786872397 }, {
      0.100100056566987, 0.688936187364462 }, { -0.876883099825346,
      0.673513461269261 }, { -0.773324542966187, 0.811107937239366 }, { -
      0.668316811346884, 0.794445408278086 }, { -0.73300184234492,
      0.0234013133867066 }, { -0.631377590566783, -0.82074845173135 }, { -
      0.831173922450478, -0.815221894433541 }, { -0.803154932905969,
      -0.598951528440691 }, { 0.0131366463784466, -0.832024879300903 }, {
      0.735906180292048, -0.79663105809838 }, { 0.943775820686637,
      0.00357565522726951 }, { 0.749294515298662, 0.788056585726458 }, { -
      0.00499311446058607, 0.838639134820122 }, { -0.737779833102237,
      0.6073510671459 }, { -0.951975950336194, 0.797795809451591 }, { -
      0.743903130233326, 0.866499050982776 }, { 0.00808409007904414,
      -0.11109679674804 }, { 0.751356220253577, -0.942759888593662 }, {
      0.926597129268668, -0.0107652736169457 }, { 0.786153694798999,
      0.993956883886621 }, { -0.0800989169982213, 0.0199940730564594 }, { -
      0.956933599651893, -1.00757516353614 }, { -0.0228571919390786,
      -0.00623148245630531 }, { 1.0235098446288, 1.01437950769088 }, { -
      0.0138220324389705, -0.0146135474505797 }, { -0.948995868500514,
      -1.00749311116895 }, { -0.0990301034682904, 0.0265488867368607 }, {
      0.843763707572375, 0.950566868122202 }, { 0.82028436135237,
      0.0842004038765598 }, { 0.598789527613151, -0.809326650834442 }, {
      0.8316090708399, -0.895787201244015 }, { 0.85294063985909,
      -0.798692763053295 }, { -0.122003334977882, 0.0714394640487189 }, { -
      0.880625733534922, 0.956563930842221 }, { -0.133212004894899,
      0.0305909317763828 }, { 0.864244621972332, -1.02548949721652 }, {
      0.821888525279268, 0.00893504692946981 }, { 0.582300157667146,
      1.01044414992577 }, { 0.853896916288968, -0.0251626689263745 }, {
      0.794635285871404, -0.94034850194416 }, { -0.0211046968869782,
      -0.0989706616294739 }, { -0.736784685161636, 0.855028550830224 }, { -
      0.934421552367619, 0.801324974466315 }, { -0.752787310069662,
      0.643989460186091 }, { 0.00366633848891637, 0.743375482411386 }, {
      0.795918669050615, 0.664397232883164 }, { 0.824842327423534,
      0.771463074855881 }, { 0.649373976614355, 0.882904264654734 }, {
      0.711742797952292, -0.108393232274876 }, { 0.673491370247324,
      -0.971918985597381 }, { 0.788213684396734, 0.0300991856552645 }, {
      0.818160120327704, 0.935386747033754 }, { 0.0076489416896219,
      0.103072148507813 }, { -0.823391794111192, -0.796507113233001 }, { -
      0.795731272092887, -0.931840481400356 }, { -0.656154558997593,
      -0.738733428882527 }, { -0.730883070051205, -0.0213114197191376 }, { -
      0.651734560101362, 0.751336140319071 }, { -0.801034066063392,
      0.957087948474413 }, { -0.864162569605137, 0.723460426494562 }, {
      0.110530294365149, 0.0179730505366983 }, { 0.904413680106844,
      -0.750933551555139 }, { 0.104198699338206, -0.951540801946772 }, { -
      0.85340244741292, -0.718064647976684 }, { -0.8118217206156,
      -0.0327433082896124 }, { -0.657193888982068, 0.805970919406834 }, { -
      0.713704378633237, 0.849194710231305 }, { -0.703004449578752,
      0.570112967833708 }, { -0.704785258703641, 0.845656115907589 }, { -
      0.674249952426396, 0.807269339332069 }, { -0.794336193794834,
      -0.03408178885597 }, { -0.847363492194718, -0.724630508101876 }, {
      0.0795024202240836, -0.940535201278152 }, { 0.9673019620125,
      -0.758846345222371 }, { 0.0053210837670631, 0.017019137008514 }, { -
      1.01942331496848, 0.746741207756127 }, { 0.022538083120169,
      0.924307579281247 }, { 0.956130340392041, 0.787273066063239 }, {
      0.0773742186213774, -0.0808409007904413 }, { -0.799274400478222,
      -0.953612892085396 }, { -0.902085192051443, -0.0254817777452841 }, { -
      0.800513601613559, 1.03150469066323 }, { 0.0791267136734779,
      -0.0241432971789265 }, { 0.944131017064489, -0.952858332081187 }, {
      0.0396573326993212, -0.0832464903483755 }, { -1.02348490714465,
      0.791737247003344 }, { -0.00282244815079745, 0.918879316431239 }, {
      1.03161050480192, 0.745619825404457 }, { -0.0457415341622837,
      0.0253628940676512 }, { -0.945593851122181, -0.796688172981428 }, { -
      0.0751535397817638, -0.852401725420276 }, { 0.777823275621812,
      -0.582879784004642 }, { 0.931155095339833, -0.822564000720365 }, {
      0.762426049910208, -0.869677744836819 }, { -0.0140311180678146,
      0.138768011910108 }, { -0.738483589943952, 0.877754643238441 }, { -
      0.939474108667022, 0.120626546476387 }, { -0.807389169203165,
      -0.84180203101231 }, { 0.126620742887862, -0.84370700554248 }, {
      0.878690262991077, -0.594042494960791 }, { 0.128910292875284,
      -0.815281336272357 }, { -0.806149968067829, -0.86879051494176 }, { -
      0.943516153706544, 0.131941826654925 }, { -0.727723467751735,
      0.940386372267482 }, { -0.0271083226074448, -0.00489300188994777 }, {
      0.755727519894165, -0.937340348304288 }, { 0.952375831797323,
      -0.126582434952725 }, { 0.720213262848436, 0.859273616059743 }, {
      0.0288696781471126, 0.823881347383043 }, { -0.789753479421342,
      0.594299480994699 }, { -0.86894740610423, 0.831965437462087 }, { -
      0.576303094947128, 0.862213825884245 }, { -0.815556930252325,
      -0.140154229720594 }, { -0.881001806884568, -0.883460129220734 }, {
      0.152718554235426, -0.109579224944085 }, { 0.887450497962035,
      0.795790423552113 }, { 0.0899949439681823, 0.942330161037335 }, { -
      0.790156068185274, 0.741684467639352 }, { -0.931214537178649,
      0.00652945737153563 }, { -0.790969846979382, -0.751511073985784 }, {
      0.0941866327977319, -0.940991680470977 }, { 0.894985640349482,
      -0.785209257201472 }, { 0.137488973182566, 0.0927762400767222 }, { -
      0.87000753223574, 0.896996356503062 }, { -0.820818572180571,
      0.135793075862162 }, { -0.602876057273472, -0.882893435722411 }, { -
      0.822254802520882, -0.797667496464966 }, { -0.848712529643608,
      -0.648759326415749 }, { 0.109519783105269, -0.740168467222415 }, {
      0.951666159451935, -0.64711753651648 }, { -0.00177362895577977,
      -0.798278126263717 }, { -0.965105483259884, -0.820805566614397 }, { -
      0.0879144796096048, 0.00786793793789321 }, { 0.81396585826068,
      0.811733520272174 }, { 0.891229235172851, 0.795872536705783 }, {
      0.818253001627222, 0.665921203998767 }, { -0.0937867513366027,
      0.716619872842366 }, { -0.923498095394534, 0.656400282941886 }, { -
      0.0963742762392546, 0.811239291232835 }, { 0.820036062683584,
      0.818432050288217 }, { 0.888254299124905, -0.0156423485070192 }, {
      0.813695939387598, -0.766691195074232 }, { -0.0845578206306066,
      -0.896397831042766 }, { -0.969569664199989, -0.813563176677329 }, {
      0.00270356447316448, 0.094034144900584 }, { 0.956815780868228,
      0.964870588247913 }, { 0.099089545307107, -0.005462348379959 }, { -
      0.815219910503201, -0.965530163045753 }, { -0.900439876082288,
      -0.0838158368383867 }, { -0.750778697822933, 0.800703479206876 }, { -
      0.033346871576057, 0.905057283992268 }, { 0.824146354115401,
      0.808911129231337 }, { 0.820362092987746, -0.0940935867394005 }, {
      0.597750197628676, -0.899287820462048 }, { 0.832619582099781,
      -0.131116226113365 }, { 0.791277450536945, 0.870126619551477 }, {
      0.00511199813821906, 0.812875746714423 }, { -0.798163847058874,
      0.597925131295389 }, { -0.832866975663762, 0.838791622717269 }, { -
      0.586766442514103, 0.799582096855205 }, { -0.833370426379568,
      -0.0146346813542591 }, { -0.818914680331913, -0.792434692124505 }, {
      0.0385749092847886, -0.822980859313228 }, { 0.732202685437865,
      -0.657215980004006 }, { 0.923622193220723, -0.70099345133522 }, {
      0.806820371797992, -0.714344198108465 }, { -0.109820602127619,
      -0.699557220994909 }, { -0.886386230493411, -0.678510982596137 }, { -
      0.134397997564108, -0.79501166923593 }, { 0.875863014400597,
      -0.846858771129085 }, { 0.806596527013989, 0.0794641122889465 }, {
      0.63222503187051, 0.9735628794035 }, { 0.758091986539724,
      -0.0024279704931971 }, { 0.649466857913873, -1.00972746024489 }, {
      0.780072996585994, 0.0146729892893962 }, { 0.88657895454894,
      0.941910343383084 }, { -0.122462658277827, 0.110029687756464 }, { -
      0.949398457264446, -0.855163324627926 }, { 0.00846865711721725,
      -0.813260313752596 }, { 0.933265080733581, -0.593814839863572 }, {
      0.127440458315457, -0.844338769244911 }, { -0.868352809497298,
      -0.809490755568833 }, { -0.810260021395785, 0.0331278753277856 }, { -
      0.599168354605588, 0.737707031737225 }, { -0.838247501269642,
      0.92116602231154 }, { -0.801456028123654, 0.812228990335624 }, {
      0.0181892026778493, -0.117982423842039 }, { 0.790508039425551,
      -0.899555635428278 }, { 0.820821416287692, -0.108559853196637 }, {
      0.6665229213582, 0.820436640360084 }, { 0.690938920087664,
      0.901465701765124 }, { 0.722256991775696, 0.800254604492219 }, {
      0.69956006510203, -0.0765486180798176 }, { 0.65700200030132,
      -0.967092004484677 }, { 0.827567025800378, -0.0116597453063136 }, {
      0.806727490498474, 0.968213386836347 }, { -0.0120666932797497,
      0.0953131836281251 }, { -0.759048227460663, -0.854771564796316 }, { -
      0.909834246311703, -0.800809053434673 }, { -0.808331502893841,
      -0.660959449088361 }, { 0.0996902644864311, -0.720721359720704 }, {
      0.949635363363849, -0.717178160636984 }, { 0.0138969199672255,
      -0.678862316188488 }, { -0.962342218189525, -0.7212767877617 }, { -
      0.106235036280923, -0.710363646654112 }, { 0.863180354503709,
      -0.64566636676589 }, { 0.796416658153411, -0.833104261708592 }, {
      0.654747571290877, -0.798918407063083 }, { 0.732687940429815,
      0.00477696231943516 }, { 0.700630933252572, 0.754427088881499 }, {
      0.690988451307054, 0.925251582190004 }, { 0.731021341740936,
      0.754276350143574 }, { 0.685667367539991, 0.00339781102125576 }, {
      0.702592609812637, -0.802593096957289 }, { 0.735115910923013,
      -0.826265606137574 }, { 0.641047239274157, -0.653105781391609 }, {
      0.815528729836338, -0.703449622244404 }, { 0.865591648333791,
      -0.705284991785995 }, { -0.12849448441428, -0.711742797952292 }, { -
      0.890215774119824, -0.665483591373724 }, { -0.110045614756338,
      -0.801678300081658 }, { 0.805970919406834, -0.868023022098378 }, {
      0.92649701669803, 0.116752916333887 }, { 0.740007653878974,
      0.91557236888813 }, { 0.0244712664854036, 0.0834060447578302 }, { -
      0.811357446922529, -0.796911805903784 }, { -0.831856464403881,
      -0.913241486641951 }, { -0.634018921859194, -0.811687234321449 }, { -
      0.727398098085583, 0.106322678535725 }, { -0.70721164448495,
      0.8978788216679 }, { -0.685332331721207, 0.121261351185662 }, { -
      0.734444181609135, -0.815593972765416 }, { -0.685034356805976,
      -0.919423437878867 }, { -0.714746786872397, -0.741071921347597 }, { -
      0.716658180777503, -0.030039743816448 }, { -0.644199417713915,
      0.813967869348111 }, { -0.826296847560404, 0.833470538950206 }, { -
      0.795389845875613, 0.633404271660588 }, { -0.00542826285000829,
      0.728101773942665 }, { 0.794219764268299, 0.710151854309453 }, {
      0.83595795128222, 0.680207863267152 }, { 0.605165417325606,
      0.736145190298302 }, { 0.803830676594888, 0.68749052771516 }, {
      0.86371369489048, 0.699876373248363 }, { -0.112929867542636,
      0.737252973013286 }, { -0.938129932169607, 0.640646661597657 }, { -
      0.0170473374245001, 0.812365842063228 }, { 0.997312615314229,
      0.862319640022937 }, { 0.0214115322897759, -0.117854110855414 }, { -
      1.018383984984, -0.898872298858942 }, { 0.0053593917022003,
      -0.105093171027573 }, { 1.00740022986943, 0.85020156971752 }, { -
      0.0188745887383731, 0.817361800630935 }, { -0.989187017656964,
      0.652336277460795 }, { 0.00278129610853988, 0.71382326231087 }, {
      0.955776450883752, 0.714746786872397 }, { 0.100100056566987,
      0.688936187364462 }, { -0.876883099825346, 0.673513461269261 }, { -
      0.773324542966187, 0.811107937239366 }, { -0.668316811346884,
      0.794445408278086 }, { -0.73300184234492, 0.0234013133867066 }, { -
      0.631377590566783, -0.82074845173135 }, { -0.831173922450478,
      -0.815221894433541 }, { -0.803154932905969, -0.598951528440691 }, {
      0.0131366463784466, -0.832024879300903 }, { 0.735906180292048,
      -0.79663105809838 }, { 0.943775820686637, 0.00357565522726951 }, {
      0.749294515298662, 0.788056585726458 }, { -0.00499311446058607,
      0.838639134820122 }, { -0.737779833102237, 0.6073510671459 }, { -
      0.951975950336194, 0.797795809451591 }, { -0.743903130233326,
      0.866499050982776 }, { 0.00808409007904414, -0.11109679674804 }, {
      0.751356220253577, -0.942759888593662 }, { 0.926597129268668,
      -0.0107652736169457 }, { 0.786153694798999, 0.993956883886621 }, { -
      0.0800989169982213, 0.0199940730564594 }, { -0.956933599651893,
      -1.00757516353614 }, { -0.0228571919390786, -0.00623148245630531 }, {
      1.0235098446288, 1.01437950769088 }, { -0.0138220324389705,
      -0.0146135474505797 }, { -0.948995868500514, -1.00749311116895 }, { -
      0.0990301034682904, 0.0265488867368607 }, { 0.843763707572375,
      0.950566868122202 }, { 0.82028436135237, 0.0842004038765598 }, {
      0.598789527613151, -0.809326650834442 }, { 0.8316090708399,
      -0.895787201244015 }, { 0.85294063985909, -0.798692763053295 }, { -
      0.122003334977882, 0.0714394640487189 }, { -0.880625733534922,
      0.956563930842221 }, { -0.133212004894899, 0.0305909317763828 }, {
      0.864244621972332, -1.02548949721652 }, { 0.821888525279268,
      0.00893504692946981 }, { 0.582300157667146, 1.01044414992577 }, {
      0.853896916288968, -0.0251626689263745 }, { 0.794635285871404,
      -0.94034850194416 }, { -0.0211046968869782, -0.0989706616294739 }, { -
      0.736784685161636, 0.855028550830224 }, { -0.934421552367619,
      0.801324974466315 }, { -0.752787310069662, 0.643989460186091 }, {
      0.00366633848891637, 0.743375482411386 }, { 0.795918669050615,
      0.664397232883164 }, { 0.824842327423534, 0.771463074855881 }, {
      0.649373976614355, 0.882904264654734 }, { 0.711742797952292,
      -0.108393232274876 }, { 0.673491370247324, -0.971918985597381 }, {
      0.788213684396734, 0.0300991856552645 }, { 0.818160120327704,
      0.935386747033754 }, { 0.0076489416896219, 0.103072148507813 }, { -
      0.823391794111192, -0.796507113233001 }, { -0.795731272092887,
      -0.931840481400356 }, { -0.656154558997593, -0.738733428882527 }, { -
      0.730883070051205, -0.0213114197191376 }, { -0.651734560101362,
      0.751336140319071 }, { -0.801034066063392, 0.957087948474413 }, { -
      0.864162569605137, 0.723460426494562 }, { 0.110530294365149,
      0.0179730505366983 }, { 0.904413680106844, -0.750933551555139 }, {
      0.104198699338206, -0.951540801946772 }, { -0.85340244741292,
      -0.718064647976684 }, { -0.8118217206156, -0.0327433082896124 }, { -
      0.657193888982068, 0.805970919406834 }, { -0.713704378633237,
      0.849194710231305 }, { -0.703004449578752, 0.570112967833708 }, { -
      0.704785258703641, 0.845656115907589 }, { -0.674249952426396,
      0.807269339332069 }, { -0.794336193794834, -0.03408178885597 }, { -
      0.847363492194718, -0.724630508101876 }, { 0.0795024202240836,
      -0.940535201278152 }, { 0.9673019620125, -0.758846345222371 }, {
      0.0053210837670631, 0.017019137008514 }, { -1.01942331496848,
      0.746741207756127 }, { 0.022538083120169, 0.924307579281247 }, {
      0.956130340392041, 0.787273066063239 }, { 0.0773742186213774,
      -0.0808409007904413 }, { -0.799274400478222, -0.953612892085396 }, { -
      0.902085192051443, -0.0254817777452841 }, { -0.800513601613559,
      1.03150469066323 }, { 0.0791267136734779, -0.0241432971789265 }, {
      0.944131017064489, -0.952858332081187 }, { 0.0396573326993212,
      -0.0832464903483755 }, { -1.02348490714465, 0.791737247003344 }, { -
      0.00282244815079745, 0.918879316431239 }, { 1.03161050480192,
      0.745619825404457 }, { -0.0457415341622837, 0.0253628940676512 }, { -
      0.945593851122181, -0.796688172981428 }, { -0.0751535397817638,
      -0.852401725420276 }, { 0.777823275621812, -0.582879784004642 }, {
      0.931155095339833, -0.822564000720365 }, { 0.762426049910208,
      -0.869677744836819 }, { -0.0140311180678146, 0.138768011910108 }, { -
      0.738483589943952, 0.877754643238441 }, { -0.939474108667022,
      0.120626546476387 }, { -0.807389169203165, -0.84180203101231 }, {
      0.126620742887862, -0.84370700554248 }, { 0.878690262991077,
      -0.594042494960791 }, { 0.128910292875284, -0.815281336272357 }, { -
      0.806149968067829, -0.86879051494176 }, { -0.943516153706544,
      0.131941826654925 }, { -0.727723467751735, 0.940386372267482 }, { -
      0.0271083226074448, -0.00489300188994777 }, { 0.755727519894165,
      -0.937340348304288 }, { 0.952375831797323, -0.126582434952725 }, {
      0.720213262848436, 0.859273616059743 }, { 0.0288696781471126,
      0.823881347383043 }, { -0.789753479421342, 0.594299480994699 }, { -
      0.86894740610423, 0.831965437462087 }, { -0.576303094947128,
      0.862213825884245 }, { -0.815556930252325, -0.140154229720594 }, { -
      0.881001806884568, -0.883460129220734 }, { 0.152718554235426,
      -0.109579224944085 }, { 0.887450497962035, 0.795790423552113 }, {
      0.0899949439681823, 0.942330161037335 }, { -0.790156068185274,
      0.741684467639352 }, { -0.931214537178649, 0.00652945737153563 }, { -
      0.790969846979382, -0.751511073985784 }, { 0.0941866327977319,
      -0.940991680470977 }, { 0.894985640349482, -0.785209257201472 }, {
      0.137488973182566, 0.0927762400767222 }, { -0.87000753223574,
      0.896996356503062 }, { -0.820818572180571, 0.135793075862162 }, { -
      0.602876057273472, -0.882893435722411 }, { -0.822254802520882,
      -0.797667496464966 }, { -0.848712529643608, -0.648759326415749 }, {
      0.109519783105269, -0.740168467222415 }, { 0.951666159451935,
      -0.64711753651648 }, { -0.00177362895577977, -0.798278126263717 }, { -
      0.965105483259884, -0.820805566614397 }, { -0.0879144796096048,
      0.00786793793789321 }, { 0.81396585826068, 0.811733520272174 }, {
      0.891229235172851, 0.795872536705783 }, { 0.818253001627222,
      0.665921203998767 }, { -0.0937867513366027, 0.716619872842366 }, { -
      0.923498095394534, 0.656400282941886 }, { -0.0963742762392546,
      0.811239291232835 }, { 0.820036062683584, 0.818432050288217 }, {
      0.888254299124905, -0.0156423485070192 }, { 0.813695939387598,
      -0.766691195074232 }, { -0.0845578206306066, -0.896397831042766 }, { -
      0.969569664199989, -0.813563176677329 }, { 0.00270356447316448,
      0.094034144900584 }, { 0.956815780868228, 0.964870588247913 }, {
      0.099089545307107, -0.005462348379959 }, { -0.815219910503201,
      -0.965530163045753 }, { -0.900439876082288, -0.0838158368383867 }, { -
      0.750778697822933, 0.800703479206876 }, { -0.033346871576057,
      0.905057283992268 }, { 0.824146354115401, 0.808911129231337 }, {
      0.820362092987746, -0.0940935867394005 } };

  creal_T eigV[16];
  double eigD[4];
  double unusedU0[4];
  int ixstart;
  int iidx[4];
  double b_eigD[4];
  double SigThd;
  double pwrSum;
  int NumSig;
  int idx;
  boolean_T exitg4;
  int br;
  creal_T b_eigV[16];
  creal_T Vnoise_data[12];
  creal_T Rnn[16];
  creal_T b_data[12];
  creal_T b_recStvPartition[484];
  int ic;
  creal_T dcv0[121];
  int ar;
  int ib;
  creal_T c_recStvPartition[484];
  double temp_re;
  creal_T dcv1[121];
  double temp_im;
  creal_T dcv2[121];
  int ia;
  double brm;
  boolean_T exitg2;
  boolean_T exitg3;
  double b_spatialSpectrum[121];
  double idxDoa_data[247];
  double processSpectrum[121];
  double b_processSpectrum[123];
  double unusedU2_data[246];
  int unusedU2_size[2];
  double b_idxDoa_data[246];
  int idxDoa_size[2];
  boolean_T exitg1;
  boolean_T c_idxDoa_data[246];
  int b_idxDoa_size[2];
  double itmp_data[247];

  /* 'DoaEstimatorMUSICSignalImplement:14' PilotSequence = [0.597750197628676 + 0.899287820462048i,0.832619582099781 + 0.131116226113365i,0.791277450536945 - 0.870126619551477i,0.00511199813821906 - 0.812875746714423i,-0.798163847058874 - 0.597925131295389i,-0.832866975663762 - 0.838791622717269i,-0.586766442514103 - 0.799582096855205i,-0.833370426379568 + 0.0146346813542591i,-0.818914680331913 + 0.792434692124505i,0.0385749092847886 + 0.822980859313228i,0.732202685437865 + 0.657215980004006i,0.923622193220723 + 0.700993451335220i,0.806820371797992 + 0.714344198108465i,-0.109820602127619 + 0.699557220994909i,-0.886386230493411 + 0.678510982596137i,-0.134397997564108 + 0.795011669235930i,0.875863014400597 + 0.846858771129085i,0.806596527013989 - 0.0794641122889465i,0.632225031870510 - 0.973562879403500i,0.758091986539724 + 0.00242797049319710i,0.649466857913873 + 1.00972746024489i,0.780072996585994 - 0.0146729892893962i,0.886578954548940 - 0.941910343383084i,-0.122462658277827 - 0.110029687756464i,-0.949398457264446 + 0.855163324627926i,0.00846865711721725 + 0.813260313752596i,0.933265080733581 + 0.593814839863572i,0.127440458315457 + 0.844338769244911i,-0.868352809497298 + 0.809490755568833i,-0.810260021395785 - 0.0331278753277856i,-0.599168354605588 - 0.737707031737225i,-0.838247501269642 - 0.921166022311540i,-0.801456028123654 - 0.812228990335624i,0.0181892026778493 + 0.117982423842039i,0.790508039425551 + 0.899555635428278i,0.820821416287692 + 0.108559853196637i,0.666522921358200 - 0.820436640360084i,0.690938920087664 - 0.901465701765124i,0.722256991775696 - 0.800254604492219i,0.699560065102030 + 0.0765486180798176i,0.657002000301320 + 0.967092004484677i,0.827567025800378 + 0.0116597453063136i,0.806727490498474 - 0.968213386836347i,-0.0120666932797497 - 0.0953131836281251i,-0.759048227460663 + 0.854771564796316i,-0.909834246311703 + 0.800809053434673i,-0.808331502893841 + 0.660959449088361i,0.0996902644864311 + 0.720721359720704i,0.949635363363849 + 0.717178160636984i,0.0138969199672255 + 0.678862316188488i,-0.962342218189525 + 0.721276787761700i,-0.106235036280923 + 0.710363646654112i,0.863180354503709 + 0.645666366765890i,0.796416658153411 + 0.833104261708592i,0.654747571290877 + 0.798918407063083i,0.732687940429815 - 0.00477696231943516i,0.700630933252572 - 0.754427088881499i,0.690988451307054 - 0.925251582190004i,0.731021341740936 - 0.754276350143574i,0.685667367539991 - 0.00339781102125576i,0.702592609812637 + 0.802593096957289i,0.735115910923013 + 0.826265606137574i,0.641047239274157 + 0.653105781391609i,0.815528729836338 + 0.703449622244404i,0.865591648333791 + 0.705284991785995i,-0.128494484414280 + 0.711742797952292i,-0.890215774119824 + 0.665483591373724i,-0.110045614756338 + 0.801678300081658i,0.805970919406834 + 0.868023022098378i,0.926497016698030 - 0.116752916333887i,0.740007653878974 - 0.915572368888130i,0.0244712664854036 - 0.0834060447578302i,-0.811357446922529 + 0.796911805903784i,-0.831856464403881 + 0.913241486641951i,-0.634018921859194 + 0.811687234321449i,-0.727398098085583 - 0.106322678535725i,-0.707211644484950 - 0.897878821667900i,-0.685332331721207 - 0.121261351185662i,-0.734444181609135 + 0.815593972765416i,-0.685034356805976 + 0.919423437878867i,-0.714746786872397 + 0.741071921347597i,-0.716658180777503 + 0.0300397438164480i,-0.644199417713915 - 0.813967869348111i,-0.826296847560404 - 0.833470538950206i,-0.795389845875613 - 0.633404271660588i,-0.00542826285000829 - 0.728101773942665i,0.794219764268299 - 0.710151854309453i,0.835957951282220 - 0.680207863267152i,0.605165417325606 - 0.736145190298302i,0.803830676594888 - 0.687490527715160i,0.863713694890480 - 0.699876373248363i,-0.112929867542636 - 0.737252973013286i,-0.938129932169607 - 0.640646661597657i,-0.0170473374245001 - 0.812365842063228i,0.997312615314229 - 0.862319640022937i,0.0214115322897759 + 0.117854110855414i,-1.01838398498400 + 0.898872298858942i,0.00535939170220030 + 0.105093171027573i,1.00740022986943 - 0.850201569717520i,-0.0188745887383731 - 0.817361800630935i,-0.989187017656964 - 0.652336277460795i,0.00278129610853988 - 0.713823262310870i,0.955776450883752 - 0.714746786872397i,0.100100056566987 - 0.688936187364462i,-0.876883099825346 - 0.673513461269261i,-0.773324542966187 - 0.811107937239366i,-0.668316811346884 - 0.794445408278086i,-0.733001842344920 - 0.0234013133867066i,-0.631377590566783 + 0.820748451731350i,-0.831173922450478 + 0.815221894433541i,-0.803154932905969 + 0.598951528440691i,0.0131366463784466 + 0.832024879300903i,0.735906180292048 + 0.796631058098380i,0.943775820686637 - 0.00357565522726951i,0.749294515298662 - 0.788056585726458i,-0.00499311446058607 - 0.838639134820122i,-0.737779833102237 - 0.607351067145900i,-0.951975950336194 - 0.797795809451591i,-0.743903130233326 - 0.866499050982776i,0.00808409007904414 + 0.111096796748040i,0.751356220253577 + 0.942759888593662i,0.926597129268668 + 0.0107652736169457i,0.786153694798999 - 0.993956883886621i,-0.0800989169982213 - 0.0199940730564594i,-0.956933599651893 + 1.00757516353614i,-0.0228571919390786 + 0.00623148245630531i,1.02350984462880 - 1.01437950769088i,-0.0138220324389705 + 0.0146135474505797i,-0.948995868500514 + 1.00749311116895i,-0.0990301034682904 - 0.0265488867368607i,0.843763707572375 - 0.950566868122202i,0.820284361352370 - 0.0842004038765598i,0.598789527613151 + 0.809326650834442i,0.831609070839900 + 0.895787201244015i,0.852940639859090 + 0.798692763053295i,-0.122003334977882 - 0.0714394640487189i,-0.880625733534922 - 0.956563930842221i,-0.133212004894899 - 0.0305909317763828i,0.864244621972332 + 1.02548949721652i,0.821888525279268 - 0.00893504692946981i,0.582300157667146 - 1.01044414992577i,0.853896916288968 + 0.0251626689263745i,0.794635285871404 + 0.940348501944160i,-0.0211046968869782 + 0.0989706616294739i,-0.736784685161636 - 0.855028550830224i,-0.934421552367619 - 0.801324974466315i,-0.752787310069662 - 0.643989460186091i,0.00366633848891637 - 0.743375482411386i,0.795918669050615 - 0.664397232883164i,0.824842327423534 - 0.771463074855881i,0.649373976614355 - 0.882904264654734i,0.711742797952292 + 0.108393232274876i,0.673491370247324 + 0.971918985597381i,0.788213684396734 - 0.0300991856552645i,0.818160120327704 - 0.935386747033754i,0.00764894168962190 - 0.103072148507813i,-0.823391794111192 + 0.796507113233001i,-0.795731272092887 + 0.931840481400356i,-0.656154558997593 + 0.738733428882527i,-0.730883070051205 + 0.0213114197191376i,-0.651734560101362 - 0.751336140319071i,-0.801034066063392 - 0.957087948474413i,-0.864162569605137 - 0.723460426494562i,0.110530294365149 - 0.0179730505366983i,0.904413680106844 + 0.750933551555139i,0.104198699338206 + 0.951540801946772i,-0.853402447412920 + 0.718064647976684i,-0.811821720615600 + 0.0327433082896124i,-0.657193888982068 - 0.805970919406834i,-0.713704378633237 - 0.849194710231305i,-0.703004449578752 - 0.570112967833708i,-0.704785258703641 - 0.845656115907589i,-0.674249952426396 - 0.807269339332069i,-0.794336193794834 + 0.0340817888559700i,-0.847363492194718 + 0.724630508101876i,0.0795024202240836 + 0.940535201278152i,0.967301962012500 + 0.758846345222371i,0.00532108376706310 - 0.0170191370085140i,-1.01942331496848 - 0.746741207756127i,0.0225380831201690 - 0.924307579281247i,0.956130340392041 - 0.787273066063239i,0.0773742186213774 + 0.0808409007904413i,-0.799274400478222 + 0.953612892085396i,-0.902085192051443 + 0.0254817777452841i,-0.800513601613559 - 1.03150469066323i,0.0791267136734779 + 0.0241432971789265i,0.944131017064489 + 0.952858332081187i,0.0396573326993212 + 0.0832464903483755i,-1.02348490714465 - 0.791737247003344i,-0.00282244815079745 - 0.918879316431239i,1.03161050480192 - 0.745619825404457i,-0.0457415341622837 - 0.0253628940676512i,-0.945593851122181 + 0.796688172981428i,-0.0751535397817638 + 0.852401725420276i,0.777823275621812 + 0.582879784004642i,0.931155095339833 + 0.822564000720365i,0.762426049910208 + 0.869677744836819i,-0.0140311180678146 - 0.138768011910108i,-0.738483589943952 - 0.877754643238441i,-0.939474108667022 - 0.120626546476387i,-0.807389169203165 + 0.841802031012310i,0.126620742887862 + 0.843707005542480i,0.878690262991077 + 0.594042494960791i,0.128910292875284 + 0.815281336272357i,-0.806149968067829 + 0.868790514941760i,-0.943516153706544 - 0.131941826654925i,-0.727723467751735 - 0.940386372267482i,-0.0271083226074448 + 0.00489300188994777i,0.755727519894165 + 0.937340348304288i,0.952375831797323 + 0.126582434952725i,0.720213262848436 - 0.859273616059743i,0.0288696781471126 - 0.823881347383043i,-0.789753479421342 - 0.594299480994699i,-0.868947406104230 - 0.831965437462087i,-0.576303094947128 - 0.862213825884245i,-0.815556930252325 + 0.140154229720594i,-0.881001806884568 + 0.883460129220734i,0.152718554235426 + 0.109579224944085i,0.887450497962035 - 0.795790423552113i,0.0899949439681823 - 0.942330161037335i,-0.790156068185274 - 0.741684467639352i,-0.931214537178649 - 0.00652945737153563i,-0.790969846979382 + 0.751511073985784i,0.0941866327977319 + 0.940991680470977i,0.894985640349482 + 0.785209257201472i,0.137488973182566 - 0.0927762400767222i,-0.870007532235740 - 0.896996356503062i,-0.820818572180571 - 0.135793075862162i,-0.602876057273472 + 0.882893435722411i,-0.822254802520882 + 0.797667496464966i,-0.848712529643608 + 0.648759326415749i,0.109519783105269 + 0.740168467222415i,0.951666159451935 + 0.647117536516480i,-0.00177362895577977 + 0.798278126263717i,-0.965105483259884 + 0.820805566614397i,-0.0879144796096048 - 0.00786793793789321i,0.813965858260680 - 0.811733520272174i,0.891229235172851 - 0.795872536705783i,0.818253001627222 - 0.665921203998767i,-0.0937867513366027 - 0.716619872842366i,-0.923498095394534 - 0.656400282941886i,-0.0963742762392546 - 0.811239291232835i,0.820036062683584 - 0.818432050288217i,0.888254299124905 + 0.0156423485070192i,0.813695939387598 + 0.766691195074232i,-0.0845578206306066 + 0.896397831042766i,-0.969569664199989 + 0.813563176677329i,0.00270356447316448 - 0.0940341449005840i,0.956815780868228 - 0.964870588247913i,0.0990895453071070 + 0.00546234837995900i,-0.815219910503201 + 0.965530163045753i,-0.900439876082288 + 0.0838158368383867i,-0.750778697822933 - 0.800703479206876i,-0.0333468715760570 - 0.905057283992268i,0.824146354115401 - 0.808911129231337i,0.820362092987746 + 0.0940935867394005i,0.597750197628676 + 0.899287820462048i,0.832619582099781 + 0.131116226113365i,0.791277450536945 - 0.870126619551477i,0.00511199813821906 - 0.812875746714423i,-0.798163847058874 - 0.597925131295389i,-0.832866975663762 - 0.838791622717269i,-0.586766442514103 - 0.799582096855205i,-0.833370426379568 + 0.0146346813542591i,-0.818914680331913 + 0.792434692124505i,0.0385749092847886 + 0.822980859313228i,0.732202685437865 + 0.657215980004006i,0.923622193220723 + 0.700993451335220i,0.806820371797992 + 0.714344198108465i,-0.109820602127619 + 0.699557220994909i,-0.886386230493411 + 0.678510982596137i,-0.134397997564108 + 0.795011669235930i,0.875863014400597 + 0.846858771129085i,0.806596527013989 - 0.0794641122889465i,0.632225031870510 - 0.973562879403500i,0.758091986539724 + 0.00242797049319710i,0.649466857913873 + 1.00972746024489i,0.780072996585994 - 0.0146729892893962i,0.886578954548940 - 0.941910343383084i,-0.122462658277827 - 0.110029687756464i,-0.949398457264446 + 0.855163324627926i,0.00846865711721725 + 0.813260313752596i,0.933265080733581 + 0.593814839863572i,0.127440458315457 + 0.844338769244911i,-0.868352809497298 + 0.809490755568833i,-0.810260021395785 - 0.0331278753277856i,-0.599168354605588 - 0.737707031737225i,-0.838247501269642 - 0.921166022311540i,-0.801456028123654 - 0.812228990335624i,0.0181892026778493 + 0.117982423842039i,0.790508039425551 + 0.899555635428278i,0.820821416287692 + 0.108559853196637i,0.666522921358200 - 0.820436640360084i,0.690938920087664 - 0.901465701765124i,0.722256991775696 - 0.800254604492219i,0.699560065102030 + 0.0765486180798176i,0.657002000301320 + 0.967092004484677i,0.827567025800378 + 0.0116597453063136i,0.806727490498474 - 0.968213386836347i,-0.0120666932797497 - 0.0953131836281251i,-0.759048227460663 + 0.854771564796316i,-0.909834246311703 + 0.800809053434673i,-0.808331502893841 + 0.660959449088361i,0.0996902644864311 + 0.720721359720704i,0.949635363363849 + 0.717178160636984i,0.0138969199672255 + 0.678862316188488i,-0.962342218189525 + 0.721276787761700i,-0.106235036280923 + 0.710363646654112i,0.863180354503709 + 0.645666366765890i,0.796416658153411 + 0.833104261708592i,0.654747571290877 + 0.798918407063083i,0.732687940429815 - 0.00477696231943516i,0.700630933252572 - 0.754427088881499i,0.690988451307054 - 0.925251582190004i,0.731021341740936 - 0.754276350143574i,0.685667367539991 - 0.00339781102125576i,0.702592609812637 + 0.802593096957289i,0.735115910923013 + 0.826265606137574i,0.641047239274157 + 0.653105781391609i,0.815528729836338 + 0.703449622244404i,0.865591648333791 + 0.705284991785995i,-0.128494484414280 + 0.711742797952292i,-0.890215774119824 + 0.665483591373724i,-0.110045614756338 + 0.801678300081658i,0.805970919406834 + 0.868023022098378i,0.926497016698030 - 0.116752916333887i,0.740007653878974 - 0.915572368888130i,0.0244712664854036 - 0.0834060447578302i,-0.811357446922529 + 0.796911805903784i,-0.831856464403881 + 0.913241486641951i,-0.634018921859194 + 0.811687234321449i,-0.727398098085583 - 0.106322678535725i,-0.707211644484950 - 0.897878821667900i,-0.685332331721207 - 0.121261351185662i,-0.734444181609135 + 0.815593972765416i,-0.685034356805976 + 0.919423437878867i,-0.714746786872397 + 0.741071921347597i,-0.716658180777503 + 0.0300397438164480i,-0.644199417713915 - 0.813967869348111i,-0.826296847560404 - 0.833470538950206i,-0.795389845875613 - 0.633404271660588i,-0.00542826285000829 - 0.728101773942665i,0.794219764268299 - 0.710151854309453i,0.835957951282220 - 0.680207863267152i,0.605165417325606 - 0.736145190298302i,0.803830676594888 - 0.687490527715160i,0.863713694890480 - 0.699876373248363i,-0.112929867542636 - 0.737252973013286i,-0.938129932169607 - 0.640646661597657i,-0.0170473374245001 - 0.812365842063228i,0.997312615314229 - 0.862319640022937i,0.0214115322897759 + 0.117854110855414i,-1.01838398498400 + 0.898872298858942i,0.00535939170220030 + 0.105093171027573i,1.00740022986943 - 0.850201569717520i,-0.0188745887383731 - 0.817361800630935i,-0.989187017656964 - 0.652336277460795i,0.00278129610853988 - 0.713823262310870i,0.955776450883752 - 0.714746786872397i,0.100100056566987 - 0.688936187364462i,-0.876883099825346 - 0.673513461269261i,-0.773324542966187 - 0.811107937239366i,-0.668316811346884 - 0.794445408278086i,-0.733001842344920 - 0.0234013133867066i,-0.631377590566783 + 0.820748451731350i,-0.831173922450478 + 0.815221894433541i,-0.803154932905969 + 0.598951528440691i,0.0131366463784466 + 0.832024879300903i,0.735906180292048 + 0.796631058098380i,0.943775820686637 - 0.00357565522726951i,0.749294515298662 - 0.788056585726458i,-0.00499311446058607 - 0.838639134820122i,-0.737779833102237 - 0.607351067145900i,-0.951975950336194 - 0.797795809451591i,-0.743903130233326 - 0.866499050982776i,0.00808409007904414 + 0.111096796748040i,0.751356220253577 + 0.942759888593662i,0.926597129268668 + 0.0107652736169457i,0.786153694798999 - 0.993956883886621i,-0.0800989169982213 - 0.0199940730564594i,-0.956933599651893 + 1.00757516353614i,-0.0228571919390786 + 0.00623148245630531i,1.02350984462880 - 1.01437950769088i,-0.0138220324389705 + 0.0146135474505797i,-0.948995868500514 + 1.00749311116895i,-0.0990301034682904 - 0.0265488867368607i,0.843763707572375 - 0.950566868122202i,0.820284361352370 - 0.0842004038765598i,0.598789527613151 + 0.809326650834442i,0.831609070839900 + 0.895787201244015i,0.852940639859090 + 0.798692763053295i,-0.122003334977882 - 0.0714394640487189i,-0.880625733534922 - 0.956563930842221i,-0.133212004894899 - 0.0305909317763828i,0.864244621972332 + 1.02548949721652i,0.821888525279268 - 0.00893504692946981i,0.582300157667146 - 1.01044414992577i,0.853896916288968 + 0.0251626689263745i,0.794635285871404 + 0.940348501944160i,-0.0211046968869782 + 0.0989706616294739i,-0.736784685161636 - 0.855028550830224i,-0.934421552367619 - 0.801324974466315i,-0.752787310069662 - 0.643989460186091i,0.00366633848891637 - 0.743375482411386i,0.795918669050615 - 0.664397232883164i,0.824842327423534 - 0.771463074855881i,0.649373976614355 - 0.882904264654734i,0.711742797952292 + 0.108393232274876i,0.673491370247324 + 0.971918985597381i,0.788213684396734 - 0.0300991856552645i,0.818160120327704 - 0.935386747033754i,0.00764894168962190 - 0.103072148507813i,-0.823391794111192 + 0.796507113233001i,-0.795731272092887 + 0.931840481400356i,-0.656154558997593 + 0.738733428882527i,-0.730883070051205 + 0.0213114197191376i,-0.651734560101362 - 0.751336140319071i,-0.801034066063392 - 0.957087948474413i,-0.864162569605137 - 0.723460426494562i,0.110530294365149 - 0.0179730505366983i,0.904413680106844 + 0.750933551555139i,0.104198699338206 + 0.951540801946772i,-0.853402447412920 + 0.718064647976684i,-0.811821720615600 + 0.0327433082896124i,-0.657193888982068 - 0.805970919406834i,-0.713704378633237 - 0.849194710231305i,-0.703004449578752 - 0.570112967833708i,-0.704785258703641 - 0.845656115907589i,-0.674249952426396 - 0.807269339332069i,-0.794336193794834 + 0.0340817888559700i,-0.847363492194718 + 0.724630508101876i,0.0795024202240836 + 0.940535201278152i,0.967301962012500 + 0.758846345222371i,0.00532108376706310 - 0.0170191370085140i,-1.01942331496848 - 0.746741207756127i,0.0225380831201690 - 0.924307579281247i,0.956130340392041 - 0.787273066063239i,0.0773742186213774 + 0.0808409007904413i,-0.799274400478222 + 0.953612892085396i,-0.902085192051443 + 0.0254817777452841i,-0.800513601613559 - 1.03150469066323i,0.0791267136734779 + 0.0241432971789265i,0.944131017064489 + 0.952858332081187i,0.0396573326993212 + 0.0832464903483755i,-1.02348490714465 - 0.791737247003344i,-0.00282244815079745 - 0.918879316431239i,1.03161050480192 - 0.745619825404457i,-0.0457415341622837 - 0.0253628940676512i,-0.945593851122181 + 0.796688172981428i,-0.0751535397817638 + 0.852401725420276i,0.777823275621812 + 0.582879784004642i,0.931155095339833 + 0.822564000720365i,0.762426049910208 + 0.869677744836819i,-0.0140311180678146 - 0.138768011910108i,-0.738483589943952 - 0.877754643238441i,-0.939474108667022 - 0.120626546476387i,-0.807389169203165 + 0.841802031012310i,0.126620742887862 + 0.843707005542480i,0.878690262991077 + 0.594042494960791i,0.128910292875284 + 0.815281336272357i,-0.806149968067829 + 0.868790514941760i,-0.943516153706544 - 0.131941826654925i,-0.727723467751735 - 0.940386372267482i,-0.0271083226074448 + 0.00489300188994777i,0.755727519894165 + 0.937340348304288i,0.952375831797323 + 0.126582434952725i,0.720213262848436 - 0.859273616059743i,0.0288696781471126 - 0.823881347383043i,-0.789753479421342 - 0.594299480994699i,-0.868947406104230 - 0.831965437462087i,-0.576303094947128 - 0.862213825884245i,-0.815556930252325 + 0.140154229720594i,-0.881001806884568 + 0.883460129220734i,0.152718554235426 + 0.109579224944085i,0.887450497962035 - 0.795790423552113i,0.0899949439681823 - 0.942330161037335i,-0.790156068185274 - 0.741684467639352i,-0.931214537178649 - 0.00652945737153563i,-0.790969846979382 + 0.751511073985784i,0.0941866327977319 + 0.940991680470977i,0.894985640349482 + 0.785209257201472i,0.137488973182566 - 0.0927762400767222i,-0.870007532235740 - 0.896996356503062i,-0.820818572180571 - 0.135793075862162i,-0.602876057273472 + 0.882893435722411i,-0.822254802520882 + 0.797667496464966i,-0.848712529643608 + 0.648759326415749i,0.109519783105269 + 0.740168467222415i,0.951666159451935 + 0.647117536516480i,-0.00177362895577977 + 0.798278126263717i,-0.965105483259884 + 0.820805566614397i,-0.0879144796096048 - 0.00786793793789321i,0.813965858260680 - 0.811733520272174i,0.891229235172851 - 0.795872536705783i,0.818253001627222 - 0.665921203998767i,-0.0937867513366027 - 0.716619872842366i,-0.923498095394534 - 0.656400282941886i,-0.0963742762392546 - 0.811239291232835i,0.820036062683584 - 0.818432050288217i,0.888254299124905 + 0.0156423485070192i,0.813695939387598 + 0.766691195074232i,-0.0845578206306066 + 0.896397831042766i,-0.969569664199989 + 0.813563176677329i,0.00270356447316448 - 0.0940341449005840i,0.956815780868228 - 0.964870588247913i,0.0990895453071070 + 0.00546234837995900i,-0.815219910503201 + 0.965530163045753i,-0.900439876082288 + 0.0838158368383867i,-0.750778697822933 - 0.800703479206876i,-0.0333468715760570 - 0.905057283992268i,0.824146354115401 - 0.808911129231337i,0.820362092987746 + 0.0940935867394005i]; */
  /* 'DoaEstimatorMUSICSignalImplement:16' Pxs = rxSigNoise.'*PilotSequence'; */
  for (i0 = 0; i0 < 4; i0++) {
    Pxs[i0].re = 0.0;
    Pxs[i0].im = 0.0;
    for (i1 = 0; i1 < 512; i1++) {
      Pxs[i0].re += rxSigNoise[i1 + (i0 << 9)].re * b[i1].re - rxSigNoise[i1 +
        (i0 << 9)].im * b[i1].im;
      Pxs[i0].im += rxSigNoise[i1 + (i0 << 9)].re * b[i1].im + rxSigNoise[i1 +
        (i0 << 9)].im * b[i1].re;
    }
  }

  /*  PN code filtering in time. */
  /* Pxs = rxSigNoise; */
  /* 'DoaEstimatorMUSICSignalImplement:19' Rxx = Pxs*Pxs'; */
  /* 'DoaEstimatorMUSICSignalImplement:20' [eigV, eigD] = eig(Rxx, 'vector'); */
  for (i0 = 0; i0 < 4; i0++) {
    for (i1 = 0; i1 < 4; i1++) {
      b_Pxs[i0 + (i1 << 2)].re = Pxs[i0].re * Pxs[i1].re - Pxs[i0].im * -Pxs[i1]
        .im;
      b_Pxs[i0 + (i1 << 2)].im = Pxs[i0].re * -Pxs[i1].im + Pxs[i0].im * Pxs[i1]
        .re;
    }
  }

  eig_DoaMusicSignal(b_Pxs, eigV, Pxs);

  /* 'DoaEstimatorMUSICSignalImplement:21' eigD = abs(eigD); */
  abs_DoaMusicSignal(Pxs, eigD);

  /* 'DoaEstimatorMUSICSignalImplement:22' [~,idx] = sort(eigD, 'ascend'); */
  for (ixstart = 0; ixstart < 4; ixstart++) {
    unusedU0[ixstart] = eigD[ixstart];
  }

  sort_DoaMusicSignal(unusedU0, iidx);

  /* 'DoaEstimatorMUSICSignalImplement:22' ~ */
  /* 'DoaEstimatorMUSICSignalImplement:23' eigD = eigD(idx); */
  for (ixstart = 0; ixstart < 4; ixstart++) {
    b_eigD[ixstart] = eigD[iidx[ixstart] - 1];
    unusedU0[ixstart] = iidx[ixstart];
  }

  for (i0 = 0; i0 < 4; i0++) {
    eigD[i0] = b_eigD[i0];
  }

  /* 'DoaEstimatorMUSICSignalImplement:24' eigV = eigV(:,idx); */
  /*  find out the Number of signal. */
  /* 'DoaEstimatorMUSICSignalImplement:27' SigThd = 0.8*sum(eigD); */
  SigThd = 0.8 * sum_DoaMusicSignal(eigD);

  /*  assume the signals power should exceed certurn percentage of the total power. */
  /* 'DoaEstimatorMUSICSignalImplement:28' NumCh = length(eigD); */
  /* 'DoaEstimatorMUSICSignalImplement:29' pwrSum = 0; */
  pwrSum = 0.0;

  /* 'DoaEstimatorMUSICSignalImplement:30' NumSig = NumCh-1; */
  NumSig = 3;

  /*  at least one column for noise space */
  /* 'DoaEstimatorMUSICSignalImplement:31' for idx = 1:NumCh-1 */
  idx = 0;
  exitg4 = false;
  while ((!exitg4) && (idx < 3)) {
    /* 'DoaEstimatorMUSICSignalImplement:32' pwrSum = pwrSum + eigD(NumCh-idx+1); */
    pwrSum += eigD[3 - idx];

    /* 'DoaEstimatorMUSICSignalImplement:33' if pwrSum>SigThd */
    if (pwrSum > SigThd) {
      /* 'DoaEstimatorMUSICSignalImplement:34' NumSig = idx; */
      NumSig = 1 + idx;
      exitg4 = true;
    } else {
      idx++;
    }
  }

  /*  noise space construction */
  /* 'DoaEstimatorMUSICSignalImplement:40' Vnoise = eigV(:, 1:NumCh-NumSig ); */
  br = 4 - NumSig;
  for (i0 = 0; i0 < 4; i0++) {
    for (i1 = 0; i1 < 4; i1++) {
      b_eigV[i1 + (i0 << 2)] = eigV[i1 + (((int)unusedU0[i0] - 1) << 2)];
    }
  }

  for (i0 = 0; i0 < br; i0++) {
    memcpy(&Vnoise_data[i0 << 2], &b_eigV[i0 << 2], sizeof(creal_T) << 2);
  }

  /* 'DoaEstimatorMUSICSignalImplement:41' Rnn = Vnoise*Vnoise'; */
  for (i0 = 0; i0 < 4; i0++) {
    for (i1 = 0; i1 < br; i1++) {
      b_data[i1 + br * i0].re = Vnoise_data[i0 + (i1 << 2)].re;
      b_data[i1 + br * i0].im = -Vnoise_data[i0 + (i1 << 2)].im;
    }
  }

  if ((4 - NumSig == 1) || (br == 1)) {
    for (i0 = 0; i0 < 4; i0++) {
      for (i1 = 0; i1 < 4; i1++) {
        Rnn[i0 + (i1 << 2)].re = 0.0;
        Rnn[i0 + (i1 << 2)].im = 0.0;
        for (ixstart = 0; ixstart < br; ixstart++) {
          Rnn[i0 + (i1 << 2)].re += Vnoise_data[i0 + (ixstart << 2)].re *
            b_data[ixstart + br * i1].re - Vnoise_data[i0 + (ixstart << 2)].im *
            b_data[ixstart + br * i1].im;
          Rnn[i0 + (i1 << 2)].im += Vnoise_data[i0 + (ixstart << 2)].re *
            b_data[ixstart + br * i1].im + Vnoise_data[i0 + (ixstart << 2)].im *
            b_data[ixstart + br * i1].re;
        }
      }
    }
  } else {
    i0 = 4 - NumSig;
    memset(&Rnn[0], 0, sizeof(creal_T) << 4);
    for (ixstart = 0; ixstart <= 13; ixstart += 4) {
      for (ic = ixstart; ic + 1 <= ixstart + 4; ic++) {
        Rnn[ic].re = 0.0;
        Rnn[ic].im = 0.0;
      }
    }

    br = 0;
    for (ixstart = 0; ixstart <= 13; ixstart += 4) {
      ar = 0;
      i1 = br + i0;
      for (ib = br; ib + 1 <= i1; ib++) {
        if ((b_data[ib].re != 0.0) || (b_data[ib].im != 0.0)) {
          temp_re = b_data[ib].re - 0.0 * b_data[ib].im;
          temp_im = b_data[ib].im + 0.0 * b_data[ib].re;
          ia = ar;
          for (ic = ixstart; ic + 1 <= ixstart + 4; ic++) {
            ia++;
            Rnn[ic].re += temp_re * Vnoise_data[ia - 1].re - temp_im *
              Vnoise_data[ia - 1].im;
            Rnn[ic].im += temp_re * Vnoise_data[ia - 1].im + temp_im *
              Vnoise_data[ia - 1].re;
          }
        }

        ar += 4;
      }

      br += i0;
    }
  }

  /* 'DoaEstimatorMUSICSignalImplement:43' spatialSpectrum = abs(sum(conj(recStvPartition).*recStvPartition)./sum((recStvPartition'*Rnn).'.*recStvPartition)); */
  for (i0 = 0; i0 < 484; i0++) {
    b_recStvPartition[i0].re = recStvPartition[i0].re * recStvPartition[i0].re -
      -recStvPartition[i0].im * recStvPartition[i0].im;
    b_recStvPartition[i0].im = recStvPartition[i0].re * recStvPartition[i0].im +
      -recStvPartition[i0].im * recStvPartition[i0].re;
  }

  b_sum_DoaMusicSignal(b_recStvPartition, dcv0);
  for (i0 = 0; i0 < 4; i0++) {
    for (i1 = 0; i1 < 121; i1++) {
      b_recStvPartition[i0 + (i1 << 2)].re = 0.0;
      b_recStvPartition[i0 + (i1 << 2)].im = 0.0;
      for (ixstart = 0; ixstart < 4; ixstart++) {
        temp_re = recStvPartition[ixstart + (i1 << 2)].re;
        temp_im = -recStvPartition[ixstart + (i1 << 2)].im;
        b_recStvPartition[i0 + (i1 << 2)].re += temp_re * Rnn[ixstart + (i0 << 2)]
          .re - temp_im * Rnn[ixstart + (i0 << 2)].im;
        b_recStvPartition[i0 + (i1 << 2)].im += temp_re * Rnn[ixstart + (i0 << 2)]
          .im + temp_im * Rnn[ixstart + (i0 << 2)].re;
      }
    }
  }

  for (i0 = 0; i0 < 121; i0++) {
    for (i1 = 0; i1 < 4; i1++) {
      c_recStvPartition[i1 + (i0 << 2)].re = b_recStvPartition[i1 + (i0 << 2)].
        re * recStvPartition[i1 + (i0 << 2)].re - b_recStvPartition[i1 + (i0 <<
        2)].im * recStvPartition[i1 + (i0 << 2)].im;
      c_recStvPartition[i1 + (i0 << 2)].im = b_recStvPartition[i1 + (i0 << 2)].
        re * recStvPartition[i1 + (i0 << 2)].im + b_recStvPartition[i1 + (i0 <<
        2)].im * recStvPartition[i1 + (i0 << 2)].re;
    }
  }

  b_sum_DoaMusicSignal(c_recStvPartition, dcv1);
  for (i0 = 0; i0 < 121; i0++) {
    if (dcv1[i0].im == 0.0) {
      if (dcv0[i0].im == 0.0) {
        dcv2[i0].re = dcv0[i0].re / dcv1[i0].re;
        dcv2[i0].im = 0.0;
      } else if (dcv0[i0].re == 0.0) {
        dcv2[i0].re = 0.0;
        dcv2[i0].im = dcv0[i0].im / dcv1[i0].re;
      } else {
        dcv2[i0].re = dcv0[i0].re / dcv1[i0].re;
        dcv2[i0].im = dcv0[i0].im / dcv1[i0].re;
      }
    } else if (dcv1[i0].re == 0.0) {
      if (dcv0[i0].re == 0.0) {
        dcv2[i0].re = dcv0[i0].im / dcv1[i0].im;
        dcv2[i0].im = 0.0;
      } else if (dcv0[i0].im == 0.0) {
        dcv2[i0].re = 0.0;
        dcv2[i0].im = -(dcv0[i0].re / dcv1[i0].im);
      } else {
        dcv2[i0].re = dcv0[i0].im / dcv1[i0].im;
        dcv2[i0].im = -(dcv0[i0].re / dcv1[i0].im);
      }
    } else {
      brm = fabs(dcv1[i0].re);
      temp_re = fabs(dcv1[i0].im);
      if (brm > temp_re) {
        temp_re = dcv1[i0].im / dcv1[i0].re;
        temp_im = dcv1[i0].re + temp_re * dcv1[i0].im;
        dcv2[i0].re = (dcv0[i0].re + temp_re * dcv0[i0].im) / temp_im;
        dcv2[i0].im = (dcv0[i0].im - temp_re * dcv0[i0].re) / temp_im;
      } else if (temp_re == brm) {
        if (dcv1[i0].re > 0.0) {
          temp_re = 0.5;
        } else {
          temp_re = -0.5;
        }

        if (dcv1[i0].im > 0.0) {
          temp_im = 0.5;
        } else {
          temp_im = -0.5;
        }

        dcv2[i0].re = (dcv0[i0].re * temp_re + dcv0[i0].im * temp_im) / brm;
        dcv2[i0].im = (dcv0[i0].im * temp_re - dcv0[i0].re * temp_im) / brm;
      } else {
        temp_re = dcv1[i0].re / dcv1[i0].im;
        temp_im = dcv1[i0].im + temp_re * dcv1[i0].re;
        dcv2[i0].re = (temp_re * dcv0[i0].re + dcv0[i0].im) / temp_im;
        dcv2[i0].im = (temp_re * dcv0[i0].im - dcv0[i0].re) / temp_im;
      }
    }
  }

  b_abs_DoaMusicSignal(dcv2, spatialSpectrum);

  /* 'DoaEstimatorMUSICSignalImplement:45' if MaxNumSig ==1 */
  if (MaxNumSig == 1.0) {
    /* 'DoaEstimatorMUSICSignalImplement:46' [~,idxDoa] = max(spatialSpectrum); */
    ixstart = 1;
    temp_re = spatialSpectrum[0];
    ib = 1;
    if (rtIsNaN(spatialSpectrum[0])) {
      br = 2;
      exitg3 = false;
      while ((!exitg3) && (br < 122)) {
        ixstart = br;
        if (!rtIsNaN(spatialSpectrum[br - 1])) {
          temp_re = spatialSpectrum[br - 1];
          ib = br;
          exitg3 = true;
        } else {
          br++;
        }
      }
    }

    if (ixstart < 121) {
      while (ixstart + 1 < 122) {
        if (spatialSpectrum[ixstart] > temp_re) {
          temp_re = spatialSpectrum[ixstart];
          ib = ixstart + 1;
        }

        ixstart++;
      }
    }

    ar = 1;
    idxDoa_data[0] = ib;

    /* 'DoaEstimatorMUSICSignalImplement:46' ~ */
  } else {
    /* 'DoaEstimatorMUSICSignalImplement:47' else */
    /* 'DoaEstimatorMUSICSignalImplement:48' processSpectrum = spatialSpectrum/max(spatialSpectrum); */
    ixstart = 1;
    temp_re = spatialSpectrum[0];
    if (rtIsNaN(spatialSpectrum[0])) {
      br = 2;
      exitg2 = false;
      while ((!exitg2) && (br < 122)) {
        ixstart = br;
        if (!rtIsNaN(spatialSpectrum[br - 1])) {
          temp_re = spatialSpectrum[br - 1];
          exitg2 = true;
        } else {
          br++;
        }
      }
    }

    if (ixstart < 121) {
      while (ixstart + 1 < 122) {
        if (spatialSpectrum[ixstart] > temp_re) {
          temp_re = spatialSpectrum[ixstart];
        }

        ixstart++;
      }
    }

    /* 'DoaEstimatorMUSICSignalImplement:49' processSpectrum = pow2db(processSpectrum); */
    for (i0 = 0; i0 < 121; i0++) {
      b_spatialSpectrum[i0] = spatialSpectrum[i0] / temp_re;
    }

    pow2db_DoaMusicSignal(b_spatialSpectrum, processSpectrum);

    /* 'DoaEstimatorMUSICSignalImplement:50' processSpectrumExpand = [processSpectrum(2), processSpectrum, processSpectrum(end-1) ]; */
    /*  expand the spectrum so that findpeaks can return peaks at the boundary. */
    /*  peak para. */
    /* 'DoaEstimatorMUSICSignalImplement:52' minPeakHeight = -15; */
    /* 'DoaEstimatorMUSICSignalImplement:53' minPeakProminence = .5; */
    /* 'DoaEstimatorMUSICSignalImplement:54' minPeakDistance = 1/(AzimuthScanAngles(2)-AzimuthScanAngles(1)); */
    /*  degrees / reselution */
    /*  find peaks */
    /* 'DoaEstimatorMUSICSignalImplement:56' [~, idxDoa] = findpeaks(processSpectrumExpand, 'NPeaks', min([MaxNumSig,NumSig]), 'MinPeakProminence', minPeakProminence, 'MinPeakHeight', minPeakHeight, 'MinPeakDistance', minPeakDistance); */
    ixstart = 1;
    temp_re = MaxNumSig;
    if (rtIsNaN(MaxNumSig)) {
      ixstart = 2;
      temp_re = NumSig;
    }

    if ((ixstart < 2) && (NumSig < temp_re)) {
      temp_re = NumSig;
    }

    b_processSpectrum[0] = processSpectrum[1];
    memcpy(&b_processSpectrum[1], &processSpectrum[0], 121U * sizeof(double));
    b_processSpectrum[122] = processSpectrum[119];
    findpeaks_DoaMusicSignal(b_processSpectrum, temp_re, 1.0 /
      (AzimuthScanAngles[1] - AzimuthScanAngles[0]), unusedU2_data,
      unusedU2_size, b_idxDoa_data, idxDoa_size);

    /* 'DoaEstimatorMUSICSignalImplement:56' ~ */
    /* 'DoaEstimatorMUSICSignalImplement:57' idxDoa = idxDoa - 1; */
    ar = idxDoa_size[1];
    br = idxDoa_size[0] * idxDoa_size[1];
    for (i0 = 0; i0 < br; i0++) {
      idxDoa_data[i0] = b_idxDoa_data[i0] - 1.0;
    }

    /*  index of processSpectrum and processSpectrumExpand differs 1 point */
    /*  if max is not in the peak list, add max */
    /* 'DoaEstimatorMUSICSignalImplement:59' [~,idxMax] = max(processSpectrum); */
    ixstart = 1;
    temp_re = processSpectrum[0];
    ib = 1;
    if (rtIsNaN(processSpectrum[0])) {
      br = 2;
      exitg1 = false;
      while ((!exitg1) && (br < 122)) {
        ixstart = br;
        if (!rtIsNaN(processSpectrum[br - 1])) {
          temp_re = processSpectrum[br - 1];
          ib = br;
          exitg1 = true;
        } else {
          br++;
        }
      }
    }

    if (ixstart < 121) {
      while (ixstart + 1 < 122) {
        if (processSpectrum[ixstart] > temp_re) {
          temp_re = processSpectrum[ixstart];
          ib = ixstart + 1;
        }

        ixstart++;
      }
    }

    /* 'DoaEstimatorMUSICSignalImplement:59' ~ */
    /* 'DoaEstimatorMUSICSignalImplement:60' if ~sum(idxDoa == idxMax) */
    b_idxDoa_size[0] = 1;
    b_idxDoa_size[1] = idxDoa_size[1];
    br = idxDoa_size[1];
    for (i0 = 0; i0 < br; i0++) {
      c_idxDoa_data[i0] = (idxDoa_data[i0] == ib);
    }

    if (!(c_sum_DoaMusicSignal(c_idxDoa_data, b_idxDoa_size) != 0.0)) {
      /* 'DoaEstimatorMUSICSignalImplement:61' idxDoa = [idxMax, idxDoa]; */
      itmp_data[0] = ib;
      br = idxDoa_size[1];
      for (i0 = 0; i0 < br; i0++) {
        itmp_data[i0 + 1] = idxDoa_data[i0];
      }

      ar = 1 + idxDoa_size[1];
      br = 1 + idxDoa_size[1];
      for (i0 = 0; i0 < br; i0++) {
        idxDoa_data[i0] = itmp_data[i0];
      }
    }
  }

  /* 'DoaEstimatorMUSICSignalImplement:64' doas = AzimuthScanAngles(idxDoa); */
  doas_size[0] = ar;
  for (i0 = 0; i0 < ar; i0++) {
    doas_data[i0] = AzimuthScanAngles[(int)idxDoa_data[i0] - 1];
  }
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void DoaEstimatorMUSICSignalImplement_initialize(void)
{
  rt_InitInfAndNaN(8U);
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void DoaEstimatorMUSICSignalImplement_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for DoaEstimatorMUSICSignalImplement.c
 *
 * [EOF]
 */
